import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { randomUUID } from 'node:crypto';
import { execFile, fork } from 'node:child_process';
import { promisify } from 'node:util';
import { once } from 'node:events';
import { getRedis, closeSharedStore, withLease, storeKey } from '../../src/server/sharedStore';
import { sessionIsActive } from '../../src/server/sessionState';
import { SharedRateLimiter } from '../../src/server/rateLimit';
const address = process.env.TEST_REDIS_URL;
if (!address || !['localhost', '127.0.0.1'].includes(new URL(address).hostname) || new URL(address).pathname !== '/15') throw new Error('Use an isolated local Redis DB 15 via TEST_REDIS_URL; this suite flushes it');
const run = promisify(execFile);
let redis: NonNullable<Awaited<ReturnType<typeof getRedis>>>;
beforeAll(async () => { process.env.REDIS_URL = address; redis = (await getRedis())!; });
beforeEach(async () => { await redis.flushDb(); });
afterAll(async () => { await closeSharedStore(); delete process.env.REDIS_URL; });
const childEnv = () => ({ ...process.env, REDIS_URL: address });
const runClient = (...args: string[]) => run(process.execPath, ['--import', 'tsx', 'tests/fixtures/redis-client.ts', ...args], { env: childEnv() });
describe('real Redis, independent Node processes', () => {
  it('shares an atomic rate bucket across processes', async () => {
    const name = randomUUID();
    const results = await Promise.all([runClient('limit', name), runClient('limit', name)]);
    expect(results.reduce((sum, result) => sum + JSON.parse(result.stdout), 0)).toBe(5);
  });
  it('shares session revocation across process restart boundaries', async () => {
    const session = { sub: 'alice', jti: randomUUID(), authTime: Date.now() - 100, exp: Math.floor(Date.now() / 1000) + 600 };
    expect(await sessionIsActive(session)).toBe(true);
    await runClient('revoke', '-', JSON.stringify(session));
    expect(await sessionIsActive(session)).toBe(false);
  });
  it('excludes a competing lease holder and recovers a crashed worker after lease expiry', async () => {
    const name = randomUUID();
    const child = fork('tests/fixtures/redis-client.ts', ['lease', name], { env: childEnv(), execArgv: ['--import', 'tsx'], stdio: ['ignore', 'ignore', 'pipe', 'ipc'] });
    try {
      expect((await once(child, 'message'))[0]).toBe('held');
      await expect(withLease(name, async () => true)).rejects.toThrow('already in progress');
      child.kill('SIGKILL'); await once(child, 'exit');
      await new Promise(resolve => setTimeout(resolve, 1000));
      expect(await withLease(name, async held => { held(); return 'recovered'; })).toBe('recovered');
    } finally { if (!child.killed) child.kill(); }
  });
  it('detects lease loss and never releases another owner’s lease', async () => {
    const name = randomUUID(), key = storeKey('lock', name);
    await withLease(name, async held => {
      await redis.set(key, 'replacement', { PX: 5000 });
      await new Promise(resolve => setTimeout(resolve, 100));
      expect(held).toThrow('lease lost');
    }, 120);
    expect(await redis.get(key)).toBe('replacement');
  });
  it('fails closed instead of switching to process memory when configured Redis fails', async () => {
    await closeSharedStore(); process.env.REDIS_URL = 'redis://127.0.0.1:1/15';
    try { expect((await new SharedRateLimiter('unavailable', { max: 3, windowMs: 1000 }).consume('a')).reason).toBe('unavailable'); }
    finally { process.env.REDIS_URL = address; redis = (await getRedis())!; }
  });
});
