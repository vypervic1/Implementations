import { assertMutationContext } from './mutationContext';
// =========================================================================
// SERVER-SIDE ORACLE AUTONOMOUS DATABASE (ORDS) ACCESS LAYER
// ------------------------------------------------------------------------
// This module is ONLY imported by server.ts (Node runtime). It is the single
// place that may hold Oracle credentials and read password material.
// Browser code must NEVER import this file.
//
// The client (src/oracleDB.ts) talks exclusively to the /api/oracle/* proxy
// in server.ts; it can no longer reach Oracle directly.
// =========================================================================

import { randomBytes, randomInt, pbkdf2Sync, timingSafeEqual, createHash } from 'crypto';
import { isProduction } from './config';
import { ApiError, OracleError } from './errors';
import { withLease } from './sharedStore';

// Server-to-server Oracle ORDS base URL. Override with ORDS_BASE_URL (e.g.
// point at a staging database or a local mock in tests).
export const ORACLE_ADB_BASE: string =
  process.env.ORDS_BASE_URL ||
  'http://127.0.0.1:9999/ords/unconfigured';

// ---------------------------------------------------------------------------
// ORDS-level credential (C-02). The credential itself is OPTIONAL at import
// time so that tooling (seed script, tests) can run without it, but the
// HTTP server REFUSES to start in production without it (config.ts) and the
// data plane refuses to forward requests when it is missing in production.
// ---------------------------------------------------------------------------
export function getOrdsApiKey(): string | undefined {
  return process.env.ORDS_API_KEY;
}

// ---------------------------------------------------------------------------
// ORDS OAuth2 client-credentials (the CORRECT companion to the deployment
// SQL). oracle_wipe_and_reset.sql creates the `vypervic_app_server` OAuth
// client with a SHORT-LIVED (15 min) access token — a raw client secret is
// NOT a valid Bearer credential. When ORDS_OAUTH_CLIENT_ID /
// ORDS_OAUTH_CLIENT_SECRET are set, the server fetches access tokens from
// `{ORDS_BASE_URL}/oauth/token`, caches them, refreshes before expiry, and
// transparently retries once after a 401 (expired/revoked token).
// A static ORDS_API_KEY is still supported for gateways that accept one.
// ---------------------------------------------------------------------------
export function getOrdsOAuthClient(): { clientId: string; clientSecret: string } | null {
  const clientId = process.env.ORDS_OAUTH_CLIENT_ID;
  const clientSecret = process.env.ORDS_OAUTH_CLIENT_SECRET;
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

/** Fail-closed guard for the data plane: in production every ORDS request
 *  must carry a credential — either a static ORDS_API_KEY or an OAuth2
 *  client-credentials pair. Throws when neither is present. */
export function assertOrdsCredential(): void {
  if (isProduction() && !getOrdsApiKey() && !getOrdsOAuthClient()) {
    throw new Error(
      '[OracleBackend] No ORDS credential configured. In production the Oracle AutoREST ' +
        'service must be authenticated: set ORDS_OAUTH_CLIENT_ID + ORDS_OAUTH_CLIENT_SECRET ' +
        '(recommended — matches the deployment SQL) or ORDS_API_KEY (C-02).'
    );
  }
}

// Token cache (module-level so every request reuses the same access token).
let ordsTokenCache: { token: string; expiresAtMs: number } | null = null;
let ordsTokenFetch: Promise<string> | null = null;

const ORDS_TOKEN_EXPIRY_SAFETY_MS = 60_000; // refresh 60s before actual expiry

/** Test hook: drop the cached ORDS access token. */
export function resetOrdsTokenCacheForTests(): void {
  ordsTokenCache = null;
  ordsTokenFetch = null;
}

function ordsTokenUrl(): string {
  return `${ORACLE_ADB_BASE.replace(/\/+$/, '')}/oauth/token`;
}

async function requestOrdsAccessToken(client: { clientId: string; clientSecret: string }): Promise<string> {
  const basic = Buffer.from(`${client.clientId}:${client.clientSecret}`).toString('base64');
  const res = await fetch(ordsTokenUrl(), {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'application/json',
    },
    body: 'grant_type=client_credentials',
    signal: AbortSignal.timeout(10_000),
    redirect: 'error',
  });
  const text = await readBoundedResponse(res, 64 * 1024);
  let json: any = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!res.ok || !json?.access_token) {
    throw new Error(
      `[OracleBackend] ORDS OAuth token request failed (HTTP ${res.status}). Check ` +
        'ORDS_OAUTH_CLIENT_ID / ORDS_OAUTH_CLIENT_SECRET against the OAuth client ' +
        'created by oracle_wipe_and_reset.sql.'
    );
  }
  // ORDS returns expires_in as a STRING (seconds) — coerce both shapes.
  const expiresInSec = typeof json.expires_in === 'string' ? parseInt(json.expires_in, 10) : Number(json.expires_in);
  const ttlMs = (Number.isFinite(expiresInSec) && expiresInSec > 0 ? expiresInSec : 900) * 1000;
  const token = String(json.access_token);
  ordsTokenCache = { token, expiresAtMs: Date.now() + ttlMs - Math.min(ORDS_TOKEN_EXPIRY_SAFETY_MS, ttlMs / 5) };
  return token;
}

/** Return a cached (unexpired) ORDS access token, fetching/refreshing as
 *  needed. Concurrent callers share one in-flight token request. */
export async function getOrdsAccessToken(): Promise<string> {
  const client = getOrdsOAuthClient();
  if (!client) throw new Error('[OracleBackend] OAuth mode requested but ORDS_OAUTH_* is not configured');
  if (ordsTokenCache && ordsTokenCache.expiresAtMs > Date.now()) return ordsTokenCache.token;
  if (!ordsTokenFetch) {
    ordsTokenFetch = requestOrdsAccessToken(client).finally(() => {
      ordsTokenFetch = null;
    });
  }
  return ordsTokenFetch;
}

// Tables the app is allowed to touch through the BROWSER proxy.
// Server-only tables (user_credentials, password_resets, scheduled_messages)
// are deliberately NOT in this list — the proxy 404s them; only server code
// may reach them.
export const ALLOWED_TABLES = ['profiles', 'messages', 'calls', 'groups'] as const;

export type AllowedTable = (typeof ALLOWED_TABLES)[number];

// ---------------------------------------------------------------------------
// Server-side PBKDF2 (must match the client's legacy parameters EXACTLY:
// PBKDF2-HMAC-SHA256, 100,000 iterations, 16-byte hex salt, 32-byte hex hash)
// ---------------------------------------------------------------------------
export function generateCryptoSalt(): string {
  return randomBytes(16).toString('hex');
}

export function hashPassword(password: string, salt: string): string {
  return pbkdf2Sync(Buffer.from(password, 'utf8'), Buffer.from(salt, 'utf8'), 100000, 32, 'sha256').toString('hex');
}

/**
 * Timing-safe password verification (G-06). Both hashes are converted to
 * buffers and compared with crypto.timingSafeEqual. Malformed stored hashes
 * (wrong charset/length) fail CLOSED instead of throwing.
 */
export function verifyPasswordHash(password: string, salt: string, expectedHexHash: string): boolean {
  try {
    if (typeof password !== 'string' || typeof salt !== 'string' || typeof expectedHexHash !== 'string') return false;
    const saltHex = /^[a-f0-9]+$/i.test(salt) ? salt : '';
    const expected = /^[a-f0-9]+$/i.test(expectedHexHash) ? expectedHexHash : '';
    if (!saltHex || !expected) return false;
    const computedHex = hashPassword(password, saltHex);
    const a = Buffer.from(computedHex, 'hex');
    const b = Buffer.from(expected, 'hex');
    if (a.length === 0 || a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch (e) {
    return false; // fail closed
  }
}

// ---------------------------------------------------------------------------
// Row normalization — mirrors the client's normalizeRow so the server can
// read rows in exactly the shape the rest of the system expects.
// Legacy credentials may still be discovered inside the ABOUT column
// (`[auth:salt:hash]`); NEW credentials are stored in the server-only
// USER_CREDENTIALS table (H-06) and legacy rows are migrated lazily at login.
// ---------------------------------------------------------------------------
const AUTH_TAG_RE = /\[auth:([a-f0-9]+):([a-f0-9]+)\]/i;

export interface ServerProfileRow {
  id: string;
  email?: string | null;
  username?: string | null;
  display_name?: string | null;
  phone_number?: string | null;
  about?: string | null;
  avatar_url?: string | null;
  is_online?: boolean;
  last_seen?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  role?: string | null;
  // Only ever populated server-side. Never sent to browsers.
  password_hash?: string | null;
  password_salt?: string | null;
  password_storage?: 'table' | 'legacy_about' | null;
}

export function normalizeServerRow(row: any, table: string): any {
  if (!row) return row;
  const normalized: Record<string, any> = {};
  for (const key of Object.keys(row)) {
    const lowerKey = key.toLowerCase();
    let val = row[key];

    if (lowerKey === 'is_online' || lowerKey === 'is_voice' || lowerKey === 'is_edited' || lowerKey === 'is_encrypted') {
      val = val === 1 || val === true || val === '1';
    }
    if (
      (lowerKey === 'custom_names' || lowerKey === 'settings' || lowerKey === 'reactions' || lowerKey === 'ice_candidates' || lowerKey === 'members' || lowerKey === 'admins') &&
      typeof val === 'string'
    ) {
      try {
        val = JSON.parse(val);
      } catch (e) {
        /* keep raw string */
      }
    }
    normalized[lowerKey] = val;
  }

  // Legacy credential discovery (server-side only; H-06 migration path)
  if (table === 'profiles' && normalized.about) {
    const authMatch = String(normalized.about).match(AUTH_TAG_RE);
    if (authMatch) {
      normalized.password_salt = authMatch[1];
      normalized.password_hash = authMatch[2];
      normalized.password_storage = 'legacy_about';
    }
  }
  return normalized;
}

// Strip every credential field from a row before it may reach a browser.
export function sanitizeProfileForClient(row: any): any {
  if (!row) return row;
  const out: Record<string, any> = {};
  for (const key of Object.keys(row)) {
    const lowerKey = key.toLowerCase();
    if (!['id', 'email', 'username', 'display_name', 'phone_number', 'about', 'avatar_url', 'cover_url', 'is_online', 'last_seen', 'created_at', 'updated_at', 'role', 'is_admin', 'settings_json'].includes(lowerKey)) continue;
    if (
      lowerKey === 'password_hash' ||
      lowerKey === 'password_salt' ||
      lowerKey === 'passwordhash' ||
      lowerKey === 'passwordsalt' ||
      lowerKey === 'password_storage'
    ) {
      continue;
    }
    let val = row[key];
    // Scrub the packed auth tag out of the ABOUT text as well (defense in
    // depth — new writes no longer put it there, but legacy rows may still
    // carry it until migration).
    if (lowerKey === 'about' && typeof val === 'string') {
      val = val.replace(/\[auth:[^\]]*\]/gi, '').replace(/\s{2,}/g, ' ').trim();
    }
    out[key] = val;
  }
  return out;
}

// ---------------------------------------------------------------------------
// ORDS fetch (server-to-server). Adds the ORDS credential header when
// configured, enforces a timeout, and (in production) refuses to run
// without the credential (C-02).
// ---------------------------------------------------------------------------
export async function readBoundedResponse(res: Response, maxBytes: number): Promise<string> {
  if (Number(res.headers.get('content-length')) > maxBytes) { await res.body?.cancel(); throw new OracleError(502); }
  const reader = res.body?.getReader();
  if (!reader) return '';
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) { await reader.cancel(); throw new OracleError(502); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks).toString('utf8');
}
export function isUniqueViolation(result: { status: number; text: string }): boolean {
  return [400, 409, 500, 555].includes(result.status) && /ORA-00001|unique constraint/i.test(result.text);
}
export async function ordsFetch(
  pathAndQuery: string,
  options: { method?: string; body?: unknown; timeoutMs?: number; skipCredentialGuard?: boolean } = {}
): Promise<{ ok: boolean; status: number; json: any; text: string }> {
  // Even internal callers cannot redirect credentials to a foreign host/path.
  const method = options.method || 'GET';
  const resource = pathAndQuery.split('?')[0].split('/').filter(Boolean);
  const control = ['deletion_jobs', 'audit_logs'].includes(resource[0]) || resource[0] === 'vyper-internal';
  const context = assertMutationContext();
  if (!['GET', 'HEAD'].includes(method) && !control && !context) {
    const { withDataMutation } = await import('./mutationGate');
    return withDataMutation(() => ordsFetch(pathAndQuery, options));
  }
  if (context?.maintenanceId && !control && !['GET', 'HEAD'].includes(method)) {
    return ordsFetch('/vyper-internal/maintenance/dml', { method: 'POST', body: {
      job_id: context.maintenanceId, table_name: resource[0], record_id: decodeURIComponent(resource[1] || ''), method, data: options.body || {},
    }, timeoutMs: options.timeoutMs });
  }
  if (context && !control && !['GET', 'HEAD'].includes(method)) {
    return ordsFetch('/vyper-internal/write', { method: 'POST', body: {
      epoch: context.epoch, table_name: resource[0], record_id: decodeURIComponent(resource[1] || ''), method, data: options.body || {},
    }, timeoutMs: options.timeoutMs });
  }
  assertOrdsCredential();
  if (!/^\/[a-z_-]+(?:\/|\?|$)/i.test(pathAndQuery) || /[\\#\r\n]/.test(pathAndQuery)) throw new Error('Invalid internal ORDS path');
  const base = ORACLE_ADB_BASE.replace(/\/+$/, '');
  const url = new URL(`${base}${pathAndQuery}`);
  if (!url.href.startsWith(`${base}/`)) throw new Error('Invalid ORDS boundary');
  const oauth = !!getOrdsOAuthClient();
  for (let attempt = 0; attempt < 2; attempt++) {
    const accessToken = oauth ? await getOrdsAccessToken() : getOrdsApiKey();
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(url, {
      method: options.method || 'GET', headers, redirect: 'error',
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      // Timeout covers response headers AND the entire streamed body.
      signal: AbortSignal.timeout(options.timeoutMs || 15000),
    });
    if (res.status === 401 && oauth && attempt === 0) {
      await res.body?.cancel();
      if (ordsTokenCache?.token === accessToken) ordsTokenCache = null;
      continue;
    }
    const maxBytes = Math.min(16 * 1024 * 1024, Math.max(4096, Number(process.env.ORDS_MAX_RESPONSE_BYTES) || 16 * 1024 * 1024));
    const text = await readBoundedResponse(res, maxBytes);
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* guarded at each data boundary */ }
    return { ok: res.ok, status: res.status, json, text };
  }
  throw new OracleError(401);
}

export function extractItems(json: any): any[] {
  if (!json) return [];
  if (Array.isArray(json)) return json;
  if (Array.isArray(json.items)) return json.items;
  // Single-object response (ORDS returns a bare object for /table/<id>)
  if (typeof json === 'object') {
    const keys = Object.keys(json);
    if (keys.length > 0 && !('item' in json) && !('items' in json) && !('count' in json) && ('id' in json || 'ID' in json)) {
      return [json];
    }
  }
  return [];
}

function buildQ(filter: Record<string, any>): string {
  return encodeURIComponent(JSON.stringify(filter));
}

/** Case-insensitive key lookup in a parsed q-filter object. */
export function qValueIgnoringCase(filter: Record<string, any> | null, field: string): any {
  if (!filter) return undefined;
  for (const key of Object.keys(filter)) {
    if (key.toLowerCase() === field.toLowerCase()) return filter[key];
  }
  return undefined;
}

// ---------------------------------------------------------------------------
// Profile queries — targeted, exact-match lookups (G-05). The old
// fetchAllProfiles(500)-based duplicate/login checks silently missed every
// profile beyond row 500 and wasted bandwidth. Lookups are now single-row q
// queries; fetchAllProfiles remains ONLY for admin listings with explicit caps.
// ---------------------------------------------------------------------------
export async function fetchProfileByEmail(email: string): Promise<ServerProfileRow | null> {
  const clean = String(email || '').trim().toLowerCase();
  if (!clean) return null;
  const res = await ordsFetch(`/profiles/?q=${buildQ({ EMAIL: clean })}&limit=1`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  return items.length > 0 ? (normalizeServerRow(items[0], 'profiles') as ServerProfileRow) : null;
}

export async function fetchProfileByUsername(username: string): Promise<ServerProfileRow | null> {
  const clean = String(username || '').trim().toLowerCase();
  if (!clean) return null;
  const res = await ordsFetch(`/profiles/?q=${buildQ({ USERNAME: clean })}&limit=1`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  return items.length > 0 ? (normalizeServerRow(items[0], 'profiles') as ServerProfileRow) : null;
}

export function normalizePhoneNumber(value: unknown): string | null {
  const clean = typeof value === 'string' ? value.trim() : '';
  return clean || null;
}
export function isValidPhoneNumber(value: unknown): boolean {
  const clean = normalizePhoneNumber(value);
  return clean === null || clean.replace(/\D/g, '').length >= 7;
}
export async function fetchProfileByPhone(phone: string): Promise<ServerProfileRow | null> {
  const clean = String(phone || '').trim();
  if (!clean) return null;
  const res = await ordsFetch(`/profiles/?q=${buildQ({ PHONE_NUMBER: clean })}&limit=1`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  return items.length > 0 ? (normalizeServerRow(items[0], 'profiles') as ServerProfileRow) : null;
}

export async function fetchAllProfiles(limit = 500): Promise<ServerProfileRow[]> {
  const res = await ordsFetch(`/profiles/?limit=${limit}`);
  if (!res.ok) throw new OracleError(res.status);
  return extractItems(res.json).map((r) => normalizeServerRow(r, 'profiles')) as ServerProfileRow[];
}

export async function fetchProfileById(id: string): Promise<ServerProfileRow | null> {
  return (await fetchRowById('profiles', id)) as ServerProfileRow | null;
}

/**
 * Fetch a single row from any allowed table, normalized to lowercase keys
 * (ORDS returns UPPERCASE). Used for server-side ownership checks.
 */
export async function fetchRowById(table: string, id: string): Promise<any | null> {
  const res = await ordsFetch(`/${table}/${encodeURIComponent(id)}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  if (items.length === 0) return null;
  const row = normalizeServerRow(items[0], table);
  if (typeof row.id !== 'string' || row.id !== id) throw new ApiError(502, 'Database returned an inconsistent resource ID');
  return row;
}

/** General filter query used by server-side authorization checks. */
export async function fetchRowsByFilter(
  table: string,
  filter: Record<string, any>,
  limit = 1000
): Promise<any[]> {
  const { metadataAlias } = await import('./metadata');
  const res = await ordsFetch(`/${metadataAlias(table)}/?q=${buildQ(filter)}&limit=${Math.min(limit, 50)}`);
  if (!res.ok) throw new OracleError(res.status);
  return extractItems(res.json).map((r) => normalizeServerRow(r, table));
}

/** ORDS collection envelope with deterministic ID ordering and no-progress guard. */
export async function fetchAllRows(table: string, filter: Record<string, unknown> = {}, pageSize = 200): Promise<any[]> {
  const out: any[] = [];
  const seen = new Set<string>();
  let offset = 0;
  const maxPages = Math.min(5000, Math.max(1, Number(process.env.ORDS_MAX_PAGES) || 200));
  for (let page = 0; page < maxPages; page++) {
    const q = { ...filter, $orderby: { ID: 'asc' } };
    const { metadataAlias } = await import('./metadata');
    const res = await ordsFetch(`/${metadataAlias(table)}/?q=${buildQ(q)}&limit=${Math.min(pageSize, 50)}&offset=${offset}`);
    if (!res.ok || !res.json || (!Array.isArray(res.json) && !Array.isArray(res.json.items))) throw new OracleError(res.status);
    const rows = extractItems(res.json);
    for (const raw of rows) {
      const row = normalizeServerRow(raw, table);
      if (!row.id || seen.has(row.id)) throw new ApiError(502, 'Database pagination made no progress');
      seen.add(row.id); out.push(row);
    }
    if (res.json.hasMore === false || rows.length === 0 && !res.json.hasMore) return out;
    if (rows.length === 0) throw new ApiError(502, 'Malformed database pagination');
    // ORDS can cap a requested page size. Advance by actual rows, never skip to the requested limit.
    offset += rows.length;
  }
  throw new ApiError(502, 'Database pagination safety limit exceeded');
}

// ---------------------------------------------------------------------------
// USER_CREDENTIALS — server-only authentication table (H-06)
// ------------------------------------------------------------------------
// Password verifiers no longer travel inside the mutable profile ABOUT
// text. They live in a dedicated table that is NOT exposed through the
// browser proxy (not in ALLOWED_TABLES) and never leaves the server.
// Legacy rows whose credentials are still packed into ABOUT are migrated
// lazily after a successful login (migrateLegacyCredentials).
// ---------------------------------------------------------------------------
export interface StoredCredentials {
  user_id: string;
  password_hash: string;
  password_salt: string;
  password_changed_at?: string | null;
}

function credentialRowId(userId: string): string {
  // Deterministic id: one credentials row per user.
  return `cred_${createHash('sha256').update(String(userId)).digest('hex').slice(0, 40)}`;
}

export async function fetchCredentials(userId: string): Promise<StoredCredentials | null> {
  const row = await fetchRowById('user_credentials', credentialRowId(userId));
  if (!row) return null;
  if (row.user_id !== userId || !row.password_hash || !row.password_salt) throw new ApiError(503, 'Invalid credential record');
  return row as StoredCredentials;
}

export async function saveCredentials(userId: string, passwordHash: string, passwordSalt: string): Promise<boolean> {
  const id = credentialRowId(userId);
  const payload = {
    ID: id,
    USER_ID: String(userId),
    PASSWORD_HASH: String(passwordHash),
    PASSWORD_SALT: String(passwordSalt),
    PASSWORD_CHANGED_AT: new Date().toISOString(),
    UPDATED_AT: new Date().toISOString(),
  };
  let res = await ordsFetch(`/user_credentials/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
  if (res.status === 404) {
    res = await ordsFetch(`/user_credentials/`, { method: 'POST', body: payload });
  }
  return res.ok;
}

export async function deleteCredentials(userId: string): Promise<void> {
  const res = await ordsFetch(`/user_credentials/${encodeURIComponent(credentialRowId(userId))}`, { method: 'DELETE' });
  if (!res.ok && res.status !== 404) throw new OracleError(res.status);
}

/**
 * H-06 lazy migration: after a successful legacy (ABOUT-tag) login, copy the
 * verifiers into USER_CREDENTIALS and strip the tag from ABOUT so the
 * credential material stops living in a client-mutable profile field.
 */
export async function migrateLegacyCredentials(profile: ServerProfileRow): Promise<boolean> {
  if (!profile?.id || !profile.password_hash || !profile.password_salt) return false;
  // Migration is insert-only: a concurrent reset must NEVER be overwritten by a legacy verifier.
  if (!(await fetchCredentials(profile.id))) {
    const inserted = await ordsFetch('/user_credentials/', { method: 'POST', body: {
      ID: credentialRowId(profile.id), USER_ID: profile.id, PASSWORD_HASH: profile.password_hash,
      PASSWORD_SALT: profile.password_salt, PASSWORD_CHANGED_AT: new Date().toISOString(), UPDATED_AT: new Date().toISOString(),
    } });
    if (!inserted.ok && !isUniqueViolation(inserted)) return false;
  }

  // Strip the legacy tag from ABOUT (keep the user's text).
  const cleanedAbout = String(profile.about || '')
    .replace(/\[auth:[^\]]*\]/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim() || 'Hey there! I am using VyperVic.';
  const stripped = await ordsFetch(`/profiles/${encodeURIComponent(profile.id)}`, {
    method: 'PATCH', body: { ABOUT: cleanedAbout, PASSWORD_HASH: null, PASSWORD_SALT: null },
  });
  if (!stripped.ok) throw new OracleError(stripped.status);
  profile.about = cleanedAbout;
  profile.password_storage = 'table';
  return true;
}

/**
 * Load the effective credentials for a profile, preferring USER_CREDENTIALS
 * and falling back to the legacy ABOUT tag (read server-side only).
 */
export async function loadCredentialsForProfile(profile: ServerProfileRow): Promise<StoredCredentials | null> {
  const fromTable = await fetchCredentials(profile.id);
  if (fromTable) {
    // Never let a stale legacy verifier overwrite a password reset during login migration.
    profile.password_storage = 'table';
    profile.password_hash = fromTable.password_hash;
    profile.password_salt = fromTable.password_salt;
    return fromTable;
  }
  if (profile.password_hash && profile.password_salt) {
    return {
      user_id: profile.id,
      password_hash: profile.password_hash,
      password_salt: profile.password_salt,
      password_changed_at: null,
    };
  }
  return null;
}

// ---------------------------------------------------------------------------
// PASSWORD_RESETS — single-use, expiring reset tokens (R-01)
// Server-only table (NOT exposed through the browser proxy).
// ---------------------------------------------------------------------------
export const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000; // 1 hour
export const PASSWORD_RESET_CODE_TTL_MS = 10 * 60 * 1000;

function resetTokenRowId(token: string): string {
  return `pwdres_${createHash('sha256').update(String(token)).digest('hex').slice(0, 40)}`;
}

export function generatePasswordResetToken(): string {
  return randomBytes(32).toString('hex');
}

export function generatePasswordResetCode(): string {
  return String(randomInt(100000, 1000000));
}

export async function storePasswordResetToken(
  userId: string,
  token: string,
  purpose: 'reset' | 'verify' = 'reset',
  ttlMs = PASSWORD_RESET_TTL_MS,
): Promise<boolean> {
  const id = resetTokenRowId(token);
  const payload = {
    ID: id,
    USER_ID: String(userId),
    PURPOSE: purpose,
    EXPIRES_AT: new Date(Date.now() + ttlMs).toISOString(),
    USED_AT: null as string | null,
    CREATED_AT: new Date().toISOString(),
  };
  let res = await ordsFetch(`/password_resets/`, { method: 'POST', body: payload });
  if (!res.ok) {
    // Row already exists (token collision is impossible in practice) — retry as PUT
    res = await ordsFetch(`/password_resets/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
  }
  return res.ok;
}

async function consumePasswordResetTokenUnlocked(
  token: string,
  purpose: 'reset' | 'verify' = 'reset'
): Promise<{ userId: string } | null> {
  const id = resetTokenRowId(token);
  let row: any = null;
  try {
    const res = await ordsFetch(`/password_resets/${encodeURIComponent(id)}`);
    if (res.ok) {
      const items = extractItems(res.json);
      if (items.length > 0) row = normalizeServerRow(items[0], 'password_resets');
    }
  } catch (e) {
    return null;
  }
  if (!row || row.used_at) return null;
  if (row.purpose && String(row.purpose) !== purpose) return null;
  const expiresAt = Date.parse(String(row.expires_at || ''));
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return null;
  const userId = row.user_id ? String(row.user_id) : null;
  if (!userId) return null;

  // Mark used BEFORE applying the password change (single-use guarantee
  // prefers failing closed: a replayed token must never work twice).
  const markRes = await ordsFetch(`/password_resets/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: { USED_AT: new Date().toISOString() },
  });
  if (!markRes.ok) return null;
  return { userId };
}

export async function consumePasswordResetToken(token: string, purpose: 'reset' | 'verify' = 'reset'): Promise<{ userId: string } | null> {
  return withLease(`password-reset:${resetTokenRowId(token)}`, () => consumePasswordResetTokenUnlocked(token, purpose));
}

// Same matching semantics as the legacy client login (username / email /
// display name / phone number, with loose phone-digit matching) — but
// resolved with TARGETED single-row lookups (G-05), never a fetch-all.
export function profileMatchesIdentifierRow(p: ServerProfileRow, identifier: string): boolean {
  const cleanInput = identifier.trim();
  if (!cleanInput) return false;
  const cleanSearch = cleanInput.toLowerCase().replace(/^@/, '');
  const cleanDigits = cleanInput.replace(/\D/g, '');

  const u = (p.username || '').toLowerCase();
  const e = (p.email || '').toLowerCase();
  const ph = (p.phone_number || '').trim();
  const phDigits = ph.replace(/\D/g, '');

  if (u && u === cleanSearch) return true;
  if (e && e === cleanInput.toLowerCase()) return true;
  if (ph && ph === cleanInput) return true;
  if (
    cleanDigits &&
    cleanDigits.length >= 7 &&
    phDigits &&
    (phDigits === cleanDigits || phDigits.endsWith(cleanDigits) || cleanDigits.endsWith(phDigits))
  ) {
    return true;
  }
  return false;
}

export async function lookupProfileByIdentifier(identifier: string): Promise<ServerProfileRow | null> {
  const clean = String(identifier || '').trim();
  if (!clean) return null;

  // 1. Exact email
  const byEmail = await fetchProfileByEmail(clean);
  if (byEmail) return byEmail;

  // 2. Exact username (strip leading @)
  if (clean.startsWith('@')) {
    const byUsername = await fetchProfileByUsername(clean.slice(1));
    if (byUsername) return byUsername;
  } else {
    const byUsername = await fetchProfileByUsername(clean);
    if (byUsername) return byUsername;
  }

  // 3. Exact phone, then suffix phone matching (rare path, capped)
  const byPhone = await fetchProfileByPhone(clean);
  if (byPhone && profileMatchesIdentifierRow(byPhone, clean)) return byPhone;

  const cleanDigits = clean.replace(/\D/g, '');
  if (cleanDigits.length >= 7) {
    const candidates = await fetchRowsByFilter('profiles', { PHONE_NUMBER: clean }, 50);
    for (const c of candidates) {
      if (profileMatchesIdentifierRow(c as ServerProfileRow, clean)) return c as ServerProfileRow;
    }
  }
  return null;
}

// Builds the exact payload shape the client's transformProfileForOracle
// produces, so rows written by the server remain compatible with client
// readers. Credential material NEVER goes into ABOUT (H-06); legacy tags in
// incoming data are stripped.
export function transformProfileForOracle(data: any): Record<string, any> {
  const transformed: Record<string, any> = {};
  transformed.ID = String(data.id || data.ID || '');
  if (data.email || data.EMAIL) transformed.EMAIL = String(data.email || data.EMAIL).toLowerCase().trim();
  if (data.username || data.USERNAME) transformed.USERNAME = String(data.username || data.USERNAME).toLowerCase().trim();
  if (data.display_name || data.DISPLAY_NAME) transformed.DISPLAY_NAME = String(data.display_name || data.DISPLAY_NAME).trim();
  transformed.PHONE_NUMBER = data.phone_number ? String(data.phone_number).trim() : null;
  transformed.AVATAR_URL = data.avatar_url || null;
  transformed.COVER_URL = data.cover_url || null;

  const cleanAbout = String(data.about || 'Hey there! I am using VyperVic.')
    .replace(/\[auth:[\s\S]*?\]/g, '')
    .replace(/\s{2,}/g, ' ')
    .trim() || 'Hey there! I am using VyperVic.';
  transformed.ABOUT = cleanAbout;

  transformed.IS_ONLINE = data.is_online || data.IS_ONLINE ? 1 : 0;
  transformed.LAST_SEEN = data.last_seen || data.LAST_SEEN || new Date().toISOString();
  transformed.ROLE = data.role === 'admin' || data.is_admin ? 'admin' : 'user';
  transformed.CREATED_AT = data.created_at || data.CREATED_AT || new Date().toISOString();
  transformed.UPDATED_AT = new Date().toISOString();
  return transformed;
}

export async function upsertProfile(row: Record<string, any>): Promise<boolean> {
  const payload = transformProfileForOracle(row);
  const id = payload.ID;
  let res = await ordsFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
  if (isUniqueViolation(res)) throw new ApiError(409, 'Email or username already exists', 'conflict');
  if (res.status === 404) res = await ordsFetch('/profiles/', { method: 'POST', body: payload });
  if (isUniqueViolation(res)) throw new ApiError(409, 'Email or username already exists', 'conflict');
  return res.ok;
}

// -----------------------------------------------------------------------
// Message / call / group lookups used for authorization decisions
// -----------------------------------------------------------------------
export async function fetchMessagesByFilter(filter: Record<string, any>, limit = 1000): Promise<any[]> {
  return fetchRowsByFilter('messages', filter, limit);
}

export async function fetchCallById(id: string): Promise<any | null> {
  const res = await ordsFetch(`/calls/${encodeURIComponent(id)}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  if (items.length === 0) return null;
  return normalizeServerRow(items[0], 'calls');
}

export async function fetchGroupById(id: string): Promise<any | null> {
  const res = await ordsFetch(`/groups/${encodeURIComponent(id)}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new OracleError(res.status);
  const items = extractItems(res.json);
  if (items.length === 0) return null;
  return normalizeServerRow(items[0], 'groups');
}

export async function fetchGroups(_limit = 500): Promise<any[]> {
  return fetchAllRows('groups');
}

export function groupMembers(g: any): string[] {
  let m = g?.members;
  if (typeof m === 'string') {
    try {
      m = JSON.parse(m);
    } catch (e) {
      m = [];
    }
  }
  return Array.isArray(m) ? m.map((x) => String(x)) : [];
}

/**
 * Authorization: can `senderId` message / push / call `targetId`?
 * Allowed when they share a 1:1 DM (messages exist in chat `dm:A:B` either
 * order) or share a group whose members contain both users.
 * Fails closed: if the relationship cannot be verified, the answer is no.
 */
export async function canInteractWith(senderId: string, targetId: string): Promise<boolean> {
  if (!senderId || !targetId) return false;
  if (senderId === targetId) return true;

  const dmA = `dm:${senderId}:${targetId}`;
  const dmB = `dm:${targetId}:${senderId}`;

  try {
    const msgsFromMe = await fetchMessagesByFilter({ CHAT_ID: dmA }, 1);
    if (msgsFromMe.length > 0) return true;
    const msgsFromThem = await fetchMessagesByFilter({ CHAT_ID: dmB }, 1);
    if (msgsFromThem.length > 0) return true;
  } catch (e) {
    return false; // fail closed
  }

  // Shared group check
  try {
    const groups = await fetchGroups();
    for (const g of groups) {
      const members = groupMembers(g);
      if (members.includes(senderId) && members.includes(targetId)) return true;
    }
  } catch (e) {
    /* fall through */
  }
  return false;
}

// ---------------------------------------------------------------------------
// Batched, awaited table wipe with PAGINATION and honest failure reporting
// (G-04). The old implementation listed the table ONCE with limit=1000 and
// returned — rows beyond the first 1000 silently survived the wipe.
// Now: repeated list/delete passes until the table is empty, with a
// no-progress guard and an absolute safety cap.
// ---------------------------------------------------------------------------
export async function wipeTable(table: string, batchSize = 20): Promise<{ deleted: number; failed: number; passes: number }> {
  const result = await drainRows(table, {}, batchSize, 2000);
  return { deleted: result.deleted, failed: result.failed, passes: result.passes };
}
export async function deleteRowsByFilter(table: string, filter: Record<string, any>, batchSize = 20, maxPasses = 1000) {
  if (Object.keys(filter).length === 0) throw new Error('Scoped deletion requires a filter');
  return drainRows(table, filter, batchSize, maxPasses);
}
async function drainRows(table: string, filter: Record<string, any>, batchSize: number, maxPasses: number) {
  let deleted = 0, total = 0, passes = 0;
  let previous = '';
  while (passes++ < maxPasses) {
    const { metadataAlias } = await import('./metadata');
    const list = await ordsFetch(`/${metadataAlias(table)}/?q=${buildQ({ ...filter, $orderby: { ID: 'asc' } })}&limit=50`);
    if (!list.ok || !list.json || (!Array.isArray(list.json) && !Array.isArray(list.json.items))) return { deleted, failed: 1, total, passes };
    const rows = extractItems(list.json);
    if (!rows.length) return { deleted, failed: list.json.hasMore ? 1 : 0, total, passes };
    const ids = rows.map(r => r.id || r.ID);
    const fingerprint = JSON.stringify(ids);
    if (ids.some(id => typeof id !== 'string' || !id) || fingerprint === previous) return { deleted, failed: 1, total, passes };
    previous = fingerprint;
    total += ids.length;
    let failures = 0;
    for (let i = 0; i < ids.length; i += batchSize) {
      const results = await Promise.allSettled(ids.slice(i, i + batchSize).map(id => ordsFetch(`/${table}/${encodeURIComponent(id)}`, { method: 'DELETE', timeoutMs: 8000 })));
      for (const result of results) {
        if (result.status === 'fulfilled' && (result.value.ok || result.value.status === 404)) deleted++;
        else failures++;
      }
    }
    if (failures) return { deleted, failed: failures, total, passes };
  }
  return { deleted, failed: 1, total, passes };
}
