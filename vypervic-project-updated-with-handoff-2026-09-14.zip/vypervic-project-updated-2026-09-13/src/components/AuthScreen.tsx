import { useState, useEffect, FormEvent } from 'react';
import { oracleDB, PUBLIC_PROFILE_COLUMNS } from '../oracleDB';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, AtSign, Loader2, Eye, EyeOff, Phone, KeyRound, ArrowLeft } from 'lucide-react';
import { Profile } from '../types';

interface AuthScreenProps {
  onAuthComplete: (profile: Profile) => void;
}

export default function AuthScreen({ onAuthComplete }: AuthScreenProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Email confirmation & password reset states
  const [isConfirmationSent, setIsConfirmationSent] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetCompleted, setResetCompleted] = useState(false);
  const [resetEmailSent, setResetEmailSent] = useState(false);
  const [resending, setResending] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);
  const [showResendButton, setShowResendButton] = useState(false);
  const [showQuickSignUpPrompt, setShowQuickSignUpPrompt] = useState(false);

  const handleResetConfirm = async (e: FormEvent) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(resetCode)) {
      setErrorMsg('Enter the six-digit verification code from your email.');
      return;
    }
    if (newPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    try {
      const { error } = await oracleDB.auth.confirmPasswordReset(resetCode, newPassword);
      if (error) throw error;
      setResetCompleted(true);
      setResetEmailSent(false);
      setResetCode('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Could not reset the password. Request a new code and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Please enter your email address to receive a verification code.');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    try {
      // R-01: real server-side reset flow. The server accepts an email OR a
      // username/phone identifier, never reveals whether the account exists,
      // and returns an honest error when email delivery is unavailable.
      const { error } = await oracleDB.auth.resetPasswordForEmail(email.trim());
      if (error) throw error;
      setResetEmailSent(true);
    } catch (err: any) {
      console.error('Password reset error:', err);
      setErrorMsg(err.message || 'Failed to send the verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendConfirmation = async () => {
    if (!email) {
      setErrorMsg('Please enter your email address to resend confirmation.');
      return;
    }
    setResending(true);
    setErrorMsg('');
    setResendSuccess(false);
    try {
      const { error } = await oracleDB.auth.resend({
        type: 'signup',
        email: email.trim(),
      });
      // R-01: an actual error is surfaced instead of a fake success.
      if (error) throw error;
      setResendSuccess(true);
    } catch (err: any) {
      console.error('Error resending confirmation:', err);
      setErrorMsg(err.message || 'Failed to resend confirmation email.');
    } finally {
      setResending(false);
    }
  };

  const handleAuth = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setResendSuccess(false);
    setShowResendButton(false);
    setShowQuickSignUpPrompt(false);
    setLoading(true);

    try {
      if (isSignUp && (!username.trim() || !displayName.trim())) throw new Error('Please fill in all profile fields');
      if (isSignUp && phoneNumber.replace(/\D/g, '').length < 7) throw new Error('A valid phone number is required to create an account.');
      const result = isSignUp
        ? await oracleDB.auth.signUp({ email: email.trim(), password, options: { data: { username: username.trim(), display_name: displayName.trim(), phone_number: phoneNumber.trim() || undefined } } })
        : await oracleDB.auth.signInWithPassword({ email: email.trim(), password });
      if (result.error) throw result.error;
      const profile = result.data.session?.profile;
      if (!profile?.id) throw new Error('The server did not confirm an account profile');
      onAuthComplete(profile);

    } catch (err: any) {
      console.warn('Authentication status notice:', err?.message || err);
      const msg = (err.message || '').toLowerCase();
      const isUnconfirmed = msg.includes('email not confirmed') ||
                            msg.includes('confirm your email') ||
                            msg.includes('verification');
      const isFetchError = msg.includes('failed to fetch') ||
                           msg.includes('networkerror') ||
                           err.name === 'TypeError' && String(err).toLowerCase().includes('fetch');
      const isInvalidCredentials = msg.includes('invalid login credentials') ||
                                   msg.includes('invalid credentials') ||
                                   msg.includes('user not found') ||
                                   msg.includes('does not exist') ||
                                   msg.includes('invalid grant');

      if (isUnconfirmed) {
        setErrorMsg('Your email has not been confirmed yet. A confirmation email was sent to your address. Please click the link inside it to activate your account, or click the button below to resend the activation link.');
        setShowResendButton(true);
      } else if (isFetchError) {
        setErrorMsg('Unable to connect to the server. Please check your internet connection or try again in a moment.');
        setShowResendButton(false);
      } else if (isInvalidCredentials) {
        setErrorMsg('No registered account was found with those details. Tap below to create your account.');
        setShowQuickSignUpPrompt(true);
        setShowResendButton(false);
      } else {
        setErrorMsg(err.message || 'An error occurred during authentication.');
        setShowResendButton(false);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="absolute inset-0 flex flex-col justify-between bg-[#080b10] px-6 py-10 overflow-hidden select-none">
      {/* Background gradients */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_15%,rgba(124,92,255,0.22),transparent_45%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_85%,rgba(32,227,162,0.1),transparent_50%)] pointer-events-none" />

      {/* Header / Logo */}
      <div className="flex flex-col items-center mt-8 relative z-10">
        <div className="relative w-16 h-16 flex items-center justify-center mb-3">
          <div className="absolute inset-[-10px] rounded-full bg-[radial-gradient(circle,rgba(32,227,162,0.25),transparent_65%)] blur-[6px]" />
          <svg width="60" height="60" viewBox="0 0 150 150" fill="none">
            <defs>
              <linearGradient id="authLogoGrad" x1="0" y1="0" x2="150" y2="150" gradientUnits="userSpaceOnUse">
                <stop stopColor="#20e3a2" />
                <stop offset="1" stopColor="#7c5cff" />
              </linearGradient>
            </defs>
            <path
              d="M30 40 C30 20, 60 15, 75 35 C95 60, 60 65, 55 80 C50 95, 85 100, 90 75 C93 60, 75 55, 70 65 C65 75, 80 85, 100 78 C118 71, 118 45, 100 35 C85 27, 75 45, 85 55"
              stroke="url(#authLogoGrad)"
              strokeWidth="9"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <h1 className="font-display text-2xl font-black text-white tracking-wide">
          Vyper<span className="bg-gradient-to-r from-[#20e3a2] to-[#7c5cff] bg-clip-text text-transparent">Vic</span>
        </h1>
        <p className="text-xs text-[#8d97ab] font-medium tracking-wide mt-1">
          {isResetMode
            ? 'Reset your account access'
            : isSignUp
            ? 'Create your account'
            : 'Enter the chat dimension'}
        </p>
      </div>

      {/* Form Area */}
      <div className="flex-1 flex flex-col justify-center my-6 relative z-10">
        <AnimatePresence mode="wait">
          {isConfirmationSent ? (
            <motion.div
              key="confirmation-sent"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.25 }}
              className="space-y-6 text-center"
            >
              <div className="mx-auto w-16 h-16 rounded-full bg-[#20e3a2]/10 border border-[#20e3a2]/20 flex items-center justify-center text-[#20e3a2] mb-2 shadow-[0_0_15px_rgba(32,227,162,0.1)]">
                <Mail className="w-8 h-8 animate-pulse" />
              </div>
              <div className="space-y-2">
                <h2 className="text-lg font-bold text-white">Check Your Inbox</h2>
                <p className="text-xs text-[#8d97ab] leading-relaxed max-w-sm mx-auto">
                  A verification link has been dispatched to <span className="text-[#20e3a2] font-mono font-semibold">{email}</span>. Please authorize this link to confirm your portal identity before connecting.
                </p>
              </div>

              {resendSuccess ? (
                <div className="text-xs text-[#20e3a2] font-semibold bg-[#20e3a2]/10 border border-[#20e3a2]/20 rounded-xl p-3 leading-relaxed animate-pulse">
                  Verification email resent successfully! Check your inbox.
                </div>
              ) : errorMsg ? (
                <div className="text-xs text-[#ff5470] font-semibold bg-[#ff5470]/10 border border-[#ff5470]/20 rounded-xl p-3 leading-relaxed">
                  {errorMsg}
                </div>
              ) : null}

              <div className="flex flex-col gap-3">
                <button
                  type="button"
                  onClick={handleResendConfirmation}
                  disabled={resending}
                  className="w-full relative py-3.5 rounded-2xl font-bold text-xs tracking-wider text-[#20e3a2] border border-[#20e3a2]/30 bg-[#20e3a2]/5 hover:bg-[#20e3a2]/10 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {resending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Resending Link...</span>
                    </>
                  ) : (
                    <span>RESEND VERIFICATION EMAIL</span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsConfirmationSent(false);
                    setIsSignUp(false);
                    setErrorMsg('');
                    setResendSuccess(false);
                  }}
                  className="text-xs font-semibold text-[#8d97ab] hover:text-[#eef1f6] transition-colors cursor-pointer py-2"
                >
                  Back to Sign In
                </button>
              </div>
            </motion.div>
          ) : resetEmailSent ? (
            <form onSubmit={handleResetConfirm} className="space-y-4">
              <div className="text-center space-y-2 mb-2">
                <KeyRound className="w-10 h-10 text-[#7c5cff] mx-auto" />
                <h2 className="text-lg font-extrabold text-[#eef1f6]">Enter your recovery code</h2>
                <p className="text-xs text-[#8b93a7] font-medium">
                  Enter the six-digit code sent to your email, then choose a new password.
                </p>
              </div>
              <div className="space-y-3">
                <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                  <KeyRound className="w-5 h-5 text-[#5a6478] mr-3" />
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]{6}"
                    maxLength={6}
                    placeholder="Six-digit verification code"
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold tracking-[0.35em] placeholder-[#5a6478] placeholder:tracking-normal"
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    required
                  />
                </div>
                <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                  <Lock className="w-5 h-5 text-[#5a6478] mr-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="New password (min 6 characters)"
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                  <Lock className="w-5 h-5 text-[#5a6478] mr-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Confirm new password"
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="ml-2 text-[#5a6478] hover:text-[#8b93a7]"
                    aria-label={showPassword ? 'Hide passwords' : 'Show passwords'}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {errorMsg && (
                <p className="text-xs text-[#ff5470] font-semibold bg-[#ff5470]/10 border border-[#ff5470]/20 rounded-xl p-3 text-center leading-relaxed">
                  {errorMsg}
                </p>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full relative py-4 rounded-2xl font-bold text-sm tracking-wider text-black bg-gradient-to-r from-[#20e3a2] to-[#7c5cff] hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    <span>Updating...</span>
                  </>
                ) : (
                  <span>UPDATE PASSWORD</span>
                )}
              </button>
            </form>
          ) : resetCompleted ? (
            <div className="space-y-4 text-center">
              <div className="text-xs text-[#20e3a2] font-bold bg-[#20e3a2]/10 border border-[#20e3a2]/20 rounded-xl p-3 leading-relaxed">
                Password updated! You can now sign in with your new password.
              </div>
              <button
                type="button"
                onClick={() => {
                  setResetCompleted(false);
                  setErrorMsg('');
                }}
                className="w-full py-3 rounded-2xl font-bold text-xs tracking-wider text-black bg-[#20e3a2] hover:opacity-90 transition-all cursor-pointer"
              >
                RETURN TO SIGN IN
              </button>
            </div>
          ) : isResetMode ? (
            <motion.form
              key="reset-mode"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.25 }}
              onSubmit={handlePasswordReset}
              className="space-y-4"
            >
              <div className="text-center space-y-1 mb-2">
                <div className="mx-auto w-12 h-12 rounded-full bg-[#7c5cff]/10 border border-[#7c5cff]/20 flex items-center justify-center text-[#7c5cff] mb-2">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-white">Reset Account Password</h3>
                <p className="text-xs text-[#8d97ab]">Enter your email or username to receive a six-digit verification code.</p>
              </div>

              {resetEmailSent ? (
                <div className="space-y-4 text-center">
                  <div className="text-xs text-[#20e3a2] font-semibold bg-[#20e3a2]/10 border border-[#20e3a2]/20 rounded-xl p-3 leading-relaxed">
                    Verification code sent! Check your inbox, then enter the code to choose a new password.
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(false);
                      setResetEmailSent(false);
                      setErrorMsg('');
                    }}
                    className="w-full py-3 rounded-2xl font-bold text-xs tracking-wider text-black bg-[#20e3a2] hover:opacity-90 transition-all cursor-pointer"
                  >
                    RETURN TO SIGN IN
                  </button>
                </div>
              ) : (
                <>
                  <div className="space-y-1">
                    <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                      <Mail className="w-5 h-5 text-[#5a6478] mr-3" />
                      <input
                        type="text"
                        placeholder="Email address or username"
                        className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {errorMsg && (
                    <p className="text-xs text-[#ff5470] font-semibold bg-[#ff5470]/10 border border-[#ff5470]/20 rounded-xl p-3 text-center leading-relaxed">
                      {errorMsg}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full relative py-4 rounded-2xl font-bold text-sm tracking-wider text-black bg-gradient-to-r from-[#20e3a2] to-[#7c5cff] hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2 shadow-[0_12px_24px_-8px_rgba(32,227,162,0.45)]"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-black" />
                        <span>Sending Code...</span>
                      </>
                    ) : (
                      <span>SEND VERIFICATION CODE</span>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(false);
                      setErrorMsg('');
                    }}
                    className="w-full text-xs font-semibold text-[#8d97ab] hover:text-[#eef1f6] cursor-pointer py-1 flex items-center justify-center gap-1.5"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Sign In</span>
                  </button>
                </>
              )}
            </motion.form>
          ) : (
            <motion.form
              key={isSignUp ? 'signup' : 'signin'}
              initial={{ opacity: 0, x: isSignUp ? 25 : -25 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isSignUp ? -25 : 25 }}
              transition={{ duration: 0.25 }}
              onSubmit={handleAuth}
              className="space-y-4"
            >
              {isSignUp && (
                <>
                  {/* Display Name Input */}
                  <div className="space-y-1">
                    <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                      <User className="w-5 h-5 text-[#5a6478] mr-3" />
                      <input
                        type="text"
                        placeholder="Display Name"
                        className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Username Input */}
                  <div className="space-y-1">
                    <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                      <AtSign className="w-5 h-5 text-[#5a6478] mr-3" />
                      <input
                        type="text"
                        placeholder="username"
                        className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478] font-mono"
                        value={username}
                        onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                        required
                      />
                    </div>
                  </div>

                  {/* Phone Number Input */}
                  <div className="space-y-1">
                    <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                      <Phone className="w-5 h-5 text-[#5a6478] mr-3" />
                      <input
                        type="tel"
                        placeholder="Phone Number (e.g. +1234567890)"
                        className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Email / Identifier Input */}
              <div className="space-y-1">
                <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                  <Mail className="w-5 h-5 text-[#5a6478] mr-3" />
                  <input
                    type={isSignUp ? 'email' : 'text'}
                    placeholder={isSignUp ? 'Email Address' : 'Email, username, or phone'}
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Password Input */}
              <div className="space-y-1">
                <div className="relative flex items-center bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3.5 focus-within:border-[#7c5cff] transition-colors">
                  <Lock className="w-5 h-5 text-[#5a6478] mr-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Password"
                    className="flex-1 bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-1 text-[#5a6478] hover:text-[#8d97ab] cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                  </button>
                </div>
                {!isSignUp && (
                  <div className="flex justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setIsResetMode(true);
                        setErrorMsg('');
                      }}
                      className="text-[11px] font-semibold text-[#8d97ab] hover:text-[#20e3a2] cursor-pointer transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>
                )}
              </div>

              {/* Error Message, Quick Sign-Up & Resend Option */}
              {errorMsg && (
                <div className="space-y-2">
                  <p className="text-xs text-[#ff5470] font-semibold bg-[#ff5470]/10 border border-[#ff5470]/20 rounded-xl p-3 text-center leading-relaxed">
                    {errorMsg}
                  </p>

                  {showQuickSignUpPrompt && !isSignUp && (
                    <button
                      type="button"
                      onClick={() => {
                        const cleanInput = (email || '').trim();
                        if (cleanInput) {
                          const base = cleanInput.includes('@') ? cleanInput.split('@')[0] : cleanInput;
                          if (!username) setUsername(base.toLowerCase().replace(/[^a-z0-9_]/g, ''));
                          if (!displayName) setDisplayName(base);
                        }
                        setIsSignUp(true);
                        setErrorMsg('');
                        setShowQuickSignUpPrompt(false);
                      }}
                      className="w-full py-2.5 rounded-xl font-bold text-xs tracking-wider text-[#20e3a2] border border-[#20e3a2]/30 bg-[#20e3a2]/10 hover:bg-[#20e3a2]/20 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>New here? Tap to Create Account</span>
                    </button>
                  )}

                  {showResendButton && (
                    <button
                      type="button"
                      onClick={handleResendConfirmation}
                      disabled={resending}
                      className="w-full relative py-3 rounded-2xl font-bold text-xs tracking-wider text-[#20e3a2] border border-[#20e3a2]/20 bg-[#20e3a2]/5 hover:bg-[#20e3a2]/10 transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      {resending ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Resending Link...</span>
                        </>
                      ) : resendSuccess ? (
                        <span>SENT! CHECK YOUR INBOX</span>
                      ) : (
                        <span>RESEND CONFIRMATION LINK</span>
                      )}
                    </button>
                  )}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full relative py-4 rounded-2xl font-bold text-sm tracking-wider text-black bg-gradient-to-r from-[#20e3a2] to-[#7c5cff] hover:opacity-90 active:scale-[0.98] transition-all cursor-pointer overflow-hidden flex items-center justify-center gap-2 shadow-[0_12px_24px_-8px_rgba(32,227,162,0.45)]"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                    <span>Configuring channel...</span>
                  </>
                ) : (
                  <span>{isSignUp ? 'REGISTER & JOIN' : 'SIGN IN TO PORTAL'}</span>
                )}
              </button>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      {/* Auth Toggle footer */}
      <div className="text-center relative z-10 mb-2 space-y-3">
        <button
          onClick={() => {
            const nextIsSignUp = !isSignUp;
            if (nextIsSignUp) {
              const cleanInput = (email || '').trim();
              if (cleanInput) {
                const base = cleanInput.includes('@') ? cleanInput.split('@')[0] : cleanInput;
                if (!username) setUsername(base.toLowerCase().replace(/[^a-z0-9_]/g, ''));
                if (!displayName) setDisplayName(base);
              }
            }
            setIsSignUp(nextIsSignUp);
            setIsResetMode(false);
            setErrorMsg('');
            setResendSuccess(false);
            setShowResendButton(false);
            setShowQuickSignUpPrompt(false);
            setIsConfirmationSent(false);
          }}
          className="text-xs font-semibold text-[#8d97ab] hover:text-[#eef1f6] cursor-pointer transition-colors"
        >
          {isSignUp ? (
            <span>
              Already have an account?{' '}
              <span className="text-[#20e3a2] underline underline-offset-4 decoration-1 font-bold">
                Connect identity
              </span>
            </span>
          ) : (
            <span>
              New to VyperVic?{' '}
              <span className="text-[#7c5cff] underline underline-offset-4 decoration-1 font-bold">
                Create new profile
              </span>
            </span>
          )}
        </button>

        <div className="pt-2 border-t border-[#1b2332]/50">
          <button
            type="button"
            onClick={async () => {
              if (window.confirm('Wipe all local cached accounts and purge database storage to start completely fresh?')) {
                try {
                  const res = await oracleDB.wipeAllSystemData();
                  if (res.success) {
                    alert('All accounts and cached messages have been wiped. You can now create a fresh account.');
                    window.location.reload();
                  } else {
                    // Honest result (High-severity fix): do NOT claim success
                    alert(res.failedCount
                      ? `Wipe finished but ${res.failedCount} row deletion(s) failed: ${res.error || ''}`
                      : (res.error || 'Wipe failed. No data was wiped.'));
                  }
                } catch (e) {
                  alert('Reset failed. Please try again.');
                }
              }
            }}
            className="text-[11px] text-[#ff5470]/70 hover:text-[#ff5470] cursor-pointer transition-colors"
          >
            Clear all cached accounts & reset app
          </button>
        </div>
      </div>
    </div>
  );
}
