# VPS deployment (Azure/Ubuntu or equivalent)

**This repository is not production-accepted.** Start with `docs/SECURITY-INCIDENT.md` and the acceptance checklist. The setup script no longer accepts service-account files/credentials in arguments, emits deployment fixtures, silently rotates JWT secrets, or modifies a DNS provider using a token-bearing URL.

## Architecture

Android WebView → the canonical **VPS HTTPS origin** → Caddy → Node on loopback → authenticated Oracle ORDS, private Redis, and one Firebase project. Browser fetch/EventSource URLs remain same-origin. There is no local-asset API-origin/CORS workaround.

Oracle is authoritative for profiles, messages, group membership, calls, push registrations, schedules and deletion jobs. Firebase is a scoped signaling/delivery projection. Redis provides shared limits, session revocation, pub/sub and leases. Configured production storage failures are errors, never memory/fabricated-account success.

## Prerequisites and migration order

1. Rotate/revoke exposed secrets and clean history. Review/commit a clean candidate; the script archives a specific clean commit and refuses shallow history/uncommitted changes. Native configuration/signing files stay outside Git.
2. Use a dedicated environment/schema/project and encrypted, restore-tested backups. **Do not run `oracle_wipe_and_reset.sql`**; it is now deliberately guarded against execution.
3. On a fresh schema, run `deploy/migrations/000_create_tables.sql`. Then run `001_additive_hardening.sql`, `002_protect_ords.sql`, and **`003_write_fence_delivery_and_metadata.sql`**. Existing schemas start at 001 after auditing base-table compatibility. Migration 003 requires DBMS_LOCK privileges, installs epoch-fenced writes, metadata views and atomic delivery intents; see docs/REMAINING-FIXES-PASS.md. Do not run old and new app versions concurrently. DDL is not globally transactional: stop on an error and complete/repair the migration before deployment.
   - Resolve duplicate normalized usernames/emails first; the migration does not guess a winner.
   - New columns include profile cover, push source/device/revocation **and session binding**, scheduled retry time; `DELETION_JOBS` holds checkpoints.
   - Legacy push registrations are revoked, not relabeled as genuine Android/browser FCM.
   - Grant the server's ORDS OAuth client the appropriate protected AutoREST roles for every required object, including deletion jobs. Verify direct **anonymous 401** and authenticated CRUD using the real ORDS version. The DDL does not prove the grant works.
4. Run `npm run migrate:credentials` for a count-only dry run and `npm run migrate:credentials -- --apply` after backup. It copies verifiers insert-only to the server-only table and scrubs profile columns/`[auth:...]` tags. It must not overwrite a newer reset password. Consider forced password resets for historically exposed verifiers.
5. Deploy `firestore.rules` and `firestore.indexes.json` to the **explicit project and intended database**. For a named database, use a Firebase CLI configuration that includes that database; do not accidentally deploy only `(default)`. Wait for indexes to finish. Deploy the TTL policies. Delivery-copy cleanup is namespace-scoped by the worker rather than enabling a project-wide TTL on all collections named `messages`.
6. Provision private, authenticated Redis with persistence/backup. Do not expose port 6379. All app instances must share the same store, revocation namespace, signing secret and Oracle/Firebase environment. A Redis data-loss event can invalidate revocation history: rotate/invalidate sessions as part of recovery.
7. Provision private coturn or a managed equivalent using short-lived credentials. Set `TURN_URLS` for UDP, TCP and TLS and a matching `TURN_SHARED_SECRET`. There are no public shared TURN credentials. Test TLS certificate/realm, relay ports, anti-open-relay configuration and separate mobile networks. Keep app-VPS and TURN firewall requirements distinct.
8. Verify the real email sender/domain/provider. Account recovery fails honestly when mail is unavailable; test actual receipt, expiry and single-use behavior.

## Runtime configuration and activation

Copy `.env.example` to a protected runtime file. Fill **one** ORDS auth mode, Redis, canonical Firebase public/private fields, mail and TURN. Keep `NODE_ENV=production` in deployment. Ordinary shared VPS web/native builds use `VITE_RUNTIME_MODE=browser`; native capability detection disables Web Push inside Android. `VITE_RUNTIME_MODE=native-android` is available for an exclusively native origin.

Do not use the `build:ci` output in staging/production. It is a structurally testable demo build that production refuses.

```sh
npm ci
npm run check:config           # with production runtime variables securely injected
npm run build                 # requires explicit public Firebase configuration
npm run check:bundle
# After reviewing a clean commit, on the VPS with Node/npm/Caddy/systemd installed:
sudo bash deploy/setup.sh --app-dir /path/to/reviewed/checkout --env-file /secure/runtime.env \
  --admin-cidrs 'YOUR_APPROVED_CIDR'
```

The script builds a versioned release, validates before switching a symlink, installs the service and an independent edge-cleanup timer, and checks `/api/ready`. It writes a Caddy include instead of replacing a shared Caddyfile. Add `import /etc/caddy/sites.d/*.caddy` to your reviewed Caddy configuration. Admin routes are loopback-only by default unless approved CIDRs are supplied.

Externally expose HTTPS only on the app host; restrict SSH to approved admin networks. Keep Node/Redis private. Caddy uses TLS-ALPN issuance; review HTTP redirect listeners/firewall rules, DNS/ACME access and any additional proxy trust settings. `TRUST_PROXY=loopback` assumes Caddy is the sole immediate proxy; do not trust arbitrary forwarded IP headers.

## Health, recovery and rollback

- `/api/health` is liveness; `/api/ready` probes shared store/required ORDS objects, direct ORDS anonymous denial, build/runtime Firebase agreement, a real Firestore write/read/delete and worker freshness. This is not a substitute for functional staging acceptance.
- Monitor worker timestamps/failures, queued/failed/expired records, deletion job attempts/partial states, Redis availability, OAuth refresh failures, rate-limit errors and FCM result counts. Alert on repeated 503 readiness, dead letters or a cleanup backlog. Install these alerts in the operational monitoring system; repository code does not deploy a monitoring provider.
- The independent `vyper-edge-cleanup.timer` bounds retention without user activity. Native Firestore TTL is a backup, not an immediate deletion guarantee.
- Deletion/wipe jobs retain operation IDs, checkpoints, counts and audit rows. A connection error does **not** cancel a durable job. Inspect/retry its operation; never infer completion from logout/401. After an all-account wipe, an authorized operator must bootstrap a new admin out of band to inspect protected job APIs.
- **Cross-store workflows are resumable, not globally atomic.** The new admission/database/Firebase epoch fences drain or reject in-flight/obsolete writes. The modeled concurrency tests pass, but the actual Oracle package/triggers and cross-store failure cases still require staging acceptance.
- Roll back code using the previous release only when schema/config compatibility is established. Do not restore a compromised key or a backup that silently resurrects revoked sessions/tokens. Backups, firewall state, IAM and alert delivery must be verified outside this sandbox.
