// Notification transport facade. Firebase JS Messaging is never imported by native registration.
import { capabilities } from './capabilities';
import { nativeRequest, type NativePushToken } from './nativeBridge';
export { VAPID_KEY } from './firebaseConfig';

function browserDeviceId(): string {
  let id = localStorage.getItem('vyper_push_device_id');
  if (!id) { id = crypto.randomUUID(); localStorage.setItem('vyper_push_device_id', id); }
  return id;
}
export async function registerForPushNotifications(_userId?: string): Promise<string | null> {
  const caps = capabilities();
  if (caps.mode !== 'browser') {
    if (!caps.nativePush) throw new Error('Native FCM is unavailable in this WebView; browser push is disabled');
    const registration = await nativeRequest<NativePushToken>('getPushToken');
    if (!registration || registration.source !== 'android_native' || registration.deviceType !== 'android' || typeof registration.token !== 'string' || registration.token.length < 100) {
      throw new Error('Android did not provide a valid FCM token');
    }
    await saveTokenToBackend('', registration.token, 'android', registration.deviceId);
    await nativeRequest('flushCookies');
    return registration.token;
  }
  if (!caps.webPush) throw new Error('Web Push is unavailable on this origin');
  const token = await (await import('./webPush')).acquireWebFcmToken();
  if (!token) throw new Error('No browser FCM token was obtained');
  await saveTokenToBackend('', token, 'web', browserDeviceId());
  return token;
}
export async function saveTokenToBackend(_userId: string, token: string, deviceType = 'web', deviceId?: string): Promise<void> {
  const android = deviceType === 'android' || deviceType === 'android_native';
  const response = await fetch('/api/push/register-token', {
    method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, deviceType: android ? 'android' : 'web', source: android ? 'android_native' : 'web_fcm', deviceId,
      deviceName: android ? 'Vyper Android' : 'Web browser' }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.success !== true) throw new Error(data.error || 'The server did not persist the push token');
  if (deviceId) localStorage.setItem('vyper_push_device_id', deviceId);
}
export function listenForForegroundPush(onPush: (payload: any) => void): () => void {
  let disposed = false;
  let unsubscribe: (() => void) | undefined;
  if (capabilities().mode === 'browser') {
    void import('./webPush').then(mod => mod.listen(onPush)).then(fn => { if (disposed) fn?.(); else unsubscribe = fn; })
      .catch(() => console.warn('[Push] Foreground Web Push is unavailable'));
  } else {
    const listener = (event: Event) => onPush((event as CustomEvent).detail);
    window.addEventListener('vyper_native_push', listener);
    unsubscribe = () => window.removeEventListener('vyper_native_push', listener);
  }
  return () => { disposed = true; unsubscribe?.(); };
}
export async function sendFcmPushNotification(params: { targetUserId?: string; targetUserIds?: string[]; title: string; body: string; chatId?: string; senderId?: string; senderName?: string; type?: 'message' | 'call' | 'mention'; callId?: string; avatarUrl?: string }): Promise<boolean> {
  const res = await fetch('/api/push/send', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) });
  const data = await res.json();
  return res.ok && data.success === true;
}
