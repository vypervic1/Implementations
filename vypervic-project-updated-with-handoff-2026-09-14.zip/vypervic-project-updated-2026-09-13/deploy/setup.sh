#!/usr/bin/env bash
# Prerequisites: Node 22, npm, Caddy, systemd, private Redis, migrated/authenticated ORDS,
# deployed Firebase rules/indexes, rotated runtime secrets, DNS pointing at this VPS.
# This script neither accepts credentials in arguments nor creates deployment fixtures.
set -euo pipefail
APP_DIR="" ENV_FILE="" APP_USER="vyper" ADMIN_CIDRS="127.0.0.1/32 ::1/128"
while (($#)); do
  case "$1" in
    --app-dir) APP_DIR="$2"; shift 2;;
    --env-file) ENV_FILE="$2"; shift 2;;
    --app-user) APP_USER="$2"; shift 2;;
    --admin-cidrs) ADMIN_CIDRS="$2"; shift 2;;
    *) echo 'Use --app-dir PATH --env-file PATH [--app-user USER] [--admin-cidrs "CIDR ..."]'; exit 1;;
  esac
done
[[ $EUID -eq 0 && -d "$APP_DIR/.git" && -f "$ENV_FILE" ]] || { echo 'Run as root with an existing reviewed checkout and runtime environment file'; exit 1; }
[[ "$APP_USER" =~ ^[a-z_][a-z0-9_-]*$ ]] || exit 1
[[ "$ADMIN_CIDRS" =~ ^[a-fA-F0-9.:/\ ]+$ ]] || { echo 'Invalid admin CIDR list'; exit 1; }
for program in node npm caddy systemctl git python3 curl; do command -v "$program" >/dev/null; done
[[ $(node -p 'Number(process.versions.node.split(".")[0])') -ge 22 ]] || { echo 'Node 22+ required'; exit 1; }
APP_DIR=$(realpath "$APP_DIR"); ENV_FILE=$(realpath "$ENV_FILE")
# Archive a clean, reviewed commit, not an ambiguous working directory or archived credential file.
[[ -z $(git -C "$APP_DIR" status --porcelain) ]] || { echo 'Review and commit the checkout before deployment'; exit 1; }
(cd "$APP_DIR" && python3 scripts/scan-private-material.py --history)
[[ $(git -C "$APP_DIR" rev-parse --is-shallow-repository) == false ]] || { echo 'Fetch full history for the release secret scan'; exit 1; }
id "$APP_USER" >/dev/null 2>&1 || useradd --system --create-home --home-dir /var/lib/vyper --shell /usr/sbin/nologin "$APP_USER"
install -d -m 750 -o "$APP_USER" -g "$APP_USER" /etc/vyper /var/lib/vyper/releases
install -m 600 -o "$APP_USER" -g "$APP_USER" "$ENV_FILE" /etc/vyper/runtime.env
RELEASE="/var/lib/vyper/releases/$(date -u +%Y%m%dT%H%M%SZ)-$(git -C "$APP_DIR" rev-parse --short HEAD)"
install -d -m 750 -o "$APP_USER" -g "$APP_USER" "$RELEASE"
git -C "$APP_DIR" archive HEAD | tar -x -C "$RELEASE"
chown -R "$APP_USER:$APP_USER" "$RELEASE"
runuser -u "$APP_USER" -- env NODE_ENV=production DOTENV_CONFIG_PATH=/etc/vyper/runtime.env bash -c '
  set -e; cd "$1"; npm ci --include=dev --no-fund; npm run check:config; npm run build; npm run check:bundle; npm prune --omit=dev --no-fund
' _ "$RELEASE"
DOMAIN=$(cd "$RELEASE" && DOTENV_CONFIG_PATH=/etc/vyper/runtime.env node --input-type=module -e '
  import {config} from "dotenv"; config({quiet:true}); const u=new URL(process.env.APP_URL);
  if (u.protocol!=="https:" || u.pathname!=="/" || u.search || u.hash || u.username || u.port && u.port!=="443" || !/^[a-z0-9.-]+$/.test(u.hostname)) process.exit(1);
  console.log(u.hostname);')
cat > /etc/systemd/system/vyper.service <<UNIT
[Unit]
Description=Vyper chat API and durable workers
After=network-online.target
Wants=network-online.target
[Service]
User=$APP_USER
Group=$APP_USER
WorkingDirectory=/var/lib/vyper/current
Environment=NODE_ENV=production
Environment=DOTENV_CONFIG_PATH=/etc/vyper/runtime.env
Environment=HOST=127.0.0.1
Environment=PORT=3000
Environment=TRUST_PROXY=loopback
ExecStart=$(command -v node) /var/lib/vyper/current/dist/server.cjs
Restart=on-failure
RestartSec=5
TimeoutStopSec=45
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
UMask=0077
[Install]
WantedBy=multi-user.target
UNIT
cat > /etc/systemd/system/vyper-edge-cleanup.service <<UNIT
[Unit]
Description=Vyper independent edge retention cleanup
After=network-online.target
[Service]
Type=oneshot
User=$APP_USER
Group=$APP_USER
WorkingDirectory=/var/lib/vyper/current
Environment=NODE_ENV=production
Environment=DOTENV_CONFIG_PATH=/etc/vyper/runtime.env
ExecStart=$(command -v node) /var/lib/vyper/current/dist/edge-cleanup.cjs
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
TimeoutStartSec=120
UNIT
cat > /etc/systemd/system/vyper-edge-cleanup.timer <<'UNIT'
[Unit]
Description=Run Vyper retention cleanup without client activity
[Timer]
OnBootSec=90s
OnUnitActiveSec=60s
Persistent=true
[Install]
WantedBy=timers.target
UNIT
# Does not overwrite a shared Caddyfile. Operator must include this directory explicitly.
install -d -m 755 /etc/caddy/sites.d
cat > "/etc/caddy/sites.d/vyper.caddy" <<CADDY
https://$DOMAIN {
  tls {
    issuer acme {
      disable_http_challenge
    }
  }
  header {
    Strict-Transport-Security "max-age=31536000"
    X-Content-Type-Options nosniff
    Referrer-Policy no-referrer
  }
  request_body {
    max_size 5MB
  }
  @blockedAdmin {
    path /api/admin/*
    not remote_ip $ADMIN_CIDRS
  }
  respond @blockedAdmin 403
  reverse_proxy 127.0.0.1:3000 {
    flush_interval -1
    transport http {
      dial_timeout 5s
      response_header_timeout 20s
    }
  }
}
CADDY
# Validate before activating. /etc/caddy/Caddyfile must import /etc/caddy/sites.d/*.caddy.
caddy validate --config /etc/caddy/Caddyfile
if ! grep -Eq '^\s*import\s+/etc/caddy/sites.d/\*\.caddy' /etc/caddy/Caddyfile; then
  echo 'Add: import /etc/caddy/sites.d/*.caddy to /etc/caddy/Caddyfile, review, and re-run'; exit 1
fi
PREVIOUS=$(readlink /var/lib/vyper/current || true)
ln -s "$RELEASE" /var/lib/vyper/.next-release
mv -Tf /var/lib/vyper/.next-release /var/lib/vyper/current
systemctl daemon-reload
systemctl enable vyper.service vyper-edge-cleanup.timer
systemctl restart vyper.service
if ! curl --fail --silent --show-error --retry 12 --retry-connrefused --retry-delay 5 --max-time 25 http://127.0.0.1:3000/api/ready >/dev/null; then
  echo 'Readiness failed. Candidate is not accepted; inspect journalctl -u vyper.'
  if [[ -n "$PREVIOUS" ]]; then ln -s "$PREVIOUS" /var/lib/vyper/.rollback; mv -Tf /var/lib/vyper/.rollback /var/lib/vyper/current; systemctl restart vyper.service; fi
  exit 1
fi
systemctl start vyper-edge-cleanup.timer
systemctl reload caddy
echo 'Candidate activated. Run docs/STAGING-ACCEPTANCE.md; this is NOT production acceptance.'
