package com.vyper.chat

import java.net.URI

/** Pure origin comparison, shared by navigation, bridge messages and permission callbacks. */
class NavigationPolicy(origin: String) {
    private val approved = URI(origin)
    fun permits(value: String?): Boolean = try {
        val uri = URI(value ?: "")
        uri.scheme == "https" && uri.host.equals(approved.host, ignoreCase = true) && uri.userInfo == null &&
            (if (uri.port == -1) 443 else uri.port) == (if (approved.port == -1) 443 else approved.port)
    } catch (_: Exception) { false }
    fun externalHttps(value: String?): Boolean = try {
        val uri = URI(value ?: "")
        uri.scheme == "https" && uri.host != null && uri.userInfo == null && !permits(value)
    } catch (_: Exception) { false }
}
