/// <reference lib="webworker" />
import { initializeApp } from 'firebase/app';
import { getMessaging, onBackgroundMessage } from 'firebase/messaging/sw';
import type { BrowserFirebaseConfig } from './shared/firebaseConfiguration';
declare const __VYPER_FIREBASE_CONFIG__: BrowserFirebaseConfig;
const worker = self as unknown as ServiceWorkerGlobalScope;
// Build-injected PUBLIC configuration is synchronous, avoiding a fetch/init race on terminated-worker push.
const messaging = getMessaging(initializeApp(__VYPER_FIREBASE_CONFIG__));
worker.addEventListener('install', () => { void worker.skipWaiting(); });
worker.addEventListener('activate', event => {
  event.waitUntil(Promise.all([worker.clients.claim(), caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('vyper-offline-')).map(key => caches.delete(key))))]));
});
// No generic push fallback and no OS notification payload: one message has exactly one rendering path.
onBackgroundMessage(messaging, async payload => {
  const data = payload.data || {};
  if (!['call', 'message', 'mention'].includes(data.type)) return;
  // An expired/revoked browser session must not continue displaying private notification content.
  const session = await fetch('/api/auth/me', { credentials: 'same-origin', cache: 'no-store' }).catch(() => null);
  if (!session?.ok) return;
  await session.body?.cancel();
  const eventId = data.eventId || payload.messageId;
  const receipts = await caches.open('vyper-push-receipts-v1');
  const receipt = new URL(`/__push_receipt/${encodeURIComponent(eventId || '')}`, worker.location.origin).href;
  if (eventId && await receipts.match(receipt)) return;
  const target = new URL('/', worker.location.origin);
  if (/^[A-Za-z0-9_:-]{1,255}$/.test(data.chatId || '')) target.searchParams.set('chat', data.chatId);
  if (/^[A-Za-z0-9_-]{1,255}$/.test(data.callId || '')) target.searchParams.set('call', data.callId);
  await worker.registration.showNotification(String(data.title || 'Vyper').slice(0, 200), {
    body: String(data.body || 'New notification').slice(0, 500), icon: '/icon.png', badge: '/notification-badge.svg',
    tag: eventId || (data.callId ? `call:${data.callId}` : data.chatId || 'vyper-message'), data: { url: target.href },
    requireInteraction: data.type === 'call',
  });
  if (eventId) { await receipts.put(receipt, new Response('seen')); const keys = await receipts.keys(); await Promise.all(keys.slice(0, Math.max(0, keys.length - 200)).map(key => receipts.delete(key))); }
});
worker.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil((async () => {
    const target = new URL(event.notification.data?.url || '/', worker.location.origin);
    if (target.origin !== worker.location.origin) return;
    const clients = await worker.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clients) if (new URL(client.url).origin === worker.location.origin) {
      await client.navigate(target.href); return client.focus();
    }
    return worker.clients.openWindow(target.href);
  })());
});
