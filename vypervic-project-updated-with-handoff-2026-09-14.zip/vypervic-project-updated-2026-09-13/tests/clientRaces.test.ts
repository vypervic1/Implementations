import 'fake-indexeddb/auto';
import { beforeEach, afterEach, expect, it, vi } from 'vitest';
import { sessionEpoch } from '../src/sessionEpoch';
import { getSessionStatus } from '../src/sessionStatus';
import { clearAllCachedDataLocally, cacheProfilesLocally, getCachedProfilesLocally } from '../src/utils/indexedDB';
function storage() {
 const data: any = {};
 Object.defineProperties(data, {
  getItem: {value:(key:string)=>data[key]??null},setItem:{value:(key:string,value:string)=>{data[key]=String(value);}},
  removeItem:{value:(key:string)=>{delete data[key];}},clear:{value:()=>{for(const key of Object.keys(data))delete data[key];}},
 });return data;
}
let db: typeof import('../src/oracleDB').oracleDB;
const profile = {id:'verified-user',email:'verified@example.com',username:'verified',display_name:'Verified',role:'user',about:'',avatar_url:null,is_online:true,last_seen:new Date().toISOString(),created_at:new Date().toISOString()};
beforeEach(async()=>{
 vi.stubGlobal('window',new EventTarget());vi.stubGlobal('location',{protocol:'https:'});vi.stubGlobal('navigator',{userAgent:'browser',onLine:true});vi.stubGlobal('localStorage',storage());vi.stubGlobal('sessionStorage',storage());
 vi.stubGlobal('fetch',vi.fn(async()=>Response.json({ok:true})));
 db=(await import('../src/oracleDB')).oracleDB;await db.auth.invalidateSession();await clearAllCachedDataLocally();
});
afterEach(()=>{sessionEpoch.invalidate();vi.unstubAllGlobals();});
it('ignores a /me response that arrives after logout even when the transport ignored AbortSignal',async()=>{
 let resolve!: (response:Response)=>void;
 const pending=new Promise<Response>(r=>{resolve=r;});
 vi.stubGlobal('fetch',vi.fn((url:string)=>url==='/api/auth/me'?pending:Promise.resolve(Response.json({ok:true}))));
 const restore=db.auth.getSession();const rejected=expect(restore).rejects.toThrow('superseded');
 await db.auth.signOut();resolve(Response.json({user:profile,firebaseToken:'not-a-session-jwt'}));await rejected;
 expect(getSessionStatus().status).toBe('signed-out');expect(localStorage.getItem('vypervic_current_user_cache')).toBeNull();
});
it('supersedes an in-flight server sign-in when logout wins',async()=>{
 let finish!: (response:Response)=>void;
 const pending=new Promise<Response>(resolve=>{finish=resolve;});
 vi.stubGlobal('fetch',vi.fn((url:string)=>url==='/api/auth/login'?pending:Promise.resolve(Response.json({ok:true}))));
 const signing=db.auth.signInWithPassword({email:profile.email,password:'password'});
 const logout=db.auth.signOut();
 finish(Response.json({user:profile}));
 const login=await signing;await logout;
 expect(login.error?.name).toBe('SessionSupersededError');expect(getSessionStatus().status).toBe('signed-out');expect(localStorage.getItem('vypervic_current_user_cache')).toBeNull();
});
it('does not fabricate a session from a cached profile or a presence flag',async()=>{
 localStorage.setItem('vypervic_current_user_cache',JSON.stringify({...profile,role:'admin'}));
 localStorage.setItem('vypervic_has_session','1');vi.stubGlobal('fetch',vi.fn(async()=>Response.json({error:'Unauthorized'},{status:401})));
 const result=await db.auth.getSession();expect(result.data.session).toBeNull();expect(getSessionStatus().status).toBe('signed-out');
});
it('purges the previous account cache before publishing a newly verified account',async()=>{
 localStorage.setItem('vypervic_current_user_cache',JSON.stringify({...profile,id:'old-user'}));await cacheProfilesLocally([{...profile,id:'old-user'} as any]);
 vi.stubGlobal('fetch',vi.fn(async()=>Response.json({user:profile})));
 expect((await db.auth.signInWithPassword({email:profile.email,password:'password'})).error).toBeNull();expect(await getCachedProfilesLocally()).toHaveLength(0);
});
it('replaces authoritative profile snapshots rather than retaining deleted users',async()=>{
 await cacheProfilesLocally([{...profile,id:'gone'} as any]);await cacheProfilesLocally([profile as any],true);expect((await getCachedProfilesLocally()).map(p=>p.id)).toEqual(['verified-user']);
 await cacheProfilesLocally([],true);expect(await getCachedProfilesLocally()).toHaveLength(0);
});
