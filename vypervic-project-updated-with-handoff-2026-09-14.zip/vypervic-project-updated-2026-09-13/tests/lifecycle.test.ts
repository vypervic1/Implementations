import { afterEach, expect, it, vi } from 'vitest';
import { ResourceScope } from '../src/utils/resources';
afterEach(()=>{vi.unstubAllGlobals();vi.restoreAllMocks();vi.useRealTimers();});
it('releases owned timers and object URLs, including when their delayed cleanup has not run',()=>{
 vi.useFakeTimers();const scope=new ResourceScope();const callback=vi.fn();const revoke=vi.spyOn(URL,'revokeObjectURL');
 const url=scope.blob(new Blob(['file']));scope.timeout(callback,1000);scope.dispose();vi.runAllTimers();expect(callback).not.toHaveBeenCalled();expect(revoke).toHaveBeenCalledWith(url);expect(vi.getTimerCount()).toBe(0);
});
it('stops a media stream granted after its view was disposed',async()=>{
 let grant!: (stream:any)=>void;vi.stubGlobal('navigator',{mediaDevices:{getUserMedia:()=>new Promise(r=>{grant=r;})}});
 const scope=new ResourceScope(),stop=vi.fn();const stream=scope.getUserMedia({audio:true});const rejected=expect(stream).rejects.toThrow('closed');scope.dispose();grant({getTracks:()=>[{stop,readyState:'live'}]});await rejected;expect(stop).toHaveBeenCalledOnce();
});
it('a StrictMode-style remount does not revive callbacks captured by the previous mount',()=>{
 const scope=new ResourceScope(),old=scope.capture();scope.dispose();scope.activate();expect(old()).toBe(false);expect(scope.capture()()).toBe(true);scope.dispose();
});
