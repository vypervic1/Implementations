import { settleOperation } from './helpers';
import { beforeEach, describe, expect, it } from 'vitest';
import jwt from 'jsonwebtoken';
import { getApp, seedUser, login, authHeader, resetAllTables, seedRow, getRow, allRows, type TestUser } from './helpers';
import { failRequests } from './mockOrds';
import { readBoundedResponse, fetchAllRows, sanitizeProfileForClient, saveCredentials, generateCryptoSalt, hashPassword, migrateLegacyCredentials, fetchCredentials } from '../src/server/oracleBackend';
import { issueTurnCredentials } from '../src/server/turn';
let app: Awaited<ReturnType<typeof getApp>>, alice: TestUser, bob: TestUser, eve: TestUser, token: string;
beforeEach(async () => {
  resetAllTables(); app = await getApp(); alice = seedUser(); bob = seedUser(); eve = seedUser();
  token = (await login(app, alice.email, alice.password)).token!;
});
const headers = () => authHeader(token);
const dm = () => `dm:${alice.id}:${bob.id}`;

describe('typed API abuse boundary', () => {
  it.each(['vault', 'user_credentials', 'user_push_tokens', 'password_resets', 'scheduled_messages', 'deletion_jobs', 'audit_logs'])('does not proxy %s', async table => {
    expect((await app.get(`/api/oracle/${table}/`).set(headers())).status).toBe(404);
  });
  it.each([{ ROLE: 'admin' }, { password_hash: 'abc' }, { arbitrary: 1 }, { about: 'text [auth:aa:bb]' }])('rejects forbidden profile fields %#', async body => {
    expect((await app.patch(`/api/profile`).set(headers()).send(body)).status).toBe(400);
  });
  it.each([{ ID: { $ne: 'anything' } }, { $or: [{ CHAT_ID: 'general' }, { TEXT: 'secret' }] }, { $where: '1=1' }])('rejects operator/scope escape %#', async q => {
    expect([400,403]).toContain((await app.get('/api/oracle/messages/').query({ q: JSON.stringify(q) }).set(headers())).status);
  });
  it('requires a scope for collections and ownership for writes', async () => {
    expect((await app.get('/api/oracle/messages/').set(headers())).status).toBe(403);
    expect((await app.delete('/api/oracle/messages/').set(headers())).status).toBe(405);
    expect((await app.patch(`/api/oracle/profiles/${bob.id}`).set(headers()).send({ display_name: 'Forged' })).status).toBe(403);
  });
  it('idempotently acknowledges the authoritative message, never overwrites conflicts', async () => {
    const message = { id: 'stable_message', text: 'one', chat_id: dm(), is_voice: false };
    const first = await app.post(`/api/chats/${dm()}/messages`).set(headers()).send(message);
    const retry = await app.post(`/api/chats/${dm()}/messages`).set(headers()).send(message);
    expect(first.status).toBe(201); expect(retry.body).toEqual(first.body);
    expect(allRows('messages')).toHaveLength(1);
    expect((await app.post(`/api/chats/${dm()}/messages`).set(headers()).send({ ...message, text: 'different' })).status).toBe(409);
    expect(getRow('messages', message.id)!.TEXT).toBe('one');
  });
  it('rejects forged sender/recipient and unknown message fields', async () => {
    const path = `/api/chats/${dm()}/messages`, base = { id: 'forged', text: 'no', chat_id: dm() };
    for (const body of [{ ...base, sender_id: eve.id }, { ...base, recipient_id: eve.id }]) expect((await app.post(path).set(headers()).send(body)).status).toBe(403);
    expect((await app.post(path).set(headers()).send({ ...base, role: 'admin' })).status).toBe(400);
    expect(allRows('messages')).toHaveLength(0);
  });
  it('never forwards sensitive upstream errors', async () => {
    failRequests('GET', /\/messages\//, 1, 503, { error: 'sensitive-upstream-body', url: 'https://internal.invalid/ords/' });
    const res = await app.get('/api/oracle/messages/').set(headers()).query({ q: JSON.stringify({ CHAT_ID: 'general' }) });
    expect(res.status).toBe(502);
    expect(JSON.stringify(res.body)).not.toMatch(/sensitive-upstream|internal.invalid/);
    expect(res.body.requestId).toBeTruthy();
  });
});

describe('broadcasts are not a persistence back door', () => {
  it('rejects client-only call creation', async () => {
    const res = await app.post('/api/realtime/broadcast').set(headers()).send({ event: 'call_invite', payload: { call: { id: 'not_persisted', caller_id: alice.id, receiver_id: bob.id, type: 'voice', status: 'ringing' } } });
    expect([403,404]).toContain(res.status); expect(allRows('calls')).toHaveLength(0);
  });
  it('does not mutate status from a broadcast and verifies nested participant identity', async () => {
    seedRow('messages', { ID: 'relationship', CHAT_ID: dm(), SENDER_ID: alice.id, TEXT: 'hello' });
    const call = { id: 'call_guard', receiver_id: bob.id, type: 'voice' };
    expect((await app.post('/api/calls').set(headers()).send(call)).status).toBe(201);
    const wrong = await app.post('/api/realtime/broadcast').set(headers()).send({ event: 'call_status_update', payload: { callId: call.id, status: 'accepted' } });
    expect(wrong.status).toBe(409); expect(getRow('calls', call.id)!.STATUS).toBe('ringing');
    expect((await app.patch(`/api/calls/${call.id}`).set(headers()).send({ status: 'accepted' })).status).toBe(403);
    const spoof = await app.post('/api/realtime/broadcast').set(headers()).send({ event: 'call_invite', payload: { call: { ...call, caller_id: eve.id } } });
    expect(spoof.status).toBe(403);
  });
  it('rejects off-chat broadcast targets', async () => {
    const res = await app.post('/api/realtime/broadcast').set(headers()).send({ event: 'typing', targetUserId: eve.id, payload: { userId: alice.id, chatId: dm(), isTyping: true } });
    expect(res.status).toBe(403);
  });
});

describe('sessions and durable push', () => {
  it('normal login exposes no JWT to browser JS, and logout revokes copied cookies', async () => {
    const signed = await app.post('/api/auth/login').set('X-Forwarded-For', '10.42.12.8').send({ identifier: alice.email, password: alice.password });
    expect(signed.body.token).toBeUndefined();
    const cookie = signed.headers['set-cookie'][0].split(';')[0];
    expect(signed.headers['set-cookie'][0]).toContain('HttpOnly');
    expect((await app.get('/api/auth/me').set('Cookie', cookie)).status).toBe(200);
    expect((await app.post('/api/auth/logout').set('Cookie', cookie)).status).toBe(200);
    expect((await app.get('/api/auth/me').set('Cookie', cookie)).status).toBe(401);
  });
  it('does not accept URL tokens for SSE', async () => {
    expect((await app.get('/api/realtime/stream').query({ token })).status).toBe(401);
    expect((await app.get('/api/realtime/stream').query({ token }).set(headers())).status).toBe(400);
  });
  it('binds a real-format test token to the verified account and persists refresh/revocation', async () => {
    const body = { userId: eve.id, token: 'A'.repeat(150), deviceType: 'android', source: 'android_native', deviceId: 'android-test-device-001' };
    expect((await app.post('/api/push/register-token').set(headers()).send(body)).status).toBe(200);
    expect(allRows('user_push_tokens')[0].USER_ID).toBe(alice.id);
    expect((await app.post('/api/push/register-token').set(headers()).send({ ...body, token: 'B'.repeat(150) })).status).toBe(200);
    const devices = await app.get('/api/push/devices').set(headers());
    expect(devices.body.items).toHaveLength(1); expect(JSON.stringify(devices.body)).not.toContain('B'.repeat(150));
    expect((await app.delete(`/api/push/devices/${devices.body.items[0].id}`).set(headers())).status).toBe(200);
    expect((await app.get('/api/push/devices').set(headers())).status).toBe(401);
    token = (await login(app, alice.email, alice.password)).token!;
    expect((await app.get('/api/push/devices').set(headers())).body.items).toHaveLength(0);
  });
  it('does not fabricate push success when Oracle writes fail', async () => {
    failRequests('POST', /\/user_push_tokens\//, 1);
    const res = await app.post('/api/push/register-token').set(headers()).send({ token: 'C'.repeat(150), source: 'web_fcm', deviceType: 'web', deviceId: 'browser-device-0001' });
    expect(res.status).toBe(503); expect(allRows('user_push_tokens')).toHaveLength(0);
  });
  it.each(['fcm_fake_device_token', 'mock_token', 'short'])('refuses fake push tokens (%s)', async tokenValue => {
    expect((await app.post('/api/push/register-token').set(headers()).send({ token: tokenValue, deviceType: 'android' })).status).toBe(400);
  });
});

describe('recoverable destructive operations', () => {
  it('requires literal confirmation and recent authentication', async () => {
    expect((await app.post('/api/account/delete').set(headers()).send({})).status).toBe(400);
    const decoded = jwt.decode(token) as jwt.JwtPayload;
    const stale = jwt.sign({ ...decoded, authTime: Date.now() - 3600000 }, process.env.JWT_SECRET!);
    expect((await app.post('/api/account/delete').set(authHeader(stale)).send({ confirmation: 'DELETE ACCOUNT' })).status).toBe(403);
  });
  it('checkpoints partial failure, keeps profile recoverable, retries without deleting unrelated calls', async () => {
    seedRow('calls', { ID: 'own_call', CALLER_ID: alice.id, RECEIVER_ID: bob.id, STATUS: 'ended' });
    seedRow('calls', { ID: 'unrelated_call', CALLER_ID: bob.id, RECEIVER_ID: eve.id, STATUS: 'ended' });
    seedRow('messages', { ID: 'delete_failure', SENDER_ID: alice.id, CHAT_ID: dm(), TEXT: 'owned' });
    failRequests('DELETE', /\/messages\/delete_failure/, 1);
    const failed = await app.post('/api/account/delete').set(headers()).send({ confirmation: 'DELETE ACCOUNT' });
    await settleOperation(failed);
    expect(failed.body.success).toBe(false); expect(failed.body.operationId).toBeTruthy();
    expect(getRow('profiles', alice.id)).toBeTruthy(); expect(getRow('calls', 'unrelated_call')).toBeTruthy();
    const retry = await app.post('/api/account/delete').set(headers()).send({ confirmation: 'DELETE ACCOUNT' });
    await settleOperation(retry);
    expect(retry.body.success).toBe(true); expect(retry.body.operationId).toBe(failed.body.operationId);
    expect(getRow('profiles', alice.id)).toBeNull(); expect(getRow('calls', 'unrelated_call')).toBeTruthy();
  });
});

describe('transport and credential invariants', () => {
  it('uses ordered pagination beyond a full 1000-row page', async () => {
    for (let i = 0; i < 1503; i++) seedRow('messages', { ID: `page_${String(i).padStart(5, '0')}`, CHAT_ID: 'general', TEXT: 'data', SENDER_ID: alice.id });
    const rows = await fetchAllRows('messages'); expect(rows).toHaveLength(1503);
    expect(new Set(rows.map(row => row.id)).size).toBe(1503);
  });
  it('bounds responses without relying on Content-Length', async () => {
    const response = new Response(new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(1025)); controller.close(); } }));
    await expect(readBoundedResponse(response, 1024)).rejects.toThrow();
  });
  it('sanitizes unknown credential columns and case-insensitive tags', () => {
    expect(sanitizeProfileForClient({ ID: 'one', ABOUT: 'hello [AUTH:aa:bb]', CREDENTIAL_BLOB: 'secret', PASSWORD_HASH: 'secret' })).toEqual({ ID: 'one', ABOUT: 'hello' });
  });
  it('legacy migration cannot overwrite a newer verifier, even outside the login path', async () => {
    const salt = generateCryptoSalt(), freshHash = hashPassword('fresh-password', salt);
    await saveCredentials(alice.id, freshHash, salt);
    await migrateLegacyCredentials({ id: alice.id, about: '[auth:aa:bb]', password_hash: 'bb', password_salt: 'aa', password_storage: 'legacy_about' } as any);
    expect((await fetchCredentials(alice.id))!.password_hash).toBe(freshHash);
    expect(getRow('profiles', alice.id)!.ABOUT).not.toContain('[auth:');
  });
  it('issues short-lived call-scoped TURN credentials, not public shared credentials', () => {
    process.env.TURN_URLS = 'turn:relay.example.com:3478?transport=udp,turn:relay.example.com:3478?transport=tcp,turns:relay.example.com:5349?transport=tcp';
    process.env.TURN_SHARED_SECRET = 'test-only-turn-secret-0000000000000';
    try {
      const result = issueTurnCredentials(alice.id, 'call-a', 1000000);
      expect(result.expiresAt).toBe(1600); expect(result.iceServers[0].username.startsWith('1600:')).toBe(true);
      expect(result.iceServers[0].credential).not.toBe(issueTurnCredentials(alice.id, 'call-b', 1000000).iceServers[0].credential);
    } finally { delete process.env.TURN_URLS; delete process.env.TURN_SHARED_SECRET; }
  });
});
