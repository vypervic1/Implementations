import { browserConfig } from './shared/firebaseConfiguration';
export type { BrowserFirebaseConfig } from './shared/firebaseConfiguration';
const env = (import.meta as ImportMeta & { env: Record<string, unknown> }).env || {};
export const defaultFirebaseConfig = browserConfig(env, env.PROD === true);
export const fcmFirebaseConfig = defaultFirebaseConfig;
export const VAPID_KEY = defaultFirebaseConfig.vapidKey;
