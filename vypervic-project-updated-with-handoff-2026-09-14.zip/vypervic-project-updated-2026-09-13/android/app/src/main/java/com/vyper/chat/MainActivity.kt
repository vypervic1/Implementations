package com.vyper.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.http.SslError
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import java.lang.ref.WeakReference

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val policy = NavigationPolicy(BuildConfig.APP_ORIGIN)
    private var pendingMedia: PermissionRequest? = null
    private var pendingPush: ((Boolean) -> Unit)? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var audioManager: AudioManager
    private val requestMedia = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val request = pendingMedia
        pendingMedia = null
        if (request != null) {
            if (!policy.permits(web.url) || !policy.permits(request.origin.toString())) request.deny()
            else {
                val granted = request.resources.filter { resource ->
                    val permission = permissionFor(resource)
                    permission != null && ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
                }
                if (granted.isEmpty()) request.deny() else request.grant(granted.toTypedArray())
            }
        }
    }
    private val requestPush = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pendingPush?.invoke(granted); pendingPush = null
    }
    private val chooseFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        fileCallback = null
    }
    companion object {
        private var active: WeakReference<MainActivity>? = null
        fun foregroundPush(data: Map<String, String>) {
            active?.get()?.runOnUiThread {
                val activity = active?.get() ?: return@runOnUiThread
                if (activity.policy.permits(activity.web.url)) {
                    val json = JSONObject(data).toString()
                    activity.web.evaluateJavascript("window.dispatchEvent(new CustomEvent('vyper_native_push',{detail:JSON.parse(${JSONObject.quote(json)})}));", null)
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(AudioManager::class.java)
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        CookieManager.getInstance().setAcceptCookie(true)
        web = WebView(this)
        setContentView(web)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        web.settings.apply {
            javaScriptEnabled = true // only the approved HTTPS app is navigable and bridge-enabled
            domStorageEnabled = true
            @Suppress("DEPRECATION")
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = false
            userAgentString += " VyperAndroid/1"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) web.settings.safeBrowsingEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (policy.permits(url)) return false
                if (request.isForMainFrame && request.hasGesture() && policy.externalHttps(url)) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, request.url).addCategory(Intent.CATEGORY_BROWSABLE)) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "No browser available", Toast.LENGTH_SHORT).show() }
                }
                return true
            }
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel() // never bypass certificate validation, including debug builds
            }
            override fun onPageFinished(view: WebView, url: String) { if (policy.permits(url)) CookieManager.getInstance().flush() }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    pendingMedia?.deny(); pendingMedia = null
                    if (!policy.permits(web.url) || !policy.permits(request.origin.toString()) || request.resources.any { permissionFor(it) == null }) {
                        request.deny(); return@runOnUiThread
                    }
                    pendingMedia = request
                    requestMedia.launch(request.resources.mapNotNull { permissionFor(it) }.distinct().toTypedArray())
                }
            }
            override fun onPermissionRequestCanceled(request: PermissionRequest) { if (pendingMedia === request) pendingMedia = null }
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                if (!policy.permits(view.url)) return false
                fileCallback?.onReceiveValue(null); fileCallback = callback
                return try { chooseFile.launch(params.createIntent()); true } catch (_: Exception) { fileCallback = null; false }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "VyperNative", setOf(BuildConfig.APP_ORIGIN)) { _, message, source, mainFrame, reply ->
                if (!mainFrame || !policy.permits(source.toString()) || !policy.permits(web.url)) return@addWebMessageListener
                val raw = message.data ?: return@addWebMessageListener
                if (raw.length > 4096) return@addWebMessageListener
                try {
                    val input = JSONObject(raw)
                    val id = input.optString("id")
                    if (
                        input.optInt("version") != 1 ||
                        !id.matches(Regex("^[a-zA-Z0-9-]{1,64}$"))
                    ) return@addWebMessageListener
                    fun respond(result: JSONObject? = null, error: String? = null) {
                        if (!isDestroyed && policy.permits(web.url)) reply.postMessage(JSONObject().put("version", 1).put("id", id).put("result", result).put("error", error).toString())
                    }
                    when (input.optString("method")) {
                        "capabilities" -> respond(JSONObject().put("version", 1).put("mode", "native-android"))
                        "getPushToken" -> {
                            val obtain: (Boolean) -> Unit = { permitted ->
                                if (!permitted) respond(error = "Android notification permission was denied")
                                else FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                                    if (!task.isSuccessful || task.result.isNullOrBlank()) respond(error = "Native FCM token unavailable")
                                    else {
                                        val prefs = getSharedPreferences("push", MODE_PRIVATE)
                                        prefs.edit().putString("token", task.result).apply()
                                        respond(JSONObject().put("token", task.result).put("deviceId", TokenRegistrationWorker.deviceId(this))
                                            .put("source", "android_native").put("deviceType", "android"))
                                    }
                                }
                            }
                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                if (pendingPush != null) respond(error = "A permission request is already pending")
                                else { pendingPush = obtain; requestPush.launch(Manifest.permission.POST_NOTIFICATIONS) }
                            } else obtain(true)
                        }
                        "flushCookies" -> {
                            CookieManager.getInstance().flush()
                            getSharedPreferences("push", MODE_PRIVATE).edit().putBoolean("session_bound", true).apply()
                            TokenRegistrationWorker.enqueue(this)
                            respond(JSONObject().put("ok", true).put("deviceId", TokenRegistrationWorker.deviceId(this)))
                        }
                        "logout" -> {
                            getSharedPreferences("push", MODE_PRIVATE).edit().remove("token").putBoolean("session_bound", false).apply()
                            TokenRegistrationWorker.cancel(this)
                            androidx.core.app.NotificationManagerCompat.from(this).cancelAll()
                            FirebaseMessaging.getInstance().deleteToken()
                            // The server expires its own HttpOnly cookie. Retain a cookie only while offline logout revocation is pending.
                            web.clearCache(true)
                            respond(JSONObject().put("ok", true))
                        }
                        else -> respond(error = "Unsupported bridge method")
                    }
                } catch (_: Exception) { /* malformed/untrusted bridge data is rejected, never logged */ }
            }
        } else Toast.makeText(this, "Update Android System WebView to enable native push", Toast.LENGTH_LONG).show()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
        // Reload HTTPS on recreation; cookies + DOM/IndexedDB persist in the WebView profile.
        web.loadUrl(intent.dataString?.takeIf(policy::permits) ?: BuildConfig.APP_ORIGIN)
    }
    private fun permissionFor(resource: String): String? = when (resource) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        else -> null
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        intent.dataString?.takeIf(policy::permits)?.let { target ->
            if (policy.permits(web.url)) web.evaluateJavascript("history.replaceState({},'',${JSONObject.quote(target)});window.dispatchEvent(new Event('vyper_native_navigation'));", null)
            else web.loadUrl(target)
        }
    }
    override fun onResume() { super.onResume(); active = WeakReference(this); web.onResume() }
    override fun onPause() {
        active = null
        // Do not cancel the request merely because the Android permission dialog pauses the Activity.
        if (pendingMedia == null && pendingPush == null && policy.permits(web.url)) web.evaluateJavascript("window.dispatchEvent(new Event('vyper_native_background'));", null)
        CookieManager.getInstance().flush()
        web.onPause(); super.onPause()
    }
    override fun onDestroy() {
        audioManager.mode = AudioManager.MODE_NORMAL
        active = null; pendingMedia?.deny(); pendingMedia = null; pendingPush = null
        fileCallback?.onReceiveValue(null); fileCallback = null
        web.stopLoading()
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) WebViewCompat.removeWebMessageListener(web, "VyperNative")
        web.loadUrl("about:blank"); web.removeAllViews(); web.destroy()
        super.onDestroy()
    }
}
