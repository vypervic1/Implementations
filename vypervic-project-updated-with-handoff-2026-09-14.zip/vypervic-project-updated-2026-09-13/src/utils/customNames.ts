import { Profile } from '../types';

export function getContactDisplayName(profile: Profile | null | undefined): string {
  if (!profile) return 'Unknown User';
  const saved = localStorage.getItem('vyper_custom_display_names');
  if (saved) {
    try {
      const map = JSON.parse(saved);
      if (map[profile.id]) {
        return map[profile.id];
      }
    } catch (e) {
      console.error(e);
    }
  }
  return profile.display_name || profile.username || 'Unknown User';
}

export function isUserOnline(profile: Profile | null | undefined): boolean {
  if (!profile) return false;
  if (!profile.is_online) return false;
  if (!profile.last_seen) return true;
  const lastSeenMs = new Date(profile.last_seen).getTime();
  if (isNaN(lastSeenMs)) return true;
  // If last_seen is within the last 150 seconds (or slightly in the future due to client-server clock disparity), they are active
  const diffMs = Date.now() - lastSeenMs;
  return diffMs < 150 * 1000;
}

export function formatLastSeen(profile: Profile | null | undefined): string {
  if (!profile) return 'offline';
  if (isUserOnline(profile)) return 'online';
  if (!profile.last_seen) return 'last seen recently';

  const date = new Date(profile.last_seen);
  if (isNaN(date.getTime())) return 'last seen recently';

  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();

  if (isToday) {
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    return `last seen today at ${timeStr}`;
  } else {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const day = date.getDate();
    const month = monthNames[date.getMonth()];
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    return `last seen ${day} ${month} at ${timeStr}`;
  }
}

export interface PollMetadata {
  id: string;
  question: string;
  options: string[];
  multipleChoice?: boolean;
  votes?: Record<string, string[]>;
}

/**
 * Safely parse poll serialization payload from message text.
 */
export function parsePollPayload(text: string | null | undefined): PollMetadata | null {
  if (!text || typeof text !== 'string') return null;
  if (!text.startsWith('_vyper_poll_::')) return null;
  try {
    const jsonStr = text.substring('_vyper_poll_::'.length);
    const parsed = JSON.parse(jsonStr);
    if (parsed && typeof parsed === 'object' && parsed.question && Array.isArray(parsed.options)) {
      return {
        id: String(parsed.id || 'poll_' + Date.now()),
        question: String(parsed.question),
        options: parsed.options.map(String),
        multipleChoice: Boolean(parsed.multipleChoice),
        votes: (parsed.votes && typeof parsed.votes === 'object') ? parsed.votes : {},
      };
    }
  } catch (e) {
    // Malformed JSON fallback
  }
  return null;
}

/**
 * Clean human-readable text extractor that strips all _vyper_* internal serialization wrappers.
 */
export function getCleanMessageExcerpt(text: string | null | undefined, maxWords = 8): string {
  if (!text || typeof text !== 'string') return '';
  if (text.startsWith('_vyper_deleted_::')) {
    return 'This message was deleted';
  }
  if (text.startsWith('_vyper_poll_::')) {
    const poll = parsePollPayload(text);
    return poll ? `📊 Poll: ${poll.question}` : '📊 Poll';
  }
  if (text.startsWith('_vyper_call_::')) {
    try {
      const call = JSON.parse(text.substring('_vyper_call_::'.length));
      return call.type === 'video' ? '📹 Video Call' : '📞 Voice Call';
    } catch {
      return '📞 Call Message';
    }
  }
  if (text.startsWith('_vyper_reply_::')) {
    try {
      const meta = JSON.parse(text.substring('_vyper_reply_::'.length));
      return meta.text || '';
    } catch {
      return '';
    }
  }
  if (text.startsWith('_vyper_location_::')) {
    return '📍 Location';
  }
  if (text.startsWith('_vyper_contact_::')) {
    return '👤 Contact card';
  }
  if (text.startsWith('[Forwarded]: ')) {
    return text.substring('[Forwarded]: '.length);
  }
  if (text.startsWith('[Forwarded File]')) {
    return '📎 Forwarded File';
  }
  return text;
}

export function parseProfileAbout(aboutStr: string | null, userId?: string) {
  let thinking: string | null = null;
  let coverUrl: string | null = null;
  let about = aboutStr || '';

  if (!aboutStr) {
    return { thinking: null, coverUrl: null, about: '' };
  }

  // Check local cache fallback first if userId provided
  if (userId) {
    try {
      const cachedCover = localStorage.getItem(`vyper_cover_${userId}`);
      if (cachedCover) {
        coverUrl = cachedCover;
      }
    } catch (e) {}
  }

  // Extract metadata tags repeatedly at start regardless of order
  let matched = true;
  while (matched) {
    matched = false;

    const thinkingMatch = about.match(/^\[thinking:(.*?)\]/);
    if (thinkingMatch) {
      matched = true;
      try {
        thinking = decodeURIComponent(thinkingMatch[1]);
      } catch (e) {
        thinking = thinkingMatch[1];
      }
      if (thinking) {
        thinking = thinking.replace(/[\r\n]+/g, ' ').trim();
      }
      about = about.substring(thinkingMatch[0].length);
      continue;
    }

    const coverMatch = about.match(/^\[cover:([\s\S]*?)\]/);
    if (coverMatch) {
      matched = true;
      if (!coverUrl) {
        try {
          coverUrl = decodeURIComponent(coverMatch[1]);
        } catch (e) {
          coverUrl = coverMatch[1];
        }
      }
      about = about.substring(coverMatch[0].length);
      continue;
    }
  }

  // Fallback strip for any inline or stray metadata tags
  about = about.replace(/\[thinking:[\s\S]*?\]/g, '');
  about = about.replace(/\[cover:[\s\S]*?\]/g, '');
  about = about.trim();

  return { thinking, coverUrl, about };
}

export function buildProfileAbout(thinking: string | null, coverUrl: string | null, about: string) {
  let result = '';
  if (thinking && thinking.trim()) {
    result += `[thinking:${encodeURIComponent(thinking.trim())}]`;
  }
  if (coverUrl && coverUrl.trim()) {
    result += `[cover:${encodeURIComponent(coverUrl.trim())}]`;
  }
  result += about;
  return result;
}

/**
 * Robust, monotonic timestamp extractor for messages.
 * Handles ISO strings, millisecond numbers, epoch strings, temp IDs with embedded timestamps, and UUID tie-breaking.
 */
export function extractMessageTimestamp(msg: { created_at?: any; id?: string } | null | undefined): number {
  if (!msg) return 0;
  
  if (msg.created_at) {
    if (typeof msg.created_at === 'number' && !isNaN(msg.created_at)) {
      return msg.created_at;
    }
    if (typeof msg.created_at === 'string') {
      const parsed = Date.parse(msg.created_at);
      if (!isNaN(parsed) && parsed > 0) {
        return parsed;
      }
      const num = Number(msg.created_at);
      if (!isNaN(num) && num > 1000000000) {
        return num;
      }
    }
  }

  // Fallback: extract timestamp embedded inside temporary or generated IDs (e.g., temp_1725280000000 or msg_1725280000000)
  if (msg.id && typeof msg.id === 'string') {
    const match = msg.id.match(/(\d{10,13})/);
    if (match) {
      const extracted = Number(match[1]);
      if (extracted > 1000000000) {
        // If extracted is in seconds, convert to ms
        return extracted < 10000000000 ? extracted * 1000 : extracted;
      }
    }
  }

  return 0;
}

/**
 * Strict monotonic ascending comparator for messages across all chat sessions.
 * Guarantees stable ordering by timestamp with deterministic ID tie-breaking.
 */
export function compareMessagesChronologically(
  a: { created_at?: any; id?: string } | null | undefined,
  b: { created_at?: any; id?: string } | null | undefined
): number {
  const ta = extractMessageTimestamp(a);
  const tb = extractMessageTimestamp(b);
  if (ta !== tb) {
    return ta - tb;
  }
  const idA = a?.id ? String(a.id) : '';
  const idB = b?.id ? String(b.id) : '';
  return idA.localeCompare(idB);
}
