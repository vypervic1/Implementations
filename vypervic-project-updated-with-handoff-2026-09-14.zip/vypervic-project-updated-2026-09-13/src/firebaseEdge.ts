/**
 * Legacy compatibility validator only.
 * Durable delivery is owned by the authenticated VPS SSE/Oracle path.
 * This module intentionally has no publish/subscribe implementation.
 */
export function isRulesVerifiableChat(chatId: string): boolean {
  return chatId === 'general' || /^dm:[A-Za-z0-9_-]+:[A-Za-z0-9_-]+$/.test(chatId);
}
