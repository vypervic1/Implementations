import { readFile } from 'node:fs/promises';
import { browserConfig } from '../shared/firebaseConfiguration';
import { ordsFetch, ORACLE_ADB_BASE } from './oracleBackend';
import { getRedis } from './sharedStore';
import { isProduction } from './config';

export const readiness = { ready: false, lastCheckedAt: 0 };
/** Fail startup when durable boundaries cannot be exercised, not merely when env strings are absent. */
async function performReadinessCheck(): Promise<void> {
  const redis = await getRedis();
  if (redis && await redis.ping() !== 'PONG') throw new Error('Shared store health check failed');
  const gate = await ordsFetch('/vyper-internal/gate/');
  if (!gate.ok || gate.json?.schemaVersion !== 3 || gate.json?.guardCount !== 10 || gate.json?.outboxTriggers !== 2) throw new Error('Database write fence / outbox migration is not installed');
  const objects: Record<string, string[]> = {
    delivery_outbox: ['ID'], profiles_meta: ['ID'], messages_meta: ['ID'], groups_meta: ['ID'], calls_meta: ['ID'], vault_meta: ['ID'], scheduled_messages_meta: ['ID'], profiles: ['ID'], messages: ['ID'], calls: ['ID'], groups: ['ID'], user_credentials: ['ID'],
    password_resets: ['ID'], scheduled_messages: ['ID', 'NEXT_ATTEMPT_AT'],
    user_push_tokens: ['ID', 'TOKEN_SOURCE', 'DEVICE_ID', 'REVOKED_AT', 'SESSION_JTI'], deletion_jobs: ['ID', 'STATUS'], audit_logs: ['ID'], vault: ['ID'],
  };
  for (const [table, fields] of Object.entries(objects)) {
    const result = await ordsFetch(`/${table}/?${new URLSearchParams({ q: JSON.stringify(Object.fromEntries(fields.map(f => [f, '__readiness_probe__']))), limit: '1' })}`);
    if (!result.ok || !Array.isArray(result.json?.items)) throw new Error(`Required ORDS object unavailable: ${table}`);
  }
  if (isProduction()) {
    const anonymous = await fetch(`${ORACLE_ADB_BASE.replace(/\/$/, '')}/profiles/?limit=1`, { redirect: 'error', signal: AbortSignal.timeout(10000) });
    await anonymous.body?.cancel();
    if (anonymous.status !== 401) throw new Error('ORDS must return 401 without authentication');
    const built = JSON.parse(await readFile('dist/firebase-build-config.json', 'utf8'));
    const runtime = browserConfig(process.env, true);
  }
  readiness.ready = true; readiness.lastCheckedAt = Date.now();
}

let checking: Promise<void> | null = null;
export function checkReadiness(): Promise<void> {
  if (checking) return checking;
  if (Date.now() - readiness.lastCheckedAt < 15000) return readiness.ready ? Promise.resolve() : Promise.reject(new Error('Readiness unavailable'));
  checking = performReadinessCheck().catch(error => {
    readiness.ready = false;
    console.error('[Readiness] check failed:', error?.message || error);
    throw error;
  })
    .finally(() => { readiness.lastCheckedAt = Date.now(); checking = null; });
  return checking;
}
