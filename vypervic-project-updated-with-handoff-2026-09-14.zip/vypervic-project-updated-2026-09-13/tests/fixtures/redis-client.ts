import { SharedRateLimiter } from '../../src/server/rateLimit';
import { withLease, closeSharedStore } from '../../src/server/sharedStore';
import { revokeSession } from '../../src/server/sessionState';
const [command, name, extra] = process.argv.slice(2);
if (command === 'limit') {
  const limiter = new SharedRateLimiter(name, { max: 5, windowMs: 60000 });
  const results = await Promise.all(Array.from({ length: 4 }, () => limiter.consume('shared-client')));
  console.log(JSON.stringify(results.filter(result => result.allowed).length));
} else if (command === 'lease') {
  await withLease(name, async () => {
    process.send?.('held');
    await new Promise<void>(resolve => process.once('message', () => resolve()));
  }, 900);
} else if (command === 'revoke') await revokeSession(JSON.parse(extra));
await closeSharedStore();
process.disconnect?.();
