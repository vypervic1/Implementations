// =========================================================================
// SHARED AUTHORIZATION HELPERS (chat membership / call participation)
// Extracted from server.ts so workers and routes share one implementation.
// All checks FAIL CLOSED: when a relationship cannot be verified, access
// is denied.
// =========================================================================

import { fetchGroupById, fetchCallById, groupMembers } from './oracleBackend';
import { parseDmChatId } from './chatIds';

export const isNonEmptyString = (v: any): v is string =>
  typeof v === 'string' && v.trim().length > 0;

/**
 * Can `userId` read/participate in the chat `chatId`?
 *   dm:A:B    -> A or B
 *   group:gid -> a member of that group (verified against the DB)
 *   general   -> any authenticated user (public channel)
 */
export async function isChatParticipant(chatId: string, userId: string): Promise<boolean> {
  if (!isNonEmptyString(chatId) || !isNonEmptyString(userId)) return false;
  if (chatId === 'general') return true;
  if (chatId.startsWith('dm:')) {
    const parts = parseDmChatId(chatId);
    return !!parts && parts.includes(userId);
  }
  if (chatId.startsWith('group:')) {
    const gid = chatId.slice(6);
    try {
      const g = await fetchGroupById(chatId) || await fetchGroupById(gid);
      return g ? groupMembers(g).includes(userId) : false;
    } catch (e) {
      return false; // fail closed
    }
  }
  return false;
}

export async function isCallParticipant(callId: string, userId: string): Promise<boolean> {
  if (!isNonEmptyString(callId) || !isNonEmptyString(userId)) return false;
  const call = await fetchCallById(callId);
  if (!call) return false;
  return String(call.caller_id) === userId || String(call.receiver_id) === userId;
}
