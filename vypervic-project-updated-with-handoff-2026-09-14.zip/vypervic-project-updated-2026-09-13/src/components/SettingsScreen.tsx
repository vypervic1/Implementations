import { useState, useRef, ChangeEvent, useEffect, memo } from 'react';
import { oracleDB } from '../oracleDB';
import { Profile } from '../types';
import {
  ArrowLeft,
  Trash,
  LogOut,
  Edit,
  Save,
  Sparkles,
  Loader2,
  Bell,
  Smartphone,
  Check,
  Database,
  RefreshCw,
  Send,
  AlertTriangle,
  HardDrive,
  Download,
  Play,
  Pause,
  Trash2,
  Link as LinkIcon,
  Globe,
  Copy,
  ExternalLink,
  Camera,
  X,
  Phone,
  MessageSquare,
  Bug,
  LifeBuoy,
  Mail,
  ShieldCheck,
  CheckCheck,
  EyeOff,
  Eye
} from 'lucide-react';
import { getAllSavedFiles, deleteSavedFile, SavedFile } from '../utils/indexedDB';
import { InteractiveImageViewer } from './InteractiveImageViewer';
import {
  checkNotificationPermission,
  requestNotificationPermission,
  registerPushToken,
  fetchRegisteredTokens,
  deletePushToken,
  PushToken
} from '../notifications';
import { registerForPushNotifications } from '../firebaseClient';
import { parseProfileAbout, buildProfileAbout } from '../utils/customNames';
import { getMiniRoastMessage } from '../utils/roasts';

function compressImage(file: File, maxWidth: number, maxHeight: number, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          let encoded = canvas.toDataURL('image/jpeg', quality);
          for (let q = quality - 0.08; encoded.length > 900_000 && q >= 0.35; q -= 0.08) {
            encoded = canvas.toDataURL('image/jpeg', q);
          }
          if (encoded.length > 900_000) return reject(new Error('Image is too large after compression. Choose a smaller image.'));
          resolve(encoded);
        } else {
          reject(new Error('Could not prepare the image for upload.'));
        }
      };
      img.onerror = () => reject(new Error('The selected file is not a readable image.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Could not read the selected image.'));
    reader.readAsDataURL(file);
  });
}

interface SettingsScreenProps {
  currentUser: Profile;
  allProfiles: Profile[];
  appTheme: string;
  onUpdateAppTheme: (theme: string) => void;
  onBack: () => void;
  onLogout: () => void;
  onUpdateProfile: (updated: Profile) => void;
  onToast: (msg: string) => void;
  onOpenAdminDashboard?: () => void;
  readReceiptsEnabled?: boolean;
  onToggleReadReceipts?: (enabled: boolean) => void;
}

function SettingsScreen({
  currentUser,
  allProfiles,
  appTheme,
  onUpdateAppTheme,
  onBack,
  onLogout,
  onUpdateProfile,
  onToast,
  onOpenAdminDashboard,
  readReceiptsEnabled = true,
  onToggleReadReceipts,
}: SettingsScreenProps) {
  const [displayName, setDisplayName] = useState(currentUser.display_name || '');
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phone_number || '');
  const parsedAbout = parseProfileAbout(currentUser.about);
  const [thinking, setThinking] = useState(parsedAbout.thinking || '');
  const [about, setAbout] = useState(parsedAbout.about || 'Hey there! I am using VyperVic.');
  const [loading, setLoading] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState<'logout' | 'delete' | null>(null);
  const [showReadReceiptModal, setShowReadReceiptModal] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showZoomedCover, setShowZoomedCover] = useState(false);
  const [lastDarkTheme, setLastDarkTheme] = useState('cosmic');
  const [highContrast, setHighContrast] = useState(() => localStorage.getItem('vypervic_high_contrast') === 'true');
  const [largeText, setLargeText] = useState(() => localStorage.getItem('vypervic_large_text') === 'true');

  useEffect(() => {
    document.documentElement.dataset.contrast = highContrast ? 'high' : 'normal';
    document.documentElement.dataset.textScale = largeText ? 'large' : 'normal';
    localStorage.setItem('vypervic_high_contrast', String(highContrast));
    localStorage.setItem('vypervic_large_text', String(largeText));
  }, [highContrast, largeText]);

  // Review & Bug report subpage states
  const [showReviewSubpage, setShowReviewSubpage] = useState(false);
  const [reviewCategory, setReviewCategory] = useState<'bug' | 'feature' | 'call_quality' | 'suggestion'>('bug');
  const [reviewSubject, setReviewSubject] = useState('');
  const [reviewMessage, setReviewMessage] = useState('');
  const [includeDiagnostics, setIncludeDiagnostics] = useState(true);

  // Push Notifications Settings States
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [pushTokens, setPushTokens] = useState<PushToken[]>([]);
  const [loadingTokens, setLoadingTokens] = useState(false);
  const [registeringDevice, setRegisteringDevice] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [coverUrl, setCoverUrl] = useState(currentUser.cover_url || parsedAbout.coverUrl || '');
  const coverInputRef = useRef<HTMLInputElement | null>(null);

  // Local files cache state
  const [localFiles, setLocalFiles] = useState<SavedFile[]>([]);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Device Storage Tabs & Fullscreen state
  const [activeStorageTab, setActiveStorageTab] = useState<'media' | 'docs' | 'voice' | 'links'>('media');
  const [fullscreenMedia, setFullscreenMedia] = useState<SavedFile | null>(null);

  // Deletion Confirmation States (Strict Requirement: all deletion must ask confirmation for delete or cancel)
  const [fileToDelete, setFileToDelete] = useState<{ id: string; name: string } | null>(null);
  const [tokenToDeregister, setTokenToDeregister] = useState<{ id: string; deviceName: string } | null>(null);

  useEffect(() => {
    loadLocalFiles();
  }, []);

  const loadLocalFiles = async () => {
    const files = await getAllSavedFiles();
    setLocalFiles(files);
  };

  const confirmDeleteFile = async () => {
    if (!fileToDelete) return;
    const { id, name } = fileToDelete;
    if (playingAudioId === id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      setPlayingAudioId(null);
    }
    await deleteSavedFile(id);
    onToast(getMiniRoastMessage('delete_file', name));
    setFileToDelete(null);
    if (fullscreenMedia?.id === id) {
      setFullscreenMedia(null);
    }
    loadLocalFiles();
  };

  const confirmDeregisterToken = async () => {
    if (!tokenToDeregister) return;
    const { id, deviceName } = tokenToDeregister;
    try {
      const success = await deletePushToken(id);
      onToast(success ? 'Device revoked' : 'Device revocation failed');
      if (success) await loadPushTokens();
    } catch { onToast('Could not revoke device; retry when connected'); }
    setTokenToDeregister(null);
  };

  const handleDownloadLocalFile = (file: SavedFile) => {
    const link = document.createElement('a');
    link.href = file.fileData;
    link.download = file.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onToast('Downloaded');
  };

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    onToast('Copied');
  };

  const handlePlayVoiceNote = (file: SavedFile) => {
    if (playingAudioId === file.id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      setPlayingAudioId(null);
    } else {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      const audio = new Audio(file.fileData);
      audioPlayerRef.current = audio;
      audio.play().catch(e => console.warn("Failed to play local voice file:", e));
      setPlayingAudioId(file.id);
      audio.onended = () => {
        setPlayingAudioId(null);
      };
    }
  };

  // Load push notifications state
  useEffect(() => {
    setPermission(checkNotificationPermission());
    loadPushTokens();
  }, [currentUser]);

  const loadPushTokens = async () => {
    setLoadingTokens(true);
    try { setPushTokens(await fetchRegisteredTokens(currentUser.id)); }
    catch { onToast('Device list unavailable; reconnect and retry'); }
    finally { setLoadingTokens(false); }
  };

  const handleRequestPermission = async () => {
    const status = await requestNotificationPermission();
    setPermission(status);
    if (status === 'granted') {
      onToast('Granted');
    } else {
      onToast('Denied');
    }
  };

  const handleRegisterDevice = async () => {
    setRegisteringDevice(true);
    try {
      // First, ensure notification permission is requested
      const realFcmToken = await registerForPushNotifications(currentUser.id);
      if (!realFcmToken) throw new Error('Push is unavailable on this device');
      onToast('Push token saved to your account');
      await loadPushTokens();
    } catch (e) {
      onToast(e instanceof Error ? e.message : 'Push registration failed');
    } finally {
      setRegisteringDevice(false);
    }
  };

  // Compute initials from name
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((w) => w[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  // Seed avatars
  const getAvatarStyle = (seed: number) => {
    const palette = [
      ['#20e3a2', '#0f8f66'],
      ['#7c5cff', '#4a2fd1'],
      ['#ff9f4a', '#c76a1a'],
      ['#4ac2ff', '#1e6fbf'],
      ['#ff5470', '#c22a48'],
      ['#ffd166', '#c99a1f'],
      ['#a78bfa', '#6d4fd4'],
      ['#34d399', '#0f9d6b'],
    ];
    const c = palette[seed % palette.length];
    return `linear-gradient(135deg, ${c[0]} 0%, ${c[1]} 100%)`;
  };

  const handleUpdateProfile = async (field: string, value: string) => {
    try {
      if (field === 'phone_number' && value.trim() && value.replace(/\D/g, '').length < 7) {
        throw new Error('Enter a valid phone number with at least 7 digits.');
      }
      const data = await saveProfileChanges({ [field]: value.trim() || null });
      onToast(getMiniRoastMessage(field, value));
      return data;
    } catch (error) {
      onToast(error instanceof Error ? error.message : `Could not save ${field.replace('_', ' ')}.`);
      return null;
    }
  };

  const handleSendFeedbackEmail = () => {
    if (!reviewMessage.trim()) {
      onToast('Please write your feedback or bug details');
      return;
    }

    const categoryLabels = {
      bug: '🐛 Bug Report & Error',
      feature: '💡 Feature Suggestion / Add',
      call_quality: '⚡ Call Quality & Low Latency',
      suggestion: '💬 General Feedback / Review',
    };

    const subjectText = `[VyperVic ${categoryLabels[reviewCategory]}] ${reviewSubject.trim() || 'App Feedback'}`;

    let bodyText = `Category: ${categoryLabels[reviewCategory]}\n`;
    bodyText += `User ID: ${currentUser.id}\n`;
    bodyText += `Username: @${currentUser.username || 'unknown'}\n`;
    bodyText += `Bound Phone: ${phoneNumber || currentUser.phone_number || 'Not bound'}\n`;
    bodyText += `Email: ${currentUser.email || 'unknown'}\n\n`;
    bodyText += `=== FEEDBACK / ISSUE DESCRIPTION ===\n${reviewMessage.trim()}\n\n`;

    if (includeDiagnostics) {
      bodyText += `=== SYSTEM & APP DIAGNOSTICS ===\n`;
      bodyText += `App: VyperVic Island v2.4.0 (Ultra-Low Latency)\n`;
      bodyText += `User Agent: ${navigator.userAgent}\n`;
      bodyText += `Screen: ${window.innerWidth}x${window.innerHeight}\n`;
      bodyText += `Online: ${navigator.onLine ? 'Yes' : 'No'}\n`;
      bodyText += `Timestamp: ${new Date().toISOString()}\n`;
    }

    const mailtoUrl = `mailto:vypervic1@gmail.com?subject=${encodeURIComponent(subjectText)}&body=${encodeURIComponent(bodyText)}`;

    window.location.href = mailtoUrl;
    onToast('Opening email app...');
    setShowReviewSubpage(false);
    setReviewSubject('');
    setReviewMessage('');
  };

  const saveProfileChanges = async (changes: Record<string, unknown>) => {
    const { data, error } = await oracleDB.from('profiles').update(changes).eq('id', currentUser.id);
    if (error || !data?.id) throw error || new Error('Profile persistence was not confirmed');
    onUpdateProfile(data);
    return data;
  };
  const handleUpdateAboutAndThinking = async (newThinking: string, newAbout: string) => {
    try {
      await saveProfileChanges({ about: buildProfileAbout(newThinking.trim(), '', newAbout.trim()) });
      onToast('Profile saved to your account');
    } catch (error) { onToast(error instanceof Error ? error.message : 'Profile update failed'); }
  };
  const handleCoverUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    try {
      const cover = await compressImage(file, 900, 450, 0.72);
      await saveProfileChanges({ cover_url: cover }); setCoverUrl(cover); onToast('Cover saved to your account');
    } catch (error) { onToast(error instanceof Error ? error.message : 'Cover upload failed'); }
  };
  const handleImageUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    try {
      const avatar = await compressImage(file, 400, 400, 0.72);
      await saveProfileChanges({ avatar_url: avatar });
      onToast('Photo saved to your account');
    } catch (error) { onToast(error instanceof Error ? error.message : 'Photo upload failed'); }
  };

  const isAdmin = currentUser.role === 'admin';

  const [reauthPassword, setReauthPassword] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState('');
  const handleDeleteAccount = async () => {
    if (deleteConfirmation !== 'DELETE ACCOUNT' || !reauthPassword) return;
    setDeleting(true);
    try {
      const response = await fetch('/api/auth/reauth', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: reauthPassword }) });
      setReauthPassword('');
      if (!response.ok) throw new Error((await response.json()).error || 'Reauthentication failed');
      const result = await oracleDB.deleteUserAccount(currentUser.id);
      if (!result.success) throw new Error(result.error || 'Deletion incomplete; retry from the existing operation');
      await oracleDB.auth.signOut();
      onToast('Account deletion completed'); onLogout();
    } catch (error) { onToast(error instanceof Error ? error.message : 'Deletion incomplete; no completion was confirmed'); }
    finally { setDeleting(false); setReauthPassword(''); setDeleteConfirmation(''); setShowConfirmModal(null); }
  };

  const handleFactoryReset = async () => {
    if (!isAdmin) {
      onToast('Permission denied. Admin privileges required.');
      return;
    }
    const confirmation = window.prompt('Type WIPE ALL DATA to permanently wipe all application data. A recent sign-in is required:');
    if (confirmation !== 'WIPE ALL DATA') return;
    setDeleting(true);
    try {
      const { oracleDB } = await import('../oracleDB');
      const res = await oracleDB.wipeAllSystemData();
      if (res.success) {
        if (res.failedCount) {
          onToast(`Wipe completed but ${res.failedCount} row deletion(s) failed — re-run to finish.`);
          return;
        }
        onToast('All accounts and messages have been wiped clean.');
        window.location.reload();
      } else {
        onToast(res.error || 'Wipe incomplete. Review the operation and retry; some steps may have completed.');
      }
    } catch (e) {
      onToast('Wipe failed. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  const seed = currentUser.username?.charCodeAt(0) || 0;

  return (
    <div className="absolute inset-0 flex flex-col bg-[#080b10] z-30">
      {/* Header */}
      <div className="pt-[calc(var(--safe-top)+10px)] px-[18px] pb-3.5 flex items-center gap-3.5 border-b border-[#212a38]">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-full bg-[#161d28] border border-[#212a38] flex items-center justify-center cursor-pointer active:bg-[#1d2531] transition-colors"
        >
          <ArrowLeft className="w-[18px] h-[18px] text-[#eef1f6]" />
        </button>
        <div className="font-display text-[17px] font-bold text-white">Settings</div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-[22px] py-6 pb-28">
        <div className="flex flex-col items-center mb-[30px] w-full relative">
          {/* Cover Photo Container */}
          <div
            onClick={() => {
              if (coverUrl) setShowZoomedCover(true);
            }}
            className="w-full h-32 rounded-2xl relative overflow-hidden bg-gradient-to-r from-[#7c5cff]/20 to-[#20e3a2]/20 border border-[#212a38]/60 group mb-[-46px] z-0 cursor-pointer"
            title={coverUrl ? "Click to Zoom Cover Photo" : "Cover Photo"}
          >
            {coverUrl ? (
              <img loading="lazy" decoding="async"
                src={coverUrl}
                alt="Cover"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
            ) : null}

            {/* Dark overlay on hover */}
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

            {/* Top-Right Edit Icon Button to Change Cover */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                if (coverInputRef.current) coverInputRef.current.value = '';
                coverInputRef.current?.click();
              }}
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 border border-white/20 flex items-center justify-center text-white cursor-pointer active:scale-95 transition-all z-20 shadow-lg"
              title="Change Cover Photo"
            >
              <Edit className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Big Avatar */}
          <div
            onClick={() => { if (fileInputRef.current) fileInputRef.current.value = ''; fileInputRef.current?.click(); }}
            className="w-[96px] h-[96px] rounded-full flex items-center justify-center text-[34px] font-extrabold text-[#06120d] cursor-pointer relative shadow-[0_12px_32px_-8px_rgba(124,92,255,0.4)] select-none group z-10 border-4 border-[#080b10]"
            style={{
              background: currentUser.avatar_url ? 'none' : getAvatarStyle(seed),
            }}
          >
            {currentUser.avatar_url ? (
              <img loading="lazy" decoding="async"
                src={currentUser.avatar_url}
                alt="Profile"
                className="w-full h-full rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              getInitials(currentUser.display_name || currentUser.username || 'V')
            )}

            <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[#1d2531] border-2 border-[#080b10] flex items-center justify-center text-white shadow-md">
              <Edit className="w-3 h-3 text-[#eef1f6]" />
            </div>
          </div>

          <div className="mt-3.5 font-display text-[19px] font-bold text-white leading-tight">
            {currentUser.display_name || currentUser.username}
          </div>
          <div className="mt-0.5 text-[#5a6478] font-mono text-[12.5px]">
            @{currentUser.username} • online
          </div>
        </div>

        {/* Hidden File input for avatar */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          className="hidden"
          accept="image/*"
        />

        {/* Hidden File input for cover photo */}
        <input
          type="file"
          ref={coverInputRef}
          onChange={handleCoverUpload}
          className="hidden"
          accept="image/*"
        />

        {/* Form Fields */}
        <div className="space-y-[22px]">
          <div className="field-group">
            <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
              Display Name
            </label>
            <div className="flex items-center justify-between gap-2.5 bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3 focus-within:border-[#7c5cff] transition-colors">
              <input
                type="text"
                className="w-full bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                onBlur={() => handleUpdateProfile('display_name', displayName)}
              />
              <button
                type="button"
                onClick={() => handleUpdateProfile('display_name', displayName)}
                className="p-1 text-[#20e3a2] hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="Save Display Name"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="field-group">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase block">
                What's on your mind
              </label>
              <span className="text-[10px] text-[#5a6478] font-mono">{thinking.length}/70</span>
            </div>
            <div className="flex items-center justify-between gap-2.5 bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3 focus-within:border-[#7c5cff] transition-colors">
              <input
                type="text"
                maxLength={70}
                placeholder="What's on your mind..."
                className="w-full bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold"
                value={thinking}
                onChange={(e) => setThinking(e.target.value.substring(0, 70))}
                onBlur={() => handleUpdateAboutAndThinking(thinking, about)}
              />
              <button
                type="button"
                onClick={() => handleUpdateAboutAndThinking(thinking, about)}
                className="p-1 text-[#20e3a2] hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="Save Status"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="field-group">
            <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
              About Status
            </label>
            <div className="flex items-center justify-between gap-2.5 bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3 focus-within:border-[#7c5cff] transition-colors">
              <input
                type="text"
                className="w-full bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold"
                value={about}
                onChange={(e) => setAbout(e.target.value)}
                onBlur={() => handleUpdateAboutAndThinking(thinking, about)}
              />
              <button
                type="button"
                onClick={() => handleUpdateAboutAndThinking(thinking, about)}
                className="p-1 text-[#20e3a2] hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="Save About"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="field-group">
            <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
              Bound Phone Number
            </label>
            <div className="flex items-center justify-between gap-2.5 bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3 focus-within:border-[#7c5cff] transition-colors">
              <div className="flex items-center gap-2.5 flex-1">
                <Phone className="w-4 h-4 text-[#5a6478] shrink-0" />
                <input
                  type="tel"
                  placeholder="e.g. +1234567890"
                  className="w-full bg-transparent border-none outline-none text-sm text-[#eef1f6] font-semibold placeholder-[#5a6478]"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  onBlur={() => handleUpdateProfile('phone_number', phoneNumber)}
                />
              </div>
              <button
                type="button"
                onClick={() => handleUpdateProfile('phone_number', phoneNumber)}
                className="p-1 text-[#20e3a2] hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="Save Phone Number"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[10px] text-[#8d97ab] mt-1.5 px-1 font-mono">
              Enables friends to search and discover you via your phone number.
            </p>
          </div>
        </div>

        {/* Bug Report, Feature Suggestions & Review Section */}
        <div className="mt-6 bg-gradient-to-br from-[#7c5cff]/10 via-[#161d28]/80 to-[#20e3a2]/10 border border-[#212a38] rounded-3xl p-5 space-y-3.5 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#ff5470]/15 text-[#ff5470]">
                <Bug className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-white leading-tight">Reports & Review</h4>
                <p className="text-[11px] text-[#8d97ab] mt-0.5">Report bugs, suggest features & review quality</p>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowReviewSubpage(true)}
            className="w-full py-3.5 px-4 rounded-2xl bg-[#161d28] hover:bg-[#1e2736] border border-[#212a38] flex items-center justify-between transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <MessageSquare className="w-4.5 h-4.5 text-[#20e3a2] group-hover:scale-110 transition-transform" />
              <div className="text-left">
                <p className="text-xs font-bold text-white">Submit Bug / Feedback to Devs</p>
                <p className="text-[10px] text-[#8d97ab] font-mono">Ready to email vypervic1@gmail.com</p>
              </div>
            </div>
            <span className="text-xs font-bold text-[#20e3a2] group-hover:translate-x-1 transition-transform flex items-center gap-1">
              Review Subpage →
            </span>
          </button>
        </div>

        {/* Privacy & Read Receipts Card */}
        <div className="mt-6 bg-[#161d28]/60 border border-[#212a38] rounded-3xl p-5 space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#20e3a2]/15 text-[#20e3a2]">
                <CheckCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-white leading-tight">Privacy & Read Receipts</h4>
                <p className="text-[11px] text-[#8d97ab] mt-0.5">Manage delivery status & message read ticks</p>
              </div>
            </div>
          </div>

          {/* Read Receipts Row */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#10151d] border border-[#212a38]/80">
            <div className="space-y-0.5 pr-3 text-left">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">Read Receipts</span>
                <span
                  className={`text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider ${
                    readReceiptsEnabled
                      ? 'bg-[#20e3a2]/15 text-[#20e3a2] border border-[#20e3a2]/30'
                      : 'bg-white/5 text-[#8d97ab] border border-white/10'
                  }`}
                >
                  {readReceiptsEnabled ? 'Active' : 'Off'}
                </span>
              </div>
              <p className="text-[10.5px] text-[#8d97ab] leading-relaxed">
                If turned off, you won't send or receive Read Receipts. Read receipts are always sent for group chats.
              </p>
            </div>

            {/* Toggle Switch */}
            <button
              type="button"
              role="switch"
              aria-checked={readReceiptsEnabled}
              onClick={() => {
                if (readReceiptsEnabled) {
                  setShowReadReceiptModal(true);
                } else {
                  if (onToggleReadReceipts) {
                    onToggleReadReceipts(true);
                  }
                  onToast('Read receipts enabled');
                }
              }}
              className={`w-12 h-6.5 flex items-center rounded-full p-1 transition-colors duration-200 cursor-pointer shrink-0 ${
                readReceiptsEnabled ? 'bg-[#20e3a2]' : 'bg-[#212a38]'
              }`}
              title={readReceiptsEnabled ? 'Turn off read receipts' : 'Turn on read receipts'}
            >
              <div
                className={`bg-[#080b10] w-4.5 h-4.5 rounded-full shadow-md transform transition-transform duration-200 ${
                  readReceiptsEnabled ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Push Notifications & FCM Devices Card */}
        <div className="mt-6 bg-[#161d28]/60 border border-[#212a38] rounded-3xl p-5 space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#7c5cff]/15 text-[#7c5cff]">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-white leading-tight">Push Notifications</h4>
                <p className="text-[11px] text-[#8d97ab] mt-0.5">FCM Background alerts & offline device sync</p>
              </div>
            </div>
            <span
              className={`text-[9px] px-2.5 py-1 rounded-full font-mono font-bold uppercase tracking-wider ${
                permission === 'granted'
                  ? 'bg-[#20e3a2]/15 text-[#20e3a2] border border-[#20e3a2]/30'
                  : permission === 'denied'
                    ? 'bg-[#ff5470]/15 text-[#ff5470] border border-[#ff5470]/30'
                    : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              }`}
            >
              {permission === 'granted' ? 'Enabled' : permission === 'denied' ? 'Blocked' : 'Default'}
            </span>
          </div>

          {/* Action Row */}
          <div className="flex items-center gap-2.5">
            {permission !== 'granted' && (
              <button
                type="button"
                onClick={handleRequestPermission}
                className="flex-1 py-2.5 px-3 rounded-xl bg-[#20e3a2]/15 hover:bg-[#20e3a2]/25 border border-[#20e3a2]/30 text-[#20e3a2] font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Grant Permissions</span>
              </button>
            )}

            <button
              type="button"
              disabled={registeringDevice}
              onClick={handleRegisterDevice}
              className="flex-1 py-2.5 px-3 rounded-xl bg-[#7c5cff] hover:bg-[#7c5cff]/90 text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {registeringDevice ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Smartphone className="w-3.5 h-3.5" />
              )}
              <span>{registeringDevice ? 'Registering...' : 'Register Device (FCM)'}</span>
            </button>
          </div>

          {/* Registered Devices List */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between text-[11px] font-bold text-[#8d97ab] uppercase tracking-wider px-1">
              <span>Registered Devices</span>
              <button
                type="button"
                onClick={loadPushTokens}
                className="p-1 hover:text-white transition-colors cursor-pointer"
                title="Refresh Devices"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingTokens ? 'animate-spin text-[#20e3a2]' : ''}`} />
              </button>
            </div>

            {loadingTokens ? (
              <div className="p-4 bg-[#10151d] rounded-2xl border border-[#212a38] flex items-center justify-center text-xs text-[#8d97ab] gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-[#7c5cff]" />
                <span>Loading devices...</span>
              </div>
            ) : pushTokens.length === 0 ? (
              <div className="p-4 bg-[#10151d] rounded-2xl border border-[#212a38] text-center">
                <p className="text-xs text-[#8d97ab]">No devices registered for push</p>
                <p className="text-[10px] text-[#5a6478] mt-0.5">Click "Register Device (FCM)" to activate alerts</p>
              </div>
            ) : (
              <div className="space-y-2">
                {pushTokens.map((t) => (
                  <div
                    key={t.id}
                    className="flex items-center justify-between p-3 bg-[#10151d] border border-[#212a38] rounded-2xl gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="w-8 h-8 rounded-xl bg-[#212a38] flex items-center justify-center shrink-0 text-[#20e3a2]">
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-white truncate">{t.device_name}</p>
                        <p className="text-[10px] text-[#5a6478] font-mono truncate">
                          {t.fcm_token.substring(0, 18)}...
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setTokenToDeregister({ id: t.id, deviceName: t.device_name })}
                      className="p-1.5 rounded-lg text-[#ff5470] hover:bg-[#ff5470]/10 transition-colors cursor-pointer"
                      title="Deregister device"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Accessibility preferences */}
        <div className="mt-6 bg-[#161d28]/60 border border-[#212a38] rounded-3xl p-5 space-y-3 shadow-lg">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#20e3a2]/15 text-[#20e3a2]"><ShieldCheck className="w-5 h-5" /></div>
            <div>
              <h4 className="font-display font-bold text-sm text-white leading-tight">Accessibility</h4>
              <p className="text-[11px] text-[#8d97ab] mt-0.5">Make long conversations easier to read and navigate</p>
            </div>
          </div>
          <label className="flex items-center justify-between gap-3 rounded-2xl bg-[#10151d] border border-[#212a38] p-3 cursor-pointer">
            <span><span className="block text-xs font-bold text-white">High contrast</span><span className="block text-[10px] text-[#8d97ab]">Strengthen text, borders, and focus indicators.</span></span>
            <input aria-label="Enable high contrast" type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} className="h-4 w-4 accent-[#20e3a2]" />
          </label>
          <label className="flex items-center justify-between gap-3 rounded-2xl bg-[#10151d] border border-[#212a38] p-3 cursor-pointer">
            <span><span className="block text-xs font-bold text-white">Larger text</span><span className="block text-[10px] text-[#8d97ab]">Scale readable interface text without changing layout controls.</span></span>
            <input aria-label="Enable larger text" type="checkbox" checked={largeText} onChange={(e) => setLargeText(e.target.checked)} className="h-4 w-4 accent-[#20e3a2]" />
          </label>
        </div>

        {/* App Theme Selection Card */}
        <div className="mt-6 bg-[#161d28]/60 border border-[#212a38] rounded-3xl p-5 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#7c5cff]/15 text-[#7c5cff]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-display font-bold text-sm text-white leading-tight">App Theme</h4>
              <p className="text-[11px] text-[#8d97ab] mt-0.5">Customize your visual interface</p>
            </div>
          </div>

          {/* Dark / Light Mode Toggle */}
          {(() => {
            const isLightMode = appTheme.startsWith('light');
            const currentBaseTheme = appTheme === 'light' ? 'cosmic' : appTheme.replace('light-', '');

            return (
              <>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#10151d] border border-[#212a38] rounded-2xl">
                  <button
                    type="button"
                    onClick={() => {
                      if (isLightMode) {
                        onUpdateAppTheme(currentBaseTheme);
                      }
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer select-none ${
                      !isLightMode
                        ? 'bg-[#1d2531] text-[#20e3a2] border border-[#20e3a2]/30 shadow-md'
                        : 'text-[#8d97ab] hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-[#20e3a2]" />
                    <span>Dark</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!isLightMode) {
                        onUpdateAppTheme(`light-${currentBaseTheme}`);
                      }
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer select-none ${
                      isLightMode
                        ? 'bg-[#ffffff] text-black border border-white shadow-md'
                        : 'text-[#8d97ab] hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-indigo-600" />
                    <span>Light</span>
                  </button>
                </div>

                {/* 4 Theme Type Cards */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  {/* Liquid Glass */}
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateAppTheme(isLightMode ? 'light-liquid-glass' : 'liquid-glass');
                    }}
                    className={`flex flex-col items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      currentBaseTheme === 'liquid-glass'
                        ? 'border-[#38bdf8] bg-[#10151d] shadow-lg shadow-[#38bdf8]/15 ring-1 ring-[#38bdf8]/40'
                        : 'border-[#212a38] bg-[#10151d] hover:bg-[#161d28]'
                    }`}
                  >
                    <div className="flex gap-1.5 mb-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#030509] border border-white/10" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#38bdf8]" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#818cf8]" />
                    </div>
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider">Liquid Glass</span>
                  </button>

                  {/* Cosmic */}
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateAppTheme(isLightMode ? 'light-cosmic' : 'cosmic');
                    }}
                    className={`flex flex-col items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      currentBaseTheme === 'cosmic'
                        ? 'border-[#20e3a2] bg-[#10151d] shadow-lg shadow-[#20e3a2]/15 ring-1 ring-[#20e3a2]/40'
                        : 'border-[#212a38] bg-[#10151d] hover:bg-[#161d28]'
                    }`}
                  >
                    <div className="flex gap-1.5 mb-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#080b10] border border-white/10" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#20e3a2]" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#7c5cff]" />
                    </div>
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider">Cosmic</span>
                  </button>

                  {/* Solar */}
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateAppTheme(isLightMode ? 'light-solar' : 'solar');
                    }}
                    className={`flex flex-col items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      currentBaseTheme === 'solar'
                        ? 'border-[#00e5ff] bg-[#10151d] shadow-lg shadow-[#00e5ff]/15 ring-1 ring-[#00e5ff]/40'
                        : 'border-[#212a38] bg-[#10151d] hover:bg-[#161d28]'
                    }`}
                  >
                    <div className="flex gap-1.5 mb-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#0b0914] border border-white/10" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#00e5ff]" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#7c5cff]" />
                    </div>
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider">Solar</span>
                  </button>

                  {/* Emerald */}
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateAppTheme(isLightMode ? 'light-emerald' : 'emerald');
                    }}
                    className={`flex flex-col items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                      currentBaseTheme === 'emerald'
                        ? 'border-[#00ff88] bg-[#10151d] shadow-lg shadow-[#00ff88]/15 ring-1 ring-[#00ff88]/40'
                        : 'border-[#212a38] bg-[#10151d] hover:bg-[#161d28]'
                    }`}
                  >
                    <div className="flex gap-1.5 mb-2">
                      <span className="w-3.5 h-3.5 rounded-full bg-[#040706] border border-white/10" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#00ff88]" />
                      <span className="w-3.5 h-3.5 rounded-full bg-[#20e3a2]" />
                    </div>
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider">Emerald</span>
                  </button>
                </div>
              </>
            );
          })()}
        </div>

        {/* ========================================================= */}
        {/* DEVICE LOCAL STORAGE MEDIA MANAGER                       */}
        {/* ========================================================= */}
        <div className="mt-8 bg-[#161d28]/60 border border-[#212a38] rounded-3xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#20e3a2]/15 text-[#20e3a2]">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-white leading-tight">Device Local Storage</h4>
                <p className="text-[11px] text-[#8d97ab] mt-0.5">Media, documents, and web links</p>
              </div>
            </div>
          </div>

          {/* Tabs Splitter: Media, Docs, Voice notes, Links */}
          <div className="grid grid-cols-4 bg-[#080b10]/80 p-1 rounded-2xl border border-[#212a38]/60 gap-1">
            <button
              type="button"
              onClick={() => setActiveStorageTab('media')}
              className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer text-center ${
                activeStorageTab === 'media'
                  ? 'bg-[#7c5cff] text-white shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              Media
            </button>
            <button
              type="button"
              onClick={() => setActiveStorageTab('docs')}
              className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer text-center ${
                activeStorageTab === 'docs'
                  ? 'bg-[#7c5cff] text-white shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              Docs
            </button>
            <button
              type="button"
              onClick={() => setActiveStorageTab('voice')}
              className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer text-center ${
                activeStorageTab === 'voice'
                  ? 'bg-[#7c5cff] text-white shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              Voice notes
            </button>
            <button
              type="button"
              onClick={() => setActiveStorageTab('links')}
              className={`py-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer text-center ${
                activeStorageTab === 'links'
                  ? 'bg-[#7c5cff] text-white shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              Links
            </button>
          </div>

          <div className="space-y-3">
            {localFiles.filter(f => {
              if (activeStorageTab === 'media') {
                return f.fileType !== 'link' && f.fileType !== 'audio/voice-note' && (f.fileType.startsWith('image/') || f.fileType.startsWith('video/'));
              } else if (activeStorageTab === 'docs') {
                return f.fileType !== 'link' && f.fileType !== 'audio/voice-note' && !f.fileType.startsWith('image/') && !f.fileType.startsWith('audio/') && !f.fileType.startsWith('video/');
              } else if (activeStorageTab === 'voice') {
                return f.fileType === 'audio/voice-note' || (f.fileType.startsWith('audio/') && ((f.fileName || '').toLowerCase().includes('voice') || (f.fileName || '').toLowerCase().includes('audio')));
              } else {
                return f.fileType === 'link';
              }
            }).length > 0 ? (
              <div className="max-h-[300px] overflow-y-auto space-y-2.5 pr-1">
                {localFiles
                  .filter(f => {
                    if (activeStorageTab === 'media') {
                      return f.fileType !== 'link' && f.fileType !== 'audio/voice-note' && (f.fileType.startsWith('image/') || f.fileType.startsWith('video/'));
                    } else if (activeStorageTab === 'docs') {
                      return f.fileType !== 'link' && f.fileType !== 'audio/voice-note' && !f.fileType.startsWith('image/') && !f.fileType.startsWith('audio/') && !f.fileType.startsWith('video/');
                    } else if (activeStorageTab === 'voice') {
                      return f.fileType === 'audio/voice-note' || (f.fileType.startsWith('audio/') && ((f.fileName || '').toLowerCase().includes('voice') || (f.fileName || '').toLowerCase().includes('audio')));
                    } else {
                      return f.fileType === 'link';
                    }
                  })
                  .map((file) => {
                    const displayTarget = (!file.targetName || (file.targetName || '').toLowerCase() === 'user' || file.targetName === 'Operator')
                      ? 'Recipient'
                      : file.targetName;

                    const directionLabel = file.direction
                      ? (file.direction === 'to' ? `To ${displayTarget}` : `From ${displayTarget}`)
                      : (file.fileType === 'link' ? 'Web Link' : 'Local File');

                    return (
                      <div
                        key={file.id}
                        onClick={() => {
                          if (file.fileType.startsWith('image/') || file.fileType.startsWith('video/')) {
                            setFullscreenMedia(file);
                          }
                        }}
                        className={`flex items-center justify-between p-3 bg-[#080b10]/60 border border-[#212a38]/60 rounded-2xl gap-3 animate-fade-in ${
                          file.fileType.startsWith('image/') || file.fileType.startsWith('video/') ? 'cursor-pointer hover:border-[#20e3a2]/40' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          {/* Left icon depending on file type */}
                          <div className="w-9 h-9 rounded-xl bg-[#212a38]/80 flex items-center justify-center shrink-0 overflow-hidden">
                            {file.fileType === 'link' ? (
                              <LinkIcon className="w-4 h-4 text-[#20e3a2]" />
                            ) : file.fileType.startsWith('image/') ? (
                              <img loading="lazy" decoding="async" src={file.fileData} className="w-full h-full object-cover" />
                            ) : file.fileType.startsWith('video/') ? (
                              <div className="relative w-full h-full flex items-center justify-center bg-black/40">
                                <Play className="w-3.5 h-3.5 text-white fill-current" />
                              </div>
                            ) : file.fileType === 'audio/voice-note' || file.fileType.startsWith('audio/') ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handlePlayVoiceNote(file);
                                }}
                                className="p-1 rounded-full text-[#20e3a2] hover:bg-[#20e3a2]/15 transition-all cursor-pointer flex items-center justify-center"
                              >
                                {playingAudioId === file.id ? (
                                  <Pause className="w-4 h-4 fill-current animate-pulse" />
                                ) : (
                                  <Play className="w-4 h-4 fill-current ml-0.5" />
                                )}
                              </button>
                            ) : (
                              <Database className="w-4.5 h-4.5 text-[#8d97ab]" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-white truncate">
                              {file.fileName}
                            </p>
                            <p className="text-[10.5px] text-[#20e3a2] font-mono mt-0.5 truncate font-medium">
                              {directionLabel}
                            </p>
                          </div>
                        </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {file.fileType === 'link' ? (
                          <>
                            <button
                              onClick={() => handleCopyLink(file.fileData)}
                              className="p-1.5 rounded-lg text-[#20e3a2] hover:bg-[#20e3a2]/10 transition-colors cursor-pointer"
                              title="Copy URL link"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            <a
                              href={file.fileData}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 rounded-lg text-[#7c5cff] hover:bg-[#7c5cff]/10 transition-colors cursor-pointer"
                              title="Open link in browser"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          </>
                        ) : (
                          <button
                            onClick={() => handleDownloadLocalFile(file)}
                            className="p-1.5 rounded-lg text-[#20e3a2] hover:bg-[#20e3a2]/10 transition-colors cursor-pointer"
                            title="Download to system"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => setFileToDelete({ id: file.id, name: file.fileName })}
                          className="p-1.5 rounded-lg text-[#ff5470] hover:bg-[#ff5470]/10 transition-colors cursor-pointer"
                          title="Delete permanently"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-5 bg-[#080b10]/30 border border-dashed border-[#212a38] rounded-2xl text-center">
                <HardDrive className="w-7 h-7 text-[#5a6478] mx-auto mb-2 opacity-50" />
                <p className="text-xs text-[#8d97ab] font-medium">No items found in this section</p>
                <p className="text-[10.5px] text-[#5a6478] mt-1 max-w-[260px] mx-auto leading-normal">
                  {activeStorageTab === 'media'
                    ? 'All media files and photos are automatically indexed here.'
                    : activeStorageTab === 'docs'
                      ? 'Document uploads, PDFs, and files are cached here.'
                      : activeStorageTab === 'voice'
                        ? 'All recorded voice notes sent and received are saved here.'
                        : 'All hyperlinks parsed from messages are indexed here.'}
                </p>
              </div>
            )}

            {/* Export All Stored Media & Cache Archive button */}
            <div className="pt-2 border-t border-[#212a38]/60 flex items-center justify-between">
              <span className="text-[11px] text-[#8d97ab] font-medium">Backup local database & cached files</span>
              <button
                type="button"
                onClick={async () => {
                  try {
                    const allFiles = await getAllSavedFiles();
                    const exportData = {
                      appName: 'VyperVic Island',
                      exportDate: new Date().toISOString(),
                      user: {
                        id: currentUser.id,
                        username: currentUser.username,
                        display_name: currentUser.display_name,
                        email: currentUser.email,
                      },
                      cachedFilesCount: allFiles.length,
                      cachedFiles: allFiles.map((f) => ({
                        id: f.id,
                        fileName: f.fileName,
                        fileType: f.fileType,
                        savedAt: f.savedAt,
                        direction: f.direction,
                        targetName: f.targetName,
                      })),
                    };

                    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `VyperVic_Backup_${currentUser.username || 'user'}_${new Date().toISOString().slice(0, 10)}.json`;
                    document.body.appendChild(a);
                    a.click();
                    setTimeout(() => {
                      if (document.body.contains(a)) document.body.removeChild(a);
                      URL.revokeObjectURL(url);
                    }, 300);
                    onToast('Workspace archive downloaded');
                  } catch (err) {
                    onToast('Failed to export backup archive');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#20e3a2]/15 hover:bg-[#20e3a2]/25 border border-[#20e3a2]/30 text-[#20e3a2] font-bold text-xs cursor-pointer transition-all active:scale-95 shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Backup</span>
              </button>
            </div>
          </div>
        </div>

        <div className="h-[1px] bg-[#212a38] my-[26px]" />

        {/* Buttons */}
        <div className="space-y-3">
          {isAdmin && onOpenAdminDashboard && (
            <button
              onClick={onOpenAdminDashboard}
              className="w-full flex items-center justify-between px-4 py-3.5 border border-[#20e3a2]/30 bg-[#20e3a2]/10 hover:bg-[#20e3a2]/18 rounded-2xl text-white font-bold text-sm transition-all cursor-pointer shadow-[0_4px_16px_rgba(32,227,162,0.12)]"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4.5 h-4.5 text-[#20e3a2]" />
                <span>Oracle ADB Control Center</span>
              </div>
              <span className="text-[10px] font-mono text-[#20e3a2] bg-[#20e3a2]/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Admin
              </span>
            </button>
          )}

          <button
            onClick={() => setShowConfirmModal('logout')}
            className="w-full flex items-center gap-3 px-4 py-3.5 border border-[#ffb454]/28 bg-[#ffb454]/5 hover:bg-[#ffb454]/10 rounded-2xl text-[#ffb454] font-semibold text-sm transition-colors cursor-pointer"
          >
            <LogOut className="w-4.5 h-4.5" />
            Log out
          </button>

          <button
            onClick={() => setShowConfirmModal('delete')}
            className="w-full flex items-center gap-3 px-4 py-3.5 border border-[#ff5470]/30 bg-[#ff5470]/6 hover:bg-[#ff5470]/12 rounded-2xl text-[#ff5470] font-semibold text-sm transition-colors cursor-pointer"
          >
            <Trash className="w-4.5 h-4.5" />
            Delete account
          </button>

          {isAdmin && (
            <button
              onClick={handleFactoryReset}
              className="w-full flex items-center gap-3 px-4 py-3.5 border border-[#ff5470]/40 bg-[#ff5470]/10 hover:bg-[#ff5470]/20 rounded-2xl text-[#ff5470] font-bold text-sm transition-colors cursor-pointer"
            >
              <Trash2 className="w-4.5 h-4.5" />
              Wipe database & reset all accounts
            </button>
          )}
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="absolute inset-0 bg-[#030509]/72 backdrop-blur-[3px] flex items-center justify-center z-[200]">
          <div className="w-[82%] bg-[#161d28] border border-[#212a38] rounded-[20px] p-5 text-center">
            <h3 className="font-display font-bold text-lg text-white mb-2">
              {showConfirmModal === 'logout' ? 'Log out of VyperVic?' : 'Delete your account?'}
            </h3>
            <p className="text-[#8d97ab] text-[13.5px] leading-relaxed mb-5">
              {showConfirmModal === 'logout'
                ? 'You can always sign back in with your credentials.'
                : 'This permanently removes your profile, chats and settings. This action cannot be undone.'}
            </p>
            {showConfirmModal === 'delete' && <div className="space-y-2 mb-4">
              <input type="password" autoComplete="current-password" aria-label="Current password" placeholder="Current password" value={reauthPassword} onChange={e => setReauthPassword(e.target.value)} className="w-full bg-black/30 rounded-lg p-2 text-white" />
              <input aria-label="Delete confirmation" placeholder="Type DELETE ACCOUNT" value={deleteConfirmation} onChange={e => setDeleteConfirmation(e.target.value)} className="w-full bg-black/30 rounded-lg p-2 text-white" />
            </div>}
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowConfirmModal(null)}
                className="flex-1 py-3 bg-[#1d2531] text-[#eef1f6] rounded-xl font-bold text-sm cursor-pointer hover:bg-opacity-80"
              >
                Cancel
              </button>
              <button
                disabled={deleting || showConfirmModal === 'delete' && (!reauthPassword || deleteConfirmation !== 'DELETE ACCOUNT')}
                onClick={showConfirmModal === 'logout' ? onLogout : handleDeleteAccount}
                className={`flex-1 py-3 text-white rounded-xl font-bold text-sm cursor-pointer flex items-center justify-center gap-1.5 ${
                  showConfirmModal === 'logout' ? 'bg-[#ffb454] text-[#241300]' : 'bg-[#ff5470]'
                }`}
              >
                {deleting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {showConfirmModal === 'logout' ? 'Log out' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* File Deletion Confirmation Modal */}
      {fileToDelete && (
        <div className="absolute inset-0 bg-[#030509]/72 backdrop-blur-[3px] flex items-center justify-center z-[200]">
          <div className="w-[82%] bg-[#161d28] border border-[#212a38] rounded-[20px] p-5 text-center animate-zoom-in">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-3.5 text-[#ff5470]">
              <Trash2 className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-base text-white mb-2">
              Permanently delete this file?
            </h3>
            <p className="text-[#8d97ab] text-xs leading-relaxed mb-5">
              Are you sure you want to delete <span className="text-white font-mono font-bold">"{fileToDelete.name}"</span>? This will permanently erase it from local cache.
            </p>
            <div className="flex gap-2.5">
              <button
                onClick={() => setFileToDelete(null)}
                className="flex-1 py-2.5 bg-[#1d2531] text-[#eef1f6] rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteFile}
                className="flex-1 py-2.5 bg-[#ff5470] text-white rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Token Deregister Confirmation Modal */}
      {tokenToDeregister && (
        <div className="absolute inset-0 bg-[#030509]/72 backdrop-blur-[3px] flex items-center justify-center z-[200]">
          <div className="w-[82%] bg-[#161d28] border border-[#212a38] rounded-[20px] p-5 text-center animate-zoom-in">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-3.5 text-[#ff5470]">
              <Trash2 className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-base text-white mb-2">
              Deregister Device?
            </h3>
            <p className="text-[#8d97ab] text-xs leading-relaxed mb-5">
              Remove push notifications for <span className="text-white font-mono font-bold">"{tokenToDeregister.deviceName}"</span>?
            </p>
            <div className="flex gap-2.5">
              <button
                onClick={() => setTokenToDeregister(null)}
                className="flex-1 py-2.5 bg-[#1d2531] text-[#eef1f6] rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeregisterToken}
                className="flex-1 py-2.5 bg-[#ff5470] text-white rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80"
              >
                Deregister
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Read Receipts Turn Off Confirmation Modal */}
      {showReadReceiptModal && (
        <div className="absolute inset-0 bg-[#030509]/78 backdrop-blur-[3px] flex items-center justify-center z-[200]">
          <div className="w-[86%] max-w-sm bg-[#161d28] border border-[#212a38] rounded-[22px] p-5 text-center animate-zoom-in shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3.5 text-[#ffb454]">
              <EyeOff className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-base text-white mb-2">
              Turn off Read Receipts?
            </h3>

            <div className="bg-[#10151d] border border-amber-500/25 rounded-xl p-3.5 mb-4 text-left">
              <p className="text-amber-300 font-semibold text-xs leading-snug flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>Notice</span>
              </p>
              <p className="text-[#8d97ab] text-[11.5px] mt-1.5 leading-relaxed">
                Once you turn your read receipts off, <strong className="text-white">you can't also see other users' read receipts</strong> on your messages.
              </p>
            </div>

            <p className="text-[10px] text-[#5a6478] font-mono mb-4 text-center">
              Note: Read receipts are always sent for group chats.
            </p>

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setShowReadReceiptModal(false)}
                className="flex-1 py-2.5 bg-[#1d2531] text-[#eef1f6] rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onToggleReadReceipts) {
                    onToggleReadReceipts(false);
                  }
                  onToast('Read receipts disabled');
                  setShowReadReceiptModal(false);
                }}
                className="flex-1 py-2.5 bg-[#ff5470] text-white rounded-xl font-bold text-xs cursor-pointer hover:bg-opacity-80 transition-colors"
              >
                Turn Off
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Zoomed Cover Modal Overlay */}
      {showZoomedCover && coverUrl && (
        <InteractiveImageViewer
          src={coverUrl}
          alt="Cover Photo Zoomed"
          onClose={() => setShowZoomedCover(false)}
        />
      )}

      {/* Fullscreen Media Viewer Modal */}
      {fullscreenMedia && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-[300] flex flex-col justify-between p-4 animate-fade-in">
          {/* Header Bar */}
          <div className="flex items-center justify-between z-10 py-2 border-b border-white/10">
            <button
              onClick={() => setFullscreenMedia(null)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <div className="text-center min-w-0 mx-2">
              <p className="text-xs font-bold text-white truncate max-w-[180px]">
                {fullscreenMedia.fileName}
              </p>
              <p className="text-[10px] text-[#20e3a2] font-mono">
                {fullscreenMedia.direction && fullscreenMedia.targetName
                  ? (fullscreenMedia.direction === 'to' ? `To ${fullscreenMedia.targetName}` : `From ${fullscreenMedia.targetName}`)
                  : 'Media Preview'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDownloadLocalFile(fullscreenMedia)}
                className="p-2 rounded-xl bg-[#20e3a2]/20 hover:bg-[#20e3a2]/30 text-[#20e3a2] transition-all cursor-pointer"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={() => setFileToDelete({ id: fullscreenMedia.id, name: fullscreenMedia.fileName })}
                className="p-2 rounded-xl bg-[#ff5470]/20 hover:bg-[#ff5470]/30 text-[#ff5470] transition-all cursor-pointer"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Media Center */}
          <div className="flex-1 flex items-center justify-center p-2 min-h-0 overflow-hidden relative">
            {fullscreenMedia.fileType.startsWith('video/') ? (
              <video
                src={fullscreenMedia.fileData}
                controls
                autoPlay
                className="max-w-full max-h-[75vh] rounded-2xl shadow-2xl object-contain border border-white/10"
              />
            ) : (
              <InteractiveImageViewer
                src={fullscreenMedia.fileData}
                alt={fullscreenMedia.fileName}
                onClose={() => setFullscreenMedia(null)}
              />
            )}
          </div>
        </div>
      )}

      {/* Review & Bug Report Subpage Modal */}
      {showReviewSubpage && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[350] flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 animate-fade-in">
          <div
            className="w-full sm:max-w-lg bg-[#0d121a] border border-[#212a38] rounded-t-3xl sm:rounded-3xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Subpage Header */}
            <div className="p-4 sm:p-5 border-b border-[#212a38] flex items-center justify-between bg-[#121822]">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowReviewSubpage(false)}
                  className="w-8 h-8 rounded-full bg-[#1b2330] flex items-center justify-center text-[#8d97ab] hover:text-white transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div>
                  <h3 className="font-display font-bold text-sm sm:text-base text-white">
                    Submit Review & Report
                  </h3>
                  <p className="text-[10.5px] text-[#8d97ab] font-mono">
                    Direct dispatcher to vypervic1@gmail.com
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowReviewSubpage(false)}
                className="p-1.5 rounded-xl hover:bg-white/5 text-[#8d97ab] hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Subpage Content */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
              {/* Category Pills */}
              <div>
                <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
                  Feedback Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'bug', label: '🐛 Bug / Error', desc: 'App crash or UI glitch' },
                    { id: 'call_quality', label: '⚡ Call Quality', desc: 'Audio/Video or 3G speed' },
                    { id: 'feature', label: '💡 Feature Request', desc: 'Suggest new capability' },
                    { id: 'suggestion', label: '💬 General Review', desc: 'Thoughts & appraisal' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setReviewCategory(cat.id as any)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        reviewCategory === cat.id
                          ? 'bg-[#20e3a2]/10 border-[#20e3a2] text-white shadow-sm'
                          : 'bg-[#161d28]/60 border-[#212a38] text-[#8d97ab] hover:bg-[#161d28]'
                      }`}
                    >
                      <p className="text-xs font-bold text-white">{cat.label}</p>
                      <p className="text-[10px] text-[#8d97ab] mt-0.5">{cat.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
                  Subject / Summary
                </label>
                <input
                  type="text"
                  placeholder="e.g. Call audio clarity suggestion, or button not clicking"
                  className="w-full bg-[#161d28] border border-[#212a38] rounded-2xl px-4 py-3 text-sm text-[#eef1f6] font-semibold outline-none focus:border-[#7c5cff] transition-colors placeholder-[#5a6478]"
                  value={reviewSubject}
                  onChange={(e) => setReviewSubject(e.target.value)}
                />
              </div>

              {/* Message Details */}
              <div>
                <label className="text-[11px] font-bold tracking-[1.4px] text-[#5a6478] uppercase mb-2 block">
                  Details & Observations
                </label>
                <textarea
                  rows={4}
                  placeholder="Please describe what happened, steps to reproduce, or your idea in detail..."
                  className="w-full bg-[#161d28] border border-[#212a38] rounded-2xl p-4 text-sm text-[#eef1f6] outline-none focus:border-[#7c5cff] transition-colors placeholder-[#5a6478] resize-none"
                  value={reviewMessage}
                  onChange={(e) => setReviewMessage(e.target.value)}
                />
              </div>

              {/* Include Diagnostics Toggle */}
              <div className="flex items-center justify-between bg-[#161d28]/60 border border-[#212a38] rounded-2xl p-3.5">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="w-4 h-4 text-[#20e3a2]" />
                  <div>
                    <p className="text-xs font-bold text-white">Include Device Diagnostics</p>
                    <p className="text-[10px] text-[#8d97ab] font-mono">OS, browser, screen resolution & timestamp</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={includeDiagnostics}
                  onChange={(e) => setIncludeDiagnostics(e.target.checked)}
                  className="w-4 h-4 accent-[#20e3a2] cursor-pointer"
                />
              </div>

              {/* Destination info pill */}
              <div className="flex items-center justify-between px-3 py-2 bg-[#20e3a2]/5 border border-[#20e3a2]/20 rounded-xl text-[11px] text-[#20e3a2]">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5" />
                  <span>Target: <strong>vypervic1@gmail.com</strong></span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText('vypervic1@gmail.com');
                    onToast('Email copied to clipboard!');
                  }}
                  className="p-1 hover:bg-[#20e3a2]/20 rounded transition-colors cursor-pointer"
                  title="Copy email address"
                >
                  <Copy className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Subpage Actions footer */}
            <div className="p-4 sm:p-5 border-t border-[#212a38] bg-[#121822] flex items-center gap-3">
              <button
                type="button"
                onClick={() => setShowReviewSubpage(false)}
                className="flex-1 py-3.5 rounded-2xl border border-[#212a38] hover:bg-white/5 text-xs text-[#8d97ab] font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSendFeedbackEmail}
                disabled={!reviewMessage.trim()}
                className={`flex-1 py-3.5 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg ${
                  reviewMessage.trim()
                    ? 'bg-[#20e3a2] text-black hover:bg-[#20e3a2]/90 active:scale-98'
                    : 'bg-[#212a38] text-[#5a6478] cursor-not-allowed opacity-60'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Open in Email App</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

export default memo(SettingsScreen);
