/** Public configuration only. Safe to import from Vite, browser and server. */
export interface BrowserFirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  vapidKey: string;
}
export const firebaseFields = {
  apiKey: 'API_KEY', authDomain: 'AUTH_DOMAIN', projectId: 'PROJECT_ID',
  storageBucket: 'STORAGE_BUCKET', messagingSenderId: 'MESSAGING_SENDER_ID',
  appId: 'APP_ID', vapidKey: 'VAPID_KEY',
} as const;
export const demoFirebaseConfig: BrowserFirebaseConfig = {
  apiKey: 'demo-local-only', authDomain: 'demo-arena-chatapp.firebaseapp.com',
  projectId: 'demo-arena-chatapp', storageBucket: 'demo-arena-chatapp.appspot.com',
  messagingSenderId: '000000000000', appId: '1:000000000000:web:0000000000000000000000',
  vapidKey: '',
};
export function browserConfig(env: Record<string, unknown>, production: boolean): BrowserFirebaseConfig {
  const configured = Object.entries(firebaseFields).some(([, suffix]) => env[`VITE_FIREBASE_${suffix}`]);
  if (!configured && !production) return { ...demoFirebaseConfig };
  const config = Object.fromEntries(Object.entries(firebaseFields).map(([key, suffix]) =>
    [key, String(env[`VITE_FIREBASE_${suffix}`] || '')]
  )) as unknown as BrowserFirebaseConfig;
  const missing = Object.keys(firebaseFields).filter(key => key !== 'vapidKey' && !config[key as keyof BrowserFirebaseConfig]);
  if (missing.length) throw new Error(`Incomplete browser Firebase configuration: ${missing.join(', ')}`);
  if (!/^\d+$/.test(config.messagingSenderId) || !config.appId.startsWith(`1:${config.messagingSenderId}:web:`)) {
    throw new Error('Firebase app ID and messaging sender ID do not match');
  }
  if (production && config.projectId.startsWith('demo-') && env.VYPER_CI_BUILD !== '1') throw new Error('Demo Firebase projects cannot be deployed');
  if (!/^[a-z0-9-]+$/.test(config.projectId)) throw new Error('Invalid Firebase project ID');
  // Custom Auth domains are allowed, but a Firebase-hosted domain must name this project.
  if (config.authDomain.endsWith('.firebaseapp.com') && config.authDomain !== `${config.projectId}.firebaseapp.com`) {
    throw new Error('Firebase Auth domain and project ID do not match');
  }
  if (env.VITE_FIREBASE_FCM_PROJECT_ID && env.VITE_FIREBASE_FCM_PROJECT_ID !== config.projectId) {
    throw new Error('Split Firebase projects are not supported');
  }
  for (const [field, suffix] of Object.entries(firebaseFields)) {
    const split = env[`VITE_FIREBASE_FCM_${suffix}`];
    if (split && split !== config[field as keyof BrowserFirebaseConfig]) throw new Error(`Split Firebase ${field} configuration`);
  }
  if (production && env.VITE_RUNTIME_MODE !== 'native-android' && !/^[A-Za-z0-9_-]{80,120}$/.test(config.vapidKey)) {
    throw new Error('VITE_FIREBASE_VAPID_KEY is required for browser Web Push');
  }
  return config;
}
