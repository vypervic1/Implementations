export type CallSignalType = 'ready' | 'offer' | 'answer' | 'candidate' | 'hangup';

export interface CallSignal {
  callId: string;
  type: CallSignalType;
  senderId?: string;
  receiverId?: string;
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
  status?: 'ended' | 'rejected' | 'missed';
}

export async function sendCallSignal(signal: CallSignal, clientId?: string | null): Promise<void> {
  const response = await fetch('/api/realtime/signal', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callId: signal.callId, signalData: signal, clientId: clientId || undefined }),
  });
  if (!response.ok) throw new Error(`Call signaling failed (${response.status})`);
}

export async function sendCallHangup(callId: string, status: 'ended' | 'rejected' | 'missed', receiverId?: string, clientId?: string | null) {
  return sendCallSignal({ callId, type: 'hangup', status, receiverId }, clientId);
}
