/** Legacy compatibility shim: Oracle commit plus authenticated SSE is authoritative. */
export async function publishAdminEphemeralMessage(_msg: unknown): Promise<boolean> {
  return true;
}
