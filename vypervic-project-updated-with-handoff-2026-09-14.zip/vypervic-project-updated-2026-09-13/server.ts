import { installAdminRoutes } from './src/server/adminRoutes';
import { startDeliveryWorker } from './src/server/deliveryWorker';
import { installMediaRoutes } from './src/server/metadata';
import { operationControls } from './src/server/operationRoutes';
import { mutationRoute } from './src/server/mutationGate';
import 'dotenv/config';
import 'express-async-errors';
import express, { type Request, type Response, type NextFunction } from 'express';
import path from 'path';
import { randomBytes, randomUUID } from 'crypto';
import { beginDeletionJob, runDeletionJob, getDeletionJob, jobResponse, startDeletionRecovery, assertAccountsWritable } from './src/server/destructiveJobs';
import { readiness, checkReadiness } from './src/server/readiness';
import { startRealtimeBus } from './src/server/realtimeBus';
import { startCallWorker, callWorkerHealth } from './src/server/callWorker';
import { schedulerHealth } from './src/server/scheduler';
import { streamLimiter } from './src/server/rateLimit';
import { ApiError } from './src/server/errors';
import { installTurnRoutes } from './src/server/turn';
import { installOracleRoutes } from './src/server/oracleRoutes';
import { z } from 'zod';
import { installRealtimeRoutes } from './src/server/realtimeRoutes';
import { sessionIsActive, revokeSession, revokeUserSessions } from './src/server/sessionState';
import jwt from 'jsonwebtoken';
import {
  ORACLE_ADB_BASE,
  ALLOWED_TABLES,
  type AllowedTable,
  type ServerProfileRow,
  generateCryptoSalt,
  hashPassword,
  verifyPasswordHash,
  sanitizeProfileForClient,
  lookupProfileByIdentifier,
  fetchProfileByEmail,
  fetchProfileByUsername,
  fetchProfileByPhone,
  normalizePhoneNumber,
  isValidPhoneNumber,
  fetchProfileById,
  fetchRowById,
  fetchRowsByFilter,
  fetchCallById,
  fetchGroupById,
  fetchGroups,
  fetchAllProfiles,
  upsertProfile,
  wipeTable,
  canInteractWith,
  deleteRowsByFilter,
  ordsFetch,
  groupMembers,
  qValueIgnoringCase,
  loadCredentialsForProfile,
  migrateLegacyCredentials,
  saveCredentials,
  deleteCredentials,
  generatePasswordResetToken,
  generatePasswordResetCode,
  PASSWORD_RESET_CODE_TTL_MS,
  storePasswordResetToken,
  consumePasswordResetToken,
  getOrdsApiKey,
  getOrdsOAuthClient,
} from './src/server/oracleBackend';
import { isProduction, resolveCorsOrigin, collectProductionConfigProblems, formatConfigProblems } from './src/server/config';
import {
  loginLimiter,
  signupLimiter,
  passwordResetLimiter,
  pushLimiter,
  oracleProxyLimiter,
  clientIp,
  hashKey,
} from './src/server/rateLimit';
import { sendPushToUsers, getSwFirebaseConfig, validateTokenWithFcm } from './src/server/firebaseAdmin';
import { revokeAllTokensForUser, validatePushToken, registerPushToken, listDevices, revokeTokenById } from './src/server/pushTokenStore';
import {
  storeCallInvite,
  updateCallStatus,
  deleteCall,
  getCallById,
  getActiveRingingCalls,
  memoryCallCount,
} from './src/server/callState';
import { sseClients, broadcastToClients, type SSEClient } from './src/server/realtimeBus';
import { isChatParticipant, isCallParticipant, isNonEmptyString } from './src/server/authz';
import {
  startScheduledMessageWorker,
  createScheduledMessage,
  listScheduledMessages,
  cancelScheduledMessage,
  sendScheduledNow,
} from './src/server/scheduler';
import { sendPasswordResetCodeEmail, sendVerificationEmail, mailerConfigured } from './src/server/mailer';


const app = express();
app.disable('x-powered-by');
// Only trust the reverse proxy networks explicitly configured by the operator.
app.set('trust proxy', process.env.TRUST_PROXY ? process.env.TRUST_PROXY.split(',') : false);
const PORT = Number(process.env.PORT || 3000);

// M-04: request body limits reduced from 50mb. 5mb accommodates base64
// media in message/file payloads while bounding request-handling memory
// and the DoS surface of the generic proxy.
const BODY_LIMIT = '5mb';
// JSON-only APIs. Reject cross-site cookie writes before executing any operation.
app.use('/api', (req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  const requestId = randomUUID();
  res.setHeader('X-Request-ID', requestId);
  res.locals.requestId = requestId;
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    const origin = req.get('origin');
    const sameOrigin = origin === `${req.protocol}://${req.get('host')}`;
    if ((origin && !sameOrigin && !resolveCorsOrigin(origin)) || req.get('sec-fetch-site') === 'cross-site') {
      return res.status(403).json({ error: 'Origin not allowed' });
    }
    if (req.headers['content-length'] !== '0' && req.headers['content-type'] && !req.is('application/json')) {
      return res.status(415).json({ error: 'JSON content type required' });
    }
  }
  next();
});

app.use(express.json({ limit: BODY_LIMIT }));

// =========================================================================
// PRODUCTION CONFIG VALIDATION (H-05/H-07/C-02) — fail closed
// =========================================================================
if (isProduction()) {
  const problems = collectProductionConfigProblems();
  if (problems.length > 0) {
    console.error(formatConfigProblems(problems));
    process.exit(1);
  }
}

// =========================================================================
// JWT SESSION AUTH (server-owns the identity decision — Issue 2)
// H-07: production REQUIRES a strong JWT_SECRET (validated above); the dev
// fallback stays ephemeral+labeled so `npm run dev` keeps working.
// The token is delivered to browsers in an HttpOnly SameSite cookie (see
// setSessionCookie) — JavaScript can no longer read the session token;
// the Authorization: Bearer path remains for API clients.
// =========================================================================
const JWT_SECRET: string =
  process.env.JWT_SECRET ||
  (() => {
    console.warn(
      '[Auth] JWT_SECRET is not set. Using an ephemeral secret — every restart invalidates all sessions. ' +
        'Set JWT_SECRET in the environment (see .env.example). Production refuses to start without it.'
    );
    return randomBytes(32).toString('hex');
  })();

const JWT_EXPIRES_IN: jwt.SignOptions['expiresIn'] = '30d'; // must not exceed shared revocation retention
const SESSION_COOKIE = 'vyper_session';

interface AuthUser {
  sub: string; // profile id
  role: 'admin' | 'user';
  email?: string;
  username?: string;
  jti: string;
  exp: number;
  authTime: number;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

function signTokenForProfile(profile: { id: string; role?: string | null; email?: string | null; username?: string | null }): string {
  return jwt.sign(
    {
      sub: profile.id,
      jti: randomUUID(),
      authTime: Date.now(),
      role: profile.role === 'admin' ? 'admin' : 'user',
      email: profile.email || undefined,
      username: profile.username || undefined,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function verifyToken(token: string | undefined | null): AuthUser | null {
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
    if (typeof decoded === 'string' || typeof decoded.sub !== 'string' || typeof decoded.jti !== 'string' || typeof decoded.exp !== 'number' || typeof decoded.authTime !== 'number') return null;
    return {
      sub: String(decoded.sub),
      jti: decoded.jti, exp: decoded.exp, authTime: decoded.authTime,
      role: decoded.role === 'admin' ? 'admin' : 'user',
      email: decoded.email ? String(decoded.email) : undefined,
      username: decoded.username ? String(decoded.username) : undefined,
    };
  } catch (e) {
    return null;
  }
}

function extractBearer(req: Request): string | null {
  const header = req.headers.authorization || '';
  if (header.startsWith('Bearer ')) return header.slice(7);
  return null;
}

function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie;
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const name = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (name) { try { out[name] = decodeURIComponent(value); } catch { /* malformed cookie is unauthenticated */ } }
  }
  return out;
}

/** H-07: session tokens live in HttpOnly Secure SameSite cookies. */
function setSessionCookie(res: Response, token: string): void {
  const secure = isProduction() || process.env.COOKIE_SECURE === 'true';
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${secure ? '; Secure' : ''}; Max-Age=${30 * 24 * 3600}`
  );
}

function clearSessionCookie(res: Response): void {
  const secure = isProduction() || process.env.COOKIE_SECURE === 'true';
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax${secure ? '; Secure' : ''}; Max-Age=0`);
}

async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = extractBearer(req) || parseCookies(req)[SESSION_COOKIE] || null;
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const user = verifyToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  if (!(await sessionIsActive(user))) return res.status(401).json({ error: 'Session revoked or expired' });
  const profile = await fetchProfileById(user.sub);
  if (!profile) { clearSessionCookie(res); return res.status(401).json({ error: 'Account no longer exists' }); }
  // All authorization uses the current database role, not a stale JWT claim.
  user.role = profile.role === 'admin' ? 'admin' : 'user';
  req.user = user;
  const recovery = req.path === '/api/auth/reauth' || req.path === '/api/account/delete' || req.path === '/api/admin/wipe-all' || /^\/api\/(account|admin)\/operations\//.test(req.path);
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !recovery) await assertAccountsWritable([user.sub]);
  next();
}

/**
 * M-08 / H-01 / H-02: for ADMIN and other destructive operations the JWT
 * role claim alone is not enough — a demoted admin could keep a valid 30-day
 * token. requireFreshAdmin re-checks the CURRENT database role before the
 * operation proceeds (fail closed on lookup failure).
 */
async function requireFreshAdminProfile(userId: string): Promise<ServerProfileRow | null> {
  try {
    const profile = await fetchProfileById(userId);
    if (!profile) return null;
    if (String(profile.role || '') !== 'admin') return null;
    return profile;
  } catch (e) {
    return null; // fail closed
  }
}

async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden: admin role required' });
  }
  const fresh = await requireFreshAdminProfile(req.user.sub);
  if (!fresh) {
    return res.status(403).json({ error: 'Forbidden: admin role could not be verified against the current database record' });
  }
  next();
}

// =========================================================================
// AUTH ENDPOINTS (the server — not the browser — verifies passwords)
// G-02: all credential endpoints are rate limited per-IP AND
// per-identifier, with exponential lockout after repeated failures.
// =========================================================================

app.post('/api/auth/login', mutationRoute(async (req, res) => {
  const identifier = String(req.body?.identifier ?? req.body?.email ?? '').trim();
  const password = String(req.body?.password ?? '');
  if (!identifier || !password || identifier.length > 254 || password.length > 1024) {
    return res.status(400).json({ error: 'Missing credentials' });
  }

  // G-02: throttle by IP and by targeted identifier (hashed in the key so
  // limiter state doesn't leak account names).
  const ipKey = hashKey('login:ip', clientIp(req));
  const idKey = hashKey('login:id', identifier.toLowerCase());
  const gate = await loginLimiter.consumeBoth(ipKey, idKey);
  if (!gate.allowed) {
    res.setHeader('Retry-After', String(gate.retryAfterSec));
    return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many attempts. Please wait before trying again.' });
  }

  try {
    const profile: ServerProfileRow | null = await lookupProfileByIdentifier(identifier);
    const credentials = profile ? await loadCredentialsForProfile(profile) : null;
    if (!profile || !credentials) {
      // Deliberately does not reveal whether the account exists.
      // Accounts without a stored hash cannot log in: re-seed the password
      // out of band (see scripts/seed-admin.ts) instead.
      await loginLimiter.recordFailure(idKey);
      await loginLimiter.recordFailure(ipKey);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // G-06: timing-safe verification. Malformed stored hashes fail closed.
    if (!verifyPasswordHash(password, credentials.password_salt, credentials.password_hash)) {
      await loginLimiter.recordFailure(idKey);
      await loginLimiter.recordFailure(ipKey);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await loginLimiter.recordSuccess(idKey);
    await loginLimiter.recordSuccess(ipKey);

    // H-06: migrate legacy ABOUT-packed verifiers into the server-only
    // USER_CREDENTIALS table and strip the tag from the profile text.
    if (profile.password_hash && !(await migrateLegacyCredentials(profile))) throw new ApiError(503, 'Credential migration could not complete');

    const token = signTokenForProfile(profile);
    setSessionCookie(res, token);

    // Best-effort presence update (server-side, never blocks the login)
    try {
      await ordsFetch(`/profiles/${encodeURIComponent(profile.id)}`, { method: 'PATCH', body: { IS_ONLINE: 1, LAST_SEEN: new Date().toISOString() } });
    } catch (e) {
      /* presence is non-critical */
    }

    res.json({ ...(req.get('X-Session-Mode') === 'bearer' ? { token } : {}), user: sanitizeProfileForClient(profile) });
  } catch (err: any) {
    console.error('[Auth] Login error:', err?.message);
    return res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

app.post('/api/auth/signup', mutationRoute(async (req, res) => {
  const email = String(req.body?.email ?? '').trim().toLowerCase();
  const password = String(req.body?.password ?? '');
  const username = String(req.body?.username ?? '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  const displayName = String(req.body?.display_name ?? '').trim() || username;
  const phoneNumber = normalizePhoneNumber(req.body?.phone_number);

  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }
  if (username.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters and alphanumeric' });
  }
  if (phoneNumber && !isValidPhoneNumber(phoneNumber)) {
    return res.status(400).json({ error: 'A valid phone number is required to create an account.' });
  }
  if (!password || password.length < 6 || password.length > 1024) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }
  if (email.length > 254 || username.length > 100 || displayName.length > 255 || (phoneNumber && phoneNumber.length > 100)) {
    return res.status(400).json({ error: 'One of the provided values is too long.' });
  }

  const ipKey = hashKey('signup:ip', clientIp(req));
  const gate = await signupLimiter.consume(ipKey);
  if (!gate.allowed) {
    res.setHeader('Retry-After', String(gate.retryAfterSec));
    return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many signup attempts. Please try again later.' });
  }

  try {
    await assertAccountsWritable([]);
    // G-05: targeted exact-match duplicate lookups (the old fetch-all-500
    // silently missed every profile beyond row 500).
    const emailDup = await fetchProfileByEmail(email);
    if (emailDup) {
      return res.status(409).json({ error: 'An account with this email already exists. Please sign in instead.' });
    }
    const usernameDup = await fetchProfileByUsername(username);
    if (usernameDup) {
      return res.status(409).json({ error: 'Username is already taken. Please choose another username.' });
    }

    const phoneDup = await fetchProfileByPhone(phoneNumber);
    if (phoneDup) {
      return res.status(409).json({ error: 'An account with this phone number already exists. Please sign in instead.' });
    }
    const id = `usr_${randomBytes(12).toString('hex')}`;
    const salt = generateCryptoSalt();
    const hash = hashPassword(password, salt);

    // New sign-ups are ALWAYS plain users. Admin accounts are provisioned
    // out of band only (scripts/seed-admin.ts) or by an existing admin via
    // POST /api/admin/promote-user. The old self-service admin backdoor is gone.
    const profile: ServerProfileRow = {
      id,
      email,
      username,
      display_name: displayName,
      phone_number: phoneNumber,
      about: 'Hey there! I am using VyperVic.',
      avatar_url: null,
      is_online: true,
      last_seen: new Date().toISOString(),
      created_at: new Date().toISOString(),
      role: 'user',
      password_hash: hash,
      password_salt: salt,
    };

    const ok = await upsertProfile(profile);
    if (!ok) {
      return res.status(502).json({ error: 'Could not create the account in the database. Please try again.' });
    }

    // G-03: the app-level check above is friendly, but the DB unique
    // constraints (UQ_PROFILES_EMAIL / UQ_PROFILES_USERNAME) are
    // authoritative for concurrent signups. If the constraints rejected the
    // insert, ORDS would have failed the write above; double-check and
    // convert the race into an honest 409 instead of a half-created account.
    const raceEmail = await fetchProfileByEmail(email);
    const raceUsername = await fetchProfileByUsername(username);
    const racePhone = await fetchProfileByPhone(phoneNumber);
    if (raceEmail && raceEmail.id !== id) {
      await ordsFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'DELETE', timeoutMs: 8000 });
      return res.status(409).json({ error: 'An account with this email already exists. Please sign in instead.' });
    }
    if (raceUsername && raceUsername.id !== id) {
      await ordsFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'DELETE', timeoutMs: 8000 });
      return res.status(409).json({ error: 'Username is already taken. Please choose another username.' });
    }

    if (racePhone && racePhone.id !== id) {
      await ordsFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'DELETE', timeoutMs: 8000 });
      return res.status(409).json({ error: 'An account with this phone number already exists. Please sign in instead.' });
    }
    // H-06: verifiers go to the server-only credentials table — never into
    // the profile ABOUT text.
    if (!(await saveCredentials(id, hash, salt))) {
      const rollback = await ordsFetch(`/profiles/${encodeURIComponent(id)}`, { method: 'DELETE' });
      if (!rollback.ok) console.error('[Auth] Signup rollback requires operator recovery', { userId: id });
      throw new ApiError(503, 'Could not save account credentials; please retry');
    }

    const token = signTokenForProfile(profile);
    setSessionCookie(res, token);

    res.json({ ...(req.get('X-Session-Mode') === 'bearer' ? { token } : {}), user: sanitizeProfileForClient(profile) });
  } catch (err: any) {
    if (err instanceof ApiError) return res.status(err.status).json({ error: err.message, code: err.code });
    console.error('[Auth] Sign-up persistence failed');
    return res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

app.post('/api/auth/reauth', requireAuth, async (req, res) => {
  const parsed = z.object({ password: z.string().min(1).max(1024) }).strict().safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'Current password is required');
  const user = req.user!;
  const gate = await loginLimiter.consumeBoth(hashKey('reauth:ip', clientIp(req)), hashKey('reauth:user', user.sub));
  if (!gate.allowed) { res.setHeader('Retry-After', String(gate.retryAfterSec)); return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Reauthentication temporarily unavailable' }); }
  const profile = await fetchProfileById(user.sub);
  const credentials = profile && await loadCredentialsForProfile(profile);
  if (!credentials || !verifyPasswordHash(parsed.data.password, credentials.password_salt, credentials.password_hash)) {
    await loginLimiter.recordFailure(hashKey('reauth:user', user.sub)); throw new ApiError(401, 'Current password is incorrect');
  }
  await revokeSession(user);
  const token = signTokenForProfile(profile!);
  setSessionCookie(res, token);
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, mutationRoute(async (req, res) => {
  const profile = await fetchProfileById(req.user!.sub);
  if (!profile) return res.status(401).json({ error: 'Account no longer exists' });
  res.json({ user: sanitizeProfileForClient(profile), role: profile.role === 'admin' ? 'admin' : 'user' });
}));

app.post('/api/auth/logout', async (req, res) => {
  const user = verifyToken(extractBearer(req) || parseCookies(req)[SESSION_COOKIE]);
  if (user) {
    await revokeSession(user);
    const deviceId = req.body?.deviceId;
    if (typeof deviceId === 'string' && /^[A-Za-z0-9_-]{16,128}$/.test(deviceId)) {
      const cleanup = await deleteRowsByFilter('user_push_tokens', { USER_ID: user.sub, DEVICE_ID: deviceId });
      if (cleanup.failed) throw new ApiError(503, 'Device revocation pending');
    }
  }
  clearSessionCookie(res);
  res.json({ ok: true });
});

app.post('/api/auth/reauthenticate', requireAuth, mutationRoute(async (req, res) => {
  const gate = await loginLimiter.consumeBoth(hashKey('reauth:ip', clientIp(req)), hashKey('reauth:user', req.user!.sub));
  if (!gate.allowed) { res.setHeader('Retry-After', String(gate.retryAfterSec)); return res.status(429).json({ error: 'Try again later' }); }
  const profile = await fetchProfileById(req.user!.sub);
  const credentials = profile && await loadCredentialsForProfile(profile);
  const password = req.body?.password;
  if (!credentials || typeof password !== 'string' || password.length > 1024 || !verifyPasswordHash(password, credentials.password_salt, credentials.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  await revokeSession(req.user!);
  setSessionCookie(res, signTokenForProfile(profile!));
  res.json({ ok: true });
}));

function requireRecentAuth(req: Request, res: Response, next: NextFunction) {
  if (Date.now() - req.user!.authTime > 10 * 60_000) return res.status(403).json({ error: 'Recent password verification required', code: 'reauthentication_required' });
  next();
}

// =========================================================================
// ACCOUNT RECOVERY (R-01) — real password reset + verification resend
// ------------------------------------------------------------------------
// The old resetPasswordForEmail/resend client methods returned
// { error: null } while doing NOTHING — the UI reported success that never
// happened. Real flows now live here:
//   * single-use, expiring numeric codes stored server-side (PASSWORD_RESETS)
//   * email delivery via the configured provider (RESEND_API_KEY)
//   * responses never reveal whether an account exists
//   * honest 503 when email delivery is not configured
// =========================================================================

function appBaseUrl(): string {
  return (process.env.APP_URL || '').replace(/\/+$/, '');
}

app.post('/api/auth/reset-password', mutationRoute(async (req, res) => {
  const identifier = String(req.body?.email ?? req.body?.identifier ?? '').trim();
  if (!identifier) {
    return res.status(400).json({ error: 'Please provide your email, username or phone number.' });
  }

  const ipKey = hashKey('reset:ip', clientIp(req));
  const idKey = hashKey('reset:id', identifier.toLowerCase());
  const gate = await passwordResetLimiter.consumeBoth(ipKey, idKey);
  if (!gate.allowed) {
    res.setHeader('Retry-After', String(gate.retryAfterSec));
    return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many reset requests. Please try again later.' });
  }

  if (!mailerConfigured()) return res.status(503).json({ error: 'Account recovery delivery is unavailable' });
  try {
    const profile = await lookupProfileByIdentifier(identifier);
    const email = profile?.email ? String(profile.email) : null;
    if (!profile || !email || !email.includes('@')) {
      // Do not reveal whether the account exists.
      return res.json({ ok: true, message: 'If an account exists for that address, a verification code has been sent.' });
    }

    const code = generatePasswordResetCode();
    const stored = await storePasswordResetToken(profile.id, code, 'reset', PASSWORD_RESET_CODE_TTL_MS);
    if (!stored) {
      return res.status(503).json({ error: 'Could not start the reset right now. Please try again.' });
    }

    const mail = await sendPasswordResetCodeEmail(email, code);
    if (!mail.delivered) {
      // Honest failure (never a fake success) — plus an operator fallback
      // in the server logs so recovery is still possible without email.
      console.warn('[Auth] Password reset delivery unavailable');
      return res.status(503).json({ error: 'Email delivery is temporarily unavailable. Please try again shortly or contact support.' });
    }

    res.json({ ok: true, message: 'If an account exists for that address, a verification code has been sent.' });
  } catch (err: any) {
    console.error('[Auth] reset-password error:', err?.message);
    res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

app.post('/api/auth/reset-password/confirm', mutationRoute(async (req, res) => {
  const token = String(req.body?.code ?? req.body?.token ?? '').trim();
  const password = String(req.body?.password ?? '');
  if (!/^(?:\d{6}|[a-f0-9]{64})$/i.test(token)) return res.status(400).json({ error: 'Enter the six-digit verification code.' });
  if (!password || password.length < 6 || password.length > 1024) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }

  const ipKey = hashKey('resetconfirm:ip', clientIp(req));
  const gate = await passwordResetLimiter.consume(ipKey);
  if (!gate.allowed) {
    res.setHeader('Retry-After', String(gate.retryAfterSec));
    return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many attempts. Please wait and try again.' });
  }

  try {
    const consumed = await consumePasswordResetToken(token, 'reset');
    if (!consumed) {
      return res.status(400).json({ error: 'This verification code is invalid, expired, or has already been used.' });
    }
    const profile = await fetchProfileById(consumed.userId);
    if (!profile) {
      return res.status(400).json({ error: 'This verification code is invalid or expired.' });
    }
    await assertAccountsWritable([profile.id]);
    const salt = generateCryptoSalt();
    const hash = hashPassword(password, salt);
    const saved = await saveCredentials(profile.id, hash, salt);
    if (saved) await revokeUserSessions(profile.id);
    if (!saved) {
      return res.status(503).json({ error: 'Could not update the password. Please try again.' });
    }
    // Strip any legacy credential tag still sitting in ABOUT (H-06).
    const cleanAbout = String(profile.about || 'Hey there! I am using VyperVic.')
      .replace(/\[auth:[a-f0-9]+:[a-f0-9]+\]/g, '')
      .replace(/\s{2,}/g, ' ')
      .trim() || 'Hey there! I am using VyperVic.';
    await ordsFetch(`/profiles/${encodeURIComponent(profile.id)}`, {
      method: 'PATCH',
      body: { ABOUT: cleanAbout },
      timeoutMs: 8000,
    }).catch(() => {});
    console.warn(`[Auth] Password reset completed for profile ${profile.id}`);
    res.json({ ok: true, message: 'Password updated. You can now sign in with your new password.' });
  } catch (err: any) {
    console.error('[Auth] reset-password/confirm error:', err?.message);
    res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

app.post('/api/auth/resend-verification', mutationRoute(async (req, res) => {
  const email = String(req.body?.email ?? '').trim().toLowerCase();
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Please provide a valid email address.' });
  }

  const ipKey = hashKey('verify:ip', clientIp(req));
  const idKey = hashKey('verify:id', email);
  const gate = await passwordResetLimiter.consumeBoth(ipKey, idKey);
  if (!gate.allowed) {
    res.setHeader('Retry-After', String(gate.retryAfterSec));
    return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many requests. Please try again later.' });
  }

  try {
    const profile = await fetchProfileByEmail(email);
    if (!profile) {
      // Do not reveal whether the account exists.
      return res.json({ ok: true, message: 'If an account exists for that address, a verification email has been sent.' });
    }
    const token = generatePasswordResetToken();
    const stored = await storePasswordResetToken(profile.id, token, 'verify');
    if (!stored) {
      return res.status(503).json({ error: 'Could not start the verification right now. Please try again.' });
    }
    const verifyUrl = `${appBaseUrl() || 'http://localhost:3000'}/?verify=${encodeURIComponent(token)}`;
    const mail = await sendVerificationEmail(email, verifyUrl);
    if (!mail.delivered) {
      console.warn(`[Auth] Verification email for profile ${profile.id} could not be sent (${mail.reason}).`);
      return res.status(503).json({ error: 'Email delivery is temporarily unavailable. Please try again shortly.' });
    }
    res.json({ ok: true, message: 'If an account exists for that address, a verification email has been sent.' });
  } catch (err: any) {
    console.error('[Auth] resend-verification error:', err?.message);
    res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

app.post('/api/auth/verify-email', mutationRoute(async (req, res) => {
  const token = String(req.body?.token ?? '').trim();
  if (!token) return res.status(400).json({ error: 'Verification token is required.' });
  try {
    const consumed = await consumePasswordResetToken(token, 'verify');
    if (!consumed) {
      return res.status(400).json({ error: 'This verification link is invalid, expired, or has already been used.' });
    }
    res.json({ ok: true, message: 'Email verified. Thank you!' });
  } catch (err: any) {
    console.error('[Auth] verify-email error:', err?.message);
    res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
  }
}));

// =========================================================================
// 1. Health check endpoint (public, no user data)
// =========================================================================

app.get('/api/health', (req, res) => {
  res.json({
    status: isProduction() && !readiness.ready ? 'degraded' : 'ok',
    activeConnections: sseClients.size,
    activeCallsMemory: memoryCallCount(),
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/ready', async (_req, res) => {
  try { if (Date.now() - readiness.lastCheckedAt > 60000) await checkReadiness(); }
  catch { readiness.ready = false; }
  // Background workers retry independently; they must not take the HTTP/SSE
  // service out of readiness while Oracle/Redis and the listener are healthy.
  const lagging = false;
  res.status(readiness.ready && !lagging ? 200 : 503).json({ status: readiness.ready && !lagging ? 'ready' : 'unavailable' });
});

// =========================================================================
// 2. Real-time SSE stream — authenticated (Issue 7)
// Identity is taken from the verified token (cookie or ?token=***, since
// EventSource cannot set headers). G-07: the wildcard CORS policy is gone —
// only origins on the APP_URL/CORS_ORIGIN allowlist receive a CORS grant;
// everything else is same-origin only (no CORS header needed).
// =========================================================================

app.get('/api/realtime/stream', requireAuth, async (req, res) => {
  if (req.query.token || req.query.access_token) return res.status(400).json({ error: 'URL credentials are not supported' });
  const gate = await streamLimiter.consumeBoth(hashKey('stream:ip', clientIp(req)), hashKey('stream:user', req.user!.sub));
  if (!gate.allowed || [...sseClients.values()].filter(c => c.userId === req.user!.sub).length >= 5) {
    res.setHeader('Retry-After', String(gate.retryAfterSec || 15)); return res.status(429).json({ error: 'Too many stream connections' });
  }
  // G-07: origin allowlist — no more 'Access-Control-Allow-Origin: *'.
  const origin = req.headers.origin;
  if (origin) {
    let allowed = resolveCorsOrigin(String(origin));
    if (!allowed && !isProduction()) { try { if (new URL(String(origin)).host === req.get('host')) allowed = String(origin); } catch { /* invalid origin */ } }
    if (!allowed) {
      return res.status(403).json({ error: 'Origin not allowed' });
    }
    res.setHeader('Access-Control-Allow-Origin', allowed);
    res.setHeader('Vary', 'Origin');
  }

  const user = req.user!;
  const userId = user.sub; // force identity — ignore any client-supplied userId
  const clientId = `client_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  res.write(`event: connected\ndata: ${JSON.stringify({ clientId, status: 'connected' })}\n\n`);

  const client: SSEClient = { id: clientId, userId, res };
  sseClients.set(clientId, client);

  // Keep-alive heartbeat every 15s to maintain connection through proxies
  const heartbeat = setInterval(async () => {
    try {
      if (!(await sessionIsActive(user))) { res.end(); clearInterval(heartbeat); sseClients.delete(clientId); return; }
      res.write(`event: heartbeat\ndata: ${Date.now()}\n\n`);
    } catch (e) {
      clearInterval(heartbeat);
      sseClients.delete(clientId);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    sseClients.delete(clientId);
  });
});

// =========================================================================
// 3b. Realtime event integrity
// ------------------------------------------------------------------------
// Endpoint authentication alone is not enough: any authenticated user
// could otherwise send arbitrary events. Every broadcast is:
//   1. checked against a strict event allowlist (unknown event -> 400)
//   2. validated against a per-event payload schema (malformed -> 400)
//   3. authorized against the database (chat membership / call
//      participation / message ownership / DM+group relationship)
//   4. stamped with the sender identity from the verified JWT — client-
//      supplied senderId / caller_id / receiver_id are never trusted.
// All checks fail closed.
// =========================================================================

installRealtimeRoutes(app, requireAuth);

// 4. Query active calls in real-time (authenticated only).
// M-02: backed by the Oracle lifecycle with a VPS hot projection for low-latency reads.
app.get('/api/realtime/active-calls', requireAuth, async (req, res) => {
  try {
    const calls = await getActiveRingingCalls();
    res.json({ calls: calls.filter(call => call.caller_id === req.user!.sub || call.receiver_id === req.user!.sub || call.receiver_id === 'general') });
  } catch (e: any) {
    res.status(503).json({ error: 'Durable call storage unavailable' });
  }
});

// Single-call lookup (used by clients to resolve ringing state)
app.get('/api/realtime/active-calls/:callId', requireAuth, async (req, res) => {
  const call = await getCallById(String(req.params.callId || ''));
  if (!call) {
    return res.status(404).json({ error: 'Call not found' });
  }
  const user = req.user!;
  const participant =
    call.caller_id === user.sub ||
    call.receiver_id === user.sub ||
    call.receiver_id === 'general';
  if (!participant) {
    return res.status(403).json({ error: 'Forbidden: not a participant of this call' });
  }
  res.json({ call });
});

// =========================================================================
// 5. FCM Push Notification Endpoints (authenticated — Issue 7)
// C-04: registration binds the token to the VERIFIED user; tokens are
// persisted durably (M-03); registration/send are rate limited; payloads
// are validated and display data is derived server-side.
// =========================================================================

app.post('/api/push/register-token', requireAuth, mutationRoute(async (req, res) => {
  const gate = await pushLimiter.consumeBoth(hashKey('push:reg:ip', clientIp(req)), hashKey('push:reg:user', req.user!.sub));
  if (!gate.allowed) { res.setHeader('Retry-After', String(gate.retryAfterSec)); return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Registration rate limit exceeded' }); }
  const parsed = z.object({ token: z.string(), deviceType: z.string(), source: z.string().optional(), deviceId: z.string().regex(/^[A-Za-z0-9_-]{16,128}$/).optional(), deviceName: z.string().max(100).optional(), userId: z.unknown().optional() }).strict().safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'Invalid token registration');
  const data = parsed.data;
  const valid = validatePushToken(data.token, data.deviceType, data.source);
  if (valid.ok === false) throw new ApiError(400, valid.error);
  if (!await validateTokenWithFcm(valid.token)) throw new ApiError(400, 'FCM did not validate this registration token');
  // userId is intentionally ignored: only the verified session binds the device.
  const saved = await registerPushToken(req.user!.sub, valid.token, valid.deviceType, { ...data, source: valid.source, session: req.user! });
  if (!saved) throw new ApiError(503, 'Durable push registration unavailable');
  res.json({ success: true, source: valid.source });
}));
app.get('/api/push/devices', requireAuth, async (req, res) => res.json({ items: await listDevices(req.user!.sub) }));
app.delete('/api/push/devices/:id', requireAuth, mutationRoute(async (req, res) => {
  await revokeTokenById(req.user!.sub, req.params.id);
  res.json({ success: true });
}));
app.post('/api/push/send', requireAuth, mutationRoute(async (req, res) => {
  const gate = await pushLimiter.consumeBoth(hashKey('push:send:ip', clientIp(req)), hashKey('push:send:user', req.user!.sub));
  if (!gate.allowed) { res.setHeader('Retry-After', String(gate.retryAfterSec)); return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Push rate limit exceeded' }); }
  const id = z.string().regex(/^[A-Za-z0-9_:-]{1,255}$/);
  const parsed = z.object({
    targetUserId: id.optional(), targetUserIds: z.array(id).max(20).optional(), title: z.string().max(200), body: z.string().max(500),
    chatId: id.optional(), callId: id.optional(), type: z.enum(['message', 'call', 'mention']).default('message'),
    senderId: z.string().optional(), senderName: z.string().optional(), avatarUrl: z.string().optional(),
  }).strict().safeParse(req.body);
  if (!parsed.success || JSON.stringify(req.body).length > 3500) throw new ApiError(400, 'Invalid push payload');
  const data = parsed.data;
  const targets = [...new Set([...(data.targetUserIds || []), ...(data.targetUserId ? [data.targetUserId] : [])])];
  if (!targets.length || targets.length > 20) throw new ApiError(400, 'Between 1 and 20 targets required');
  if (data.chatId && !(await isChatParticipant(data.chatId, req.user!.sub))) throw new ApiError(403, 'Not a chat member');
  if (data.type === 'call' && !data.callId) throw new ApiError(400, 'Call ID is required');
  const call = data.callId ? await fetchCallById(data.callId) : null;
  if (data.callId && (!call || call.caller_id !== req.user!.sub || call.status !== 'ringing')) throw new ApiError(403, 'Only the caller of a ringing call may notify');
  // Reject the WHOLE request if any target is unauthorized; do not silently send to a subset.
  for (const target of targets) {
    if (!(await canInteractWith(req.user!.sub, target)) || data.chatId && !(await isChatParticipant(data.chatId, target)) || call && call.receiver_id !== target) throw new ApiError(403, 'Unauthorized push recipient');
  }
  const profile = await fetchProfileById(req.user!.sub);
  if (!profile) throw new ApiError(401, 'Account not found');
  const senderName = profile.display_name || profile.username || 'Vyper user';
  const result = await sendPushToUsers({ ...data, targetUserIds: targets,
    title: data.type === 'call' ? `Incoming call from ${senderName}` : senderName,
    senderId: req.user!.sub, senderName, avatarUrl: profile.avatar_url || undefined });
  res.status(result.success ? 200 : 503).json(result);
}));

// =========================================================================
// 6. ADMIN ENDPOINTS (JWT role-verified + FRESH database role re-check —
//    Issues 3 & 4, M-08, H-02)
// =========================================================================

const operations = operationControls(JWT_SECRET);
operations.install(app, requireAuth, requireAdmin, requireRecentAuth);

app.post('/api/admin/wipe-all', requireAuth, requireAdmin, requireRecentAuth, async (req, res) => {
  const body = z.object({ confirmation: z.literal('WIPE ALL DATA'), operationId: z.string().regex(/^wipe_[a-f0-9-]{36}$/).optional() }).strict().safeParse(req.body);
  if (!body.success) throw new ApiError(400, 'Explicit WIPE ALL DATA confirmation is required');
  await operations.submit(req, res, 'wipe', undefined, body.data.operationId);
});
app.get('/api/admin/operations/:id', requireAuth, requireAdmin, async (req, res) => {
  const job = await getDeletionJob(req.params.id);
  if (!job) throw new ApiError(404, 'Unknown operation');
  res.json(jobResponse(job));
});
app.post('/api/admin/operations/:id/retry', requireAuth, requireAdmin, requireRecentAuth, async (req, res) => {
  if (req.body?.confirmation !== 'RETRY DELETION') throw new ApiError(400, 'Explicit retry confirmation required');
  const job = await getDeletionJob(req.params.id);
  if (!job) throw new ApiError(404, 'Unknown operation');
  operations.accepted(res, job, req.user!.sub);
});

app.post('/api/admin/promote-user', requireAuth, requireAdmin, requireRecentAuth, mutationRoute(async (req, res) => {
  const userId = String(req.body?.userId ?? '').trim();
  if (!userId) {
    res.status(400).json({ error: 'userId is required' });
    return;
  }
  try {
    const profile = await fetchProfileById(userId);
    if (!profile) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    await assertAccountsWritable([userId]);
    const updated = await ordsFetch(`/profiles/${encodeURIComponent(userId)}`, { method: 'PATCH', body: { ROLE: 'admin' } });
    const ok = updated.ok;
    if (!ok) {
      res.status(502).json({ error: 'Failed to update the user role in the database' });
      return;
    }
    res.json({ success: true, userId });
  } catch (err: any) {
    console.error('[Admin] Promote error:', err?.message);
    res.status(503).json({ error: 'Database temporarily unavailable' });
  }
}));

// =========================================================================
// 6b. ACCOUNT DELETION — server-side, identity-scoped (Remaining Finding 1)
// ------------------------------------------------------------------------
// The old client-side deleteUserAccount() listed EVERY row of `calls` and
// deleted each one — one account deletion erased unrelated users' call
// history. Deletion is now a single authenticated server operation:
//   * the account comes from the verified JWT (self by default); a
//     client-supplied target is honored ONLY for admins whose CURRENT
//     database role is admin (M-08),
//   * only the account's own rows are deleted: calls where it is the
//     caller OR the receiver, messages it sent, its push tokens, its
//     credentials, and the profile row,
//   * deletes are batched, paginated, awaited, and reported honestly.
// =========================================================================

app.post('/api/account/delete', requireAuth, requireRecentAuth, async (req, res) => {
  const user = req.user!;
  const rawTarget = typeof req.body?.targetUserId === 'string' ? req.body.targetUserId : user.sub;
  if (rawTarget !== user.sub && !(await requireFreshAdminProfile(user.sub))) throw new ApiError(403, 'Only a current admin may delete another account');
  if (req.body?.confirmation !== 'DELETE ACCOUNT') throw new ApiError(400, 'Explicit DELETE ACCOUNT confirmation is required');
  await operations.submit(req, res, 'account', rawTarget);
});

app.get('/api/account/operations/:id', requireAuth, async (req, res) => {
  const job = await getDeletionJob(req.params.id);
  if (!job || job.kind !== 'account' || job.target_id !== req.user!.sub) throw new ApiError(404, 'Unknown operation');
  res.json(jobResponse(job));
});
app.post('/api/account/operations/:id/retry', requireAuth, requireRecentAuth, async (req, res) => {
  const job = await getDeletionJob(req.params.id);
  if (!job || job.kind !== 'account' || job.target_id !== req.user!.sub) throw new ApiError(404, 'Unknown operation');
  if (req.body?.confirmation !== 'RETRY DELETION') throw new ApiError(400, 'Explicit retry confirmation required');
  operations.accepted(res, job, req.user!.sub);
});

// =========================================================================
// 6c. SCHEDULED MESSAGES API (M-06) — server-backed scheduler
// ------------------------------------------------------------------------
// Schedules live in the server-only SCHEDULED_MESSAGES table and are
// delivered by the server worker (atomic claims, idempotent message ids,
// retry with cap). localStorage is now only an offline display cache.
// =========================================================================

app.get('/api/scheduler/messages', requireAuth, async (req, res) => {
  try {
    const rows = await listScheduledMessages(req.user!.sub);
    // Never leak other users' rows and cap payload size (file_data can be
    // large — it stays server-side; clients only need the metadata).
    res.json({
      items: rows.map((r) => ({
        id: r.id,
        chat_id: r.chat_id,
        recipient_id: r.recipient_id,
        text: r.text,
        file_name: r.file_name,
        file_type: r.file_type,
        is_voice: r.is_voice,
        scheduled_for: r.scheduled_for,
        status: r.status,
        attempts: r.attempts,
        created_at: r.created_at,
      })),
    });
  } catch (err: any) {
    console.warn('[Scheduler] list error:', err?.message);
    res.status(503).json({ error: 'Scheduler temporarily unavailable' });
  }
});

app.post('/api/scheduler/messages', requireAuth, oracleProxyLimiterMiddleware(), mutationRoute(async (req, res) => {
  const parsed = z.object({ chat_id: z.string().max(255), recipient_id: z.string().max(255).nullable().optional(),
    text: z.string().max(8000).nullable().optional(), file_name: z.string().max(500).nullable().optional(), file_type: z.string().max(255).nullable().optional(),
    file_data: z.string().max(4000000).nullable().optional(), is_voice: z.boolean().optional(), scheduled_for: z.string().datetime({ offset: true }),
  }).strict().safeParse(req.body);
  if (!parsed.success) throw new ApiError(400, 'Invalid scheduled message');
  const user = req.user!;
  const chatId = String(req.body?.chat_id ?? req.body?.chatId ?? '').trim();
  const recipientId = req.body?.recipient_id ? String(req.body.recipient_id) : null;
  const scheduledForRaw = String(req.body?.scheduled_for ?? req.body?.scheduledFor ?? '');

  if (!isNonEmptyString(chatId)) {
    return res.status(400).json({ error: 'chat_id is required' });
  }
  if (!(await isChatParticipant(chatId, user.sub))) {
    return res.status(403).json({ error: 'Forbidden: you are not a member of this chat' });
  }
  if (recipientId) {
    const dmOk =
      chatId === `dm:${user.sub}:${recipientId}` || chatId === `dm:${recipientId}:${user.sub}`;
    if (!dmOk) {
      return res.status(403).json({ error: 'Forbidden: recipient does not match the chat' });
    }
  }

  const result = await createScheduledMessage({
    userId: user.sub,
    chatId,
    recipientId,
    text: req.body?.text != null ? String(req.body.text) : null,
    fileName: req.body?.file_name ? String(req.body.file_name).slice(0, 500) : null,
    fileType: req.body?.file_type ? String(req.body.file_type).slice(0, 255) : null,
    fileData: req.body?.file_data ? String(req.body.file_data) : null,
    isVoice: !!req.body?.is_voice,
    scheduledFor: new Date(scheduledForRaw),
  });

  if (result.ok === false) {
    return res.status(result.status).json({ error: result.error });
  }
  res.json({ ok: true, item: { ...result.row, file_data: undefined } });
}));

app.delete('/api/scheduler/messages/:id', requireAuth, mutationRoute(async (req, res) => {
  const result = await cancelScheduledMessage(req.user!.sub, String(req.params.id || ''));
  if (!result.ok) {
    return res.status(result.status).json({ error: result.error || 'Could not cancel' });
  }
  res.json({ ok: true });
}));

app.post('/api/scheduler/messages/:id/send-now', requireAuth, mutationRoute(async (req, res) => {
  const result = await sendScheduledNow(req.user!.sub, String(req.params.id || ''));
  if (!result.ok) {
    return res.status(result.status).json({ error: result.error || 'Could not deliver' });
  }
  res.json({ ok: true });
}));

function isProductionAdmin(user: { role: string }): boolean {
  return user.role === 'admin';
}

// =========================================================================
// 6d. SERVICE-WORKER FIREBASE CONFIG (Remaining Finding 4)
// ------------------------------------------------------------------------
// The service worker (public/firebase-messaging-sw.js) fetches its config
// from here at startup — the SAME server env that configures Firebase
// Admin — so all surfaces (browser default app, FCM app, service worker,
// admin) are pointed at one canonical project per environment.
// PUBLIC WEB CONFIG ONLY — no private keys, ever.
// =========================================================================

app.get('/api/firebase/sw-config', (req, res) => {
  res.json(getSwFirebaseConfig());
});

// =========================================================================
// 7. Oracle Autonomous Database ORDS proxy — FULLY AUTHENTICATED, SCOPED
//    (Issue 4, G-01, M-04)
// ------------------------------------------------------------------------
// Browsers can no longer reach Oracle directly; every request here carries
// a verified JWT and is checked against the caller's row scope BEFORE being
// forwarded. G-01 closes the biggest remaining gap: READS on messages,
// calls and groups are now authorization-scoped too (previously only
// writes were).
// =========================================================================

installAdminRoutes(app, requireAuth, requireAdmin, requireRecentAuth, oracleProxyLimiterMiddleware());
installMediaRoutes(app, requireAuth);
installTurnRoutes(app, requireAuth, oracleProxyLimiterMiddleware());
installOracleRoutes(app, requireAuth, oracleProxyLimiterMiddleware());

// Rate limiter wrapper that never blocks admins' table access on lockout
// and always returns 429 with Retry-After.
function oracleProxyLimiterMiddleware() {
  return async (req: Request, res: Response, next: NextFunction) => {
    const result = await oracleProxyLimiter.consumeBoth(hashKey('proxy:ip', clientIp(req)), hashKey('proxy:user', req.user?.sub || 'anonymous'));
    if (!result.allowed) {
      res.setHeader('Retry-After', String(result.retryAfterSec));
      res.status(result.reason === 'unavailable' ? 503 : 429).json({ error: 'Too many requests. Please slow down.' });
      return;
    }
    next();
  };
}

app.use('/api', (_req, res) => res.status(404).json({ error: 'API endpoint not found' }));
app.use((error: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
  const status = error instanceof ApiError ? error.status : [400, 409, 413, 415, 429].includes(error.status || 0) ? error.status! : 503;
  console.error('[API] Request failed', { requestId: res.locals.requestId, code: error instanceof ApiError ? error.code : error.name, status });
  res.status(status).json({ error: error instanceof ApiError ? error.message : status === 413 ? 'Request too large' : status < 500 ? 'Request could not be completed' : 'Service temporarily unavailable', code: error instanceof ApiError ? error.code : 'request_failed', requestId: res.locals.requestId });
});

// =========================================================================
// STATIC / DEV SERVER
// =========================================================================

async function startServer() {
  if (isProduction()) {
    try {
      await checkReadiness();
    } catch (error: any) {
      // Readiness remains fail-closed, but an external quota outage must not
      // make the HTTP server unavailable for health checks or recovery.
      console.error('[Startup] Continuing in degraded mode:', error?.message || error);
    }
  }
  try {
    await Promise.race([
      startRealtimeBus(),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error('Realtime bus startup timed out')), 5000)),
    ]);
  } catch (error: any) {
    console.error('[Startup] Realtime bus unavailable; continuing without shared delivery:', error?.message || error);
  }
  if (!isProduction()) {
    let worker: string | undefined;
    app.get('/firebase-messaging-sw.js', async (_req, res) => {
      if (!worker) {
        const { build } = await import('esbuild');
        const result = await build({ entryPoints: ['src/firebaseMessagingWorker.ts'], bundle: true, platform: 'browser', format: 'iife', write: false,
          define: { __VYPER_FIREBASE_CONFIG__: JSON.stringify(getSwFirebaseConfig()) } });
        worker = result.outputFiles[0].text;
      }
      res.setHeader('Cache-Control', 'no-cache'); res.type('application/javascript').send(worker);
    });
  }
  app.use((req, res, next) => {
    const resource = decodeURIComponent(req.path);
    if (/\.(cjs|map|sql|env)$/i.test(resource) || resource.includes('/src/server/') || /\/server\.ts$/i.test(resource)) return res.status(404).end();
    next();
  });
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    // Serve browser assets only. Node bundles, source maps and server sources are never public.
    app.use('/assets', express.static(path.join(distPath, 'assets'), { index: false, immutable: true, maxAge: '1y' }));
    app.get('/firebase-messaging-sw.js', (_req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(distPath, 'firebase-messaging-sw.js')); });
    app.use(express.static(path.join(process.cwd(), 'public'), { index: false, dotfiles: 'deny' }));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, process.env.HOST || (isProduction() ? '127.0.0.1' : '0.0.0.0'), () => {
    console.log(`Vyper Messenger Server running on port ${PORT}`);
    const ordsAuthMode = process.env.ORDS_OAUTH_CLIENT_ID
      ? 'OAuth2 client-credentials ON (auto token refresh)'
      : process.env.ORDS_API_KEY
        ? 'static API key auth ON'
        : 'NO ORDS-level credential set — enable ORDS auth in OCI (see oracle_wipe_and_reset.sql)';
    console.log(`Oracle ORDS backend: ${ORACLE_ADB_BASE} (${ordsAuthMode})`);
    startScheduledMessageWorker();
    startDeletionRecovery();
    startCallWorker();
    startDeliveryWorker();
  });
}

// Auto-start unless running under the test runner (tests import `app`).
if (!process.env.VITEST && !process.env.ARENA_TEST) {
  startServer();
}

export { app, startServer };
