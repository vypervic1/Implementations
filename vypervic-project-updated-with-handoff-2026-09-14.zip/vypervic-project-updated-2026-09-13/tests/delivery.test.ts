import { beforeEach, expect, it, vi } from 'vitest';
const transport = vi.hoisted(() => ({ send: vi.fn() }));
vi.mock('../src/server/firebaseAdmin', async original => ({ ...await original<typeof import('../src/server/firebaseAdmin')>(), sendPushToUsers: transport.send }));
import { getApp, login, seedUser, resetAllTables, authHeader, allRows, getRow } from './helpers';
import { runDeliveryPass } from '../src/server/deliveryWorker';
let app: Awaited<ReturnType<typeof getApp>>, alice: ReturnType<typeof seedUser>, bob: ReturnType<typeof seedUser>, token: string;
beforeEach(async()=>{
 resetAllTables();app=await getApp();alice=seedUser();bob=seedUser();token=(await login(app,alice.email,alice.password)).token!;
 const b=(await login(app,bob.email,bob.password)).token!;
 expect((await app.post('/api/push/register-token').set(authHeader(b)).send({token:'b'.repeat(150),deviceType:'web',source:'web_fcm',deviceId:'bob-real-format-test-device'})).status).toBe(200);
 transport.send.mockReset();transport.send.mockResolvedValue({success:true,successCount:1,failureCount:0});
});
async function create() {return app.post(`/api/chats/dm:${alice.id}:${bob.id}/messages`).set(authHeader(token)).send({id:'durable-delivery',text:'Hello',is_voice:false});}
it('message persistence creates one transactional delivery intent, including an idempotent retry',async()=>{
 expect((await create()).status).toBe(201);expect((await create()).status).toBe(201);
 expect(allRows('messages')).toHaveLength(1);expect(allRows('delivery_outbox')).toHaveLength(1);expect(transport.send).not.toHaveBeenCalled();
 await runDeliveryPass();expect(transport.send).toHaveBeenCalledTimes(1);expect(allRows('delivery_outbox')[0].STATUS).toBe('sent');
 await runDeliveryPass();expect(transport.send).toHaveBeenCalledTimes(1);
});
it('keeps failed delivery durable and reuses the event id on retry',async()=>{
 await create();transport.send.mockResolvedValueOnce({success:false,error:'Provider down'});
 await runDeliveryPass();const job=allRows('delivery_outbox')[0];expect(job.STATUS).toBe('queued');expect(job.ATTEMPTS).toBe(1);
 job.NEXT_ATTEMPT_AT=new Date(Date.now()-1000).toISOString();await runDeliveryPass();
 expect(getRow('delivery_outbox',job.ID)!.STATUS).toBe('sent');
 expect(transport.send.mock.calls[0][0].eventId).toBe(transport.send.mock.calls[1][0].eventId);
});
it('recovers a stale sending claim after restart without creating another message',async()=>{
 await create();const row=allRows('delivery_outbox')[0];row.STATUS='sending';row.UPDATED_AT=new Date(Date.now()-121000).toISOString();
 await runDeliveryPass();expect(allRows('messages')).toHaveLength(1);expect(allRows('delivery_outbox')[0].STATUS).toBe('sent');
});
it('rechecks the source before sending a queued notification',async()=>{
 await create();expect((await app.delete('/api/messages/durable-delivery').set(authHeader(token))).status).toBe(200);
 await runDeliveryPass();expect(transport.send).not.toHaveBeenCalled();expect(allRows('delivery_outbox')[0].STATUS).toBe('cancelled');
});
