import type { Response } from 'express';
import { randomUUID } from 'node:crypto';
import { fetchGroupById, fetchCallById, groupMembers } from './oracleBackend';
import { getRedis } from './sharedStore';
import { ApiError } from './errors';
export interface SSEClient { id: string; userId?: string; res: Response }
export const sseClients = new Map<string, SSEClient>();
export interface Audience { chatId?: string; callId?: string; userIds?: string[] }
export async function resolveAudience(scope: Audience): Promise<string[] | 'authenticated'> {
  if (scope.userIds) return Array.from(new Set(scope.userIds));
  if (scope.chatId === 'general') return 'authenticated';
  if (scope.chatId?.startsWith('dm:')) {
    const parts = scope.chatId.split(':');
    if (parts.length === 3 && parts[1] && parts[2] && parts[1] !== parts[2]) return parts.slice(1);
  }
  if (scope.chatId?.startsWith('group:')) {
    const group = await fetchGroupById(scope.chatId) || await fetchGroupById(scope.chatId.slice(6));
    if (group) return groupMembers(group);
  }
  if (scope.callId) {
    const call = await fetchCallById(scope.callId);
    if (call) return call.receiver_id === 'general' ? 'authenticated' : [call.caller_id, call.receiver_id];
  }
  throw new ApiError(403, 'Unverifiable realtime audience');
}
interface Envelope { id: string; instance: string; event: string; payload: unknown; recipients: string[] | 'authenticated'; excludeClientId?: string }
const instance = randomUUID();
const TOPIC = 'vyper:realtime:v1';
function deliver(envelope: Envelope): number {
  let delivered = 0;
  if (JSON.stringify(envelope.payload).length > 256000) envelope = { ...envelope, event: 'reconcile', payload: {} };
  const data = `id: ${envelope.id}\nevent: ${envelope.event}\ndata: ${JSON.stringify(envelope.payload)}\n\n`;
  for (const [id, client] of sseClients) {
    if (!client.userId || id === envelope.excludeClientId || envelope.recipients !== 'authenticated' && !envelope.recipients.includes(client.userId)) continue;
    if (client.res.writableLength > 1_000_000) { client.res.end(); sseClients.delete(id); continue; }
    try { client.res.write(data); delivered++; } catch { client.res.end(); sseClients.delete(id); }
  }
  return delivered;
}
let subscriber: Awaited<ReturnType<typeof getRedis>>;
export async function startRealtimeBus(): Promise<void> {
  const redis = await getRedis();
  if (!redis || subscriber) return;
  subscriber = redis.duplicate({ socket: { connectTimeout: 3000, reconnectStrategy: attempt => Math.min(30000, 500 * 2 ** Math.min(attempt, 6)) } });
  subscriber.on('ready', () => deliver({ id: randomUUID(), instance, event: 'reconcile', payload: {}, recipients: 'authenticated' }));
  subscriber.on('error', () => console.error('[Realtime] Shared delivery unavailable; clients must reconcile'));
  await subscriber.connect();
  await subscriber.subscribe(TOPIC, raw => {
    try { const envelope = JSON.parse(raw) as Envelope; if (envelope.instance !== instance) deliver(envelope); }
    catch { console.error('[Realtime] Invalid internal event'); }
  });
}
export async function publishScopedEvent(event: string, payload: unknown, scope: Audience, options: { targetUserId?: string; excludeClientId?: string } = {}): Promise<number> {
  let recipients = await resolveAudience(scope);
  if (options.targetUserId) {
    if (recipients !== 'authenticated' && !recipients.includes(options.targetUserId)) throw new ApiError(403, 'Target is outside the event scope');
    recipients = [options.targetUserId];
  }
  if (JSON.stringify(payload).length > 256000) { event = 'reconcile'; payload = {}; }
  const envelope: Envelope = { id: randomUUID(), instance, event, payload, recipients, excludeClientId: options.excludeClientId };
  const count = deliver(envelope);
  try { const redis = await getRedis(); if (redis) await redis.publish(TOPIC, JSON.stringify(envelope)); }
  catch { console.error('[Realtime] Shared publish failed; authoritative reconciliation required'); }
  return count;
}
/** Compatibility helper: there is deliberately NO unscoped broadcast default. */
export function broadcastToClients(event: string, payload: unknown, filter?: { excludeClientId?: string; targetUserId?: string }): number {
  if (!filter?.targetUserId) throw new Error('Realtime requires an explicit audience');
  return deliver({ id: randomUUID(), instance, event, payload, recipients: [filter.targetUserId], excludeClientId: filter.excludeClientId });
}
export const sendToUser = (userId: string, event: string, payload: unknown) => publishScopedEvent(event, payload, { userIds: [userId] });

export async function stopRealtimeBus(): Promise<void> {
  if (subscriber?.isOpen) await subscriber.quit();
  subscriber = null;
}
