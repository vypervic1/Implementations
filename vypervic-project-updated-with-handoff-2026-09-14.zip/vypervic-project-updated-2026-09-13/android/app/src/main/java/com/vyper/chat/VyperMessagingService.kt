package com.vyper.chat

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class VyperMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        getSharedPreferences("push", MODE_PRIVATE).edit().putString("token", token).apply()
        TokenRegistrationWorker.enqueue(this)
    }
    override fun onMessageReceived(message: RemoteMessage) {
        if (!getSharedPreferences("push", MODE_PRIVATE).getBoolean("session_bound", false)) return
        val data = message.data
        if (data["type"] !in listOf("message", "mention", "call")) return
        val eventId = (data["eventId"] ?: message.messageId)?.takeIf { it.matches(Regex("^[A-Za-z0-9_:-]{1,255}$")) } ?: return
        if (NotificationHistory.seen(this, eventId)) return
        val isCall = data["type"] == "call"
        // Late call invitations must not ring after their server-side ringing deadline.
        if (isCall && System.currentTimeMillis() - message.sentTime > 30_000) return
        val idPattern = Regex("^[A-Za-z0-9_:-]{1,255}$")
        val chatId = data["chatId"]?.takeIf(idPattern::matches)
        val callId = data["callId"]?.takeIf(idPattern::matches)
        if (isCall && callId == null) return
        val target = Uri.parse(BuildConfig.APP_ORIGIN).buildUpon().path("/")
        chatId?.let { target.appendQueryParameter("chat", it) }
        callId?.let { target.appendQueryParameter("call", it) }
        val intent = Intent(this, MainActivity::class.java).setData(target.build())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val notificationId = eventId.hashCode()
        val pending = PendingIntent.getActivity(this, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, if (isCall) "vyper_calls" else "vyper_messages")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle((data["title"] ?: "Vyper").take(200))
            .setContentText((data["body"] ?: "New notification").take(500))
            .setPriority(if (isCall) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (isCall) NotificationCompat.CATEGORY_CALL else NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true).setOnlyAlertOnce(true).setContentIntent(pending).setNumber(1)
        if (isCall) builder.setTimeoutAfter(30000).addAction(R.drawable.ic_notification, "Open call", pending)
        // Not a full-screen intent: Android policy/user settings decide heads-up behavior.
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(this).notify(notificationId, builder.build())
            NotificationHistory.record(this, eventId)
        }
        MainActivity.foregroundPush(data)
    }
}
