# Staging acceptance — must be executed, not inferred

Status: **not executed against live Oracle/Firebase/VPS or physical Android devices in this workspace**. Use isolated staging accounts/data, protected environment variables and sanitized logs. Never paste credentials or raw device tokens into an issue/chat. Record commit/build, environment/project/database, device/OS/WebView versions and evidence for each check.

## 1. Incident and configuration gate

- [ ] Revoke/replace the historical Firebase key; confirm old-key authentication is denied; audit its use.
- [ ] Clean all affected history/archives/references/caches and rerun full-history gitleaks/private-material scans.
- [ ] One explicit Firebase project/sender/database across web, worker, Auth, Admin and Android; no demo/partial/split configs. Deliberate mismatch/missing credentials stops production.
- [ ] Verify least-privilege IAM, ORDS OAuth/gateway grants, private Redis, approved proxy/admin networks, HTTPS, mail sender and private TURN.
- [ ] Apply reviewed additive SQL, including migration 003 and its epoch-fenced gateway/trigger grants; deploy actual rules/indexes/TTLs; restore a backup into a separate environment.

## 2. Real Oracle contract and authentication

- [ ] From outside the VPS, every direct ORDS application table rejects unauthenticated access with 401. Do not print response bodies containing private data if a test fails.
- [ ] Real client-credentials token acquisition, caching, expiration and one 401 refresh/retry work. Bad credentials/timeouts fail without credential or URL leakage.
- [ ] Authenticated create/read/update/delete and unique-constraint conflicts work with actual ORDS column casing, CLOB/JSON, nulls, numeric booleans and canonical UTC timestamp formats.
- [ ] Read/delete more than every configured page size, including a server page cap below the requested limit; no skipped/repeated pages or infinite no-progress loop.
- [ ] Parallel normalized username/email signup yields one account and HTTP 409 for the loser. No orphan credentials/profile is reported as a successful signup.
- [ ] A reset email reaches a real inbox; its token expires and is single-use. Legacy migration cannot roll back the reset password.

## 3. Authorization, session and stream abuse

- [ ] User A cannot read/delete user B/C's private messages/calls, alter roles/credentials/immutable IDs, inject filter operators/extra columns, or reach server-only tables.
- [ ] Push/broadcast sender identity is derived server-side; one unauthorized recipient rejects the entire explicit send. Nested forged call/message/group fields cannot create state or change membership/lifecycle.
- [ ] Demote an admin while a session is open: every admin/destructive endpoint rechecks the database role. Reauthentication and literal confirmation are required where documented.
- [ ] Run `npm run test:rules` inside the Firestore emulator; verify actual deployed rules match. Test foreign sessions, changed caller/receiver/path/retention, oversized signaling, lifecycle mutations, unrestricted presence and outbox access.
- [ ] No application JWT in localStorage or SSE URLs. Revoked/expired cookie sessions cannot use API/streams; Firebase account/session gates and push session bindings stop previously issued credentials appropriately.
- [ ] Disconnect/kill a VPS instance, interrupt SSE and Redis pub/sub, reconnect with backoff and verify missed Oracle rows reconcile. Test simultaneous instances and slow consumers; no unscoped private fan-out.

## 4. Durable messaging and workers

- [ ] Send offline with a stable ID and real attachment bytes, kill/restart the app, then reconnect. Confirm one Oracle row, a cleared acknowledged outbox entry and no placeholder attachment.
- [ ] Test quota/IndexedDB transaction failure, 4xx/5xx/timeout, retry caps and dead-letter presentation. No pending item is rendered as a confirmed send.
- [ ] Schedule on device A; view/cancel/send on B. Kill workers before/after claim, after message/notification-intent commit and before sent checkpoint. Run two workers: exactly one message ID survives.
- [ ] Restart real durable call/token storage and exercise independent instances. Configured storage outages must not switch to process memory.
- [ ] Crash/retry edge claims, race workers and retry publish. Lifecycle must not reset; failed/expired records and orphaned delivery copies must be bounded. Unrelated collections remain untouched.
- [ ] Observe cleanup after all clients are closed and validate TTL types/index readiness/health alerts, not only a successful function invocation.

## 5. Physical signed Android candidate

- [ ] Build, lint, test and sign the correct flavor using the protected configuration. Inspect APK contents for private credentials/direct ORDS URLs. Register its real signing fingerprint and verified App Links.
- [ ] Log in once, background, swipe away, kill process and reboot. Verify cookies, DOM/IndexedDB, account restoration, pending outbox and revocation/expiry/logout behavior.
- [ ] Obtain a real FCM token, validate/register it, rotate it and revoke it from another device. No synthetic token or saved-session identity may be accepted as proof.
- [ ] Foreground/background/process-dead message and incoming-call notifications render once on `vyper_messages`/`vyper_calls`; sound/vibration/badge and permission-denial behavior match settings. Distinguish process death from Android force-stop/OEM restrictions.
- [ ] Tap notifications while closed, open and already in a call; only authorized chat/call targets open and existing media is not destroyed by an unnecessary reload. Test expired call invitations.
- [ ] Camera/mic denial, retry/revocation, both device orientations, keyboard/system insets and WebView navigation isolation. Repeat mount/unmount/navigation and check media tracks, recorders, peer connections, listeners, timers and blob URLs.
- [ ] Direct audio/video on separate mobile/Wi-Fi networks; test TURN UDP, TCP and TLS, credential expiry/renewal, network changes, ICE restart and honest timeout/failure states. Ongoing background/Telecom calls and group calls are not implemented; do not count them as passing features.
- [ ] Measure cold/warm startup, JS/network bytes, memory and data usage on a low-end device/slow network. The automated compressed-JS budget alone is not device performance acceptance.

## 6. Destructive operations and operations

- [ ] Create unrelated A/B and C/D calls/messages. Delete A with explicit confirmation/recent password; preserve C/D and verify the intended retention policy for other authors' content.
- [ ] Inject failures after each checkpoint; restart/retry; reconcile exact counts and profile-last behavior. Test already-in-flight concurrent writers, not only requests started after the job flag.
- [ ] Run a quiesced all-data wipe beyond a full page, interrupt it, recover it, inspect retained audit/operation records and verify accurate partial/completed reporting. An HTTP timeout or 401 is not a completion receipt.
- [ ] Verify firewall/SSH/admin restrictions, secret rotation procedure, encrypted backup restoration, restart policies, alert delivery and incident response.

Release requires reviewed evidence for every applicable boundary. Local mocks, an emulator pass, a debug APK or an accepted FCM API request are not proof of end-to-end delivery or production readiness.

## Additional follow-up cases

- [ ] Delay a `/me`/Firebase sign-in response until after logout/account switch: old identity must not return. Race mint/revoke across VPS instances.
- [ ] Let an ORDS request execute after losing its Node lease; verify the database transaction fence drains executing DML and rejects an old epoch after reopening.
- [ ] Lose a successful deletion response, retry, and verify receipt-backed counts. Poll the HttpOnly operation receipt after account/session deletion; it must not authorize any mutation.
- [ ] Kill notification delivery after FCM acceptance but before its checkpoint; retry with the same event ID and verify no repeated device alert.
- [ ] Verify metadata views omit inline media at the Oracle boundary, attachment reads are authorized, and cache pruning never removes pending/explicitly saved content.
