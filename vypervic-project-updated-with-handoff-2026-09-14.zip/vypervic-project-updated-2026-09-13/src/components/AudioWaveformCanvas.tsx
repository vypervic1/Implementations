import React, { useRef, useEffect, useState, useCallback } from 'react';
import { globalAudioPlayer } from '../utils/audioPlayer';

interface AudioWaveformCanvasProps {
  isPlaying: boolean;
  progress: number; // 0 to 1
  barCount?: number;
  height?: number;
  barWidth?: number;
  barGap?: number;
  activeColor?: string;
  inactiveColor?: string;
  playbackRate?: number;
  onSeek?: (progress: number) => void;
  className?: string;
}

export const AudioWaveformCanvas: React.FC<AudioWaveformCanvasProps> = ({
  isPlaying,
  progress,
  barCount = 28,
  height = 28,
  barWidth = 3,
  barGap = 2,
  activeColor = '#20e3a2',
  inactiveColor = 'rgba(255, 255, 255, 0.25)',
  playbackRate = 1,
  onSeek,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragProgress, setDragProgress] = useState<number | null>(null);
  const isDraggingRef = useRef(false);
  const dragProgressRef = useRef<number | null>(null);

  // Generate deterministic, realistic voice audio waveform bar profiles
  const baseHeights = useRef<number[]>([]);
  if (baseHeights.current.length !== barCount) {
    baseHeights.current = Array.from({ length: barCount }, (_, i) => {
      // Natural voice note envelope: starts moderate, builds peaks, has realistic valleys
      const normalizedIndex = i / (barCount - 1);
      const envelope = Math.sin(normalizedIndex * Math.PI); // arch envelope
      const harmonic1 = Math.sin(i * 0.85) * 0.22;
      const harmonic2 = Math.cos(i * 1.7) * 0.18;
      const pseudoNoise = ((Math.sin(i * 12.9898 + 45.123) * 43758.5453) % 1) * 0.25;

      const rawVal = 0.28 + (envelope * 0.45) + Math.abs(harmonic1 + harmonic2 + pseudoNoise) * 0.35;
      return Math.max(0.2, Math.min(0.95, rawVal));
    });
  }

  // Draw routine with smooth seeking and playhead
  const renderFrame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
    const totalWidth = barCount * barWidth + (barCount - 1) * barGap;

    canvas.width = totalWidth * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, totalWidth, height);

    // Determine effective playback progress (prioritize active drag scrub)
    let currentProgress = progress;
    if (isDraggingRef.current && dragProgressRef.current !== null) {
      currentProgress = dragProgressRef.current;
    } else if (isPlaying) {
      // Sample high-precision audio timestamp directly from audio player
      const cur = globalAudioPlayer.getCurrentTime();
      const dur = globalAudioPlayer.getDuration();
      if (dur > 0 && isFinite(cur)) {
        currentProgress = Math.max(0, Math.min(1, cur / dur));
      }
    }

    const currentX = currentProgress * totalWidth;

    for (let i = 0; i < barCount; i++) {
      const barHeightRatio = baseHeights.current[i];
      const barH = Math.max(4, barHeightRatio * (height - 4));
      const x = i * (barWidth + barGap);
      const y = (height - barH) / 2;
      const barCenterX = x + barWidth / 2;

      // Smooth seek progress: check if bar is behind playhead
      const isPlayed = barCenterX <= currentX;

      if (isPlayed) {
        ctx.fillStyle = activeColor;
      } else {
        ctx.fillStyle = inactiveColor;
      }

      // Draw rounded bar
      ctx.beginPath();
      if (ctx.roundRect) {
        ctx.roundRect(x, y, barWidth, barH, barWidth / 2);
      } else {
        ctx.rect(x, y, barWidth, barH);
      }
      ctx.fill();
    }

    // Draw active circular playhead indicator (circle display on seeker)
    const playheadX = Math.max(0, Math.min(totalWidth, currentX));
    const thumbRadius = isDraggingRef.current ? 6 : 4.8;

    ctx.save();
    // Outer glow
    ctx.shadowColor = activeColor;
    ctx.shadowBlur = isPlaying || isDraggingRef.current ? 10 : 6;

    // Outer border / halo ring
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(playheadX, height / 2, thumbRadius + 1.2, 0, Math.PI * 2);
    ctx.fill();

    // Vibrant main circle body
    ctx.fillStyle = activeColor;
    ctx.beginPath();
    ctx.arc(playheadX, height / 2, thumbRadius, 0, Math.PI * 2);
    ctx.fill();

    // Inner crisp center white dot
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(playheadX, height / 2, thumbRadius * 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }, [barCount, barWidth, barGap, height, activeColor, inactiveColor, isPlaying, progress]);

  // Smooth continuous animation loop during playback
  useEffect(() => {
    let active = true;

    const loop = () => {
      if (!active) return;
      renderFrame();
      if (isPlaying || isDragging) {
        animFrameRef.current = requestAnimationFrame(loop);
      }
    };

    loop();

    return () => {
      active = false;
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isPlaying, isDragging, renderFrame]);

  // Seek position calculator
  const calculateSeekRatio = (clientX: number): number => {
    if (!canvasRef.current) return 0;
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = clientX - rect.left;
    return Math.max(0, Math.min(1, clickX / rect.width));
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const ratio = calculateSeekRatio(e.clientX);
    setIsDragging(true);
    setDragProgress(ratio);
    isDraggingRef.current = true;
    dragProgressRef.current = ratio;
    renderFrame();

    const handlePointerMove = (moveEvent: PointerEvent) => {
      const newRatio = calculateSeekRatio(moveEvent.clientX);
      setDragProgress(newRatio);
      dragProgressRef.current = newRatio;
      renderFrame();
      if (onSeek) {
        onSeek(newRatio);
      }
    };

    const handlePointerUp = (upEvent: PointerEvent) => {
      const finalRatio = calculateSeekRatio(upEvent.clientX);
      setIsDragging(false);
      setDragProgress(null);
      isDraggingRef.current = false;
      dragProgressRef.current = null;
      if (onSeek) {
        onSeek(finalRatio);
      }
      renderFrame();
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);
  };

  const totalW = barCount * barWidth + (barCount - 1) * barGap;

  return (
    <canvas
      ref={canvasRef}
      onPointerDown={handlePointerDown}
      style={{
        width: `${totalW}px`,
        height: `${height}px`,
        touchAction: 'none',
      }}
      className={`cursor-pointer touch-none select-none transition-opacity hover:opacity-95 ${className}`}
      title="Click or drag to seek audio"
    />
  );
};

