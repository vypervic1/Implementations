import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';
import { browserConfig } from './src/shared/firebaseConfiguration';

export default defineConfig(({ command, mode }) => {
  const env = { ...loadEnv(mode, process.cwd(), ''), ...process.env };
  const config = browserConfig(env, command === 'build');
  return {
    define: { 'import.meta.env.VYPER_CI_BUILD': JSON.stringify(env.VYPER_CI_BUILD || '') },
    plugins: [react(), tailwindcss(), {
      name: 'firebase-build-configuration',
      generateBundle() {
        this.emitFile({ type: 'asset', fileName: 'firebase-build-config.json', source: JSON.stringify(config) });
      },
    }],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      manifest: true,
      // R-04 (bundle size): split stable vendor libraries into cacheable
      // chunks so app-code changes don't invalidate the whole bundle and no
      // single chunk balloons past a reasonable size. Feature screens are
      // additionally React.lazy-split in App.tsx.
      rollupOptions: {
        output: {
          manualChunks(id: string) {
            if (!id.includes('node_modules')) return undefined;
            if (id.includes('@firebase/messaging') || id.includes('firebase/messaging')) return 'vendor-web-push';
            if (id.includes('@firebase/auth') || id.includes('firebase/auth')) return 'vendor-firebase-auth';
            if (id.includes('firebase') || id.includes('@firebase')) return 'vendor-firebase-core';
            if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('scheduler')) return 'vendor-react';
            if (id.includes('/motion/') || id.includes('framer-motion')) return 'vendor-motion';
            if (id.includes('lucide-react')) return 'vendor-lucide';
            return undefined;
          },
        },
      },
      chunkSizeWarningLimit: 500,
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
      // Allow the sandbox/preview proxy hostnames to reach the dev server.
      allowedHosts: true as const,
      fs: { deny: ['.env', '.env.*', '**/.git/**', '**/src/server/**', '**/server.ts', '**/deploy/**', '**/android/**'] },
    },
  };
});
