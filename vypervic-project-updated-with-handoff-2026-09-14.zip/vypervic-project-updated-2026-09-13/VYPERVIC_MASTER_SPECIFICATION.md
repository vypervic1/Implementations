# VYPERVIC MASTER SPECIFICATION — Arena ChatApp

Version: 2026-09-09. Binding architecture contract. Anything not in this
document that weakens it is a bug, not a feature.

## 1. Parties and trust levels

| Layer | Role | Trust |
|---|---|---|
| Android APK / browser | Renders UI, requests operations | **Untrusted.** Decides nothing authoritative |
| VPS (Node/Express behind Caddy TLS) | Sole policy authority | Trusted. Verifies session, authorizes, validates, then calls Oracle/Firebase |
| Oracle ADB `VYPERVIC1` via authenticated ORDS | Durable system of record | Trusted store; reached only by the VPS |
| Firebase `vypervic-chatapp` / `(default)` | Edge presence, signaling, FCM | Scoped realtime + push; Admin SDK is VPS-only |
| Private Redis | Sessions, revocation, locks, rate limits, realtime fan-out | Trusted infra, private network |
| Private coturn (REST) | WebRTC relay | Trusted infra; secret is VPS-only |

```text
App --HTTPS + HttpOnly vyper_session--> VPS --OAuth ORDS--> Oracle
                                          |--Admin SDK--> Firebase/FCM
                                          +--short-lived creds--> coturn
```

## 2. Client <-> VPS contract

- Single API surface: same-origin `/api/...` (browser) and the configured
  HTTPS origin inside the locked-down Android WebView. No local-asset API
  origin, no direct ORDS URL in any client, no `VITE_ORDS_*` bypass.
- Auth: `POST /api/auth/login` with identifier + password. The VPS
  rate-limits (IP + identifier), looks the account up in Oracle, verifies
  PBKDF2-HMAC-SHA256/100k with timing-safe comparison, and issues a JWT in an
  HttpOnly `Secure; SameSite=Lax; Path=/` cookie (`vyper_session`, 30 days).
  The app may keep a boolean `vypervic_has_session` flag; it must never store
  the JWT in `localStorage`.
- Every authenticated request: verify signature -> expiry -> revocation ->
  load current Oracle profile -> refresh role -> route authorization ->
  validated typed operation -> sanitized response.
- Admin routes re-read the role from Oracle; the JWT role snapshot is a hint.
- The VPS overwrites identity-sensitive fields (`sender_id`, token `userId`,
  signaling caller/receiver) with the session identity and rejects
  cross-user / cross-chat injection.

## 3. VPS <-> Oracle contract

- Server-only: `ORDS_BASE_URL` + exactly one auth mode (OAuth
  client-credentials preferred; static gateway key only where supported).
  Token fetch/cache/refresh with single in-flight refresh and one 401 retry.
- Browser proxy allowlist: `profiles`, `messages`, `calls`, `groups`.
  Server-only tables (`user_credentials`, `password_resets`,
  `scheduled_messages`, push/deletion/maintenance) are never proxied.
- Writes are validated (method, table, row id, filters, pagination, schema,
  lengths, attachment caps, prototype-pollution keys) and membership-checked
  (chat membership, call participation, group membership from Oracle).
- Message send: derive sender from session -> authorize -> ORDS commit ->
  re-read committed row -> realtime/push projection -> return authoritative
  row. Stable client message ids make retries idempotent.
- Profile output is sanitized: no `password_hash/salt/storage`, no
  `[auth:...]` tags.
- Uniqueness is enforced in the database: `UQ_PROFILES_EMAIL`,
  `UQ_PROFILES_USERNAME`, `UQ_PROFILES_PHONE`, normalized unique indexes;
  unique-violation maps to HTTP 409, never silent overwrite.

## 4. VPS <-> Firebase contract (Admin SDK, VPS-only)

Credentials (`FIREBASE_PROJECT_ID/CLIENT_EMAIL/PRIVATE_KEY`,
`FIRESTORE_DATABASE_ID=(default)`) exist only in the VPS runtime env. Used for:
custom-token minting (only for the active session's own `sub`, after
writability checks, with `edge_accounts` version + `edge_sessions` binding),
FCM multicast (durable token lookup, dedupe, 500-token batches, invalid-token
revocation), identity/session revocation, lifecycle management and archival of
ephemeral edge records. Admin SDK bypasses Firestore rules: treat as root.

## 5. App <-> Firestore contract (edge, least privilege)

After VPS login the app signs in with the custom token; the Firebase UID
equals the Oracle profile id. Firestore holds presence, typing, DM delivery
streams, and WebRTC signaling only. Rules guarantee: users write only their
own presence; signaling documents are participant-only with immutable
caller/receiver/call id; lifecycle fields (`claimed_at`, `attempts`,
`archived_at`, `last_error`, `expires_at`) are VPS-worker-only; no globally
readable group feed (membership is Oracle-authoritative).

## 6. Push contract

Native Android SDK mints the FCM token; after login the worker posts it to
`POST /api/push/register-token` (session cookie supplies the user id; body
`userId` is ignored). The VPS validates the token with FCM, binds it to the
session/device, and stores it durably. Sends are data-only with TTL 30s for
calls / 1h otherwise; the native service dedupes, rejects stale call invites,
checks session binding, and renders exactly once. Invalid tokens are revoked.

## 7. Realtime (SSE) + WebRTC contracts

- `POST /api/realtime/broadcast` authenticates, rate-limits, schema-validates,
  re-checks the referenced Oracle message/call, enforces chat/call membership,
  stamps server-derived identity, and publishes to the correct audience only.
  Broadcasts never create durable state; `call_status=accepted` requires the
  durable call transition first.
- TURN credentials are minted per active call after participation checks and
  expire quickly; the shared secret never leaves the VPS. Media is peer or
  TURN-relayed, never through Oracle.

## 8. Logout / reset / deletion contract

Logout revokes the server session + Firebase session, removes the native
token binding, cancels registration work, deletes the local FCM token, and
clears notifications/WebView state. Password reset, demotion, and deletion
invalidate JWT sessions, Firebase sessions, push bindings, Oracle rows, edge
state, and schedules. Deletion is a durable resumable job reporting
`completed|partial|failed` — the UI never claims success from a 401/logout.

## 9. Deployment invariants

HTTPS-only origin; Caddy -> loopback Node; Node/Redis private; strong
`JWT_SECRET`; HTTPS ORDS with required auth; shared authenticated Redis with
persistence; canonical Firebase project on Admin/browser/native; deployed +
tested Firestore rules/indexes/TTL; private TURN; correct APK origin +
`google-services.json` per flavor; physical-device tests (cookies, push,
permissions, realtime, deep links, calls); correct `assetlinks.json`.

## 10. Central rule

> The client requests an operation; the VPS decides whether it is allowed;
> Oracle stores the durable result; Firebase provides controlled realtime
> and notification services.
