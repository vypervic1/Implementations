// =========================================================================
// UNIT TESTS: password verification, config validation, rate limiting
// =========================================================================
import { describe, it, expect } from 'vitest';

describe('verifyPasswordHash (G-06)', () => {
  it('verifies correct passwords and rejects wrong ones', async () => {
    const { hashPassword, generateCryptoSalt, verifyPasswordHash } = await import('../src/server/oracleBackend');
    const salt = generateCryptoSalt();
    const hash = hashPassword('my-secret-password', salt);
    expect(verifyPasswordHash('my-secret-password', salt, hash)).toBe(true);
    expect(verifyPasswordHash('wrong-password', salt, hash)).toBe(false);
  });

  it('fails closed on malformed hashes and salts (G-06)', async () => {
    const { generateCryptoSalt, hashPassword, verifyPasswordHash } = await import('../src/server/oracleBackend');
    const salt = generateCryptoSalt();
    const hash = hashPassword('x', salt);
    expect(verifyPasswordHash('x', salt, 'zzz-not-hex')).toBe(false);
    expect(verifyPasswordHash('x', 'bad salt!', hash)).toBe(false);
    expect(verifyPasswordHash('x', salt, '')).toBe(false);
    expect(verifyPasswordHash('x', salt, 'abcd')).toBe(false); // wrong length
    // @ts-ignore deliberate wrong types
    expect(verifyPasswordHash(null, salt, hash)).toBe(false);
  });
});

describe('wipeTable pagination (G-04)', () => {
  it('drains tables larger than one page', async () => {
    // This test runs against the mock ORDS via the integration suite; here
    // we assert the returned shape includes pass accounting.
    const src = await import('../src/server/oracleBackend');
    expect(typeof src.wipeTable).toBe('function');
    expect(typeof src.deleteRowsByFilter).toBe('function');
  });
});

describe('production config validation (C-02, H-05, H-07)', () => {
  it('reports missing production requirements', async () => {
    const { collectProductionConfigProblems, isProduction } = await import('../src/server/config');
    expect(isProduction()).toBe(false); // tests run with NODE_ENV=test

    const savedEnv = { ...process.env };
    process.env.NODE_ENV = 'production';
    delete process.env.JWT_SECRET;
    delete process.env.ORDS_API_KEY;
    const problems = collectProductionConfigProblems();
    expect(problems.map((p) => p.var)).toContain('JWT_SECRET');
    expect(problems.map((p) => p.var)).toContain('ORDS_API_KEY');
    // restore
    process.env.NODE_ENV = savedEnv.NODE_ENV;
    if (savedEnv.JWT_SECRET) process.env.JWT_SECRET = savedEnv.JWT_SECRET;
    if (savedEnv.ORDS_API_KEY) process.env.ORDS_API_KEY = savedEnv.ORDS_API_KEY;
  });

  it('flags a weak JWT secret and split Firebase projects', async () => {
    const { collectProductionConfigProblems } = await import('../src/server/config');
    const savedEnv = { ...process.env };
    process.env.NODE_ENV = 'production';
    process.env.JWT_SECRET = 'short';
    process.env.ORDS_API_KEY = 'some-key';
    process.env.FIREBASE_PROJECT_ID = 'project-a';
    process.env.FIREBASE_CLIENT_EMAIL = 'a@b.c';
    process.env.FIREBASE_PRIVATE_KEY = '-----BEGIN PRIVATE KEY-----\nx\n-----END PRIVATE KEY-----';
    process.env.FIRESTORE_PROJECT_ID = 'project-b';
    process.env.FIRESTORE_CLIENT_EMAIL = 'a@b.c';
    process.env.FIRESTORE_PRIVATE_KEY = '-----BEGIN PRIVATE KEY-----\nx\n-----END PRIVATE KEY-----';
    delete process.env.ALLOW_TWO_FIREBASE_PROJECTS;
    const problems = collectProductionConfigProblems();
    expect(problems.some((p) => p.var === 'JWT_SECRET')).toBe(true);
    expect(problems.some((p) => p.var.includes('FIREBASE_PROJECT_ID'))).toBe(true);
    Object.keys(process.env).forEach((k) => {
      if (k in savedEnv) process.env[k] = savedEnv[k];
      else delete process.env[k];
    });
  });
});

describe('SSE origin resolution (G-07)', () => {
  it('echoes allowed origins, denies others, never returns "*"', async () => {
    const { resolveCorsOrigin, allowedOrigins } = await import('../src/server/config');
    // APP_URL=https://app.example.com set by tests/setup.ts
    expect(allowedOrigins()).toContain('https://app.example.com');
    expect(resolveCorsOrigin('https://app.example.com')).toBe('https://app.example.com');
    expect(resolveCorsOrigin('https://app.example.com/')).toBe('https://app.example.com');
    expect(resolveCorsOrigin('https://evil.example.net')).toBeNull();
    expect(resolveCorsOrigin(undefined)).toBeNull();
    expect(resolveCorsOrigin('*')).toBeNull();
  });
});

describe('rate limiter (G-02)', () => {
  it('allows normal usage, blocks floods, applies exponential lockout', async () => {
    const { RateLimiter } = await import('../src/server/rateLimit');
    const rl = new RateLimiter({ max: 3, windowMs: 60_000, lockoutAfterFailures: 2, lockoutBaseMs: 1000 });
    expect(rl.consume('k').allowed).toBe(true);
    expect(rl.consume('k').allowed).toBe(true);
    expect(rl.consume('k').allowed).toBe(true);
    const blocked = rl.consume('k');
    expect(blocked.allowed).toBe(false);
    expect(blocked.reason).toBe('rate_limited');

    const failureLimiter = new RateLimiter({ max: 100, windowMs: 60_000, lockoutAfterFailures: 3, lockoutBaseMs: 5000 });
    failureLimiter.recordFailure('u1');
    failureLimiter.recordFailure('u1');
    expect(failureLimiter.consume('u1').allowed).toBe(true);
    failureLimiter.recordFailure('u1');
    const locked = failureLimiter.consume('u1');
    expect(locked.allowed).toBe(false);
    expect(locked.locked).toBe(true);
    expect(locked.retryAfterSec).toBeGreaterThan(0);
    failureLimiter.recordSuccess('u1');
    expect(failureLimiter.consume('u1').allowed).toBe(true);
  });
});

describe('push token validation (C-04)', () => {
  it('accepts realistic FCM tokens and rejects junk', async () => {
    const { validatePushToken } = await import('../src/server/pushTokenStore');
    const good = validatePushToken('f'.repeat(152), 'web');
    expect(good.ok).toBe(true);
    if (good.ok) expect(good.deviceType).toBe('web');
    expect(validatePushToken('short', 'web').ok).toBe(false);
    expect(validatePushToken('a b c d e f g h i j k l m n o p', 'web').ok).toBe(false);
    expect(validatePushToken('<script>', 'web').ok).toBe(false);
    expect(validatePushToken('x'.repeat(5000), 'web').ok).toBe(false);
    const normalized = validatePushToken('k'.repeat(200), 'desktop-app');
    expect(normalized.ok).toBe(false);
  });
});

describe('edge chat rules helper (M-07)', () => {
  it('treats general and dm chats as rules-verifiable, groups as not', async () => {
    const { isRulesVerifiableChat } = await import('../src/firebaseEdge');
    expect(isRulesVerifiableChat('general')).toBe(true);
    expect(isRulesVerifiableChat('dm:usr_a:usr_b')).toBe(true);
    expect(isRulesVerifiableChat('dm:usr_a:')).toBe(false);
    expect(isRulesVerifiableChat('dm:usr_a')).toBe(false);
    expect(isRulesVerifiableChat('group:g1')).toBe(false);
    expect(isRulesVerifiableChat('')).toBe(false);
  });
});
