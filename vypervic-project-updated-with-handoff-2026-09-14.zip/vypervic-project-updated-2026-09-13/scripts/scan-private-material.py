#!/usr/bin/env python3
"""Targeted private-key/archive regression scan. Complements, does not replace, CI gitleaks.
Only locations are printed. Credential values and matching lines are never emitted.
"""
import argparse
import io
import json
import pathlib
import re
import subprocess
import tarfile
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--history', action='store_true')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent.parent
findings = []
private_key = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----(?:\\n|\s)+[A-Za-z0-9+/=\s\\n]{64,}')

def inspect(data, location, depth=0):
    if private_key.search(data):
        findings.append({'location': location, 'kind': 'private-key-material'})
    if depth >= 3:
        return
    try:
        if data[:4] == b'PK\x03\x04':
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                for entry in archive.infolist():
                    if entry.is_dir():
                        continue
                    if entry.file_size > 20_000_000:
                        findings.append({'location': location, 'kind': 'oversized-archive-entry-needs-review'})
                        continue
                    inspect(archive.read(entry), location + '!' + entry.filename, depth + 1)
        elif data[:2] == b'\x1f\x8b' or location.endswith('.tar'):
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
                for entry in archive:
                    if not entry.isfile():
                        continue
                    if entry.size > 20_000_000:
                        findings.append({'location': location, 'kind': 'oversized-archive-entry-needs-review'})
                        continue
                    inspect(archive.extractfile(entry).read(), location + '!' + entry.name, depth + 1)
    except (zipfile.BadZipFile, tarfile.TarError, OSError):
        findings.append({'location': location, 'kind': 'unreadable-archive-needs-review'})

files = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=root).split(b'\0')
for file in set(files):
    if not file:
        continue
    path = root / file.decode()
    if path.is_file():
        inspect(path.read_bytes(), file.decode())
blobs = 0
if args.history:
    objects = subprocess.check_output(['git', 'rev-list', '--objects', '--all'], cwd=root).splitlines()
    for line in objects:
        parts = line.decode().split(' ', 1)
        if len(parts) < 2:
            continue
        sha, path = parts
        kind = subprocess.check_output(['git', 'cat-file', '-t', sha], cwd=root).strip()
        if kind != b'blob':
            continue
        blobs += 1
        inspect(subprocess.check_output(['git', 'cat-file', 'blob', sha], cwd=root), 'git:' + sha[:12] + ':' + path)
print(json.dumps({'workingFiles': len(set(files)) - 1, 'historicalBlobs': blobs,
                  'shallowHistory': subprocess.check_output(['git', 'rev-parse', '--is-shallow-repository'], cwd=root).strip() == b'true',
                  'findings': findings}, indent=2))
raise SystemExit(1 if findings else 0)
