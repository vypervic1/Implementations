-- DEPRECATED / DESTRUCTIVE. Prefer deploy/migrations/ for setup and API operation jobs for wipes.
-- This safety guard deliberately stops execution. Do not remove it on a live database.
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
BEGIN
  RAISE_APPLICATION_ERROR(-20099, 'Use additive migrations; use a confirmed resumable API job for deletion');
END;
/

-- =========================================================================
-- VYPERVIC ORACLE AUTONOMOUS DATABASE (ATP / 23ai / 26ai) WIPE & RESET SCRIPT
-- =========================================================================
-- How to run this in Oracle Cloud:
-- 1. Open Oracle Cloud Infrastructure (OCI) Console
-- 2. Go to: Autonomous Database -> Click your database ("VYPERVIC1")
-- 3. Click "Database Actions" -> Select "SQL"
-- 4. Paste and run this entire script (Press F5 or click the "Run Script" icon)
--
-- SECURITY (C-02 / G-03): AutoREST services are enabled WITH authentication
-- (p_auto_rest_auth => TRUE) and an OAuth client is created for the
-- application server. Anonymous access to every REST endpoint is rejected.
-- ORDS AUTO-GENERATES the OAuth client_id / client_secret. After running the
-- script, copy them with the SELECT in PART 6 and set them as
-- ORDS_OAUTH_CLIENT_ID / ORDS_OAUTH_CLIENT_SECRET on the application server
-- (the server fetches and refreshes short-lived tokens by itself).
-- =========================================================================

-- PART 1: ENSURE ALL TABLES EXIST FIRST (Safely creates them if missing)
-- -------------------------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE PROFILES (
      ID VARCHAR2(255) PRIMARY KEY,
      EMAIL VARCHAR2(255) CONSTRAINT UQ_PROFILES_EMAIL UNIQUE,
      USERNAME VARCHAR2(100) CONSTRAINT UQ_PROFILES_USERNAME UNIQUE,
      DISPLAY_NAME VARCHAR2(255),
      PHONE_NUMBER VARCHAR2(100),
      ABOUT VARCHAR2(1000) DEFAULT ''Hey there! I am using VyperVic.'',
      AVATAR_URL CLOB,
      IS_ONLINE NUMBER(1) DEFAULT 0,
      LAST_SEEN VARCHAR2(100),
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''),
      UPDATED_AT VARCHAR2(100),
      ROLE VARCHAR2(50) DEFAULT ''user'',
      PASSWORD_HASH VARCHAR2(255),
      PASSWORD_SALT VARCHAR2(255)
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- Ensure upgrade columns exist on already created tables. Per-column adds:
-- a single batched ALTER fails entirely if ANY column exists, silently
-- leaving the others missing (seen live: PASSWORD_SALT missing on a
-- pre-existing table -> admin insert ORA-00904).
DECLARE
  PROCEDURE add_col(p_col VARCHAR2, p_type VARCHAR2) IS
    v_cnt NUMBER;
  BEGIN
    SELECT COUNT(*) INTO v_cnt FROM user_tab_columns
    WHERE table_name = 'PROFILES' AND column_name = p_col;
    IF v_cnt = 0 THEN
      EXECUTE IMMEDIATE 'ALTER TABLE PROFILES ADD (' || p_col || ' ' || p_type || ')';
    END IF;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
BEGIN
  add_col('UPDATED_AT',    'VARCHAR2(100)');
  add_col('ROLE',          'VARCHAR2(50) DEFAULT ''user''');
  add_col('PASSWORD_HASH', 'VARCHAR2(255)');
  add_col('PASSWORD_SALT', 'VARCHAR2(255)');
END;
/

-- G-03: UNIQUE constraints on normalized email + username. The application
-- performs a friendly pre-check, but these constraints are the AUTHORITATIVE
-- protection against concurrent duplicate signups (unique-violation -> 409).
-- Existing tables get the constraints added here (idempotent).
BEGIN
  EXECUTE IMMEDIATE 'ALTER TABLE PROFILES ADD CONSTRAINT UQ_PROFILES_EMAIL UNIQUE (EMAIL)';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'ALTER TABLE PROFILES ADD CONSTRAINT UQ_PROFILES_USERNAME UNIQUE (USERNAME)';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE MESSAGES (
      ID VARCHAR2(255) PRIMARY KEY,
      CHAT_ID VARCHAR2(255),
      SENDER_ID VARCHAR2(255),
      RECIPIENT_ID VARCHAR2(255),
      TEXT CLOB,
      FILE_NAME VARCHAR2(500),
      FILE_TYPE VARCHAR2(255),
      FILE_DATA CLOB,
      IS_VOICE NUMBER(1) DEFAULT 0,
      DURATION NUMBER,
      IS_EDITED NUMBER(1) DEFAULT 0,
      IS_ENCRYPTED NUMBER(1) DEFAULT 0,
      STATUS VARCHAR2(50) DEFAULT ''sent'',
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- M-01: message id uniqueness is the idempotency anchor for offline retries
-- and edge archival (a retried insert of the same id can never duplicate).
BEGIN
  EXECUTE IMMEDIATE 'CREATE INDEX IX_MESSAGES_CHAT_ID ON MESSAGES (CHAT_ID)';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE CALLS (
      ID VARCHAR2(255) PRIMARY KEY,
      CALLER_ID VARCHAR2(255),
      RECEIVER_ID VARCHAR2(255),
      TYPE VARCHAR2(50) DEFAULT ''voice'',
      STATUS VARCHAR2(50) DEFAULT ''ringing'',
      SIGNAL_DATA CLOB,
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''),
      UPDATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE GROUPS (
      ID VARCHAR2(255) PRIMARY KEY,
      NAME VARCHAR2(255),
      ICON CLOB,
      COVER_URL CLOB,
      DESCRIPTION VARCHAR2(1000),
      CREATOR_ID VARCHAR2(255),
      MEMBERS CLOB,
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE VAULT (
      ID VARCHAR2(255) PRIMARY KEY,
      USER_ID VARCHAR2(255),
      FILE_NAME VARCHAR2(500),
      FILE_TYPE VARCHAR2(255),
      FILE_DATA CLOB,
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE AUDIT_LOGS (
      ID VARCHAR2(255) PRIMARY KEY,
      ADMIN_ID VARCHAR2(255),
      ACTION VARCHAR2(100),
      TARGET_ID VARCHAR2(255),
      DETAILS CLOB,
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- M-03: durable push-token registry (source of truth for FCM sends).
BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE USER_PUSH_TOKENS (
      ID VARCHAR2(255) PRIMARY KEY,
      USER_ID VARCHAR2(255),
      TOKEN VARCHAR2(4096),
      DEVICE_TYPE VARCHAR2(50) DEFAULT ''web'',
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''),
      UPDATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'CREATE INDEX IX_PUSH_TOKENS_USER ON USER_PUSH_TOKENS (USER_ID)';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- H-06: SERVER-ONLY password verifiers. Password hashes/salts live here —
-- NOT in the client-visible profile ABOUT text. This table is REST-enabled
-- for the application server but is NOT exposed through the browser proxy
-- (it is not in the server''s ALLOWED_TABLES), and ORDS-level authentication
-- is required to reach it at all.
BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE USER_CREDENTIALS (
      ID VARCHAR2(255) PRIMARY KEY,
      USER_ID VARCHAR2(255),
      PASSWORD_HASH VARCHAR2(255),
      PASSWORD_SALT VARCHAR2(255),
      PASSWORD_CHANGED_AT VARCHAR2(100),
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''),
      UPDATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- R-01: single-use, expiring password-reset / email-verification tokens.
-- SERVER-ONLY (not exposed through the browser proxy).
BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE PASSWORD_RESETS (
      ID VARCHAR2(255) PRIMARY KEY,
      USER_ID VARCHAR2(255),
      PURPOSE VARCHAR2(20) DEFAULT ''reset'',
      EXPIRES_AT VARCHAR2(100),
      USED_AT VARCHAR2(100),
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

-- M-06: server-backed scheduled messages (atomic claim + idempotent
-- delivery by the server worker). SERVER-ONLY.
BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE SCHEDULED_MESSAGES (
      ID VARCHAR2(255) PRIMARY KEY,
      USER_ID VARCHAR2(255),
      CHAT_ID VARCHAR2(255),
      RECIPIENT_ID VARCHAR2(255),
      TEXT CLOB,
      FILE_NAME VARCHAR2(500),
      FILE_TYPE VARCHAR2(255),
      FILE_DATA CLOB,
      IS_VOICE NUMBER(1) DEFAULT 0,
      SCHEDULED_FOR VARCHAR2(100),
      STATUS VARCHAR2(20) DEFAULT ''scheduled'',
      ATTEMPTS NUMBER DEFAULT 0,
      MESSAGE_ID VARCHAR2(255),
      LAST_ERROR VARCHAR2(500),
      CREATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''),
      UPDATED_AT VARCHAR2(100) DEFAULT TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
    )';
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'CREATE INDEX IX_SCHEDULED_STATUS ON SCHEDULED_MESSAGES (STATUS, SCHEDULED_FOR)';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- PART 2: WIPE ALL ROWS FROM ALL TABLES
-- -------------------------------------------------------------------------
-- FK-safe: legacy schemas may carry foreign keys into PROFILES; drop those
-- constraints first (by name, dynamically), otherwise DROP TABLE fails with
-- ORA-02449 and aborts everything after it.
DECLARE
  v_cnt NUMBER := 0;
BEGIN
  FOR c IN (SELECT c.constraint_name, c.table_name
            FROM user_constraints c
            JOIN user_constraints p ON c.r_constraint_name = p.constraint_name
            WHERE p.table_name = 'PROFILES' AND c.constraint_type = 'R') LOOP
    BEGIN
      EXECUTE IMMEDIATE 'ALTER TABLE ' || c.table_name || ' DROP CONSTRAINT "' || c.constraint_name || '"';
      v_cnt := v_cnt + 1;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  IF v_cnt > 0 THEN
    DBMS_OUTPUT.PUT_LINE('Dropped ' || v_cnt || ' legacy foreign key(s) into PROFILES');
  END IF;
END;
/
BEGIN
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM CALLS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM MESSAGES'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM VAULT'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM AUDIT_LOGS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM GROUPS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM USER_PUSH_TOKENS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM USER_CREDENTIALS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM PASSWORD_RESETS'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM SCHEDULED_MESSAGES'; EXCEPTION WHEN OTHERS THEN NULL; END;
  BEGIN EXECUTE IMMEDIATE 'DELETE FROM PROFILES'; EXCEPTION WHEN OTHERS THEN NULL; END;
  COMMIT;
END;
/

-- PART 3: SAFELY ENABLE / RE-ENABLE ORDS REST SERVICES (WITH AUTH — C-02)
-- -------------------------------------------------------------------------
-- p_auto_rest_auth => TRUE protects every AutoREST endpoint: anonymous
-- requests are rejected by ORDS and clients must present an OAuth2
-- client-credentials Bearer token (the server stores it in ORDS_API_KEY).
-- After running this script, verify from OUTSIDE the VPC/VCN:
--   curl -i https://<adb-host>/ords/admin/profiles/
--   -> expect 401 Unauthorized (NOT 200).
DECLARE
  PROCEDURE enable_rest_object(p_tbl IN VARCHAR2, p_alias IN VARCHAR2) IS
  BEGIN
    -- 1. Try to disable first in case alias already exists (avoids ORA-20006)
    BEGIN
      ORDS.ENABLE_OBJECT(
        p_enabled     => FALSE,
        p_schema      => 'ADMIN',
        p_object      => p_tbl,
        p_object_type => 'TABLE'
      );
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    -- 2. Enable AutoREST for the table WITH authentication required
    ORDS.ENABLE_OBJECT(
      p_enabled        => TRUE,
      p_schema         => 'ADMIN',
      p_object         => p_tbl,
      p_object_type    => 'TABLE',
      p_object_alias   => p_alias,
      p_auto_rest_auth => TRUE
    );
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;
BEGIN
  enable_rest_object('PROFILES', 'profiles');
  enable_rest_object('MESSAGES', 'messages');
  enable_rest_object('CALLS', 'calls');
  enable_rest_object('VAULT', 'vault');
  enable_rest_object('AUDIT_LOGS', 'audit_logs');
  -- Server-only tables: REST-enabled so the APPLICATION SERVER can reach
  -- them, but they are never exposed through the app''s browser proxy and
  -- ORDS-level auth is required to touch them directly.
  enable_rest_object('USER_CREDENTIALS', 'user_credentials');
  enable_rest_object('PASSWORD_RESETS', 'password_resets');
  enable_rest_object('SCHEDULED_MESSAGES', 'scheduled_messages');
  enable_rest_object('USER_PUSH_TOKENS', 'user_push_tokens');
  COMMIT;
END;
/

-- PART 4: OAUTH CLIENT FOR THE APPLICATION SERVER (C-02)
-- -------------------------------------------------------------------------
-- Matches the documented OAUTH package API (ORDS on Autonomous DB):
--   p_name/p_grant_type/p_owner/p_description/p_support_email/p_privilege_names
-- The client itself is the OAuth identity — there is NO OAUTH.create_user /
-- GRANT_USER_ROLE in this API. Token duration defaults to 3600s; the app
-- server (oracleBackend.ts) fetches/caches/refreshes tokens automatically.
-- Roles are granted DYNAMICALLY from user_ords_privileges so the exact
-- AutoREST privilege names never need to be hardcoded. Idempotent.
DECLARE
BEGIN
  BEGIN
    OAUTH.delete_client(p_name => 'vypervic_app_server');
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  OAUTH.create_client(
    p_name            => 'vypervic_app_server',
    p_grant_type      => 'client_credentials',
    p_owner           => 'VyperVic Messenger',
    p_description     => 'VyperVic Messenger application server (client-credentials)',
    p_support_email   => 'vypervic1@gmail.com',
    p_privilege_names => NULL
  );

  -- Grant the client every AutoREST object privilege created in PART 3.
  -- NOTE: on current ORDS builds the AutoREST privilege names are
-- 'oracle.dbtools.autorest.privilege.<SCHEMA>.<TABLE>' (older docs say
-- '.object.'). Matching 'oracle.dbtools.autorest.%' covers both spellings.
  FOR r IN (SELECT name FROM user_ords_privileges WHERE name LIKE 'oracle.dbtools.autorest.%') LOOP
    BEGIN
      OAUTH.grant_client_role(p_client_name => 'vypervic_app_server', p_role_name => r.name);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END LOOP;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20001, 'OAuth client setup failed: ' || SQLERRM);
END;
/

-- Diagnostics: list the AutoREST privileges (expect one per REST-enabled
-- table). If a later API call returns 403, paste this output for diagnosis.
SELECT name FROM user_ords_privileges ORDER BY name;

-- PART 5: NETWORK RESTRICTIONS (operational checklist)
-- -------------------------------------------------------------------------
-- 1. OCI: restrict the Autonomous Database''s Access Control List to the
--    application server''s egress IP(s) (ATP -> Manage access control
--    lists / private endpoint).
-- 2. Verify from an outside network:
--      curl -i https://<adb-host>/ords/admin/profiles/   -> 401
-- 3. Verify with the OAuth token:
--      TOKEN=$(curl -s -X POST https://<adb-host>/ords/oauth/token \
--        -u "<client_id>:<secret>" -d "grant_type=client_credentials" | jq -r .access_token)
--      curl -i -H "Authorization: Bearer $TOKEN" https://<adb-host>/ords/admin/profiles/ -> 200
-- 4. Copy the auto-generated client credentials with the SELECT in PART 6
--    and set them in the application server environment (MANDATORY in
--    production — the server refuses to start without them):
--      ORDS_OAUTH_CLIENT_ID=<client_id from PART 6>
--      ORDS_OAUTH_CLIENT_SECRET=<client_secret from PART 6>
--    The app then handles the whole token lifecycle automatically.
--    (Alternative for gateways that accept a static key: ORDS_API_KEY.)

SELECT 'SUCCESS: ORACLE DATABASE TABLES INITIALIZED, WIPED, AND REST SERVICES ENABLED WITH AUTH' AS STATUS FROM DUAL;

-- =========================================================================
-- PART 6: COPY THE APP SERVER'S OAUTH CREDENTIALS (do this after SUCCESS)
-- -------------------------------------------------------------------------
-- ORDS generated these when PART 4 ran. Copy BOTH values exactly and set
-- them as ORDS_OAUTH_CLIENT_ID and ORDS_OAUTH_CLIENT_SECRET on the
-- application server. (Re-running PART 4 invalidates them and generates
-- new ones — rotate any time by re-running the script.)
-- =========================================================================
SELECT client_id, client_secret FROM user_ords_clients WHERE name = 'vypervic_app_server';
