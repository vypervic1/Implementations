# VyperVic roadmap acceptance

This checklist separates repository implementation from provider- and device-dependent acceptance. A checked source artifact does not imply that production infrastructure has been verified.

## Repository artifacts

- [x] Firestore rules and indexes are tracked in `firestore.rules` and `firestore.indexes.json`.
- [x] Firestore retention policy is documented in `deploy/FIRESTORE-RETENTION.md`.
- [x] Android App Links response template is tracked at `public/.well-known/assetlinks.json`.
- [x] Light and dark theme tokens, browser color-scheme synchronization, and accessibility focus/reduced-motion styles are tracked in `src/index.css`.
- [x] Offline queue, durable server-side delivery, session revocation, authorization, and audit-oriented server modules are covered by the existing test suite.

## Required external acceptance before claiming production complete

- [ ] Revoke and audit any historical provider credential, then run the full-history private-material scan.
- [ ] Apply Oracle migrations and verify ORDS roles, write fences, triggers, pagination, and failure recovery on the real ADB.
- [ ] Deploy Firestore rules, indexes, and TTL policies to the canonical project/database and run emulator plus staging tests.
- [ ] Verify real FCM delivery, token rotation, invalid-token cleanup, and cross-device notification state.
- [ ] Verify real password-recovery mail delivery, expiry, single use, and domain alignment.
- [ ] Provision private TURN relay infrastructure and verify UDP/TCP/TLS calls across separate networks.
- [ ] Build and sign the Android release with real flavor configuration, serve the exact App Links fingerprint, and test on physical devices.
- [ ] Run backup/restore, Redis recovery, monitoring, alerting, rollback, and destructive-operation drills.

These items require access to external infrastructure, credentials, provider consoles, or physical devices and cannot be truthfully completed by source edits alone.
