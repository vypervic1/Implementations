import { withSessionAccount } from './sessionState';
import type { Express, Request, RequestHandler } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { mutationRoute } from './mutationGate';
import { fetchRowById, fetchProfileById, ordsFetch, sanitizeProfileForClient } from './oracleBackend';
import { metadataPage, publicMetadata } from './metadata';
import { ApiError } from './errors';
import { assertAccountsWritable } from './destructiveJobs';
import { deleteCall } from './callState';
import { publishScopedEvent } from './realtimeBus';
import { retryDelivery } from './deliveryWorker';
const id = z.string().regex(/^[A-Za-z0-9_:-]{1,255}$/);
async function fresh(req: Request) {
  if ((await fetchProfileById(req.user!.sub))?.role !== 'admin') throw new ApiError(403, 'Current admin role required');
}
async function audit(req: Request, action: string, targetId: string, details: Record<string, unknown> = {}) {
  const result = await ordsFetch('/audit_logs/', { method: 'POST', body: { ID: randomUUID(), ADMIN_ID: req.user!.sub, ACTION: action, TARGET_ID: targetId,
    DETAILS: JSON.stringify(details), CREATED_AT: new Date().toISOString() } });
  if (!result.ok) throw new ApiError(503, 'Audit could not be persisted; retry/review required');
}
export function installAdminRoutes(app: Express, auth: RequestHandler, admin: RequestHandler, recent: RequestHandler, rate: RequestHandler) {
  app.get('/api/admin/stats', auth, admin, rate, async (_req, res) => {
    const result = await ordsFetch('/vyper-internal/admin/stats');
    if (!result.ok || !['totalUsers','totalMessages','totalCalls','onlineUsers','vaultItemsCount'].every(key => Number.isSafeInteger(result.json?.[key]) && result.json[key] >= 0)) throw new ApiError(502, 'Invalid authoritative statistics');
    res.json(result.json);
  });
  app.get('/api/admin/resources/:table', auth, admin, rate, async (req, res) => {
    const table = z.enum(['profiles','messages','calls','vault','audit_logs','delivery_outbox','deletion_jobs']).safeParse(req.params.table);
    const query = z.object({ limit: z.coerce.number().int().min(1).max(50).default(50), offset: z.coerce.number().int().min(0).max(1000000).default(0) }).strict().safeParse(req.query);
    if (!table.success || !query.success) throw new ApiError(400, 'Invalid admin list');
    const page = await metadataPage(table.data, { $orderby: { CREATED_AT: 'desc', ID: 'asc' } }, query.data.limit, query.data.offset);
    res.json({ ...page, rows: undefined, items: page.rows.map(row => table.data === 'profiles' ? sanitizeProfileForClient(publicMetadata('profiles', row)) : publicMetadata(table.data, row)) });
  });
  app.patch('/api/admin/users/:id/role', auth, admin, recent, rate, mutationRoute(async (req, res) => {
    const parsed = z.object({ role: z.enum(['user','admin']), confirmation: z.literal('CHANGE ROLE') }).strict().safeParse(req.body);
    if (!parsed.success || !id.safeParse(req.params.id).success) throw new ApiError(400, 'Role and confirmation required');
    await fresh(req); await assertAccountsWritable([req.params.id]);
    if (req.params.id === req.user!.sub && parsed.data.role === 'user') throw new ApiError(409, 'Have another administrator change your role');
    if (!await fetchProfileById(req.params.id)) throw new ApiError(404, 'User not found');
    await audit(req, 'ROLE_CHANGE_REQUESTED', req.params.id, { role: parsed.data.role });
    const result = await withSessionAccount(req.params.id, () => ordsFetch(`/profiles/${encodeURIComponent(req.params.id)}`, { method: 'PATCH', body: { ROLE: parsed.data.role } }));
    if (!result.ok) throw new ApiError(503, 'Role change not confirmed');
    res.json({ ok: true, user: sanitizeProfileForClient(await fetchProfileById(req.params.id)) });
  }));
  app.delete('/api/admin/resources/:table/:id', auth, admin, recent, rate, mutationRoute(async (req, res) => {
    const table = z.enum(['messages','calls','vault']).safeParse(req.params.table);
    if (!table.success || !id.safeParse(req.params.id).success || req.body?.confirmation !== 'DELETE RECORD') throw new ApiError(400, 'Explicit record deletion required');
    await fresh(req);
    const row = await fetchRowById(table.data, req.params.id);
    if (!row) return res.json({ ok: true, alreadyAbsent: true });
    await audit(req, 'RECORD_DELETE_REQUESTED', req.params.id, { table: table.data });
    const result = await ordsFetch(`/${table.data}/${encodeURIComponent(req.params.id)}`, { method: 'DELETE' });
    if (!result.ok && result.status !== 404) throw new ApiError(503, 'Record deletion not confirmed');
    if (table.data === 'calls') await deleteCall(req.params.id);
    if (table.data === 'messages') {
      try { await publishScopedEvent('delete_message', { messageId: row.id, chatId: row.chat_id }, { chatId: row.chat_id }); } catch { /* reconciliation covers publication failure */ }
    }
    res.json({ ok: true });
  }));
  app.post('/api/admin/deliveries/:id/retry', auth, admin, recent, rate, mutationRoute(async (req, res) => {
    await fresh(req);
    if (!id.safeParse(req.params.id).success || req.body?.confirmation !== 'RETRY DELIVERY') throw new ApiError(400, 'Explicit retry required');
    await audit(req, 'DELIVERY_RETRY', req.params.id); await retryDelivery(req.params.id); res.json({ ok: true });
  }));
}
