import type { Express, RequestHandler } from 'express';
import { ordsFetch, normalizeServerRow, sanitizeProfileForClient, fetchRowById, groupMembers } from './oracleBackend';
import { ApiError, OracleError } from './errors';
import { isChatParticipant } from './authz';
export const metadataAlias = (table: string) => ['messages','profiles','calls','groups','vault','scheduled_messages'].includes(table) ? `${table}_meta` : table;
export function publicMetadata(table: string, row: any): any {
  const result = { ...row };
  if (table === 'messages') { result.has_media = !!(row.has_media || row.file_data); delete result.file_data; }
  if (table === 'calls') delete result.signal_data;
  for (const [field, flag, kind] of [['avatar_url','has_avatar','avatar'],['cover_url','has_cover','cover'],['icon','has_icon','icon']]) {
    if (field === 'icon' && typeof row.icon === 'string' && row.icon.length <= 32) continue;
    if (['profiles','groups'].includes(table) && (row[flag] || typeof row[field] === 'string' && row[field].startsWith('data:'))) {
      result[field] = `/api/media/${table}/${encodeURIComponent(row.id)}/${kind}`;
    }
  }
  return table === 'profiles' ? sanitizeProfileForClient(result) : result;
}
export async function metadataPage(table: string, filter: Record<string, unknown>, limit = 50, offset = 0) {
  const size = Math.min(50, Math.max(1, limit));
  const response = await ordsFetch(`/${metadataAlias(table)}/?${new URLSearchParams({ q: JSON.stringify(filter), limit: String(size), offset: String(offset) })}`);
  if (!response.ok || !Array.isArray(response.json?.items)) throw new OracleError(response.status);
  const rows = response.json.items.map((row: any) => normalizeServerRow(row, table));
  return { rows, hasMore: response.json.hasMore ?? rows.length > 0, nextOffset: offset + rows.length, limit: size, offset };
}
export function installMediaRoutes(app: Express, auth: RequestHandler) {
  app.get('/api/media/:table/:id/:field', auth, async (req, res) => {
    const { table, id, field } = req.params;
    if (!['profiles','groups','messages'].includes(table) || !/^[A-Za-z0-9_:-]{1,255}$/.test(id)) throw new ApiError(404, 'Unknown media');
    const row = await fetchRowById(table, id);
    if (!row || table === 'groups' && !groupMembers(row).includes(req.user!.sub) || table === 'messages' && !await isChatParticipant(row.chat_id, req.user!.sub)) throw new ApiError(403, 'Media is not accessible');
    const column = table === 'profiles' ? ({ avatar: 'avatar_url', cover: 'cover_url' } as const)[field]
      : table === 'groups' ? ({ icon: 'icon', cover: 'cover_url' } as const)[field] : field === 'attachment' ? 'file_data' : undefined;
    if (!column || !row[column]) throw new ApiError(404, 'Media not found');
    const value = String(row[column]);
    res.setHeader('Cache-Control', 'no-store'); // do not reuse a private attachment after logout/account switch
    if (table !== 'messages' && /^https:\/\//.test(value)) return res.redirect(302, value); // browser fetch; never server-side SSRF
    const match = /^data:([a-z0-9.+/-]*)(?:;[^,]*)?;base64,([A-Za-z0-9+/=\r\n]+)$/i.exec(value);
    if (!match) throw new ApiError(422, 'Unsupported media encoding');
    const bytes = Buffer.from(match[2], 'base64');
    if (bytes.length > 3_000_000) throw new ApiError(413, 'Media exceeds the supported size');
    const mime = match[1] || 'application/octet-stream';
    const safeInline = /^(image\/(png|jpeg|webp|gif)|audio\/[a-z0-9.+-]+|video\/[a-z0-9.+-]+)$/i.test(mime);
    res.type(safeInline ? mime : 'application/octet-stream');
    res.setHeader('Content-Disposition', safeInline ? 'inline' : 'attachment');
    res.setHeader('Content-Security-Policy', "sandbox; default-src 'none'");
    res.send(bytes);
  });
}
