# Exposed Firebase credential: release blocker

## Confirmed finding

The fetched Git history (22 commits, no longer shallow at the time of inspection) contains one usable Firebase private-key blob at `src/server/firebaseAdmin.ts` (blob prefix `596fcdda0370`). The current working files do not contain that key. A targeted scan also inspects tracked/untracked source and archives and prints **locations only**.

The final restored checkout was shallow again; its history refresh failed GitHub authentication. Reconnect GitHub in Arena and repeat a full-history scan before release. This does not change the confirmed finding from the earlier full scan.

A non-secret SPKI SHA-256 fingerprint is recorded in `src/server/compromisedKeyFingerprints.json`; production configuration rejects reuse of that key, including an equivalent PEM re-encoding. This is a safeguard, **not key revocation**. Removing a file, adding `.gitignore`, or replacing a public Firebase configuration does not revoke credentials or erase Git history.

**No Google Cloud key revocation, service-account rotation, cached GitHub-view removal, or repository-wide history rewrite has been performed here.** The active CI secret gate deliberately remains failing while historical private material is reachable.

## Required owner actions, in order

1. Use the affected project's Google Cloud IAM administration to identify and disable/delete every exposed service-account key. Remove unnecessary roles/disable the old account if needed to contain access. Review audit logs and consider previously minted access tokens, not just new key authentication.
2. Issue separate, least-privilege runtime service accounts in one canonical Firebase project per environment. Scope access to the application's project/database; do not reuse Owner/Editor credentials or a browser configuration as a server credential. Required operations include FCM sends, custom-token signing, application Firestore documents and account-auth cleanup. Review the exact IAM permissions before granting them.
3. Supply replacement credentials through protected runtime environment/secret storage; validate with `npm run check:config`. Never put them in chat, a commit, APK, command-line argument or build artifact. Rotate related server/ORDS/session secrets if exposure cannot be excluded. Invalidate sessions and device registrations as part of the incident response, not only the signing key.
4. Coordinate a repository-owner maintenance window for a **complete history rewrite**: all affected branches/tags, archives, release assets, CI caches/artifacts, pull-request/cached views and forks/clones. Use an approved `git-filter-repo` sensitive-data-removal procedure and GitHub's sensitive-data-removal guidance. Preserve the clean current implementation separately, require fresh clones, and communicate changed commit IDs. Do not blindly run a force-mirror push from this working checkout.
5. Rerun the full-history/archive scan and the independent gitleaks CI job. Confirm the old credential can no longer authenticate through Google Cloud controls. Document rotation timestamps and audit findings without copying the private key.
6. Validate encrypted backups and restore procedures; old backups/archives containing credentials need access restrictions and retention review too.

The working branch can remove current source material, but a branch-only change cannot erase a secret still reachable through other repository references, cached views or existing clones. Provider-side revocation is the first containment step.
