import { beforeEach, describe, expect, it } from 'vitest';
import { getApp, login, seedUser, resetAllTables, authHeader, seedRow, getRow, allRows, settleOperation } from './helpers';
import { pauseNextDml, loseNextDeletionAck } from './mockOrds';
import { withDataMutation } from '../src/server/mutationGate';
import { ordsFetch } from '../src/server/oracleBackend';
import { runDeletionJob, accountJobId } from '../src/server/destructiveJobs';
import { withSessionAccount, revokeSession, sessionIsActive } from '../src/server/sessionState';
let app: Awaited<ReturnType<typeof getApp>>, user: ReturnType<typeof seedUser>, token: string;
beforeEach(async () => { resetAllTables(); app = await getApp(); user = seedUser(); token = (await login(app,user.email,user.password)).token!; });
describe('write fencing and non-blocking operations', () => {
  it('accepts a durable job without waiting for an in-flight writer, then drains before deletion', async () => {
    let finish!: () => void, entered!: () => void;
    const started = new Promise<void>(resolve => { entered = resolve; });
    const wait = new Promise<void>(resolve => { finish = resolve; });
    const writing = withDataMutation(async () => { entered(); await wait; await ordsFetch('/messages/', {method:'POST',body:{ID:'inflight',CHAT_ID:'general',SENDER_ID:user.id,TEXT:'before deletion',CREATED_AT:new Date().toISOString()}}); });
    await started;
    const accepted = await app.post('/api/account/delete').set(authHeader(token)).send({confirmation:'DELETE ACCOUNT'});
    expect(accepted.status).toBe(202); expect(accepted.body.success).toBe(false);
    finish(); await writing; await runDeletionJob(accepted.body.operationId);
    const status = await app.get(accepted.body.statusUrl).set('Cookie',[].concat(accepted.headers['set-cookie'] as any).map((s:string)=>s.split(';')[0]).join('; '));
    expect(status.body.status).toBe('completed'); expect(getRow('messages','inflight')).toBeNull();
    expect(status.body.results.messages.deleted).toBe(1);
    expect((await app.get('/api/auth/me').set(authHeader(token))).status).toBe(401);
    expect((await app.get(`/api/operations/wipe_00000000-0000-0000-0000-000000000000`).set('Cookie',accepted.headers['set-cookie'][0].split(';')[0])).status).toBe(403);
  });
  it('database fence waits for a transaction whose Node lease owner no longer exists', async () => {
    const pause = pauseNextDml('messages');
    const external = fetch(`${process.env.ORDS_BASE_URL}/vyper-internal/write`, {method:'POST',headers:{Authorization:`Bearer ${process.env.ORDS_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({epoch:0,method:'POST',table_name:'messages',data:{ID:'late-db',CHAT_ID:'general',SENDER_ID:user.id,TEXT:'already executing',CREATED_AT:new Date().toISOString()}})});
    await pause.started;
    const accepted = await app.post('/api/account/delete').set(authHeader(token)).send({confirmation:'DELETE ACCOUNT'});
    expect(accepted.status).toBe(202); expect(getRow('profiles',user.id)).not.toBeNull();
    pause.release(); expect((await external).status).toBe(201);
    await settleOperation(accepted);
    expect(accepted.body.success).toBe(true); expect(getRow('messages','late-db')).toBeNull();
  });
  it('retains receipt-backed counts after deletion committed but its acknowledgment was lost', async () => {
    seedRow('messages',{ID:'lost-ack',CHAT_ID:'general',SENDER_ID:user.id,TEXT:'x'}); loseNextDeletionAck('lost-ack');
    const first = await app.post('/api/account/delete').set(authHeader(token)).send({confirmation:'DELETE ACCOUNT'}); await settleOperation(first);
    expect(first.body.success).toBe(false); expect(getRow('messages','lost-ack')).toBeNull();
    await runDeletionJob(accountJobId(user.id));
    const receipts = await ordsFetch(`/vyper-internal/maintenance/counts/${accountJobId(user.id)}`);
    expect(receipts.json.messages).toBe(1); expect(getRow('profiles',user.id)).toBeNull();
  });
  it('does not allow a detached continuation to mutate after releasing its admission scope', async () => {
    let late!: () => Promise<any>;
    await withDataMutation(async () => {
      const { AsyncResource } = await import('node:async_hooks'); const resource = new AsyncResource('late-test');
      late = () => resource.runInAsyncScope(() => ordsFetch('/messages/', {method:'POST',body:{ID:'late',CHAT_ID:'general',SENDER_ID:user.id,TEXT:'no'}}));
    });
    await expect(late()).rejects.toThrow('scope has ended'); expect(allRows('messages')).toHaveLength(0);
  });
});
describe('mint/revoke serialization', () => {
  it('revocation queues behind a started mint and is the final state', async () => {
    let release!: () => void, entered!: () => void;
    const started = new Promise<void>(resolve=>{entered=resolve;}); const wait = new Promise<void>(resolve=>{release=resolve;});
    const session = {sub:user.id,jti:'test-session-serial',authTime:Date.now(),exp:Math.floor(Date.now()/1000)+60};
    const mint = withSessionAccount(user.id, async()=>{entered();await wait;expect(await sessionIsActive(session)).toBe(true);});
    await started; const revoke = revokeSession(session); release(); await Promise.all([mint,revoke]);
    expect(await sessionIsActive(session)).toBe(false);
  });
});
