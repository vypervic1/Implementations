export interface Profile {
  id: string;
  email: string;
  username: string | null;
  display_name: string | null;
  phone_number?: string | null;
  about: string | null;
  avatar_url: string | null;
  cover_url?: string | null;
  is_online: boolean;
  last_seen: string;
  created_at: string;
  role?: 'admin' | 'user' | null;
  is_admin?: boolean;
  settings_json?: string | null;
}

export interface Message {
  id: string;
  chat_id: string;
  sender_id: string;
  text: string | null;
  file_name: string | null;
  file_type: string | null;
  file_data: string | null; // Base64 representation of attachments or voice notes
  is_voice: boolean;
  created_at: string;
  is_pending?: boolean;
  retry_count?: number;
  last_attempt_at?: string;
  next_attempt_at?: string;
  last_error?: string;
  sync_status?: 'pending' | 'sending' | 'failed';
  has_media?: boolean;
  reply_to_id?: string | null;
  reply_to_sender?: string | null;
  reply_preview?: string | null;
  poll_data?: any;
  profiles?: Profile; // Joined profile of the sender
}

export interface Call {
  id: string;
  caller_id: string;
  receiver_id: string;
  type: 'voice' | 'video';
  status: 'ringing' | 'accepted' | 'rejected' | 'ended' | 'missed';
  signal_data: string | null;
  created_at: string;
  updated_at: string;
  caller?: Profile;
  receiver?: Profile;
}

export interface PushNotification {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  title: string;
  body: string;
  isMention: boolean;
  timestamp: string;
  isRead?: boolean;
}

// ---------------------------------------------------------------------------
// Oracle ORDS response row shapes (typed to replace the old `any` defaults —
// High-severity item). These mirror the lowercase keys produced by
// normalizeRow in src/oracleDB.ts.
// ---------------------------------------------------------------------------
export interface OracleProfileRow {
  id: string;
  email?: string | null;
  username?: string | null;
  display_name?: string | null;
  phone_number?: string | null;
  about?: string | null;
  avatar_url?: string | null;
  is_online?: boolean;
  last_seen?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  role?: 'admin' | 'user' | string | null;
  is_admin?: boolean;
  // Deprecated client-side: never populated by queries anymore (Issue 1).
  // Kept optional only so stale local caches still parse.
}

export interface OracleMessageRow {
  id: string;
  chat_id?: string | null;
  sender_id?: string | null;
  recipient_id?: string | null;
  text?: string | null;
  file_name?: string | null;
  file_type?: string | null;
  file_data?: string | null;
  is_voice?: boolean;
  duration?: number | null;
  is_edited?: boolean;
  is_encrypted?: boolean;
  status?: string | null;
  created_at?: string | null;
}

export interface OracleCallRow {
  id: string;
  caller_id?: string | null;
  receiver_id?: string | null;
  type?: 'voice' | 'video' | string | null;
  status?: 'ringing' | 'accepted' | 'rejected' | 'ended' | 'missed' | string | null;
  signal_data?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface OracleGroupRow {
  id: string;
  name?: string | null;
  icon?: string | null;
  creator_id?: string | null;
  members?: string[] | string | null;
  admins?: string[] | string | null;
  description?: string | null;
  cover_url?: string | null;
  theme?: Record<string, unknown> | string | null;
  created_at?: string | null;
}

export interface ThemeConfig {
  type: 'solid' | 'gradient' | 'image';
  value: string;
  brightness?: number; // 10 to 100
  zoom?: number; // 1.0 to 3.0
  offsetX?: number; // -100 to 100
  offsetY?: number; // -100 to 100
}

export interface Group {
  id: string; // group:id
  name: string;
  icon: string;
  creator_id: string;
  members: string[]; // list of profile IDs
  theme?: ThemeConfig;
  created_at: string;
  description?: string;
  cover_url?: string;
  admins?: string[]; // list of profile IDs who are admins
}

