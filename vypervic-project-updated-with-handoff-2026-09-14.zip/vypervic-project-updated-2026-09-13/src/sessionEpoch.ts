export class SessionSupersededError extends Error { constructor() { super('Session operation superseded'); this.name = 'SessionSupersededError'; } }
export class SessionEpoch {
  private epoch = 0;
  private controllers = new Set<AbortController>();
  get version() { return this.epoch; }
  invalidate() { this.epoch++; for (const controller of this.controllers) controller.abort(); this.controllers.clear(); }
  capture() {
    const version = this.epoch, controller = new AbortController(); this.controllers.add(controller);
    return { signal: controller.signal, current: () => version === this.epoch,
      assertCurrent: () => { if (version !== this.epoch) throw new SessionSupersededError(); },
      release: () => this.controllers.delete(controller) };
  }
}
// A Firebase sign-in already in flight cannot be cancelled. Queue sign-out behind it so it
// always wins on logout, and check the epoch before starting any subsequent sign-in.
let firebaseTail: Promise<unknown> = Promise.resolve();
export function serializeFirebaseAuth<T>(action: () => Promise<T>): Promise<T> {
  const current = firebaseTail.then(action, action);
  firebaseTail = current.catch(() => undefined);
  return current;
}
export const sessionEpoch = new SessionEpoch();
