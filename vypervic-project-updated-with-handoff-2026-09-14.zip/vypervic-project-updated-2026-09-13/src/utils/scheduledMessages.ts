// =========================================================================
// SCHEDULED MESSAGES — server-backed client (M-06)
// ------------------------------------------------------------------------
// Schedules used to live ONLY in localStorage: they never synced across
// devices, several tabs could process the same due message (double sends),
// and a crashed browser lost them entirely — and due messages were removed
// from local storage BEFORE delivery was durably confirmed.
//
// Now the schedule lives on the SERVER (SCHEDULED_MESSAGES table) and the
// server worker delivers it: atomic claim, idempotent message id, retry
// with cap. This module is a thin API client; localStorage remains only an
// offline DISPLAY cache of the user's own schedules.
// =========================================================================

export interface ScheduledMessage {
  id?: string;
  chatId?: string;
  chat_id?: string;
  senderId?: string;
  sender_id?: string;
  recipientName?: string;
  recipient_id?: string | null;
  text: string;
  file_name?: string | null;
  file_type?: string | null;
  file_data?: string | null;
  is_voice?: boolean;
  scheduledFor?: string; // ISO string
  scheduled_for?: string;
  createdAt?: string;
  created_at?: string;
  status?: string;
}

const CACHE_KEY = 'vyper_scheduled_messages_cache';

function readCache(): ScheduledMessage[] {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch (e) {
    return [];
  }
}

function writeCache(list: ScheduledMessage[]): void {
  try {
    // Keep file payloads out of the display cache (large base64 blobs).
    const lightweight = list.map((m) => ({
      ...m,
      file_data: m.file_data && m.file_data.length > 100_000 ? '[stored_in_indexeddb]' : m.file_data,
    }));
    localStorage.setItem(CACHE_KEY, JSON.stringify(lightweight.slice(0, 500)));
    window.dispatchEvent(new CustomEvent('vyper_scheduled_messages_changed'));
  } catch (err) {
    console.warn('Failed to persist scheduled message cache:', err);
  }
}

import { getAuthToken } from '../oracleDB';

function authHeaders(): Record<string, string> {
  // Same-origin cookies authenticate the request; the in-memory bearer
  // token is attached when present.
  try {
    const token = getAuthToken();
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch (e) {
    return {};
  }
}

/**
 * Fetch the user's schedules from the server and refresh the local cache.
 */
export async function refreshScheduledMessages(): Promise<ScheduledMessage[]> {
  try {
    const res = await fetch('/api/scheduler/messages', {
      headers: authHeaders(),
      credentials: 'same-origin',
    });
    if (!res.ok) { window.dispatchEvent(new CustomEvent('vyper_schedule_sync_unavailable')); return readCache(); }
    const body = await res.json().catch(() => ({}));
    const items: ScheduledMessage[] = Array.isArray(body?.items) ? body.items : [];
    writeCache(items);
    return items;
  } catch (err) {
    return readCache();
  }
}

/**
 * Synchronous, cache-backed list (for rendering). Call
 * refreshScheduledMessages() to sync with the server.
 */
export function getScheduledMessages(chatId?: string): ScheduledMessage[] {
  const list = readCache();
  if (chatId) {
    return list.filter((m) => m.chatId === chatId || m.chat_id === chatId);
  }
  return list;
}

/**
 * Create a schedule on the server. Returns null on failure (the UI should
 * surface the error instead of pretending the schedule exists).
 */
export async function saveScheduledMessage(msg: ScheduledMessage): Promise<ScheduledMessage | null> {
  const chatId = msg.chatId || msg.chat_id || 'general';
  const scheduledFor = msg.scheduledFor || msg.scheduled_for || new Date().toISOString();
  try {
    const res = await fetch('/api/scheduler/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      credentials: 'same-origin',
      body: JSON.stringify({
        chat_id: chatId,
        recipient_id: msg.recipient_id ?? null,
        text: msg.text ?? null,
        file_name: msg.file_name ?? null,
        file_type: msg.file_type ?? null,
        file_data: msg.file_data ?? null,
        is_voice: !!msg.is_voice,
        scheduled_for: scheduledFor,
      }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      console.warn('Failed to save scheduled message:', body?.error || res.status);
      return null;
    }
    await refreshScheduledMessages();
    return body?.item || null;
  } catch (err) {
    console.warn('Failed to save scheduled message:', err);
    return null;
  }
}

/**
 * Cancel a pending schedule (only possible while it is still 'scheduled').
 */
export async function deleteScheduledMessage(id?: string): Promise<boolean> {
  if (!id) return false;
  try {
    const res = await fetch(`/api/scheduler/messages/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: authHeaders(),
      credentials: 'same-origin',
    });
    if (!res.ok) {
      // 404/409: it was already delivered or cancelled — treat as gone.
      if (res.status === 404) {
        await refreshScheduledMessages();
        return true;
      }
      return false;
    }
    await refreshScheduledMessages();
    return true;
  } catch (err) {
    console.warn('Failed to delete scheduled message:', err);
    return false;
  }
}

/**
 * Deliver a scheduled message immediately on the user's request. The
 * SERVER performs the delivery (insert + fan-out) and marks the schedule
 * sent — the client does not duplicate the message creation path.
 */
export async function sendScheduledMessageNow(id?: string): Promise<boolean> {
  if (!id) return false;
  try {
    const res = await fetch(`/api/scheduler/messages/${encodeURIComponent(id)}/send-now`, {
      method: 'POST',
      headers: authHeaders(),
      credentials: 'same-origin',
    });
    if (!res.ok || (await res.json()).ok !== true) return false;
    await refreshScheduledMessages();
    return true;
  } catch (err) {
    console.warn('Failed to send scheduled message now:', err);
    return false;
  }
}
