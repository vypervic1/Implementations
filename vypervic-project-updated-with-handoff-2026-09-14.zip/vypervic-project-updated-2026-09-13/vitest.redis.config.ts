import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { include: ['tests/redis/**/*.test.ts'], setupFiles: ['tests/setup.ts'], testTimeout: 20000, hookTimeout: 20000, pool: 'forks', poolOptions: { forks: { singleFork: true } } } });
