import { AsyncLocalStorage } from 'node:async_hooks';
export interface MutationContext { active: boolean; assertHeld: () => void; maintenanceId?: string; epoch: number }
export const mutations = new AsyncLocalStorage<MutationContext>();
export function assertMutationContext(): MutationContext | undefined {
  const context = mutations.getStore();
  if (context) { if (!context.active) throw new Error('Mutation scope has ended'); context.assertHeld(); }
  return context;
}
