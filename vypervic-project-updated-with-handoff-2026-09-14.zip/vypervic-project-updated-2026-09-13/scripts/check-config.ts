import 'dotenv/config';
import { collectProductionConfigProblems, formatConfigProblems } from '../src/server/config';
process.env.NODE_ENV = 'production';
const problems = collectProductionConfigProblems();
if (problems.length) { console.error(formatConfigProblems(problems)); process.exitCode = 1; }
else console.log('Production configuration is structurally consistent. Connectivity/device acceptance is a separate gate.');
