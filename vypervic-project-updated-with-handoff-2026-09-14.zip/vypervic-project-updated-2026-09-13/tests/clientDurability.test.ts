import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it, vi, afterEach } from 'vitest';
import { resolveCapabilities } from '../src/capabilities';
import { getOfflineQueueMessagesLocally, saveOfflineQueueMessageLocally, removeOfflineQueueMessageLocally, clearAllCachedDataLocally } from '../src/utils/indexedDB';
import type { Message } from '../src/types';
import { setSessionStatus } from '../src/sessionStatus';
import { nativeRequest, disposeNativeRequests } from '../src/nativeBridge';
const message: Message = { id: 'stable_id', chat_id: 'general', sender_id: 'alice', text: 'offline', file_data: 'data:application/octet-stream;base64,AAAA', file_name: 'file', file_type: 'application/octet-stream', is_voice: false, created_at: new Date().toISOString() };
beforeEach(() => clearAllCachedDataLocally());
afterEach(() => { disposeNativeRequests(); vi.unstubAllGlobals(); vi.useRealTimers(); setSessionStatus('checking'); });
describe('native/browser capability isolation', () => {
  it('never uses Web Push or workers in native or generic WebViews', () => {
    for (const mode of ['native-android', 'android-webview']) expect(resolveCapabilities({ configuredMode: mode, protocol: 'https:', hasNativeBridge: true }).webPush).toBe(false);
    expect(resolveCapabilities({ userAgent: 'VyperAndroid/1', protocol: 'https:', hasNativeBridge: true }).nativePush).toBe(true);
    expect(resolveCapabilities({ configuredMode: 'native-android', protocol: 'file:', hasNativeBridge: true }).sameOriginApi).toBe(false);
    expect(resolveCapabilities({ protocol: 'https:' }).webPush).toBe(true);
  });
  it('rejects missing native integration instead of inventing an FCM token', async () => {
    vi.stubGlobal('window', { VyperNative: undefined }); vi.stubGlobal('location', { protocol: 'https:' }); vi.stubGlobal('navigator', { userAgent: 'VyperAndroid/1' });
    await expect(nativeRequest('getPushToken')).rejects.toThrow('unavailable');
  });
  it('correlates concurrent native responses and ignores unsolicited identities', async () => {
    const sent: any[] = [];
    const bridge = { onmessage: null as any, postMessage: (text: string) => sent.push(JSON.parse(text)) };
    vi.stubGlobal('window', { VyperNative: bridge }); vi.stubGlobal('location', { protocol: 'https:' }); vi.stubGlobal('navigator', { userAgent: 'VyperAndroid/1' });
    const first = nativeRequest('capabilities'), second = nativeRequest('flushCookies');
    bridge.onmessage({ data: JSON.stringify({ version: 2, id: sent[0].id, result: 'invalid' }) });
    bridge.onmessage({ data: JSON.stringify({ version: 1, id: sent[1].id, result: 'second' }) });
    bridge.onmessage({ data: JSON.stringify({ version: 1, id: sent[0].id, result: 'first' }) });
    expect(await first).toBe('first'); expect(await second).toBe('second');
  });
  it('times out bridge failures and cleans its timer', async () => {
    vi.useFakeTimers();
    vi.stubGlobal('window', { VyperNative: { onmessage: null, postMessage() {} } }); vi.stubGlobal('location', { protocol: 'https:' }); vi.stubGlobal('navigator', { userAgent: 'VyperAndroid/1' });
    const assertion = expect(nativeRequest('getPushToken')).rejects.toThrow('timed out');
    await vi.advanceTimersByTimeAsync(30001); await assertion; expect(vi.getTimerCount()).toBe(0);
  });
});
describe('IndexedDB transaction durability', () => {
  it('survives reopening and keeps actual file bytes, ID and retry metadata', async () => {
    await saveOfflineQueueMessageLocally({ ...message, retry_count: 3, next_attempt_at: '2099-01-01T00:00:00.000Z' });
    const records = await getOfflineQueueMessagesLocally();
    expect(records[0].id).toBe(message.id); expect(records[0].file_data).toBe(message.file_data); expect(records[0].retry_count).toBe(3);
    await removeOfflineQueueMessageLocally(message.id); expect(await getOfflineQueueMessagesLocally()).toHaveLength(0);
  });
  it('rejects missing IDs and clears all outbox content on logout/deletion', async () => {
    await expect(saveOfflineQueueMessageLocally({ ...message, id: '' })).rejects.toThrow();
    await saveOfflineQueueMessageLocally(message); await clearAllCachedDataLocally();
    expect(await getOfflineQueueMessagesLocally()).toHaveLength(0);
  });
});
