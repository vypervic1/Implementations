import 'dotenv/config';
import { build as buildVite } from 'vite';
import { build as buildEsbuild } from 'esbuild';
import { browserConfig } from '../src/shared/firebaseConfiguration';
// Validate public config before generating any deployable browser output.
const config = browserConfig(process.env, true);
await buildVite();
await Promise.all([
  buildEsbuild({ entryPoints: ['server.ts'], bundle: true, platform: 'node', format: 'cjs', packages: 'external', outfile: 'dist/server.cjs' }),
  buildEsbuild({ entryPoints: ['src/firebaseMessagingWorker.ts'], bundle: true, minify: true, platform: 'browser', format: 'iife', target: 'es2020',
    define: { __VYPER_FIREBASE_CONFIG__: JSON.stringify(config) }, outfile: 'dist/firebase-messaging-sw.js' }),
]);
