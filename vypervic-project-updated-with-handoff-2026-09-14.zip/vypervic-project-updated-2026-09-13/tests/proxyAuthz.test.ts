// =========================================================================
// ORACLE PROXY READ/WRITE AUTHORIZATION TESTS (G-01, C-04, M-04)
// Two users in separate chats: cross-user reads must fail.
// =========================================================================
import { describe, it, expect, beforeAll, afterEach } from 'vitest';
import {
  getApp,
  seedUser,
  login,
  authHeader,
  seedRow,
  resetAllTables,
  type TestUser,
} from './helpers';

let app: any;
let alice: TestUser;
let bob: TestUser;
let mallory: TestUser;
let aliceToken: string;
let bobToken: string;
let malloryToken: string;

beforeAll(async () => {
  app = await getApp();
});

afterEach(() => {
  resetAllTables();
});

async function setupUsers() {
  alice = seedUser({ username: 'alice' });
  bob = seedUser({ username: 'bob' });
  mallory = seedUser({ username: 'mallory' });
  aliceToken = (await login(app, alice.email, alice.password)).token!;
  bobToken = (await login(app, bob.email, bob.password)).token!;
  malloryToken = (await login(app, mallory.email, mallory.password)).token!;
  // seed messages in alice<->bob dm chat
  seedRow('messages', {
    ID: 'msg-1',
    CHAT_ID: `dm:${alice.id}:${bob.id}`,
    SENDER_ID: alice.id,
    TEXT: 'hello bob',
    CREATED_AT: new Date().toISOString(),
  });
  seedRow('messages', {
    ID: 'msg-2',
    CHAT_ID: `dm:${alice.id}:${bob.id}`,
    SENDER_ID: bob.id,
    TEXT: 'hi alice',
    CREATED_AT: new Date().toISOString(),
  });
  // messages in alice<->mallory chat (mallory's own chat)
  seedRow('messages', {
    ID: 'msg-3',
    CHAT_ID: `dm:${mallory.id}:${alice.id}`,
    SENDER_ID: mallory.id,
    TEXT: 'private to mallory and alice',
    CREATED_AT: new Date().toISOString(),
  });
}

describe('messages read authorization (G-01)', () => {
  it('rejects unfiltered list reads for non-admins', async () => {
    await setupUsers();
    const res: any = await new Promise((resolve) =>
      app.get('/api/oracle/messages/?limit=100').set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(403);
  });

  it('allows a chat member to read their chat; strangers get 403', async () => {
    await setupUsers();
    const chatId = `dm:${alice.id}:${bob.id}`;
    const strangerChat = `dm:${mallory.id}:${alice.id}`;
    const q = encodeURIComponent(JSON.stringify({ CHAT_ID: chatId }));

    const member: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/?q=${q}&limit=100`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
    );
    expect(member.status).toBe(200);

    const stranger: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/?q=${q}&limit=100`).set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(stranger.status).toBe(403);
    void strangerChat;
  });

  it('allows reading only your own sent messages via sender_id filter', async () => {
    await setupUsers();
    const q = encodeURIComponent(JSON.stringify({ SENDER_ID: mallory.id }));
    const res: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/?q=${q}&limit=100`).set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(200);

    const foreign: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/?q=${q}&limit=100`).set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(foreign.status).toBe(403);
  });

  it('single-message reads require chat membership', async () => {
    await setupUsers();
    const member: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/msg-1`).set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(member.status).toBe(200);

    const stranger: any = await new Promise((resolve) =>
      app.get(`/api/oracle/messages/msg-1`).set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(stranger.status).toBe(403);
  });

  it('message writes require membership (stranger cannot post into a foreign chat)', async () => {
    await setupUsers();
    const res: any = await new Promise((resolve) =>
      app
        .post('/api/oracle/messages/')
        .set(authHeader(malloryToken))
        .send({ ID: 'msg-evil', CHAT_ID: `dm:${alice.id}:${bob.id}`, SENDER_ID: mallory.id, TEXT: 'inject' })
        .end((e: any, r: any) => resolve(r))
    );
    expect([403, 400]).toContain(res.status);
  });
});

describe('calls read authorization (G-01)', () => {
  it('rejects unfiltered list reads; allows user-scoped reads', async () => {
    await setupUsers();
    seedRow('calls', {
      ID: 'call-1',
      CALLER_ID: alice.id,
      RECEIVER_ID: bob.id,
      TYPE: 'voice',
      STATUS: 'ringing',
      CREATED_AT: new Date().toISOString(),
      UPDATED_AT: new Date().toISOString(),
    });

    const unfiltered: any = await new Promise((resolve) =>
      app.get('/api/oracle/calls/?limit=100').set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(unfiltered.status).toBe(403);

    const scoped: any = await new Promise((resolve) =>
      app
        .get(`/api/oracle/calls/?q=${encodeURIComponent(JSON.stringify({ CALLER_ID: alice.id }))}&limit=100`)
        .set(authHeader(aliceToken))
        .end((e: any, r: any) => resolve(r))
    );
    expect(scoped.status).toBe(200);
  });

  it('rejects $or scopes that include foreign constraints', async () => {
    await setupUsers();
    const q = encodeURIComponent(
      JSON.stringify({ $or: [{ CALLER_ID: alice.id }, { RECEIVER_ID: mallory.id }] })
    );
    // bob's token: the second branch leaks mallory's calls -> rejected
    const res: any = await new Promise((resolve) =>
      app.get(`/api/oracle/calls/?q=${q}&limit=100`).set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(403);
  });

  it('allows the public general room for any authenticated user', async () => {
    await setupUsers();
    const q = encodeURIComponent(JSON.stringify({ RECEIVER_ID: 'general' }));
    const res: any = await new Promise((resolve) =>
      app.get(`/api/oracle/calls/?q=${q}&limit=100`).set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(200);
  });

  it('single-call reads are participant-only', async () => {
    await setupUsers();
    seedRow('calls', {
      ID: 'call-2',
      CALLER_ID: alice.id,
      RECEIVER_ID: bob.id,
      TYPE: 'video',
      STATUS: 'ringing',
      CREATED_AT: new Date().toISOString(),
      UPDATED_AT: new Date().toISOString(),
    });
    const member: any = await new Promise((resolve) =>
      app.get('/api/oracle/calls/call-2').set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(member.status).toBe(200);
    const stranger: any = await new Promise((resolve) =>
      app.get('/api/oracle/calls/call-2').set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(stranger.status).toBe(403);
  });
});

describe('groups read/write authorization (G-01)', () => {
  it('list reads are server-filtered to the caller\'s own groups', async () => {
    await setupUsers();
    seedRow('groups', {
      ID: 'group:g1',
      NAME: 'Alice and Bob',
      MEMBERS: JSON.stringify([alice.id, bob.id]),
      CREATOR_ID: alice.id,
      CREATED_AT: new Date().toISOString(),
    });
    seedRow('groups', {
      ID: 'group:g2',
      NAME: 'Mallory only',
      MEMBERS: JSON.stringify([mallory.id]),
      CREATOR_ID: mallory.id,
      CREATED_AT: new Date().toISOString(),
    });

    const res: any = await new Promise((resolve) =>
      app.get('/api/oracle/groups/?limit=200').set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(200);
    const ids = (res.body || []).map((g: any) => g.ID || g.id);
    expect(ids).toContain('group:g1');
    expect(ids).not.toContain('group:g2');
  });

  it('single group reads are member-only', async () => {
    await setupUsers();
    seedRow('groups', {
      ID: 'group:g1',
      NAME: 'Alice and Bob',
      MEMBERS: JSON.stringify([alice.id, bob.id]),
      CREATED_AT: new Date().toISOString(),
    });
    const member: any = await new Promise((resolve) =>
      app.get('/api/oracle/groups/group:g1').set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(member.status).toBe(200);
    const stranger: any = await new Promise((resolve) =>
      app.get('/api/oracle/groups/group:g1').set(authHeader(malloryToken)).end((e: any, r: any) => resolve(r))
    );
    expect(stranger.status).toBe(403);
  });

  it('group creation must include the creator as a member', async () => {
    await setupUsers();
    const bad: any = await new Promise((resolve) =>
      app
        .post('/api/oracle/groups/')
        .set(authHeader(malloryToken))
        .send({ ID: 'group:evil', NAME: 'sneaky', MEMBERS: JSON.stringify([alice.id, bob.id]) })
        .end((e: any, r: any) => resolve(r))
    );
    expect(bad.status).toBe(403);

    const good: any = await new Promise((resolve) =>
      app
        .post('/api/oracle/groups/')
        .set(authHeader(malloryToken))
        .send({ ID: 'group:ok', NAME: 'fine', MEMBERS: JSON.stringify([mallory.id]) })
        .end((e: any, r: any) => resolve(r))
    );
    expect(good.status).toBeLessThan(300);
  });
});

describe('profile sanitization (Issue 1 / H-06)', () => {
  it('never returns password fields or the packed auth tag', async () => {
    await setupUsers();
    const row = seedRow('profiles', {
      ID: alice.id,
      EMAIL: alice.email,
      USERNAME: alice.username,
      ABOUT: `Hey there [auth:deadbeef:${'a'.repeat(64)}]`,
      PASSWORD_HASH: 'should-never-leave',
      PASSWORD_SALT: 'should-never-leave',
    });
    void row;
    const res: any = await new Promise((resolve) =>
      app.get(`/api/oracle/profiles/${alice.id}`).set(authHeader(bobToken)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(200);
    const text = JSON.stringify(res.body);
    expect(text).not.toMatch(/should-never-leave/);
    expect(text).not.toMatch(/\[auth:/);
    expect(text.toLowerCase()).not.toContain('password_hash');
  });
});

describe('push token endpoints (C-04 / M-03)', () => {
  it('rejects unauthenticated registration and binds tokens to the JWT subject', async () => {
    await setupUsers();
    const noAuth: any = await new Promise((resolve) =>
      app.post('/api/push/register-token').send({ token: 'f'.repeat(140), deviceType: 'web' }).end((e: any, r: any) => resolve(r))
    );
    expect(noAuth.status).toBe(401);

    const ok: any = await new Promise((resolve) =>
      app
        .post('/api/push/register-token')
        .set(authHeader(bobToken))
        .send({ token: `tok_${'b'.repeat(140)}`, deviceType: 'web' })
        .end((e: any, r: any) => resolve(r))
    );
    expect(ok.status).toBe(200);

    // The durable store must hold the token under BOB's id, not a caller-chosen one
    const { allRows: rows } = await import('./mockOrds');
    const stored = rows('user_push_tokens').find((r) => r.TOKEN === `tok_${'b'.repeat(140)}`);
    expect(stored).toBeTruthy();
    expect(stored!.USER_ID).toBe(bob.id);
  });

  it('rejects malformed tokens', async () => {
    await setupUsers();
    const short: any = await new Promise((resolve) =>
      app.post('/api/push/register-token').set(authHeader(bobToken)).send({ token: 'short' }).end((e: any, r: any) => resolve(r))
    );
    expect(short.status).toBe(400);
    const weird: any = await new Promise((resolve) =>
      app.post('/api/push/register-token').set(authHeader(bobToken)).send({ token: '<script>alert(1)</script>' }).end((e: any, r: any) => resolve(r))
    );
    expect(weird.status).toBe(400);
  });

  it('rejects push sends to unrelated users (fail closed)', async () => {
    await setupUsers();
    const res: any = await new Promise((resolve) =>
      app
        .post('/api/push/send')
        .set(authHeader(malloryToken))
        .send({ targetUserId: bob.id, title: 'spam', body: 'spam' })
        .end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(403);
  });
});

describe('proxy hardening (M-04)', () => {
  it('rejects non-JSON write content types', async () => {
    await setupUsers();
    const res: any = await new Promise((resolve) =>
      app
        .post('/api/oracle/messages/')
        .set(authHeader(aliceToken))
        .set('Content-Type', 'text/plain')
        .send('plain text')
        .end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(415);
  });

  it('rejects out-of-range limit params and oversized q filters', async () => {
    await setupUsers();
    const bigLimit: any = await new Promise((resolve) =>
      app
        .get(`/api/oracle/messages/?q=${encodeURIComponent(JSON.stringify({ SENDER_ID: alice.id }))}&limit=5000`)
        .set(authHeader(aliceToken))
        .end((e: any, r: any) => resolve(r))
    );
    expect(bigLimit.status).toBe(400);

    const bigQ: any = await new Promise((resolve) =>
      app
        .get(`/api/oracle/messages/?q=${encodeURIComponent('x'.repeat(5000))}&limit=10`)
        .set(authHeader(aliceToken))
        .end((e: any, r: any) => resolve(r))
    );
    expect(bigQ.status).toBe(400);
  });

  it('404s server-only tables through the browser proxy', async () => {
    await setupUsers();
    for (const table of ['user_credentials', 'password_resets', 'scheduled_messages']) {
      const res: any = await new Promise((resolve) =>
        app.get(`/api/oracle/${table}/?limit=10`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
      );
      expect(res.status).toBe(404);
    }
  });
});

// =========================================================================
// ORDS OAuth2 client-credentials flow (C-02 completion)
// The deployment SQL creates a SHORT-LIVED (15 min) OAuth client, so the
// server must fetch/cache/refresh access tokens — sending the raw client
// secret as a static Bearer header does NOT work against real ORDS.
// =========================================================================
import {
  enableOrdsOAuth,
  disableOrdsOAuth,
  expireAllOrdsOAuthTokens,
  oauthIssuanceCount,
} from './mockOrds';
import { resetOrdsTokenCacheForTests } from '../src/server/oracleBackend';

describe('ORDS OAuth2 client-credentials (C-02)', () => {
  const CLIENT_ID = 'vypervic_app_server_test_client';
  const CLIENT_SECRET = 'oauth-client-secret-test';

  it('fetches, caches, refreshes and retries with OAuth bearer tokens', async () => {
    enableOrdsOAuth(CLIENT_ID, CLIENT_SECRET);
    resetOrdsTokenCacheForTests();
    process.env.ORDS_OAUTH_CLIENT_ID = CLIENT_ID;
    process.env.ORDS_OAUTH_CLIENT_SECRET = CLIENT_SECRET;
    try {
      await setupUsers();

      // 1st request: fetches a token from POST /oauth/token, then succeeds.
      const r1: any = await new Promise((resolve) =>
        app.get(`/api/oracle/profiles/${alice.id}`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
      );
      expect(r1.status).toBe(200);
      expect(oauthIssuanceCount()).toBe(1);

      // 2nd request: reuses the cached token — no new issuance.
      const r2: any = await new Promise((resolve) =>
        app.get(`/api/oracle/profiles/${alice.id}`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
      );
      expect(r2.status).toBe(200);
      expect(oauthIssuanceCount()).toBe(1);

      // Expire the token server-side (mock) while the server still trusts
      // its cache: 401 -> transparent refresh -> retry succeeds.
      expireAllOrdsOAuthTokens();
      const r3: any = await new Promise((resolve) =>
        app.get(`/api/oracle/profiles/${alice.id}`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
      );
      expect(r3.status).toBe(200);
      expect(oauthIssuanceCount()).toBe(2);

      // Wrong client secret must NOT yield a usable token (401 bubbles up).
      process.env.ORDS_OAUTH_CLIENT_SECRET = 'wrong-secret';
      resetOrdsTokenCacheForTests();
      const r4: any = await new Promise((resolve) =>
        app.get(`/api/oracle/profiles/${alice.id}`).set(authHeader(aliceToken)).end((e: any, r: any) => resolve(r))
      );
      expect(r4.status).toBe(503); // token fetch failure surfaces as upstream error
    } finally {
      delete process.env.ORDS_OAUTH_CLIENT_ID;
      delete process.env.ORDS_OAUTH_CLIENT_SECRET;
      disableOrdsOAuth();
      resetOrdsTokenCacheForTests();
    }
  });
});
