// =========================================================================
// ONE-OFF ADMIN SEED SCRIPT — run MANUALLY from a trusted machine
// ------------------------------------------------------------------------
// SECURITY (Issue 3): the old app auto-provisioned an admin account from an
// UNAUTHENTICATED login attempt (logging in as "admin"/"vypervic"/... with
// any 6+ char password created an admin). That backdoor has been deleted
// from the client and the server. Admin accounts are now provisioned
// exactly once, out of band, by running THIS script yourself:
//
//   SEED_ADMIN_PASSWORD="a-strong-password" \
//   SEED_ADMIN_EMAIL="you@yourdomain.com" \
//   npx tsx scripts/seed-admin.ts
//
// Optional env:
//   SEED_ADMIN_ID      default: usr_admin_vypervic
//   SEED_ADMIN_USERNAME default: vypervic
//   ORDS_BASE_URL      default: the production ADB instance
//   ORDS_API_KEY       required once ORDS-level auth is enabled in OCI
//
// The script is idempotent: re-running it RESETS the seeded admin's
// password (new salt + hash) and keeps the account in the admin role.
// Never deploy this script's password in any code or config file.
// =========================================================================

import {
  ORACLE_ADB_BASE,
  fetchProfileById,
  upsertProfile,
  generateCryptoSalt,
  hashPassword,
} from '../src/server/oracleBackend';

async function main(): Promise<void> {
  const password = process.env.SEED_ADMIN_PASSWORD;
  if (!password || password.length < 6) {
    console.error('✖ SEED_ADMIN_PASSWORD must be set in the environment (min 6 characters).');
    console.error('  Example: SEED_ADMIN_PASSWORD="a-strong-password" npx tsx scripts/seed-admin.ts');
    process.exit(1);
  }

  const id = process.env.SEED_ADMIN_ID || 'usr_admin_vypervic';
  const email = (process.env.SEED_ADMIN_EMAIL || 'vypervic1@gmail.com').trim().toLowerCase();
  const username = (process.env.SEED_ADMIN_USERNAME || 'vypervic').trim().toLowerCase();

  console.log(`Seeding admin account (ORDS: ${ORACLE_ADB_BASE})`);
  console.log(`  id:       ${id}`);
  console.log(`  email:    ${email}`);
  console.log(`  username: ${username}`);

  const existing = await fetchProfileById(id);
  if (existing) {
    console.log('→ Account exists — resetting its password and role.');
  } else {
    console.log('→ Account not found — creating it.');
  }

  const now = new Date().toISOString();
  const salt = generateCryptoSalt();
  const hash = hashPassword(password, salt);

  const row = existing
    ? {
        ...existing,
        email: existing.email || email,
        username: existing.username || username,
        role: 'admin',
        password_salt: salt,
        password_hash: hash,
      }
    : {
        id,
        email,
        username,
        display_name: 'VyperVic Admin',
        phone_number: null,
        about: 'Super Admin Operator',
        avatar_url: null,
        is_online: false,
        last_seen: now,
        created_at: now,
        role: 'admin',
        password_salt: salt,
        password_hash: hash,
      };

  const ok = await upsertProfile(row);
  if (!ok) {
    console.error('✖ Failed to write the admin profile to Oracle. Check ORDS_BASE_URL / ORDS_API_KEY and network access.');
    process.exit(1);
  }

  // H-06: the verifiers go into the SERVER-ONLY USER_CREDENTIALS table —
  // never into the profile ABOUT text.
  const { saveCredentials } = await import('../src/server/oracleBackend');
  const credOk = await saveCredentials(id, hash, salt);
  if (!credOk) {
    console.warn('⚠ Could not write USER_CREDENTIALS (does the table exist? run oracle_wipe_and_reset.sql).');
    console.warn('  Login will fall back to the legacy ABOUT tag until the credentials table is available.');
  }

  console.log('✔ Admin account seeded. The password is stored ONLY as a PBKDF2 hash in the server-only credentials table.');
  console.log('  You can now sign in to the app with these credentials.');
  console.log('  To change the password later, re-run this script with a new SEED_ADMIN_PASSWORD.');
}

main().catch((err) => {
  console.error('✖ Seed script failed:', err?.message || err);
  process.exit(1);
});
