import { sharedGet, sharedSet, storeKey, withQueuedLease } from './sharedStore';
export interface SessionIdentity { sub: string; jti: string; exp: number; authTime: number }
const MAX_SESSION_MS = 30 * 86400_000;
export async function sessionIsActive(session: SessionIdentity): Promise<boolean> {
  if (!session.sub || !session.jti || !Number.isFinite(session.exp) || !Number.isFinite(session.authTime) || session.exp * 1000 <= Date.now()) return false;
  const [revoked, cutoff, wipeCutoff] = await Promise.all([
    sharedGet(storeKey('revoked-session', session.jti)), sharedGet(storeKey('revoked-user', session.sub)), sharedGet('vyper:session-wipe-cutoff'),
  ]);
  return !revoked && session.authTime > Number(cutoff || 0) && session.authTime > Number(wipeCutoff || 0);
}
export const withSessionAccount = <T>(userId: string, action: () => Promise<T>) => withQueuedLease(`session-account:${userId}`, action);
export async function revokeSession(session: SessionIdentity): Promise<void> {
  return withSessionAccount(session.sub, async () => {
  await sharedSet(storeKey('revoked-session', session.jti), '1', Math.max(1, session.exp * 1000 - Date.now()));
  });
}
export async function revokeUserSessions(userId: string): Promise<void> {
  return withSessionAccount(userId, async () => {
  await sharedSet(storeKey('revoked-user', userId), String(Date.now()), MAX_SESSION_MS);
  });
}
export async function revokeEverySession(): Promise<void> {
  await sharedSet('vyper:session-wipe-cutoff', String(Date.now()), MAX_SESSION_MS);
}
