import { oracleDB, ClientApiError } from '../oracleDB';
import { getSessionStatus } from '../sessionStatus';
import { sessionEpoch } from '../sessionEpoch';
import type { Message } from '../types';
import { cacheMessagesLocally, deleteCachedMessageLocally, saveOfflineQueueMessageLocally, getOfflineQueueMessagesLocally, removeOfflineQueueMessageLocally } from './indexedDB';
let memoryQueue: Message[] = [];
let flushing = false;
const changed = () => { if (typeof window !== 'undefined') window.dispatchEvent(new Event('vyper_outbox_changed')); };
export function retryDelay(attempts: number): number { return Math.min(300000, 1000 * 2 ** Math.min(attempts, 9)); }
export function getOfflineQueue(): Message[] { return memoryQueue.filter(row => row.sender_id === getSessionStatus().userId); }
export async function getOfflineQueueAsync(): Promise<Message[]> {
  const version = sessionEpoch.version, rows = await getOfflineQueueMessagesLocally();
  if (version !== sessionEpoch.version) return [];
  memoryQueue = rows; return rows;
}
export async function queueOfflineMessage(msg: Message): Promise<void> {
  const version = sessionEpoch.version;
  if (!msg.id || msg.file_data === '[stored_in_indexeddb]') throw new Error('Cannot queue a placeholder message');
  const existing = (await getOfflineQueueMessagesLocally()).find(row => row.id === msg.id);
  const pending: Message = { ...msg, ...existing, is_pending: true, sync_status: existing?.sync_status || 'pending', retry_count: existing?.retry_count || 0 };
  await saveOfflineQueueMessageLocally(pending, () => version === sessionEpoch.version);
  memoryQueue = [...memoryQueue.filter(row => row.id !== msg.id), pending];
  await cacheMessagesLocally([pending]); changed();
}
export async function removeOfflineMessage(id: string): Promise<void> {
  await removeOfflineQueueMessageLocally(id); memoryQueue = memoryQueue.filter(row => row.id !== id); changed();
}
export async function cancelOfflineMessage(id: string): Promise<void> {
  const row = (await getOfflineQueueAsync()).find(row => row.id === id);
  if (row?.sync_status === 'sending') throw new Error('Send in progress; wait for its acknowledgment before cancelling');
  await removeOfflineMessage(id); await deleteCachedMessageLocally(id); changed();
}
export async function retryOfflineMessage(id: string): Promise<void> {
  const row = (await getOfflineQueueAsync()).find(row => row.id === id && row.sender_id === getSessionStatus().userId);
  if (!row || getSessionStatus().status !== 'authenticated') throw new Error('Verify this account before retrying');
  await saveOfflineQueueMessageLocally({ ...row, sync_status: 'pending', retry_count: 0, next_attempt_at: new Date().toISOString(), last_error: undefined });
  changed(); await flushOfflineQueue();
}
export async function flushOfflineQueue(onSynced?: (id: string) => void): Promise<void> {
  const session = getSessionStatus(), version = sessionEpoch.version;
  const current = () => version === sessionEpoch.version && getSessionStatus().status === 'authenticated' && getSessionStatus().userId === session.userId;
  if (flushing || !current() || !session.userId) return;
  flushing = true;
  try {
    for (const msg of await getOfflineQueueAsync()) {
      if (!current()) break;
      if (msg.sender_id !== session.userId || msg.sync_status === 'failed' || (msg.retry_count || 0) >= 8 || Date.parse(msg.next_attempt_at || '') > Date.now()) continue;
      // 'sending' from a killed WebView is safe to retry with the same ID.
      const attempt = (msg.retry_count || 0) + 1;
      const sending = { ...msg, sync_status: 'sending' as const, retry_count: attempt, last_attempt_at: new Date().toISOString() };
      await saveOfflineQueueMessageLocally(sending, current); memoryQueue = memoryQueue.map(row => row.id === msg.id ? sending : row); changed();
      const { data, error } = await oracleDB.from('messages').insert({ id: msg.id, chat_id: msg.chat_id, sender_id: msg.sender_id, text: msg.text,
        file_name: msg.file_name, file_type: msg.file_type, file_data: msg.file_data, is_voice: msg.is_voice });
      if (!current()) break; // never recreate an old account's outbox after logout/purge
      if (!error && data?.id === msg.id) { await removeOfflineMessage(msg.id); onSynced?.(msg.id); }
      else {
        const permanent = error instanceof ClientApiError && [400,403,404,409,413,422].includes(error.status);
        const failed: Message = { ...msg, retry_count: attempt, sync_status: permanent || attempt >= 8 ? 'failed' : 'pending', is_pending: true,
          last_attempt_at: new Date().toISOString(), next_attempt_at: new Date(Date.now() + retryDelay(attempt)).toISOString(), last_error: error?.message || 'Missing acknowledgment' };
        await saveOfflineQueueMessageLocally(failed, current); memoryQueue = memoryQueue.map(row => row.id === msg.id ? failed : row); await cacheMessagesLocally([failed]); changed();
      }
    }
  } catch { console.error('[Outbox] Local storage/synchronization unavailable; no completion assumed'); }
  finally { flushing = false; }
}
