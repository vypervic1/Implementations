import { useEffect, useState } from 'react';
import { dismissOperation, getOperation, pendingOperationId, type OperationProgress } from '../utils/operations';
export function OperationStatus() {
  const [operation, setOperation] = useState<OperationProgress | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let disposed = false, inFlight = false;
    const abort = new AbortController();
    const refresh = async () => {
      const id = pendingOperationId(); if (!id || inFlight) return;
      inFlight = true;
      try { const current = await getOperation(id, abort.signal); if (!disposed) { setOperation(current); setError(''); } }
      catch { if (!disposed) setError('Status temporarily unavailable; the operation may still be running.'); }
      finally { inFlight = false; }
    };
    const changed = (event: Event) => setOperation((event as CustomEvent).detail);
    const dismissed = () => { setOperation(null); setError(''); };
    window.addEventListener('vyper_operation', changed); window.addEventListener('vyper_operation_dismissed', dismissed);
    void refresh(); const timer = setInterval(() => void refresh(), 5000);
    return () => { disposed = true; abort.abort(); clearInterval(timer); window.removeEventListener('vyper_operation', changed); window.removeEventListener('vyper_operation_dismissed', dismissed); };
  }, []);
  if (!operation && !error) return null;
  return <aside role="status" className="fixed bottom-4 left-4 right-4 z-[9999] rounded-xl border border-amber-400/30 bg-slate-950 p-3 text-xs text-white shadow-xl">
    <b>Data operation: {operation?.status || 'checking'}</b>
    <p>{error || `${Object.keys(operation?.results || {}).length} checkpoint(s) recorded. ${operation?.success ? 'Completion confirmed by the server.' : 'Do not assume deletion is complete.'}`}</p>
    <p className="break-all font-mono opacity-70">{operation?.operationId || pendingOperationId()}</p>
    <button className="mt-2 underline" onClick={dismissOperation}>Dismiss status (does not cancel the operation)</button>
  </aside>;
}
