// =========================================================================
// OUTBOUND EMAIL (R-01) — real account recovery delivery
// ------------------------------------------------------------------------
// Password reset / verification emails need a delivery provider. This
// module integrates with Resend (https://resend.com) via RESEND_API_KEY.
// When no provider is configured, the caller gets an honest "delivery
// unavailable" result — the old behavior (returning success from a stub
// that sent nothing) is gone.
// =========================================================================

const RESEND_ENDPOINT = 'https://api.resend.com/emails';

export interface MailResult {
  delivered: boolean;
  reason?: string;
}

function mailFrom(): string {
  return process.env.MAIL_FROM || 'VyperVic <noreply@vypechat.cloud-ip.cc>';
}

export function mailerConfigured(): boolean {
  return !!process.env.RESEND_API_KEY;
}

async function sendViaResend(payload: Record<string, any>): Promise<MailResult> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return { delivered: false, reason: 'no mail provider configured (set RESEND_API_KEY)' };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const res = await fetch(RESEND_ENDPOINT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) {
      const detail = await res.json().catch(() => ({} as any));
      console.error('[Mailer] provider error', { status: res.status, name: detail?.name, message: detail?.message });
      return { delivered: false, reason: `mail provider responded ${res.status}` };
    }
    const accepted = await res.json().catch(() => ({} as any));
    console.info('[Mailer] provider accepted message', { id: accepted?.id || 'unknown' });
    return { delivered: true };
  } catch (err: any) {
    console.error('[Mailer] send failed:', err?.message);
    return { delivered: false, reason: 'mail provider unreachable' };
  } finally { clearTimeout(timeout); }
}

const wrap = (title: string, bodyLines: string[]): string => `
  <div style="font-family:system-ui,Segoe UI,Arial,sans-serif;max-width:520px;margin:0 auto;padding:24px">
    <h2 style="margin:0 0 16px">${title}</h2>
    ${bodyLines.map((l) => `<p style="line-height:1.5">${l}</p>`).join('')}
  </div>`;

export async function sendPasswordResetEmail(to: string, resetUrl: string): Promise<MailResult> {
  return sendViaResend({
    from: mailFrom(),
    to,
    subject: 'Reset your VyperVic password',
    html: wrap('Reset your password', [
      'We received a request to reset your VyperVic password.',
      `<a href="${resetUrl}" style="display:inline-block;background:#7c3aed;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Choose a new password</a>`,
      'This link expires in 1 hour and can be used only once.',
      'If you did not request this, you can safely ignore this email — your password stays unchanged.',
    ]),
  });
}

export async function sendPasswordResetCodeEmail(to: string, code: string): Promise<MailResult> {
  return sendViaResend({
    from: mailFrom(),
    to,
    subject: 'Your VyperVic password recovery code',
    html: wrap('Password recovery code', [
      `Your one-time VyperVic verification code is <strong style="font-size:28px;letter-spacing:6px">${code}</strong>.`,
      'Enter this code in the VyperVic app to choose a new password.',
      'This code expires in 10 minutes and can be used only once.',
      'If you did not request this, you can safely ignore this email — your password stays unchanged.',
    ]),
  });
}

export async function sendVerificationEmail(to: string, verifyUrl: string): Promise<MailResult> {
  return sendViaResend({
    from: mailFrom(),
    to,
    subject: 'Verify your VyperVic email',
    html: wrap('Verify your email', [
      'Please confirm this email address for your VyperVic account.',
      `<a href="${verifyUrl}" style="display:inline-block;background:#7c3aed;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Verify email</a>`,
      'If you did not sign up, you can ignore this email.',
    ]),
  });
}
