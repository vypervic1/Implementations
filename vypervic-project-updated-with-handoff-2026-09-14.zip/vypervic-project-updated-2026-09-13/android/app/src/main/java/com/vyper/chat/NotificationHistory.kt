package com.vyper.chat
import android.content.Context
import org.json.JSONObject
/** Stable delivery event IDs provide at-least-once transport deduplication on this device. */
object NotificationHistory {
    @Synchronized fun seen(context: Context, id: String): Boolean = read(context).optLong(id, 0L) > System.currentTimeMillis() - 48 * 3600000L
    @Synchronized fun record(context: Context, id: String) {
        val old = read(context)
        val entries = old.keys().asSequence().map { it to old.optLong(it) }.filter { it.second > System.currentTimeMillis() - 48 * 3600000L }.toList()
        val next = JSONObject()
        for ((key, value) in entries.sortedByDescending { it.second }.take(199)) next.put(key, value)
        next.put(id, System.currentTimeMillis())
        context.getSharedPreferences("push_receipts", Context.MODE_PRIVATE).edit().putString("seen", next.toString()).commit()
    }
    private fun read(context: Context): JSONObject = try { JSONObject(context.getSharedPreferences("push_receipts", Context.MODE_PRIVATE).getString("seen", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
}
