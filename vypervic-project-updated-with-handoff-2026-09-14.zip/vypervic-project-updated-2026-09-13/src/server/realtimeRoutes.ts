import { publicMetadata } from './metadata';
import type { Express, RequestHandler } from 'express';
import { z } from 'zod';
import { ApiError } from './errors';
import { identifier } from './oracleRoutes';
import { fetchRowById, fetchProfileById, fetchGroupById, sanitizeProfileForClient, groupMembers } from './oracleBackend';
import { isChatParticipant } from './authz';
import { publishScopedEvent, type Audience, sseClients } from './realtimeBus';
import { broadcastLimiter, clientIp, hashKey, RateLimiter } from './rateLimit';
const signalLimiter = new RateLimiter({ windowMs: 10_000, max: 40 });
const id = identifier;
const identity = { senderId: id.optional(), userId: id.optional(), readerId: id.optional() };
const schemas: Record<string, z.ZodType> = {
  new_message: z.object({ message: z.object({ id, chat_id: id.optional(), sender_id: id.optional() }).loose() }).strict(),
  edit_message: z.object({ messageId: id, text: z.string().max(32000).nullable().optional() }).strict(),
  reaction: z.object({ messageId: id, emoji: z.string().min(1).max(32), ...identity }).strict(),
  pin_change: z.object({ chatId: id, pinnedMessageIds: z.array(id).max(100) }).strict(),
  read_receipt: z.object({ chatId: id, lastReadMessageId: id, timestamp: z.string().max(50).optional(), ...identity }).strict(),
  typing: z.object({ chatId: id, isTyping: z.boolean(), username: z.string().max(255).optional(), ...identity }).strict(),
  call_invite: z.object({ call: z.object({ id, caller_id: id.optional(), receiver_id: id.optional() }).loose() }).strict(),
  call_status_update: z.object({ callId: id, status: z.enum(['ringing', 'accepted', 'rejected', 'ended', 'missed']), ...identity }).strict(),
  webrtc_signaling: z.object({
    callId: id, type: z.enum(['offer', 'answer', 'candidate', 'ice-candidate', 'end', 'ringing', 'hangup', 'ready']),
    receiverId: id.optional(), ...identity, sigId: id.optional(), ts: z.number().optional(),
    status: z.enum(['ended', 'rejected', 'missed']).optional(),
    sdp: z.object({ type: z.enum(['offer', 'answer']), sdp: z.string().max(48000) }).strict().optional(),
    candidate: z.object({ candidate: z.string().max(8192), sdpMid: z.string().max(255).nullable().optional(), sdpMLineIndex: z.number().int().min(0).nullable().optional(), usernameFragment: z.string().max(255).nullable().optional() }).strict().optional(),
  }).strict(),
  vyper_user_presence: z.object({ userId: id, is_online: z.boolean(), last_seen: z.string().max(50).optional() }).strict(),
  vyper_group_created: z.object({ group: z.object({ id }).loose() }).strict(),
  vyper_group_updated: z.object({ group: z.object({ id }).loose() }).strict(),
  vyper_call_live_reaction: z.object({ callId: id, emoji: z.string().min(1).max(32), senderName: z.string().max(255).optional(), ...identity }).strict(),
  vyper_group_call_heartbeat: z.object({ callId: id, profile: z.object({ id }).loose() }).strict(),
  vyper_group_call_leave: z.object({ callId: id, userId: id }).strict(),
};
export function installRealtimeRoutes(app: Express, requireAuth: RequestHandler) {
  app.post('/api/realtime/signal', requireAuth, async (req, res) => {
    const limit = signalLimiter.consume(req.user!.sub);
    if (!limit.allowed) { res.setHeader('Retry-After', String(limit.retryAfterSec)); return res.status(429).json({ error: 'Too many signaling messages' }); }
    const signalSchema = z.object({
      type: z.enum(['ready', 'offer', 'answer', 'candidate', 'hangup']),
      senderId: id.optional(), receiverId: id.optional(), callId: id,
      status: z.enum(['ended', 'rejected', 'missed']).optional(),
      sdp: z.object({ type: z.enum(['offer', 'answer']), sdp: z.string().max(48000) }).strict().optional(),
      candidate: z.object({ candidate: z.string().max(8192), sdpMid: z.string().max(255).nullable().optional(), sdpMLineIndex: z.number().int().min(0).nullable().optional(), usernameFragment: z.string().max(255).nullable().optional() }).strict().optional(),
    }).strict();
    const parsed = z.object({ callId: id, signalData: signalSchema, clientId: z.string().max(128).nullable().optional() }).strict().safeParse(req.body);
    if (!parsed.success || JSON.stringify(req.body).length > 64_000) throw new ApiError(400, 'Invalid signaling payload');
    const { callId, signalData, clientId } = parsed.data;
    const call = await fetchRowById('calls', callId);
    if (!call || ![call.caller_id, call.receiver_id].includes(req.user!.sub)) throw new ApiError(403, 'Not a call participant');
    if (signalData.type !== 'hangup' && call.status !== 'accepted') throw new ApiError(409, 'Call media is not ready until the call is accepted');
    const peer = call.caller_id === req.user!.sub ? call.receiver_id : call.caller_id;
    if (signalData.receiverId && signalData.receiverId !== peer) throw new ApiError(403, 'Signal target is not the peer');
    if (signalData.type === 'offer' || signalData.type === 'answer') {
      if (!signalData.sdp || signalData.sdp.type !== signalData.type) throw new ApiError(400, 'Missing or inconsistent SDP');
    }
    if (signalData.type === 'candidate' && !signalData.candidate) throw new ApiError(400, 'Missing ICE candidate');
    const delivered = await publishScopedEvent('webrtc_signal', { callId, signalData: { ...signalData, senderId: req.user!.sub, receiverId: peer, callId }, from: req.user!.sub }, { callId }, { excludeClientId: clientId || undefined });
    res.json({ ok: true, delivered });
  });
  app.post('/api/realtime/broadcast', requireAuth, async (req, res) => {
    const sub = req.user!.sub;
    const gate = await broadcastLimiter.consumeBoth(hashKey('ip', clientIp(req)), hashKey('user', sub));
    if (!gate.allowed) { res.setHeader('Retry-After', String(gate.retryAfterSec)); return res.status(gate.reason === 'unavailable' ? 503 : 429).json({ error: 'Realtime rate limit exceeded' }); }
    const envelope = z.object({ event: z.string().max(64), payload: z.record(z.string(), z.unknown()), targetUserId: id.optional(), clientId: z.string().max(128).nullable().optional(), channel: z.string().max(128).optional() }).strict().safeParse(req.body);
    if (!envelope.success || JSON.stringify(req.body).length > 256_000) throw new ApiError(400, 'Malformed realtime event');
    const { event, targetUserId, clientId } = envelope.data;
    const parsed = schemas[event]?.safeParse(envelope.data.payload);
    if (!parsed?.success) throw new ApiError(400, 'Unsupported event or invalid payload');
    if (clientId && sseClients.get(clientId)?.userId !== sub) throw new ApiError(403, 'Foreign stream client');
    let payload = parsed.data as Record<string, any>;
    for (const field of ['senderId', 'readerId', 'userId']) if (payload[field] && payload[field] !== sub) throw new ApiError(403, 'Forged event identity');
    let scope: Audience;
    const messageId = payload.messageId || payload.lastReadMessageId || payload.message?.id;
    if (messageId) {
      const message = await fetchRowById('messages', messageId);
      if (!message || !(await isChatParticipant(message.chat_id, sub))) throw new ApiError(403, 'Not a message participant');
      if (payload.chatId && payload.chatId !== message.chat_id || payload.message?.chat_id && payload.message.chat_id !== message.chat_id) throw new ApiError(403, 'Cross-chat injection');
      if (['new_message', 'edit_message'].includes(event) && message.sender_id !== sub) throw new ApiError(403, 'Not the message sender');
      if (payload.message?.sender_id && payload.message.sender_id !== sub) throw new ApiError(403, 'Forged message sender');
      scope = { chatId: message.chat_id };
      if (event === 'new_message') payload = { message: publicMetadata('messages', message) };
      if (event === 'edit_message') payload = { messageId, text: message.text, chatId: message.chat_id };
    } else if (payload.callId || payload.call?.id) {
      const call = await fetchRowById('calls', payload.callId || payload.call.id);
      if (!call || ![call.caller_id, call.receiver_id].includes(sub)) throw new ApiError(403, 'Not a call participant');
      scope = { callId: call.id };
      if (event === 'call_invite') {
        if (call.caller_id !== sub || call.status !== 'ringing' || payload.call.caller_id && payload.call.caller_id !== sub || payload.call.receiver_id && payload.call.receiver_id !== call.receiver_id) throw new ApiError(403, 'Invalid call invite');
        payload = { call };
      }
      if (event === 'call_status_update' && payload.status !== call.status) throw new ApiError(409, 'Persist call state before broadcasting');
      if (event === 'webrtc_signaling') {
        if (!['ringing', 'accepted'].includes(call.status) && payload.type !== 'hangup') throw new ApiError(409, 'Call is no longer active');
        const other = call.caller_id === sub ? call.receiver_id : call.caller_id;
        if (payload.receiverId && payload.receiverId !== other) throw new ApiError(403, 'Signal target is not the peer');
        if (['offer', 'answer'].includes(payload.type) && (!payload.sdp || payload.sdp.type !== payload.type)) throw new ApiError(400, 'Missing or inconsistent SDP');
        if (['candidate', 'ice-candidate'].includes(payload.type) && !payload.candidate) throw new ApiError(400, 'Missing ICE candidate');
        payload = { ...payload, receiverId: other };
      }
      if (payload.profile) {
        if (payload.profile.id !== sub) throw new ApiError(403, 'Forged participant profile');
        payload.profile = sanitizeProfileForClient(await fetchProfileById(sub));
      }
    } else if (payload.chatId) {
      if (!(await isChatParticipant(payload.chatId, sub))) throw new ApiError(403, 'Not a chat member');
      scope = { chatId: payload.chatId };
      if (event === 'pin_change') for (const pinnedId of payload.pinnedMessageIds) {
        const message = await fetchRowById('messages', pinnedId);
        if (!message || message.chat_id !== payload.chatId) throw new ApiError(403, 'Cross-chat pin');
      }
    } else if (payload.group) {
      const group = await fetchGroupById(payload.group.id);
      if (!group || !groupMembers(group).includes(sub)) throw new ApiError(403, 'Not a group member');
      payload = { group };
      scope = { userIds: groupMembers(group) };
    } else if (event === 'vyper_user_presence') {
      // Presence is persisted through the protected profile endpoint; this is only a hint.
      const profile = await fetchProfileById(sub);
      payload = { userId: sub, is_online: !!profile?.is_online, last_seen: profile?.last_seen };
      // Presence remains Oracle-backed; this event is only a self-state hint.
      scope = { userIds: [sub] };
    } else throw new ApiError(400, 'Missing event scope');
    const profile = await fetchProfileById(sub);
    payload.senderId = sub;
    if (event === 'reaction' || event === 'typing') payload.userId = sub;
    if (event === 'typing') payload.username = profile?.display_name || profile?.username;
    if (event === 'read_receipt') { payload.readerId = sub; payload.timestamp = new Date().toISOString(); }
    if (event === 'vyper_call_live_reaction') payload.senderName = profile?.display_name || profile?.username;
    // This endpoint NEVER mutates messages, call state, group membership or moderation state.
    const deliveredTo = await publishScopedEvent(event, payload, scope, { targetUserId, excludeClientId: clientId || undefined });
    res.json({ ok: true, deliveredTo });
  });
}
