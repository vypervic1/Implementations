package com.vyper.chat

import org.junit.Assert.*
import org.junit.Test

class NavigationPolicyTest {
    private val policy = NavigationPolicy("https://chat.example.com")
    @Test fun allowsOnlyCanonicalHttpsOrigin() {
        assertTrue(policy.permits("https://chat.example.com/?chat=dm:a:b"))
        assertTrue(policy.permits("https://chat.example.com:443/api/auth/me"))
        listOf("http://chat.example.com", "https://chat.example.com.evil.test", "https://evil.test@chat.example.com", "file:///android_asset/index.html", "content://app", "javascript:alert(1)", "https://chat.example.com:444").forEach { assertFalse(it, policy.permits(it)) }
    }
    @Test fun externalLinksNeverInheritBridgePrivileges() {
        assertTrue(policy.externalHttps("https://example.org/article"))
        assertFalse(policy.externalHttps("intent://malicious"))
        assertFalse(policy.externalHttps("https://chat.example.com/"))
    }
}
