import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, RefreshCw, Shield, Trash2 } from 'lucide-react';
import type { Profile } from '../types';
import { submitOperation } from '../utils/operations';
interface AdminDashboardProps { currentUser: Profile; onBack: () => void; onToast?: (message: string, type?: 'success'|'error'|'info') => void }
type Tab = 'profiles'|'messages'|'calls'|'vault'|'audit_logs'|'delivery_outbox'|'deletion_jobs';
const tabs: [Tab,string][] = [['profiles','People'],['messages','Messages'],['calls','Calls'],['vault','Vault'],['audit_logs','Audit'],['delivery_outbox','Delivery'],['deletion_jobs','Operations']];
export const AdminDashboard = ({ currentUser, onBack, onToast }: AdminDashboardProps) => {
  const [tab, setTab] = useState<Tab>('profiles');
  const [rows, setRows] = useState<any[]>([]), [stats, setStats] = useState<Record<string, number> | null>(null);
  const [nextOffset, setNextOffset] = useState<number | null>(null), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [action, setAction] = useState<{ label: string; confirmation: string; run: () => Promise<void> } | null>(null);
  const [password, setPassword] = useState(''), [confirmation, setConfirmation] = useState('');
  const generation = useRef(0), mounted = useRef(true), aborts = useRef(new Set<AbortController>());
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; generation.current++; for (const abort of aborts.current) abort.abort(); }; }, []);
  async function api(path: string, method = 'GET', body?: unknown) {
    const abort = new AbortController(); aborts.current.add(abort);
    try {
      const response = await fetch(path, { method, credentials: 'same-origin', cache: 'no-store', signal: abort.signal,
        headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
      const data = await response.json();
      if (!response.ok) {
        if (mounted.current && [401,403].includes(response.status)) { setRows([]); setStats(null); }
        throw new Error(data.error || 'Admin request was not confirmed');
      }
      return data;
    } finally { aborts.current.delete(abort); }
  }
  const refresh = async (offset = 0) => {
    const version = ++generation.current; setBusy(true); setError('');
    try {
      const [counts, page] = await Promise.all([api('/api/admin/stats'), api(`/api/admin/resources/${tab}?offset=${offset}&limit=50`)]);
      if (!mounted.current || generation.current !== version) return;
      setStats(counts); setRows(previous => offset ? [...previous, ...page.items] : page.items);
      setNextOffset(page.hasMore ? page.nextOffset : null);
    } catch (error) { if (mounted.current && generation.current === version) setError(error instanceof Error ? error.message : 'Admin data unavailable'); }
    finally { if (mounted.current && generation.current === version) setBusy(false); }
  };
  useEffect(() => { if (currentUser.role === 'admin') void refresh(); }, [tab, currentUser.id, currentUser.role]);
  const propose = (label: string, literal: string, run: () => Promise<void>) => { setPassword(''); setConfirmation(''); setAction({ label, confirmation: literal, run }); };
  async function execute() {
    if (!action || confirmation !== action.confirmation || !password) return;
    setBusy(true); setError('');
    try {
      await api('/api/auth/reauth', 'POST', { password });
      setPassword('');
      await action.run();
      if (mounted.current) { setAction(null); onToast?.('Server confirmed the action or accepted its durable operation', 'success'); await refresh(); }
    } catch (error) { if (mounted.current) { const message = error instanceof Error ? error.message : 'Action not confirmed'; setError(message); onToast?.(message, 'error'); } }
    finally { if (mounted.current) { setPassword(''); setBusy(false); } }
  }
  const operation = async (path: string, data: unknown) => {
    const job = await submitOperation(path, data);
    if (!job.success) throw new Error(`Operation ${job.operationId} is ${job.status}; review the persistent status panel.`);
  };
  if (currentUser.role !== 'admin') return <section className="p-8 text-white"><h2>Administrator access required</h2><button onClick={onBack}>Return to chats</button></section>;
  return <section className="h-full overflow-y-auto bg-[#080b10] text-[#eef1f6] p-4 space-y-5">
    <header className="flex items-center justify-between gap-3"><button aria-label="Back" onClick={onBack}><ArrowLeft /></button><h1 className="font-bold text-lg flex gap-2"><Shield className="text-[#20e3a2]" /> Administration</h1><button disabled={busy} aria-label="Refresh" onClick={() => void refresh()}><RefreshCw className={busy ? 'animate-spin' : ''} /></button></header>
    <p className="text-xs text-slate-400">Every request revalidates your current database role. Counts come from Oracle; lists are paginated metadata, not a database dump.</p>
    <div className="grid grid-cols-2 gap-2">{[['totalUsers','Accounts'],['totalMessages','Messages'],['totalCalls','Calls'],['pendingDeliveries','Pending delivery']].map(([key,label]) => <div key={key} className="rounded-xl border border-slate-800 p-3"><div className="text-2xl font-bold">{stats?.[key] ?? '—'}</div><div className="text-xs text-slate-400">{label}</div></div>)}</div>
    {error && <p role="alert" className="rounded-lg bg-red-950 p-3 text-sm text-red-200">{error}</p>}
    <nav className="flex flex-wrap gap-2">{tabs.map(([key,label]) => <button key={key} onClick={() => setTab(key)} className={`rounded-lg px-3 py-2 text-xs ${tab===key?'bg-[#20e3a2] text-black':'bg-slate-800'}`}>{label}</button>)}</nav>
    <div className="space-y-2">{rows.map(row => <article key={row.id} className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
      <div className="flex justify-between gap-2"><div className="min-w-0"><strong className="block truncate text-sm">{row.display_name || row.file_name || row.action || row.kind || row.type || row.id}</strong><small className="break-all text-slate-400">{row.email || row.chat_id || row.target_id || row.id}</small></div>
        {tab==='profiles' && row.id !== currentUser.id && <button className="shrink-0 text-xs text-[#20e3a2]" onClick={() => propose(`Change ${row.username || row.id}'s role`, 'CHANGE ROLE', async () => { await api(`/api/admin/users/${encodeURIComponent(row.id)}/role`, 'PATCH', { role: row.role==='admin'?'user':'admin', confirmation:'CHANGE ROLE' }); })}>{row.role==='admin'?'Remove admin':'Make admin'}</button>}
      </div>
      {row.text && <p className="mt-2 line-clamp-3 break-words text-sm">{row.text}</p>}
      {row.status && <p className="mt-2 text-xs">Status: {row.status} {row.attempts != null && `· attempts ${row.attempts}`}</p>}
      {row.last_error && <p className="mt-1 text-xs text-amber-300">{row.last_error}</p>}
      <div className="mt-2 flex gap-3 text-xs">
        {['messages','calls','vault'].includes(tab) && <button className="text-red-300 flex gap-1" onClick={() => propose('Delete this record', 'DELETE RECORD', async () => { await api(`/api/admin/resources/${tab}/${encodeURIComponent(row.id)}`, 'DELETE', { confirmation:'DELETE RECORD' }); })}><Trash2 size={13} /> Delete</button>}
        {tab==='profiles' && row.id !== currentUser.id && <button className="text-red-300" onClick={() => propose('Delete this account and its owned data', 'DELETE ACCOUNT', () => operation('/api/account/delete', { targetUserId:row.id, confirmation:'DELETE ACCOUNT' }))}>Delete account</button>}
        {tab==='delivery_outbox' && row.status==='failed' && <button className="text-amber-300" onClick={() => propose('Retry failed delivery', 'RETRY DELIVERY', async () => { await api(`/api/admin/deliveries/${row.id}/retry`, 'POST', { confirmation:'RETRY DELIVERY' }); })}>Retry delivery</button>}
        {tab==='deletion_jobs' && ['partial','failed','queued'].includes(row.status) && <button className="text-amber-300" onClick={() => propose('Resume the same immutable operation', 'RETRY DELETION', () => operation(`/api/admin/operations/${row.id}/retry`, { confirmation:'RETRY DELETION' }))}>Resume operation</button>}
      </div>
    </article>)}</div>
    {!rows.length && !busy && <p className="text-sm text-slate-400">No records on this page.</p>}
    {nextOffset !== null && <button disabled={busy} className="w-full rounded-lg bg-slate-800 p-3" onClick={() => void refresh(nextOffset)}>Load more</button>}
    <section className="rounded-xl border border-red-900 p-4 space-y-3"><h2 className="font-bold text-red-300">Destructive operations</h2><p className="text-xs text-slate-400">Jobs fence concurrent writes and survive a lost HTTP connection. Do not infer completion from logout or a timeout.</p>
      <div className="flex flex-wrap gap-2">{(['messages','calls'] as const).map(kind => <button key={kind} className="rounded bg-red-950 px-3 py-2 text-xs" onClick={() => propose(`Delete all ${kind}`, `DELETE ALL ${kind.toUpperCase()}`, () => operation('/api/admin/operations', {kind,confirmation:`DELETE ALL ${kind.toUpperCase()}`}))}>Delete all {kind}</button>)}
        <button className="rounded bg-red-800 px-3 py-2 text-xs" onClick={() => propose('Wipe all application accounts and data', 'WIPE ALL DATA', () => operation('/api/admin/wipe-all', {confirmation:'WIPE ALL DATA'}))}>Wipe all data</button>
      </div>
    </section>
    {action && <div className="fixed inset-0 z-[1000] bg-black/80 flex items-center justify-center p-5"><form onSubmit={event => { event.preventDefault(); void execute(); }} className="w-full max-w-sm rounded-2xl border border-slate-700 bg-slate-950 p-5 space-y-3">
      <h2 className="font-bold">{action.label}</h2><p className="text-xs text-amber-300">Type {action.confirmation} and re-enter your current password.</p>
      <input autoComplete="off" aria-label="Action confirmation" className="w-full rounded bg-slate-800 p-2" value={confirmation} onChange={e=>setConfirmation(e.target.value)} />
      <input type="password" autoComplete="current-password" aria-label="Current password" className="w-full rounded bg-slate-800 p-2" value={password} onChange={e=>setPassword(e.target.value)} />
      <div className="flex gap-3"><button type="button" onClick={()=>{setAction(null);setPassword('');}} className="rounded bg-slate-800 px-3 py-2">Cancel</button><button disabled={busy || confirmation!==action.confirmation || !password} className="rounded bg-red-700 px-3 py-2 disabled:opacity-40">Confirm</button></div>
    </form></div>}
  </section>;
};
