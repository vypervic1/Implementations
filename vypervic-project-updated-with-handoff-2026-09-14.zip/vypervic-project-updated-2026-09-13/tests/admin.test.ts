import { settleOperation } from './helpers';
// =========================================================================
// ADMIN OPERATIONS TESTS (G-04, H-01, H-02, M-08)
// =========================================================================
import { describe, it, expect, beforeAll, afterEach } from 'vitest';
import {
  getApp,
  seedUser,
  login,
  authHeader,
  seedRow,
  allRows,
  resetAllTables,
  type TestUser,
} from './helpers';

let app: any;
let admin: TestUser;
let userA: TestUser;
let userB: TestUser;
let adminToken: string;
let aToken: string;
let bToken: string;

beforeAll(async () => {
  app = await getApp();
});

afterEach(() => {
  resetAllTables();
});

async function setupUsers(withAdmin = true) {
  admin = seedUser({ username: 'admin', role: 'admin' });
  userA = seedUser({ username: 'usera' });
  userB = seedUser({ username: 'userb' });
  if (withAdmin) adminToken = (await login(app, admin.email, admin.password)).token!;
  aToken = (await login(app, userA.email, userA.password)).token!;
  bToken = (await login(app, userB.email, userB.password)).token!;
}

describe('admin wipe-all (G-04 pagination)', () => {
  it('wipes MORE than one page of rows completely', async () => {
    await setupUsers();
    // 1,050 messages: the old implementation listed once with limit=1000
    // and silently left 50 rows behind.
    for (let i = 0; i < 1050; i++) {
      seedRow('messages', {
        ID: `m-${i}`,
        CHAT_ID: 'general',
        SENDER_ID: userA.id,
        TEXT: `msg ${i}`,
        CREATED_AT: new Date().toISOString(),
      });
    }
    for (let i = 0; i < 1020; i++) {
      seedRow('calls', {
        ID: `c-${i}`,
        CALLER_ID: userA.id,
        RECEIVER_ID: userB.id,
        STATUS: 'ended',
        CREATED_AT: new Date().toISOString(),
        UPDATED_AT: new Date().toISOString(),
      });
    }

    const res: any = await new Promise((resolve) =>
      app.post('/api/admin/wipe-all').set(authHeader(adminToken)).send({ confirmation: 'WIPE ALL DATA' }).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.failedCount).toBe(0);
    expect(allRows('messages').length).toBe(0);
    expect(allRows('calls').length).toBe(0);
    expect(allRows('profiles').length).toBe(0);
  });

  it('rejects non-admins (403)', async () => {
    await setupUsers();
    const res: any = await new Promise((resolve) =>
      app.post('/api/admin/wipe-all').set(authHeader(aToken)).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(403);
  });

  it('rejects a demoted admin whose JWT still carries the admin role (M-08)', async () => {
    await setupUsers();
    // Demote the admin directly in the DB (role change without re-login).
    const row = allRows('profiles').find((p) => p.ID === admin.id)!;
    row.ROLE = 'user';
    seedRow('profiles', row);

    const res: any = await new Promise((resolve) =>
      app.post('/api/admin/wipe-all').set(authHeader(adminToken)).send({ confirmation: 'WIPE ALL DATA' }).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(403);
  });
});

describe('account deletion scoping (H-01)', () => {
  it('deletes ONLY the target account\'s rows; other users\' data survives', async () => {
    await setupUsers(false);
    // A's calls (as caller and receiver) + B's unrelated call
    seedRow('calls', { ID: 'ca-1', CALLER_ID: userA.id, RECEIVER_ID: userB.id, STATUS: 'ended', CREATED_AT: new Date().toISOString() });
    seedRow('calls', { ID: 'ca-2', CALLER_ID: userB.id, RECEIVER_ID: userA.id, STATUS: 'ended', CREATED_AT: new Date().toISOString() });
    seedRow('calls', { ID: 'cb-1', CALLER_ID: userB.id, RECEIVER_ID: 'someone-else', STATUS: 'ended', CREATED_AT: new Date().toISOString() });
    seedRow('messages', { ID: 'ma-1', CHAT_ID: 'general', SENDER_ID: userA.id, TEXT: 'a', CREATED_AT: new Date().toISOString() });
    seedRow('messages', { ID: 'mb-1', CHAT_ID: 'general', SENDER_ID: userB.id, TEXT: 'b', CREATED_AT: new Date().toISOString() });

    const res: any = await new Promise((resolve) =>
      app.post('/api/account/delete').set(authHeader(aToken)).send({ confirmation: 'DELETE ACCOUNT' }).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.results.calls.deleted).toBe(2);
    expect(allRows('calls').map((c) => c.ID)).toEqual(['cb-1']);
    expect(allRows('messages').map((m) => m.ID)).toEqual(['mb-1']);
    expect(allRows('profiles').find((p) => p.ID === userA.id)).toBeUndefined();
    expect(allRows('profiles').find((p) => p.ID === userB.id)).toBeTruthy();
  });

  it('refuses a non-admin targeting someone else (H-01 regression)', async () => {
    await setupUsers(false);
    const res: any = await new Promise((resolve) =>
      app.post('/api/account/delete').set(authHeader(aToken)).send({ targetUserId: userB.id }).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(403);
    expect(allRows('profiles').find((p) => p.ID === userB.id)).toBeTruthy();
  });

  it('a demoted admin cannot delete other accounts (M-08)', async () => {
    await setupUsers();
    const row = allRows('profiles').find((p) => p.ID === admin.id)!;
    row.ROLE = 'user';
    seedRow('profiles', row);

    const res: any = await new Promise((resolve) =>
      app.post('/api/account/delete').set(authHeader(adminToken)).send({ targetUserId: userB.id }).end((e: any, r: any) => resolve(r))
    );
    await settleOperation(res);
    expect(res.status).toBe(403);
    expect(allRows('profiles').find((p) => p.ID === userB.id)).toBeTruthy();
  });
});
