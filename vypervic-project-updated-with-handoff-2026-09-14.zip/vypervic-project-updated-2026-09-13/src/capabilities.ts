export type RuntimeMode = 'browser' | 'android-webview' | 'native-android';
export interface RuntimeCapabilities { mode: RuntimeMode; webPush: boolean; serviceWorker: boolean; nativePush: boolean; sameOriginApi: boolean }
interface CapabilityInput { configuredMode?: string; userAgent?: string; hasNativeBridge?: boolean; protocol?: string }
export function resolveCapabilities(input: CapabilityInput): RuntimeCapabilities {
  const nativeShell = /VyperAndroid\/1/.test(input.userAgent || '');
  const mode: RuntimeMode = input.configuredMode === 'native-android' || nativeShell ? 'native-android'
    : input.configuredMode === 'android-webview' || /; wv\)/.test(input.userAgent || '') ? 'android-webview' : 'browser';
  const sameOriginApi = input.protocol === 'https:' || mode === 'browser' && input.protocol === 'http:';
  return { mode, webPush: mode === 'browser' && sameOriginApi, serviceWorker: mode === 'browser' && sameOriginApi,
    nativePush: mode === 'native-android' && !!input.hasNativeBridge && sameOriginApi, sameOriginApi };
}
export function capabilities(): RuntimeCapabilities {
  return resolveCapabilities({ configuredMode: (import.meta as any).env?.VITE_RUNTIME_MODE,
    userAgent: typeof navigator === 'undefined' ? '' : navigator.userAgent,
    hasNativeBridge: typeof window !== 'undefined' && typeof window.VyperNative?.postMessage === 'function',
    protocol: typeof location === 'undefined' ? '' : location.protocol });
}
