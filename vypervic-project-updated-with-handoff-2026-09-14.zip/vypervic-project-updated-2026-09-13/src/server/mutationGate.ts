import type { RequestHandler } from 'express';
import { withQueuedLease, BusyError } from './sharedStore';
import { ApiError } from './errors';
import { mutations, assertMutationContext } from './mutationContext';

/** All logical application writes share one admission gate. Availability is sacrificed during
 * destructive maintenance; Oracle's transaction lock/trigger is the final fence for requests
 * that were already executing when an instance died or lost a Redis lease. */
export async function withDataMutation<T>(work: () => Promise<T>, maintenanceId?: string): Promise<T> {
  const parent = assertMutationContext();
  if (parent) {
    if (maintenanceId && parent.maintenanceId !== maintenanceId) throw new ApiError(503, 'Conflicting maintenance operation');
    return work();
  }
  return withQueuedLease('application-writes-v2', async held => {
    const context = { active: true, assertHeld: held, maintenanceId, epoch: 0 };
    return mutations.run(context, async () => {
      try {
        const { ordsFetch, fetchRowsByFilter } = await import('./oracleBackend');
        if (!maintenanceId) {
          const active = await fetchRowsByFilter('deletion_jobs', { STATUS: { $in: ['queued', 'running', 'partial', 'failed'] } }, 1);
          if (active.length) throw new ApiError(503, 'Maintenance is in progress; retry later', 'maintenance');
          const gate = await ordsFetch('/vyper-internal/gate/');
          if (!gate.ok || gate.json?.schemaVersion !== 3 || gate.json?.guardCount !== 10 || gate.json?.outboxTriggers !== 2 || gate.json?.owner) throw new ApiError(503, 'Database write gate unavailable', 'maintenance');
          context.epoch = Number(gate.json.epoch);
          if (!Number.isFinite(context.epoch)) throw new Error('Invalid database fence');
        }
        return await work();
      } finally { context.active = false; }
    });
  }).catch(error => {
    if (error instanceof BusyError) throw new ApiError(503, 'Another write is finishing; retry shortly', 'write_busy');
    throw error;
  });
}
export function mutationRoute(handler: RequestHandler): RequestHandler {
  return (req, res, next) => { void withDataMutation(async () => { await handler(req, res, next); }).catch(next); };
}

export async function beginMaintenance(id: string): Promise<void> {
  const context = assertMutationContext();
  if (context?.maintenanceId !== id) throw new Error('Maintenance scope required');
  const { ordsFetch } = await import('./oracleBackend');
  const response = await ordsFetch('/vyper-internal/gate/begin', { method: 'POST', body: { job_id: id } });
  if (!response.ok || response.json.owner !== id) throw new ApiError(503, 'Database maintenance fence unavailable');
  context.epoch = Number(response.json.epoch);
}
export async function finishMaintenance(id: string): Promise<void> {
  const context = assertMutationContext();
  if (context?.maintenanceId !== id) throw new Error('Maintenance scope required');
  const { ordsFetch } = await import('./oracleBackend');
  // Oracle is opened last. If it fails, its durable owner/active job keeps writes closed.
  const result = await ordsFetch('/vyper-internal/gate/end', { method: 'POST', body: { job_id: id } });
  if (!result.ok) throw new ApiError(503, 'Could not release database maintenance fence');
}
