-- ADDITIVE migration for an existing Vyper schema. NEVER runs DROP/TRUNCATE.
-- Requires the base application tables. Take an encrypted, restore-tested backup first.
-- SQLcl/SQL*Plus: @deploy/migrations/001_additive_hardening.sql
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
SET SERVEROUTPUT ON

-- Stop on duplicates; an operator must resolve ownership, never silently select a winner.
DECLARE n NUMBER;
BEGIN
  SELECT COUNT(*) INTO n FROM (SELECT LOWER(TRIM(email)) FROM profiles GROUP BY LOWER(TRIM(email)) HAVING COUNT(*) > 1);
  IF n > 0 THEN RAISE_APPLICATION_ERROR(-20001, 'Resolve duplicate normalized emails before migration'); END IF;
  SELECT COUNT(*) INTO n FROM (SELECT LOWER(TRIM(username)) FROM profiles WHERE username IS NOT NULL GROUP BY LOWER(TRIM(username)) HAVING COUNT(*) > 1);
  IF n > 0 THEN RAISE_APPLICATION_ERROR(-20002, 'Resolve duplicate normalized usernames before migration'); END IF;
END;
/
DECLARE n NUMBER;
BEGIN
  SELECT COUNT(*) INTO n FROM user_indexes WHERE index_name = 'UX_PROFILE_EMAIL_NORMALIZED';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX UX_PROFILE_EMAIL_NORMALIZED ON profiles (LOWER(TRIM(email)))'; END IF;
  SELECT COUNT(*) INTO n FROM user_indexes WHERE index_name = 'UX_PROFILE_USERNAME_NORMALIZED';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX UX_PROFILE_USERNAME_NORMALIZED ON profiles (LOWER(TRIM(username)))'; END IF;
END;
/

DECLARE
  PROCEDURE add_column(t VARCHAR2, c VARCHAR2, definition VARCHAR2) IS n NUMBER;
  BEGIN
    SELECT COUNT(*) INTO n FROM user_tab_columns WHERE table_name = UPPER(t) AND column_name = UPPER(c);
    IF n = 0 THEN EXECUTE IMMEDIATE 'ALTER TABLE ' || t || ' ADD (' || c || ' ' || definition || ')'; END IF;
  END;
BEGIN
  add_column('PROFILES', 'COVER_URL', 'CLOB');
  add_column('USER_PUSH_TOKENS', 'SESSION_JTI', 'VARCHAR2(128)');
  add_column('USER_PUSH_TOKENS', 'SESSION_EXP', 'NUMBER');
  add_column('USER_PUSH_TOKENS', 'SESSION_AUTH_TIME', 'NUMBER');
  add_column('USER_PUSH_TOKENS', 'TOKEN_SOURCE', 'VARCHAR2(32)');
  add_column('USER_PUSH_TOKENS', 'DEVICE_ID', 'VARCHAR2(128)');
  add_column('USER_PUSH_TOKENS', 'DEVICE_NAME', 'VARCHAR2(100)');
  add_column('USER_PUSH_TOKENS', 'REVOKED_AT', 'VARCHAR2(100)');
  add_column('SCHEDULED_MESSAGES', 'NEXT_ATTEMPT_AT', 'VARCHAR2(100)');
END;
/
UPDATE profiles SET email = LOWER(TRIM(email)), username = LOWER(TRIM(username));
UPDATE scheduled_messages SET next_attempt_at = scheduled_for WHERE next_attempt_at IS NULL;

-- Legacy push rows cannot prove native/browser provenance or device binding. Re-register real
-- FCM tokens after login rather than guessing ownership or keeping synthetic subscriptions alive.
UPDATE user_push_tokens SET revoked_at = TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP), 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"')
 WHERE session_jti IS NULL OR token_source IS NULL OR device_id IS NULL OR LENGTH(token) < 100 OR REGEXP_LIKE(token, '^(mock|test_|fcm_|device_fcm_)', 'i');

DECLARE n NUMBER;
BEGIN
  SELECT COUNT(*) INTO n FROM user_tables WHERE table_name = 'DELETION_JOBS';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE TABLE deletion_jobs (
    id VARCHAR2(255) PRIMARY KEY, kind VARCHAR2(20) NOT NULL,
    actor_id VARCHAR2(255) NOT NULL, target_id VARCHAR2(255),
    status VARCHAR2(20) NOT NULL, steps CLOB CHECK (steps IS JSON),
    attempts NUMBER DEFAULT 0 NOT NULL, last_error VARCHAR2(1000),
    created_at VARCHAR2(100) NOT NULL, updated_at VARCHAR2(100) NOT NULL,
    CONSTRAINT ck_deletion_kind CHECK (kind IN (''wipe'', ''account'')),
    CONSTRAINT ck_deletion_status CHECK (status IN (''queued'', ''running'', ''partial'', ''failed'', ''completed'')))'; END IF;
  SELECT COUNT(*) INTO n FROM user_indexes WHERE index_name = 'IX_DELETION_STATUS';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE INDEX IX_DELETION_STATUS ON deletion_jobs(status, updated_at)'; END IF;
  SELECT COUNT(*) INTO n FROM user_indexes WHERE index_name = 'IX_SCHEDULE_NEXT_ATTEMPT';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE INDEX IX_SCHEDULE_NEXT_ATTEMPT ON scheduled_messages(status, next_attempt_at, scheduled_for)'; END IF;
  SELECT COUNT(*) INTO n FROM user_indexes WHERE index_name = 'IX_PUSH_OWNER_DEVICE';
  IF n = 0 THEN EXECUTE IMMEDIATE 'CREATE INDEX IX_PUSH_OWNER_DEVICE ON user_push_tokens(user_id, device_id, revoked_at)'; END IF;
END;
/
BEGIN
  ORDS.ENABLE_OBJECT(p_enabled => TRUE, p_schema => USER, p_object => 'DELETION_JOBS',
    p_object_type => 'TABLE', p_object_alias => 'deletion_jobs', p_auto_rest_auth => TRUE);
END;
/
COMMIT;
-- Add DELETION_JOBS to the same protected ORDS privilege/role as the existing tables.
-- Verify ALL direct unauthenticated object URLs return 401, not 200 or a public redirect.
-- Run scripts/migrate-credentials.ts --apply separately (server-only credential copy + profile scrubbing).
