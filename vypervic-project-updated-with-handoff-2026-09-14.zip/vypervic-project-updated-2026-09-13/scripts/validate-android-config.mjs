import { readFileSync } from 'node:fs';
const flavors = process.argv.slice(2);
if (!flavors.length) throw new Error('Pass one or more Android environment flavors');
for (const flavor of flavors) {
  if (!['development', 'staging', 'production'].includes(flavor)) throw new Error('Unsupported flavor');
  const env = flavor.toUpperCase();
  const origin = new URL(process.env[`${env}_APP_ORIGIN`]);
  if (origin.protocol !== 'https:' || origin.pathname !== '/' || origin.username || origin.search || origin.hash || ['localhost','127.0.0.1'].includes(origin.hostname)) throw new Error(`${flavor}: invalid HTTPS origin`);
  const config = JSON.parse(readFileSync(`android/app/src/${flavor}/google-services.json`, 'utf8'));
  const expected = process.env[`${env}_FIREBASE_PROJECT_ID`];
  if (expected?.startsWith('demo-') && process.env.VYPER_CI_BUILD !== '1') throw new Error('Demo native Firebase configuration cannot be deployed');
  if (!expected || config.project_info.project_id !== expected) throw new Error(`${flavor}: native/web Firebase project mismatch`);
  const packageName = `com.vyper.chat${flavor === 'production' ? '' : `.${flavor}`}`;
  const client = config.client?.find(c => c.client_info?.android_client_info?.package_name === packageName);
  if (!client || !client.client_info.mobilesdk_app_id.startsWith(`1:${config.project_info.project_number}:android:`)) throw new Error(`${flavor}: Firebase Android app ID, package or sender mismatch`);
  if (JSON.stringify(config).includes('private_key')) throw new Error('Private Firebase credentials must NEVER enter the APK');
}
console.log('Native public configuration validated (no secrets printed).');
