import { mkdirSync, writeFileSync } from 'node:fs';
if (process.env.VYPER_CI_BUILD !== '1') throw new Error('Contract configuration is permitted only in explicit CI test mode');
mkdirSync('android/app/src/development', { recursive: true });
writeFileSync('android/app/src/development/google-services.json', JSON.stringify({
  project_info: { project_number: '100000000002', project_id: 'demo-ci-native', storage_bucket: 'demo-ci-native.appspot.com' },
  client: [{ client_info: { mobilesdk_app_id: '1:100000000002:android:000000000000000000000002', android_client_info: { package_name: 'com.vyper.chat.development' } },
    api_key: [{ current_key: 'ci-public-only-not-a-live-key' }], services: { appinvite_service: { other_platform_oauth_client: [] } } }], configuration_version: '1',
}, null, 2));
