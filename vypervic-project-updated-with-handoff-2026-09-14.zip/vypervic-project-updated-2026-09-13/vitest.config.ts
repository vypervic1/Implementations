import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  test: {
    include: ['tests/**/*.test.ts'],
    exclude: ['tests/firestore/**', 'tests/redis/**'],
    setupFiles: ['tests/setup.ts'],
    testTimeout: 60_000,
    hookTimeout: 60_000,
    environment: 'node',
    globals: false,
    // Keep the mock ORDS server + app in the same process.
    pool: 'forks',
    poolOptions: {
      forks: { singleFork: true },
    },
  },
});
