import { capabilities } from './capabilities';
export interface NativePushToken { token: string; deviceId: string; source: 'android_native'; deviceType: 'android' }
declare global {
  interface Window { VyperNative?: { postMessage(message: string): void; onmessage: ((event: MessageEvent) => void) | null } }
}
const pending = new Map<string, { complete: (value: any) => void; fail: (error: Error) => void; timer: ReturnType<typeof setTimeout> }>();
/** v1: origin-scoped AndroidX WebMessage bridge. No arbitrary native URL/HTTP/file methods. */
export function nativeRequest<T>(method: 'capabilities' | 'getPushToken' | 'flushCookies' | 'logout'): Promise<T> {
  const bridge = window.VyperNative;
  if (!capabilities().nativePush || !bridge) return Promise.reject(new Error('Native Android integration is unavailable'));
  bridge.onmessage = event => {
    let data: any;
    try { data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data; } catch { return; }
    if (data.version !== 1 || typeof data.id !== 'string') return;
    const callback = pending.get(data.id); if (!callback) return;
    clearTimeout(callback.timer); pending.delete(data.id);
    if (data.error) callback.fail(new Error(String(data.error))); else callback.complete(data.result);
  };
  return new Promise<T>((resolve, reject) => {
    const id = crypto.randomUUID();
    const timer = setTimeout(() => { pending.delete(id); reject(new Error('Android bridge timed out')); }, 30000);
    pending.set(id, { complete: resolve, fail: reject, timer });
    try { bridge.postMessage(JSON.stringify({ version: 1, id, method })); }
    catch { clearTimeout(timer); pending.delete(id); reject(new Error('Android bridge unavailable')); }
  });
}
export function disposeNativeRequests(): void {
  for (const entry of pending.values()) { clearTimeout(entry.timer); entry.fail(new Error('Native request cancelled')); }
  pending.clear();
  if (typeof window !== 'undefined' && window.VyperNative) window.VyperNative.onmessage = null;
}
