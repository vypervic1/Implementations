// Shared test helpers: app import, user seeding, login.
import supertest from 'supertest';

export type TestApi = supertest.SuperTest<supertest.Test>;

export async function getApp(): Promise<TestApi> {
  // Imported lazily so the vitest setup (mock ORDS env) runs first.
  const mod: any = await import('../server');
  return supertest(mod.app) as unknown as TestApi;
}

const { generateCryptoSalt, hashPassword } = await import('../src/server/oracleBackend');
const { seedRow, clearTable, resetAllTables, allRows, getRow, credentialRowId, resetTokenRowId } = await import('./mockOrds');

export { seedRow, clearTable, resetAllTables, allRows, getRow, credentialRowId, resetTokenRowId };

export interface TestUser {
  id: string;
  email: string;
  username: string;
  password: string;
  role: 'admin' | 'user';
}

export function seedUser(overrides: Partial<TestUser> = {}): TestUser {
  const user: TestUser = {
    id: overrides.id || `usr_${Math.random().toString(36).slice(2, 12)}`,
    email: overrides.email || `user${Math.random().toString(36).slice(2, 8)}@example.com`,
    username: overrides.username || `user${Math.random().toString(36).slice(2, 8)}`,
    password: overrides.password || 'correct-horse-battery',
    role: overrides.role || 'user',
  };
  const salt = generateCryptoSalt();
  const hash = hashPassword(user.password, salt);
  seedRow('profiles', {
    ID: user.id,
    EMAIL: user.email,
    USERNAME: user.username,
    DISPLAY_NAME: `Display ${user.username}`,
    PHONE_NUMBER: null,
    ABOUT: 'Hey there! I am using VyperVic.',
    AVATAR_URL: null,
    IS_ONLINE: 0,
    LAST_SEEN: new Date().toISOString(),
    CREATED_AT: new Date().toISOString(),
    UPDATED_AT: new Date().toISOString(),
    ROLE: user.role,
    PASSWORD_HASH: hash,
    PASSWORD_SALT: salt,
  });
  return user;
}

export async function login(
  app: any,
  identifier: string,
  password: string
): Promise<{ status: number; body: any; token?: string; cookie?: string }> {
  const res: any = await new Promise((resolve) => {
    const req = app
      .post('/api/auth/login')
      .set('X-Session-Mode', 'bearer')
      .set('X-Forwarded-For', `10.0.0.${Math.ceil(Math.random() * 250)}`) // isolate rate limits per test call
      .send({ identifier, password });
    req.end((err: any, r: any) => resolve(r));
  });
  const setCookie = res.headers['set-cookie'];
  return {
    status: res.status,
    body: res.body,
    token: res.body?.token,
    cookie: Array.isArray(setCookie) ? setCookie[0]?.split(';')[0] : setCookie,
  };
}

export function authHeader(token: string): Record<string, string> {
  return { Authorization: `Bearer ${token}` };
}

/** Settle an explicitly accepted HTTP operation through its read-only receipt, even if the
 * job revoked the initiating account. This does not fabricate an HTTP mutation success. */
export async function settleOperation(response: any) {
  if (response.status !== 202 || !response.body.operationId) return response;
  const { waitForLocalOperation } = await import('../src/server/destructiveJobs');
  await waitForLocalOperation(response.body.operationId);
  const cookies = response.headers['set-cookie'];
  const result = await (await getApp()).get(response.body.statusUrl).set('Cookie', cookies.map((c: string) => c.split(';')[0]).join('; '));
  if (result.status !== 200) throw new Error('Operation status could not be verified');
  response.status = result.status; response.body = result.body;
  return response;
}
