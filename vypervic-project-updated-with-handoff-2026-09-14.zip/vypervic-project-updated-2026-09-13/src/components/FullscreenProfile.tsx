import { useResources } from '../utils/resources';
import React, { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Search,
  Shield,
  User,
  Mail,
  Info,
  Hash,
  Users,
  Circle,
  Phone,
  Video,
  MessageSquare,
  Calendar,
  Lock,
  Sparkles,
  X,
  Share2,
  Image as ImageIcon,
  Star,
  ChevronRight,
  FileText,
  Link as LinkIcon,
  ExternalLink,
  Download,
  Mic,
  Check,
  Copy,
  Send,
  Maximize2,
  Minimize2,
  Camera,
  Edit2,
  Upload
} from 'lucide-react';
import { Profile, Group, Message } from '../types';
import { isUserOnline, formatLastSeen, parseProfileAbout, compareMessagesChronologically, getCleanMessageExcerpt } from '../utils/customNames';
import { oracleDB } from '../oracleDB';
import InteractiveImageViewer from './InteractiveImageViewer';

interface FullscreenProfileProps {
  type: 'user' | 'group' | 'general';
  data?: any; // Profile, Group, or undefined (for general)
  currentUser: Profile;
  allProfiles: Profile[];
  messagesList?: Message[];
  groupsList?: Group[];
  onClose: () => void;
  onStartDM?: (peer: Profile) => void;
  onCall?: (type: 'voice' | 'video', peerId: string) => void;
  onSelectChat?: (chatId: string, peer?: Profile | null, targetMessageId?: string) => void;
  onSendMessage?: (message: Message) => void;
}

export default function FullscreenProfile({
  type,
  data,
  currentUser,
  allProfiles,
  messagesList = [],
  groupsList = [],
  onClose,
  onStartDM,
  onCall,
  onSelectChat,
  onSendMessage,
}: FullscreenProfileProps) {
  const resources = useResources();
  const [searchQuery, setSearchQuery] = useState('');
  const [showZoomedAvatar, setShowZoomedAvatar] = useState(false);
  const [showZoomedCover, setShowZoomedCover] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  const handleProfileScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const top = e.currentTarget.scrollTop;
    setScrollY(top);
    if (top > 55 && !isScrolled) {
      setIsScrolled(true);
    } else if (top <= 55 && isScrolled) {
      setIsScrolled(false);
    }
  };

  const formatDateSafe = (d?: string | null) => {
    if (!d) return 'Recently';
    const dt = new Date(d);
    return isNaN(dt.getTime()) ? 'Recently' : dt.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  };

  // Determine which layout to show
  const isGeneral = type === 'general';
  const isGroup = type === 'group';
  const isUser = type === 'user';

  // Determine the chat room ID for this profile
  const targetChatId = useMemo(() => {
    if (isGeneral) return 'general';
    if (isGroup && data) return (data as Group).id;
    if (isUser && data) {
      const sortedIds = [currentUser.id, (data as Profile).id].sort();
      return `dm:${sortedIds[0]}:${sortedIds[1]}`;
    }
    return '';
  }, [isGeneral, isGroup, isUser, data, currentUser.id]);

  // Admin and permission checks
  const isAdmin = currentUser.role === 'admin';
  const canEdit = isAdmin || (isUser && data && data.id === currentUser.id);

  // Admin editable states
  const [editingBio, setEditingBio] = useState(false);
  const [customBioText, setCustomBioText] = useState('');
  const [localCoverUrl, setLocalCoverUrl] = useState<string | null>(null);
  const [localAvatarUrl, setLocalAvatarUrl] = useState<string | null>(null);
  const [localBio, setLocalBio] = useState<string | null>(null);

  const coverFileInputRef = useRef<HTMLInputElement | null>(null);
  const avatarFileInputRef = useRef<HTMLInputElement | null>(null);

  const hasContactHistory = useMemo(() => {
    if (isGeneral) return true;
    if (isGroup) return true;
    if (!isUser || !data) return false;
    if (data.id === currentUser.id) return true;
    return messagesList.some(
      (m) => m.chat_id === targetChatId || (m.sender_id === data.id && m.chat_id.includes(currentUser.id))
    );
  }, [isGeneral, isGroup, isUser, data, currentUser.id, targetChatId, messagesList]);

  const saveDetails = async (changes: Record<string, unknown>) => {
    if (!data || !isUser && !isGroup) throw new Error('This setting is device-only');
    const result = await oracleDB.from(isUser ? 'profiles' : 'groups').update(changes).eq('id', data.id);
    if (result.error || !result.data?.id) throw result.error || new Error('Update was not confirmed');
    Object.assign(data, result.data);
  };
  const handleSaveBio = async (newBio: string) => {
    try {
      if (isGeneral) { localStorage.setItem('vyper_general_bio', newBio); showLocalToast('Device-only room description saved'); }
      else {
        const parsed = parseProfileAbout(data?.about);
        await saveDetails(isUser ? { about: `[about]:${newBio}\n[thinking]:${parsed.thinking || ''}` } : { description: newBio });
        showLocalToast('Description saved');
      }
      setLocalBio(newBio); setEditingBio(false);
    } catch (error) { showLocalToast(error instanceof Error ? error.message : 'Update failed'); }
  };
  const readImage = (file: File) => new Promise<string>((resolve, reject) => {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 700000) { reject(new Error('Choose a PNG, JPEG or WebP image smaller than 700 KB')); return; }
    const reader = resources.reader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(new Error('Could not read image')); reader.readAsDataURL(file);
  });
  const handleUploadCover = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const image = await readImage(file);
      if (isGeneral) { localStorage.setItem('vyper_general_cover', image); showLocalToast('Device-only cover saved'); }
      else { await saveDetails({ cover_url: image }); showLocalToast('Cover saved'); }
      setLocalCoverUrl(image);
    } catch (error) { showLocalToast(error instanceof Error ? error.message : 'Cover upload failed'); }
  };
  const handleUploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const image = await readImage(file);
      if (isGeneral) { localStorage.setItem('vyper_general_avatar', image); showLocalToast('Device-only room photo saved'); }
      else { await saveDetails(isUser ? { avatar_url: image } : { icon: image }); showLocalToast('Photo saved'); }
      setLocalAvatarUrl(image);
    } catch (error) { showLocalToast(error instanceof Error ? error.message : 'Photo upload failed'); }
  };

  // Sub-modal states
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [activeMediaTab, setActiveMediaTab] = useState<'media' | 'links' | 'docs'>('media');
  const [showStarredModal, setShowStarredModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareSearchQuery, setShareSearchQuery] = useState('');
  const [showMediaVisibilityModal, setShowMediaVisibilityModal] = useState(false);

  // Media visibility state ('default' | 'always' | 'never')
  const [mediaVisibility, setMediaVisibility] = useState<'default' | 'always' | 'never'>(() => {
    if (!targetChatId) return 'default';
    try {
      return (localStorage.getItem(`vyper_media_visibility_${targetChatId}`) as any) || 'default';
    } catch {
      return 'default';
    }
  });

  const handleSaveMediaVisibility = (val: 'default' | 'always' | 'never') => {
    setMediaVisibility(val);
    if (targetChatId) {
      try {
        localStorage.setItem(`vyper_media_visibility_${targetChatId}`, val);
      } catch {}
    }
    setShowMediaVisibilityModal(false);
    showLocalToast('Media visibility preference saved');
  };

  // Chat lock state per chat room
  const [isChatLocked, setIsChatLocked] = useState<boolean>(() => {
    if (!targetChatId) return false;
    try {
      const saved = localStorage.getItem('vyper_locked_chats');
      if (saved) {
        const list: string[] = JSON.parse(saved);
        return list.includes(targetChatId);
      }
    } catch (e) {}
    return false;
  });

  const toggleChatLock = () => {
    if (!targetChatId) return;
    try {
      const saved = localStorage.getItem('vyper_locked_chats') || '[]';
      let list: string[] = JSON.parse(saved);
      const nextLocked = !isChatLocked;
      if (nextLocked) {
        if (!list.includes(targetChatId)) list.push(targetChatId);
        showLocalToast('Chat locked on this device');
      } else {
        list = list.filter((id) => id !== targetChatId);
        showLocalToast('Chat unlocked');
      }
      localStorage.setItem('vyper_locked_chats', JSON.stringify(list));
      setIsChatLocked(nextLocked);
      window.dispatchEvent(new Event('vyper_locked_chats_updated'));
    } catch (e) {
      console.error(e);
    }
  };

  const showLocalToast = (msg: string) => {
    setToastMessage(msg);
    resources.timeout(() => setToastMessage(null), 2500);
  };

  // Filter messages for this specific conversation
  const conversationMessages = useMemo(() => {
    if (!targetChatId) return [];
    return messagesList.filter((m) => m.chat_id === targetChatId).sort(compareMessagesChronologically);
  }, [messagesList, targetChatId]);

  // Extract media items, links, and documents
  const mediaItems = useMemo(() => {
    return conversationMessages.filter(
      (m) => m.file_name && (m.file_type?.startsWith('image/') || m.file_type?.startsWith('video/') || m.is_voice)
    );
  }, [conversationMessages]);

  const linkRegex = /https?:\/\/[^\s]+|www\.[^\s]+/gi;
  const linkItems = useMemo(() => {
    return conversationMessages.filter((m) => m.text && linkRegex.test(m.text));
  }, [conversationMessages]);

  const docItems = useMemo(() => {
    return conversationMessages.filter(
      (m) => m.file_name && !m.file_type?.startsWith('image/') && !m.file_type?.startsWith('video/') && !m.is_voice
    );
  }, [conversationMessages]);

  // Starred messages for this user/chat
  const starredMessages = useMemo(() => {
    try {
      const saved = localStorage.getItem(`vyper_starred_msg_ids_${currentUser?.id || 'default'}`);
      const starredIds: string[] = saved ? JSON.parse(saved) : [];
      return conversationMessages.filter((m) => starredIds.includes(m.id));
    } catch (e) {
      return [];
    }
  }, [conversationMessages, currentUser?.id]);

  const [isEditingDisplayName, setIsEditingDisplayName] = useState(false);
  const [customDisplayName, setCustomDisplayName] = useState(() => {
    if (isUser && data) {
      const saved = localStorage.getItem('vyper_custom_display_names');
      if (saved) {
        try {
          const map = JSON.parse(saved);
          return map[data.id] || '';
        } catch (e) {
          console.error(e);
        }
      }
    }
    return '';
  });

  const handleSaveCustomDisplayName = () => {
    if (!data) return;
    const saved = localStorage.getItem('vyper_custom_display_names') || '{}';
    try {
      const map = JSON.parse(saved);
      if (customDisplayName.trim()) {
        map[data.id] = customDisplayName.trim();
      } else {
        delete map[data.id];
      }
      localStorage.setItem('vyper_custom_display_names', JSON.stringify(map));
      setIsEditingDisplayName(false);
      window.dispatchEvent(new Event('vyper_custom_names_updated'));
      showLocalToast('Display name updated');
    } catch (e) {
      console.error(e);
    }
  };

  // Helpers
  const getAvatarStyle = (seed: number) => {
    const gradients = [
      'linear-gradient(135deg, #20e3a2 0%, #007adf 100%)',
      'linear-gradient(135deg, #7c5cff 0%, #ff4b91 100%)',
      'linear-gradient(135deg, #ff9233 0%, #ea00d9 100%)',
      'linear-gradient(135deg, #20e3a2 0%, #7c5cff 100%)',
      'linear-gradient(135deg, #007adf 0%, #7c5cff 100%)',
    ];
    return gradients[seed % gradients.length];
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  const [isMembersExpanded, setIsMembersExpanded] = useState(false);

  // Extract profiles of community members with strict hierarchical sorting (Admin -> Moderator -> Active -> Idle)
  let communityMembers: Profile[] = [];
  let title = '';
  let subTitle = '';
  let bioText = '';
  let badgeText = '';
  let badgeStyle = '';
  let iconContent: React.ReactNode = null;
  let bgStyle: React.CSSProperties = {};
  let parsedAbout: { thinking: string | null; coverUrl: string | null; about: string } | null = null;

  const handleMemberClick = (member: Profile) => {
    if (member.id === currentUser.id) return;
    if (onStartDM) {
      onStartDM(member);
    }
  };

  // Helper to compute member activity score and role category
  const getMemberTier = (member: Profile, group?: Group | null) => {
    const isCreator = group && group.creator_id === member.id;
    const isAdmin = (group && (group.admins || []).includes(member.id)) || (!group && ((member as any).role === 'admin' || member.username === 'vyper_admin'));
    const isMod = (group && ((group as any).moderators || []).includes(member.id)) || (member as any).role === 'moderator';
    const isOnline = isUserOnline(member);

    // Count messages sent by member in this chat or all chats
    const userMsgCount = messagesList.filter(m => m.sender_id === member.id && (!targetChatId || m.chat_id === targetChatId)).length;

    if (isCreator) return { tier: 1, role: 'CREATOR', score: 1000000 + userMsgCount, isOnline };
    if (isAdmin) return { tier: 2, role: 'ADMIN', score: 500000 + userMsgCount, isOnline };
    if (isMod) return { tier: 3, role: 'MODERATOR', score: 250000 + userMsgCount, isOnline };
    if (isOnline || userMsgCount > 3) return { tier: 4, role: 'ACTIVE', score: 10000 + (isOnline ? 500 : 0) + userMsgCount * 10, isOnline };
    return { tier: 5, role: 'IDLE', score: userMsgCount, isOnline };
  };

  if (isGeneral) {
    title = 'VyperVic General Chat';
    subTitle = '#general';
    bioText = 'The primary communications channel for all VyperVic operators worldwide. Access is guaranteed for all registered and verified profiles.';
    badgeText = 'Public Chat Room';
    badgeStyle = 'bg-emerald-500/10 text-[#20e3a2] border-emerald-500/20';

    // Sort all profiles by Admin -> Moderator -> Active -> Idle
    const sorted = [...allProfiles].sort((a, b) => {
      const tierA = getMemberTier(a, null);
      const tierB = getMemberTier(b, null);
      if (tierA.tier !== tierB.tier) return tierA.tier - tierB.tier;
      return tierB.score - tierA.score;
    });
    communityMembers = sorted;

    iconContent = (
      <svg width="60" height="60" viewBox="0 0 150 150" fill="none">
        <defs>
          <linearGradient id="profileLogoGrad" x1="0" y1="0" x2="150" y2="150" gradientUnits="userSpaceOnUse">
            <stop stopColor="#20e3a2" />
            <stop offset="1" stopColor="#7c5cff" />
          </linearGradient>
        </defs>
        <path
          d="M30 40 C30 20, 60 15, 75 35 C95 60, 60 65, 55 80 C50 95, 85 100, 90 75 C93 60, 75 55, 70 65 C65 75, 80 85, 100 78 C118 71, 118 45, 100 35 C85 27, 75 45, 85 55"
          stroke="url(#profileLogoGrad)"
          strokeWidth="11"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  } else if (isGroup && data) {
    const group = data as Group;
    title = group.name;
    subTitle = `Group ID: ${group.id.replace('group:', '')}`;
    bioText = group.description || 'Custom operator group channel created to synchronize tasks.';
    badgeText = 'Group Chat';
    badgeStyle = 'bg-[#7c5cff]/10 text-[#7c5cff] border-[#7c5cff]/20';

    // Resolve members and sort by ADMIN -> MODERATOR -> Most active -> Idle
    const memberIds = group.members || [];
    const resolvedMembers = allProfiles.filter((p) => memberIds.includes(p.id));
    resolvedMembers.sort((a, b) => {
      const tierA = getMemberTier(a, group);
      const tierB = getMemberTier(b, group);
      if (tierA.tier !== tierB.tier) return tierA.tier - tierB.tier;
      return tierB.score - tierA.score;
    });
    communityMembers = resolvedMembers;

    if (group.icon && (group.icon.startsWith('data:image/') || (group.icon.startsWith('http') || group.icon.startsWith('/api/media/')))) {
      iconContent = (
        <img loading="lazy" decoding="async"
          src={group.icon}
          alt=""
          className="w-full h-full object-cover rounded-full"
        />
      );
    } else {
      iconContent = <span className="text-3xl font-black">{group.icon || '👥'}</span>;
    }
  } else if (isUser && data) {
    const profile = data as Profile;
    title = profile.display_name || profile.username || 'Operator';
    subTitle = `@${profile.username || 'unknown'}`;
    parsedAbout = parseProfileAbout(profile.about);
    bioText = parsedAbout.about || 'Hey there! I am using VyperVic.';
    badgeText = formatLastSeen(profile);
    badgeStyle = isUserOnline(profile)
      ? 'bg-emerald-500/10 text-[#20e3a2] border-emerald-500/20'
      : 'bg-white/5 text-[#8d97ab] border-white/5';

    const seed = profile.username?.charCodeAt(0) || 0;
    bgStyle = {
      background: profile.avatar_url ? 'none' : getAvatarStyle(seed),
    };

    if (profile.avatar_url) {
      iconContent = (
        <img loading="lazy" decoding="async"
          src={profile.avatar_url}
          alt=""
          className="w-full h-full object-cover rounded-full"
          referrerPolicy="no-referrer"
        />
      );
    } else {
      iconContent = getInitials(title);
    }
  }

  // Filter members list based on search query
  const filteredMembers = communityMembers.filter((member) => {
    const nameMatch = (member.display_name || '').toLowerCase().includes(searchQuery.toLowerCase());
    const userMatch = (member.username || '').toLowerCase().includes(searchQuery.toLowerCase());
    return nameMatch || userMatch;
  });

  const rawCoverUrl = data?.cover_url || parsedAbout?.coverUrl;
  const rawAvatarUrl = isGroup
    ? (data?.icon?.startsWith('data:image/') || (data?.icon?.startsWith('http') || data?.icon?.startsWith('/api/media/')) ? data.icon : null)
    : (data as Profile)?.avatar_url;

  const coverUrl = localCoverUrl || rawCoverUrl;
  const avatarUrl = localAvatarUrl || rawAvatarUrl;

  // Share profile action
  const handleShareProfile = () => {
    setShowShareModal(true);
  };

  const handleCopyProfileCard = () => {
    if (!data) return;
    const name = data.display_name || data.username || 'User';
    const username = data.username ? `@${data.username}` : '';
    const email = data.email || '';
    const phone = data.phone_number || '';
    const shareText = `📇 VyperVic Profile:\nName: ${name} (${username})\nEmail: ${email}\nPhone: ${phone || 'Not provided'}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareText);
      showLocalToast('Profile info copied to clipboard');
    }
  };

  const handleNativeShare = async () => {
    if (!data) return;
    const name = data.display_name || data.username || 'User';
    const shareText = `VyperVic Contact: ${name} (@${data.username || ''}) - Email: ${data.email}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${name} on VyperVic`,
          text: shareText,
        });
      } catch (e) {}
    } else {
      handleCopyProfileCard();
    }
  };

  const handleSendProfileToChat = (chatTargetId: string, peerObj?: Profile | null) => {
    if (!data) return;
    const name = data.display_name || data.username || 'User';
    const username = data.username ? `@${data.username}` : '';
    const email = data.email || '';
    const phone = data.phone_number || 'Not provided';
    const avatar = data.avatar_url || '';

    const textPayload = `[Contact Card]: ${name} (${username})\nEmail: ${email}\nPhone: ${phone}`;

    const newMsg: Message = {
      id: `share_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      chat_id: chatTargetId,
      sender_id: currentUser.id,
      text: textPayload,
      file_name: avatar ? `${name}_Avatar.jpg` : null,
      file_type: avatar ? 'image/jpeg' : null,
      file_data: avatar || null,
      is_voice: false,
      created_at: new Date().toISOString(),
    };

    if (onSendMessage) {
      onSendMessage(newMsg);
    }

    showLocalToast(`Shared profile to conversation`);
    setShowShareModal(false);

    if (onSelectChat) {
      onSelectChat(chatTargetId, peerObj);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 w-screen max-w-full min-w-0 bg-[#080b10] z-50 flex flex-col md:flex-row animate-fade-in text-left overflow-hidden screen-gpu" style={{ willChange: 'transform', transform: 'translateZ(0)' }}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[600] bg-[#161d28]/95 border border-[#20e3a2]/40 text-[#20e3a2] px-4 py-2 rounded-full text-xs font-bold shadow-2xl backdrop-blur-md animate-fade-in flex items-center gap-2">
          <Check className="w-3.5 h-3.5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* LEFT COLUMN: Main profile details card */}
      <div
        onScroll={handleProfileScroll}
        className={`w-full min-w-0 max-w-full ${isMembersExpanded ? 'hidden' : ''} ${isUser ? 'md:max-w-xl mx-auto border-x border-[#212a38]' : 'md:w-[360px] md:max-w-[42vw] shrink-0 border-b md:border-b-0 md:border-r border-[#212a38]'} flex flex-col relative overflow-y-auto`}
      >
        {/* Sticky Collapsible Navigation Bar */}
        <motion.div
          initial={false}
          animate={{
            backgroundColor: isScrolled ? 'rgba(8, 11, 16, 0.95)' : 'rgba(0, 0, 0, 0)',
            borderBottomColor: isScrolled ? 'rgba(33, 42, 56, 1)' : 'rgba(33, 42, 56, 0)',
            backdropFilter: isScrolled ? 'blur(16px)' : 'blur(0px)',
          }}
          className="sticky top-0 z-40 w-full px-3.5 py-2.5 flex items-center justify-between transition-colors duration-200 border-b pointer-events-auto"
        >
          {/* Top Left: Back button & Retracted Avatar when scrolled down */}
          <div className="flex items-center gap-2 min-w-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className={`px-3 py-1.5 rounded-full border flex items-center gap-1.5 text-white hover:text-[#20e3a2] cursor-pointer transition-all shadow-xl backdrop-blur-md shrink-0 ${
                isScrolled ? 'bg-[#161d28] border-[#212a38] hover:bg-[#1d2531]' : 'bg-black/75 border-white/20 hover:bg-black/90'
              }`}
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-xs font-bold font-sans">Back</span>
            </button>

            {/* Retracted Avatar & Header title at the top left side when scrolled */}
            <AnimatePresence>
              {isScrolled && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, x: -8 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.8, x: -8 }}
                  transition={{ duration: 0.18 }}
                  className="flex items-center gap-2 min-w-0"
                >
                  {avatarUrl ? (
                    <img loading="lazy" decoding="async"
                      src={avatarUrl}
                      alt=""
                      className="w-8 h-8 rounded-full object-cover border border-[#20e3a2]/40 shadow-sm shrink-0"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-black text-white border border-[#20e3a2]/40 shrink-0"
                      style={bgStyle}
                    >
                      {isGeneral ? <Sparkles className="w-4 h-4 text-[#20e3a2]" /> : getInitials(title)}
                    </div>
                  )}
                  <div className="min-w-0 text-left">
                    <h2 className="text-xs font-bold text-white truncate max-w-[120px] sm:max-w-[180px] leading-tight flex items-center gap-1">
                      <span>{customDisplayName || title}</span>
                      {isUser && isUserOnline(data) && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#20e3a2] shrink-0" />
                      )}
                    </h2>
                    <p className="text-[9px] text-[#8d97ab] font-mono truncate">
                      {badgeText}
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Top Right Action: Share Profile or Badge */}
          {isUser && data ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleShareProfile();
              }}
              className={`p-2 rounded-full border text-white hover:text-[#20e3a2] transition-all shadow-xl backdrop-blur-md cursor-pointer ${
                isScrolled ? 'bg-[#161d28] border-[#212a38] hover:bg-[#1d2531]' : 'bg-black/75 border-white/20 hover:bg-black/90'
              }`}
              title="Share profile to chat"
            >
              <Share2 className="w-4 h-4" />
            </button>
          ) : (
            <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider border ${badgeStyle} backdrop-blur-sm shadow-md whitespace-nowrap overflow-hidden text-ellipsis truncate max-w-[140px]`}>
              {badgeText}
            </span>
          )}
        </motion.div>

        {/* Profile Hero Cover Image / Gradient Background */}
        <div
          onClick={() => {
            if (coverUrl) setShowZoomedCover(true);
          }}
          className={`${isGroup ? 'h-40 sm:h-48' : 'h-48 sm:h-56'} relative flex items-end justify-center overflow-hidden bg-gradient-to-r from-[#7c5cff]/20 to-[#20e3a2]/20 -mt-[48px] ${coverUrl ? 'cursor-pointer group' : ''}`}
        >
          {coverUrl ? (
            <img loading="lazy" decoding="async"
              src={coverUrl}
              alt="Cover"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
          ) : null}
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/30 pointer-events-none z-10" />

          {/* Admin / Self Edit Cover Photo Button */}
          {canEdit && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                coverFileInputRef.current?.click();
              }}
              className="absolute top-14 right-3 z-30 px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black/90 text-white text-[10px] font-bold border border-white/20 flex items-center gap-1.5 backdrop-blur-md cursor-pointer transition-all shadow-lg hover:text-[#20e3a2]"
              title="Update Cover Photo (Admin)"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{isAdmin && (!isUser || data?.id !== currentUser.id) ? 'Admin: Edit Cover' : 'Edit Cover'}</span>
            </button>
          )}
          <input
            type="file"
            ref={coverFileInputRef}
            accept="image/*"
            className="hidden"
            onChange={handleUploadCover}
          />
        </div>

        {/* Profile Content Container */}
        <div className="px-5 relative -mt-12 sm:-mt-14 pb-8 z-20">
          {/* Profile Big Avatar (Normal large size, retracts smoothly on scroll) */}
          <div className="flex justify-between items-end mb-3">
            <div className="relative">
              <motion.div
                onClick={() => {
                  if (avatarUrl) setShowZoomedAvatar(true);
                }}
                animate={{
                  scale: isScrolled ? 0.65 : 1,
                  opacity: isScrolled ? 0.4 : 1,
                  y: isScrolled ? 10 : 0,
                }}
                transition={{ type: 'spring', damping: 22, stiffness: 240 }}
                className={`${isGroup ? 'w-28 h-28 sm:w-32 sm:h-32 text-3xl' : 'w-32 h-32 sm:w-36 sm:h-36 text-4xl'} rounded-full border-4 border-[#080b10] flex items-center justify-center text-white font-black shadow-2xl relative overflow-hidden bg-[#161d28] ${avatarUrl ? 'cursor-pointer hover:scale-105 active:scale-95' : ''} z-20 shrink-0 ring-2 ring-white/10`}
                style={bgStyle}
                title={avatarUrl ? "Tap to zoom and expand" : undefined}
              >
                {iconContent}
              </motion.div>

              {/* Admin / Self Edit Avatar Button */}
              {canEdit && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    avatarFileInputRef.current?.click();
                  }}
                  className="absolute bottom-1 right-1 p-2 rounded-full bg-[#20e3a2] text-black hover:scale-110 active:scale-95 transition-transform shadow-xl cursor-pointer z-30 border-2 border-[#080b10]"
                  title="Update Profile Photo (Admin)"
                >
                  <Camera className="w-4 h-4 stroke-[2.5]" />
                </button>
              )}
              <input
                type="file"
                ref={avatarFileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleUploadAvatar}
              />
            </div>

            {/* Online Status Badge for User */}
            {isUser && (
              <span className={`px-2.5 py-1 rounded-full text-[9.5px] font-bold uppercase tracking-wider border ${badgeStyle} backdrop-blur-sm shadow-md inline-block max-w-[160px] truncate`}>
                {badgeText}
              </span>
            )}
          </div>

          {/* Texts */}
          <div className="text-center md:text-left">
            {isUser && data && data.id !== currentUser.id ? (
              <div className="flex flex-col gap-1">
                {isEditingDisplayName ? (
                  <div className="flex items-center gap-2 mt-1 justify-center md:justify-start">
                    <input
                      type="text"
                      className="bg-[#161d28] border border-[#212a38] text-white text-sm font-semibold rounded-lg px-2.5 py-1.5 outline-none focus:border-[#7c5cff] max-w-[180px]"
                      placeholder="Edit display name..."
                      value={customDisplayName}
                      onChange={(e) => setCustomDisplayName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveCustomDisplayName();
                        else if (e.key === 'Escape') setIsEditingDisplayName(false);
                      }}
                      autoFocus
                    />
                    <button
                      onClick={handleSaveCustomDisplayName}
                      className="px-2 py-1.5 bg-[#20e3a2] text-black text-xs font-bold rounded-lg hover:opacity-90 cursor-pointer"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setIsEditingDisplayName(false)}
                      className="px-2 py-1.5 bg-white/10 text-white text-xs font-bold rounded-lg hover:bg-white/15 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-center md:justify-start gap-2 flex-wrap">
                    <h1 className="text-lg font-display font-black text-white tracking-wide flex items-center gap-2">
                      <span>{customDisplayName ? `${customDisplayName} (${data.display_name || data.username})` : title}</span>
                      {isUserOnline(data) && (
                        <span className="w-2 h-2 rounded-full bg-[#20e3a2] animate-pulse shrink-0" />
                      )}
                    </h1>
                    <button
                      onClick={() => setIsEditingDisplayName(true)}
                      className="text-[9px] bg-[#161d28] hover:bg-[#1d2531] border border-[#212a38] text-[#20e3a2] font-semibold px-2 py-0.5 rounded-md cursor-pointer transition-colors"
                    >
                      Edit Name
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <h1 className="text-lg font-display font-black text-white tracking-wide flex items-center justify-center md:justify-start gap-2">
                <span>{title}</span>
                {isUser && isUserOnline(data) && (
                  <span className="w-2 h-2 rounded-full bg-[#20e3a2] animate-pulse shrink-0" />
                )}
              </h1>
            )}
            <p className="text-[11px] text-[#8d97ab] font-mono mt-0.5">
              {subTitle}
            </p>
          </div>

          {/* Action buttons for platform users */}
          {isUser && data && data.id !== currentUser.id && (
            <div className="flex items-center gap-2 mt-4">
              {onStartDM && (
                <button
                  onClick={() => {
                    onStartDM(data as Profile);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7c5cff] to-[#6849eb] hover:shadow-lg hover:shadow-[#7c5cff]/10 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Start Chat</span>
                </button>
              )}

              {onCall && (
                <>
                  <button
                    onClick={() => onCall('voice', (data as Profile).id)}
                    className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:border-[#20e3a2]/30 hover:bg-[#20e3a2]/5 flex items-center justify-center text-[#20e3a2] transition-colors cursor-pointer"
                    title="Start Voice Call"
                  >
                    <Phone className="w-4 h-4 fill-current" />
                  </button>
                  <button
                    onClick={() => onCall('video', (data as Profile).id)}
                    className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:border-[#7c5cff]/30 hover:bg-[#7c5cff]/5 flex items-center justify-center text-[#7c5cff] transition-colors cursor-pointer"
                    title="Start Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </>
              )}

              {/* Share Profile Button */}
              <button
                onClick={handleShareProfile}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:border-amber-400/30 hover:bg-amber-400/5 flex items-center justify-center text-amber-400 transition-colors cursor-pointer"
                title="Share Profile"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Biography Detail with Admin/Self editing */}
          <div className="mt-4 pt-3 border-t border-[#212a38]">
            <div className="flex items-center justify-between mb-1.5">
              <h3 className="text-[9.5px] text-[#5a6478] uppercase font-mono font-black tracking-widest flex items-center gap-1.5">
                <Info className="w-3 h-3 text-[#7c5cff]" />
                <span>{isUser ? 'Bio' : 'Biography & Description'}</span>
              </h3>
              {canEdit && !editingBio && (
                <button
                  onClick={() => {
                    setCustomBioText(localBio || bioText);
                    setEditingBio(true);
                  }}
                  className="text-[9.5px] text-[#20e3a2] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>{isAdmin && (!isUser || data?.id !== currentUser.id) ? 'Admin: Edit' : 'Edit'}</span>
                </button>
              )}
            </div>

            {editingBio ? (
              <div className="flex flex-col gap-2">
                <textarea
                  value={customBioText}
                  onChange={(e) => setCustomBioText(e.target.value)}
                  className="w-full bg-[#111622] border border-[#20e3a2]/40 rounded-xl p-2.5 text-xs text-white placeholder-gray-500 focus:outline-none font-medium"
                  rows={3}
                  placeholder="Enter biography or description..."
                />
                <div className="flex items-center gap-2 justify-end">
                  <button
                    onClick={() => handleSaveBio(customBioText)}
                    className="px-3 py-1.5 bg-[#20e3a2] text-black text-xs font-bold rounded-lg hover:opacity-90 cursor-pointer"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setEditingBio(false)}
                    className="px-3 py-1.5 bg-white/10 text-white text-xs font-bold rounded-lg hover:bg-white/20 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-[11.5px] text-[#eef1f6] leading-snug italic bg-black/30 p-2.5 rounded-xl border border-[#212a38]/30">
                "{localBio || bioText}"
              </p>
            )}
          </div>

          {/* Details Fields: Email, Phone Number, Joined Date */}
          <div className="mt-3 space-y-1.5">
            {isUser && data && (
              <>
                {/* Email Address */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/3 border border-[#212a38]/20 text-[10.5px]">
                  <span className="text-[#8d97ab] font-mono font-medium flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#8d97ab]" /> Email Address
                  </span>
                  <span className="text-white font-mono font-semibold truncate max-w-[180px]" title={(data as Profile).email}>
                    {(data as Profile).email}
                  </span>
                </div>

                {/* Phone Number (Requirement 8) */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/3 border border-[#212a38]/20 text-[10.5px]">
                  <span className="text-[#8d97ab] font-mono font-medium flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-[#8d97ab]" /> Phone Number
                  </span>
                  <span className="text-white font-mono font-semibold truncate max-w-[180px]" title={(data as Profile).phone_number || 'Not provided'}>
                    {(data as Profile).phone_number || 'Not provided'}
                  </span>
                </div>

                {/* Joined On */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/3 border border-[#212a38]/20 text-[10.5px]">
                  <span className="text-[#8d97ab] font-mono font-medium flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#8d97ab]" /> Joined On
                  </span>
                  <span className="text-white font-mono">
                    {formatDateSafe((data as Profile).created_at)}
                  </span>
                </div>
              </>
            )}

            {isGroup && data && (
              <>
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/3 border border-[#212a38]/20 text-[10.5px]">
                  <span className="text-[#8d97ab] font-mono font-medium flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#8d97ab]" /> Created On
                  </span>
                  <span className="text-white font-mono">
                    {formatDateSafe((data as Group).created_at)}
                  </span>
                </div>
              </>
            )}
          </div>

          {/* SECTION: Reference Media, Links & Docs / Starred Messages / Media Visibility / Chat Lock (Hidden for non-contacts) */}
          {((isUser && hasContactHistory) || isGroup) && (
            <div className="mt-5 pt-4 border-t border-[#212a38] space-y-2.5">
              <h3 className="text-[10px] text-[#5a6478] uppercase font-mono font-black tracking-widest mb-2 flex items-center justify-between">
                <span>Chat Content & Privacy</span>
              </h3>

              {/* 1. Media, links and docs Card (Top Preview Gallery) */}
              <div
                onClick={() => setShowMediaModal(true)}
                className="w-full p-3.5 rounded-2xl bg-[#121824] border border-[#212a38]/80 hover:border-[#20e3a2]/40 hover:bg-[#161f2e] transition-all cursor-pointer flex flex-col gap-3 group shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-[#20e3a2]/10 border border-[#20e3a2]/20 flex items-center justify-center text-[#20e3a2] shrink-0">
                      <ImageIcon className="w-4.5 h-4.5" />
                    </div>
                    <div className="min-w-0 text-left">
                      <h4 className="text-xs font-bold text-white group-hover:text-[#20e3a2] transition-colors truncate">
                        Media, links, and docs
                      </h4>
                      <p className="text-[10px] text-[#8d97ab] font-mono mt-0.5">
                        {mediaItems.length + linkItems.length + docItems.length} items shared in this session
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#8d97ab] group-hover:text-white transition-colors shrink-0">
                    <span className="text-xs font-mono font-bold text-white/60">{mediaItems.length + linkItems.length + docItems.length}</span>
                    <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-white" />
                  </div>
                </div>

                {/* Media preview thumbnails row if media exists */}
                {mediaItems.length > 0 ? (
                  <div className="flex items-center gap-2 overflow-x-auto pt-0.5 pb-1 scrollbar-none">
                    {mediaItems.slice(0, 6).map((m) => (
                      <div key={m.id} className="w-14 h-14 rounded-xl overflow-hidden border border-white/10 shrink-0 bg-black/40 flex items-center justify-center relative shadow-inner">
                        {m.is_voice ? (
                          <div className="w-full h-full flex flex-col items-center justify-center bg-[#20e3a2]/10 text-[#20e3a2]">
                            <Mic className="w-5 h-5" />
                            <span className="text-[7.5px] font-mono mt-0.5 font-bold">VOICE</span>
                          </div>
                        ) : m.file_type?.startsWith('video/') && m.file_data ? (
                          <video src={m.file_data} className="w-full h-full object-cover" muted />
                        ) : m.file_data ? (
                          <img loading="lazy" decoding="async" src={m.file_data} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <span className="text-[8.5px] text-[#8d97ab] font-mono font-bold">{m.file_name?.slice(0, 4)}</span>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-1 px-2.5 rounded-xl bg-white/2 border border-dashed border-white/10 flex items-center justify-between text-[10px] text-[#8d97ab]">
                    <span>No media shared yet</span>
                    <span className="text-[9px] font-mono text-[#5a6478]">Photos, videos & docs appear here</span>
                  </div>
                )}
              </div>

              {/* 2. Media Visibility Row (WhatsApp Business Spec) */}
              <div
                onClick={() => setShowMediaVisibilityModal(true)}
                className="w-full p-3 rounded-2xl bg-[#121824] border border-[#212a38]/80 hover:border-[#20e3a2]/40 hover:bg-[#161f2e] transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-[#7c5cff]/10 border border-[#7c5cff]/20 flex items-center justify-center text-[#7c5cff] shrink-0">
                    <ImageIcon className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0 text-left">
                    <h4 className="text-xs font-bold text-white group-hover:text-[#7c5cff] transition-colors truncate">
                      Media visibility
                    </h4>
                    <p className="text-[10px] text-[#8d97ab] mt-0.5 line-clamp-1">
                      Show newly downloaded media in your device's gallery
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-[#8d97ab] group-hover:text-white transition-colors shrink-0">
                  <span className="text-[10px] font-semibold text-white/50 capitalize">
                    {mediaVisibility === 'default' ? 'Default (Yes)' : mediaVisibility === 'always' ? 'Always' : 'No'}
                  </span>
                  <ChevronRight className="w-4 h-4 text-white/40" />
                </div>
              </div>

              {/* 3. Starred Messages Row */}
              <div
                onClick={() => setShowStarredModal(true)}
                className="w-full p-3 rounded-2xl bg-[#121824] border border-[#212a38]/80 hover:border-amber-400/40 hover:bg-[#161f2e] transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400 shrink-0">
                    <Star className="w-4.5 h-4.5 fill-current" />
                  </div>
                  <div className="min-w-0 text-left">
                    <h4 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors truncate">
                      Starred messages
                    </h4>
                    <p className="text-[10px] text-[#8d97ab] font-mono mt-0.5">
                      {starredMessages.length} bookmarked {starredMessages.length === 1 ? 'message' : 'messages'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-[#8d97ab] group-hover:text-white transition-colors shrink-0">
                  <span className="text-[11px] font-mono font-bold text-white/50">{starredMessages.length}</span>
                  <ChevronRight className="w-4 h-4 text-white/40" />
                </div>
              </div>

              {/* 4. Chat Lock Row */}
              <div className="w-full p-3 rounded-2xl bg-[#121824] border border-[#212a38]/80 flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl ${isChatLocked ? 'bg-[#20e3a2]/15 border-[#20e3a2]/30 text-[#20e3a2]' : 'bg-white/5 border-white/10 text-[#8d97ab]'} border flex items-center justify-center shrink-0 transition-colors`}>
                    <Lock className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0 text-left">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Chat lock</span>
                      {isChatLocked && (
                        <span className="text-[9px] font-mono font-bold text-[#20e3a2] bg-[#20e3a2]/10 px-1.5 py-0.2 rounded border border-[#20e3a2]/20">
                          ACTIVE
                        </span>
                      )}
                    </h4>
                    <p className="text-[10px] text-[#8d97ab] mt-0.5">
                      Lock and hide this chat on this device.
                    </p>
                  </div>
                </div>

                {/* Switch Toggle */}
                <button
                  type="button"
                  onClick={toggleChatLock}
                  className={`w-11 h-6 rounded-full transition-colors relative flex items-center p-0.5 cursor-pointer shrink-0 ${
                    isChatLocked ? 'bg-[#20e3a2]' : 'bg-[#212a38]'
                  }`}
                  title={isChatLocked ? "Unlock chat" : "Lock chat"}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      isChatLocked ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: Community members area (For general chat and groups only) */}
      {!isUser && (
        <div className="flex-1 flex flex-col overflow-hidden bg-[#0a0d14]/90 p-5 md:p-6">
          {/* Header / Members Count Area with Expand to Fullscreen button */}
          <div className="flex items-center justify-between border-b border-[#212a38] pb-4 mb-4">
            <div>
              <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-[#20e3a2]" />
                <span>Channel Members</span>
                <span className="text-[10px] font-mono font-bold bg-white/5 border border-white/10 text-white/70 px-2 py-0.5 rounded-full">
                  {communityMembers.length}
                </span>
              </h3>
              <p className="text-[10px] text-[#8d97ab] mt-0.5 font-mono">
                Hierarchically ranked: Admins • Moderators • Active • Idle
              </p>
            </div>

            {/* Expand / Collapse Fullscreen View button */}
            <button
              type="button"
              onClick={() => setIsMembersExpanded(!isMembersExpanded)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#161d28] hover:bg-[#212a38] border border-[#212a38] hover:border-[#20e3a2]/40 text-[#8d97ab] hover:text-white text-xs font-mono transition-all cursor-pointer shadow-sm"
              title={isMembersExpanded ? "Restore split view" : "Expand members full screen"}
            >
              {isMembersExpanded ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5 text-[#20e3a2]" />
                  <span className="text-[11px] font-bold text-[#20e3a2]">Collapse View</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="text-[11px] font-bold">Full Screen</span>
                </>
              )}
            </button>
          </div>

          {/* Search Input Area with Search Icon */}
          <div className="relative mb-4">
            <span className="absolute inset-y-0 left-3.5 flex items-center pointer-events-none text-[#5a6478]">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder="Search community operators by name or @username..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111622]/90 border border-[#212a38] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#5a6478] focus:border-[#7c5cff] focus:outline-none focus:ring-1 focus:ring-[#7c5cff]/30 transition-all font-medium font-mono shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-3 flex items-center text-[#5a6478] hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Scrollable Members List */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-1.5">
            {filteredMembers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center animate-fade-in">
                <span className="text-xs text-gray-400 font-bold uppercase tracking-wider font-mono">No matching operators found</span>
                <p className="text-[10.5px] text-gray-500 mt-1 max-w-[200px]">Ensure spelling matches the user's username or ID</p>
              </div>
            ) : (
              filteredMembers.map((member) => {
                const seed = member.username?.charCodeAt(0) || 0;
                const isSelf = member.id === currentUser.id;
                const tierInfo = getMemberTier(member, isGroup ? (data as Group) : null);

                return (
                  <div
                    key={member.id}
                    onClick={() => handleMemberClick(member)}
                    className={`w-full flex items-center justify-between py-2 px-3 rounded-xl border transition-all text-left group/row ${
                      isSelf
                        ? 'bg-[#161d28]/10 border-[#212a38]/10 cursor-default'
                        : 'bg-[#161d28]/30 hover:bg-[#161d28]/80 border-[#212a38]/20 hover:border-[#212a38]/60 cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {/* Member Avatar */}
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] font-black shadow-md shrink-0 relative overflow-hidden"
                        style={{
                          background: member.avatar_url ? 'none' : getAvatarStyle(seed),
                        }}
                      >
                        {member.avatar_url ? (
                          <img loading="lazy" decoding="async"
                            src={member.avatar_url}
                            alt=""
                            className="w-full h-full object-cover rounded-full"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          getInitials(member.display_name || member.username || 'U')
                        )}
                      </div>

                      {/* Member details & Role Badges */}
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white flex items-center gap-1.5 flex-wrap">
                          <span className="group-hover/row:text-[#20e3a2] transition-colors truncate">
                            {member.display_name || member.username}
                          </span>

                          {/* Role Tag */}
                          {tierInfo.role === 'CREATOR' && (
                            <span className="text-[7.5px] font-mono font-bold bg-[#20e3a2]/15 text-[#20e3a2] border border-[#20e3a2]/30 px-1.5 py-0.2 rounded shadow-sm">
                              CREATOR
                            </span>
                          )}
                          {tierInfo.role === 'ADMIN' && (
                            <span className="text-[7.5px] font-mono font-bold bg-[#20e3a2]/10 text-[#20e3a2] border border-[#20e3a2]/20 px-1.5 py-0.2 rounded">
                              ADMIN
                            </span>
                          )}
                          {tierInfo.role === 'MODERATOR' && (
                            <span className="text-[7.5px] font-mono font-bold bg-[#7c5cff]/10 text-[#7c5cff] border border-[#7c5cff]/20 px-1.5 py-0.2 rounded">
                              MODERATOR
                            </span>
                          )}
                          {tierInfo.role === 'ACTIVE' && !isSelf && (
                            <span className="text-[7.5px] font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.2 rounded">
                              ACTIVE
                            </span>
                          )}
                          {tierInfo.role === 'IDLE' && !isSelf && (
                            <span className="text-[7.5px] font-mono text-gray-500 bg-white/5 border border-white/5 px-1.5 py-0.2 rounded">
                              IDLE
                            </span>
                          )}
                          {isSelf && (
                            <span className="text-[7.5px] font-bold text-[#7c5cff] bg-[#7c5cff]/10 border border-[#7c5cff]/15 px-1 py-0.5 rounded font-mono">
                              YOU
                            </span>
                          )}
                        </div>
                        <p className="text-[9px] text-[#8d97ab] font-mono leading-none mt-0.5 truncate">
                          @{member.username}
                        </p>
                      </div>
                    </div>

                    {/* Right online status marker */}
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-wider border whitespace-nowrap overflow-hidden text-ellipsis truncate max-w-[120px] sm:max-w-[160px] inline-block ${
                        isUserOnline(member)
                          ? 'bg-emerald-500/10 text-[#20e3a2] border-emerald-500/20'
                          : 'bg-white/5 text-[#8d97ab] border-white/5'
                      }`}>
                        {formatLastSeen(member)}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* PINCH-TO-ZOOM / MULTI-TOUCH INTERACTIVE VIEWER FOR COVER PHOTO (Requirement 1) */}
      {showZoomedCover && coverUrl && (
        <InteractiveImageViewer
          src={coverUrl}
          alt="Cover Photo"
          title={title}
          subtitle="Cover Photo • Pinch to expand or drag"
          isAvatar={false}
          onClose={() => setShowZoomedCover(false)}
          onShare={handleNativeShare}
        />
      )}

      {/* PINCH-TO-ZOOM / MULTI-TOUCH INTERACTIVE VIEWER FOR AVATAR PORTRAIT (Requirement 1) */}
      {showZoomedAvatar && avatarUrl && (
        <InteractiveImageViewer
          src={avatarUrl}
          alt="Profile Avatar"
          title={title}
          subtitle={`${subTitle} • Pinch to expand or drag`}
          isAvatar={true}
          onClose={() => setShowZoomedAvatar(false)}
          onShare={handleNativeShare}
        />
      )}

      {/* SUB-MODAL: Media, links and docs Full Viewer (Requirement 9 & 11) */}
      {showMediaModal && (
        <div className="fixed inset-0 bg-[#080b10] z-[550] flex flex-col p-4 md:p-6 animate-fade-in">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-[#212a38] pb-4 mb-4 shrink-0">
            <button
              onClick={() => setShowMediaModal(false)}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:text-[#20e3a2] cursor-pointer hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h3 className="font-display font-bold text-sm text-white">Media, links and docs</h3>
              <p className="text-[10px] text-[#8d97ab] mt-0.5">{title}</p>
            </div>
          </div>

          {/* Tab Headers */}
          <div className="flex border-b border-[#212a38] shrink-0 mb-4 bg-black/20 p-1 rounded-xl">
            {(['media', 'links', 'docs'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveMediaTab(tab)}
                className={`flex-1 py-2 text-center text-xs font-bold rounded-lg capitalize cursor-pointer transition-all ${
                  activeMediaTab === tab
                    ? 'bg-[#161d28] text-[#20e3a2] border border-[#212a38]'
                    : 'text-[#8d97ab] hover:text-white'
                }`}
              >
                {tab === 'media' ? `Media (${mediaItems.length})` : tab === 'links' ? `Links (${linkItems.length})` : `Docs (${docItems.length})`}
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto pr-1">
            {activeMediaTab === 'media' && (
              mediaItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <ImageIcon className="w-10 h-10 text-[#5a6478] mb-3 opacity-50" />
                  <p className="text-xs text-[#8d97ab]">No media shared in this chat yet</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 pb-4">
                  {mediaItems.map((m) => (
                    <div key={m.id} className="relative aspect-square rounded-xl overflow-hidden border border-[#212a38] bg-[#161d28]/30 flex items-center justify-center group">
                      {m.is_voice ? (
                        <div className="flex flex-col items-center justify-center p-2 text-center">
                          <Mic className="w-5 h-5 text-[#20e3a2] mb-1" />
                          <span className="text-[8px] text-[#8d97ab] font-mono">Voice note</span>
                        </div>
                      ) : m.file_type?.startsWith('video/') && m.file_data ? (
                        <video src={m.file_data} className="w-full h-full object-cover" controls preload="metadata" />
                      ) : m.file_data ? (
                        <img loading="lazy" decoding="async" src={m.file_data} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-[9px] text-[#8d97ab] font-mono break-all p-1 text-center">{m.file_name}</span>
                      )}
                    </div>
                  ))}
                </div>
              )
            )}

            {activeMediaTab === 'links' && (
              linkItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <LinkIcon className="w-10 h-10 text-[#5a6478] mb-3 opacity-50" />
                  <p className="text-xs text-[#8d97ab]">No links shared in this chat yet</p>
                </div>
              ) : (
                <div className="space-y-2.5 pb-4">
                  {linkItems.map((m) => {
                    const linksFound = m.text?.match(linkRegex) || [];
                    return (
                      <div key={m.id} className="p-3.5 rounded-2xl bg-[#161d28]/40 border border-[#212a38]/60 flex flex-col gap-1.5">
                        {linksFound.map((url, i) => (
                          <a
                            key={i}
                            href={(url.startsWith('http') || url.startsWith('/api/media/')) ? url : `https://${url}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between text-xs font-bold text-[#20e3a2] hover:underline"
                          >
                            <span className="truncate max-w-[260px]">{url}</span>
                            <ExternalLink className="w-3.5 h-3.5 shrink-0 ml-1.5" />
                          </a>
                        ))}
                        <span className="text-[9.5px] text-[#5a6478] font-mono mt-0.5">
                          {new Date(m.created_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )
            )}

            {activeMediaTab === 'docs' && (
              docItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <FileText className="w-10 h-10 text-[#5a6478] mb-3 opacity-50" />
                  <p className="text-xs text-[#8d97ab]">No documents shared in this chat yet</p>
                </div>
              ) : (
                <div className="space-y-2.5 pb-4">
                  {docItems.map((m) => (
                    <div key={m.id} className="p-3.5 rounded-2xl bg-[#161d28]/40 border border-[#212a38]/60 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-xl bg-[#161d28] border border-[#212a38] text-amber-400">
                          <FileText className="w-4.5 h-4.5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-white truncate">{m.file_name}</p>
                          <p className="text-[9px] text-[#5a6478] font-mono uppercase mt-0.5">{m.file_type || 'Document'}</p>
                        </div>
                      </div>
                      {m.file_data && (
                        <a
                          href={m.file_data}
                          download={m.file_name || 'document'}
                          className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white cursor-pointer transition-colors"
                          title="Download Document"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )
            )}
          </div>
        </div>
      )}

      {/* SUB-MODAL: Starred Messages Full Viewer (Requirement 9) */}
      {showStarredModal && (
        <div className="fixed inset-0 bg-[#080b10] z-[550] flex flex-col p-4 md:p-6 animate-fade-in">
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-[#212a38] pb-4 mb-4 shrink-0">
            <button
              onClick={() => setShowStarredModal(false)}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:text-[#20e3a2] cursor-pointer hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-400 fill-current" />
                <span>Starred Messages</span>
              </h3>
              <p className="text-[10px] text-[#8d97ab] mt-0.5">{title} • {starredMessages.length} starred</p>
            </div>
          </div>

          {/* List of Starred Messages */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-3">
            {starredMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <Star className="w-10 h-10 text-[#5a6478] mb-3 opacity-40" />
                <p className="text-xs text-[#8d97ab] font-bold">No starred messages</p>
                <p className="text-[10.5px] text-[#5a6478] max-w-xs mt-1">
                  Long press or right click any message in chat and tap "Star" to save it here.
                </p>
              </div>
            ) : (
              starredMessages.map((msg) => {
                const sender = allProfiles.find((p) => p.id === msg.sender_id);
                const senderName = msg.sender_id === currentUser.id ? 'You' : (sender?.display_name || sender?.username || 'User');
                return (
                  <div
                    key={msg.id}
                    onClick={() => {
                      setShowStarredModal(false);
                      onClose();
                      if (onSelectChat) {
                        onSelectChat(targetChatId, isUser ? (data as Profile) : null, msg.id);
                      }
                    }}
                    className="p-3.5 rounded-2xl bg-[#121824] border border-[#212a38] hover:border-amber-400/30 transition-all cursor-pointer flex flex-col gap-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#20e3a2]">{senderName}</span>
                      <span className="text-[9.5px] text-[#5a6478] font-mono">
                        {new Date(msg.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
                      </span>
                    </div>

                    {msg.text && (
                      <p className="text-xs text-white leading-relaxed">
                        {getCleanMessageExcerpt(msg.text)}
                      </p>
                    )}

                    {msg.file_data && msg.file_type?.startsWith('image/') && (
                      <img loading="lazy" decoding="async" src={msg.file_data} alt="" className="max-h-32 rounded-xl object-cover border border-white/10" referrerPolicy="no-referrer" />
                    )}

                    <div className="flex items-center justify-between text-[9px] text-[#8d97ab] font-mono pt-1 border-t border-white/5">
                      <span>Tap to jump to message</span>
                      <Star className="w-3 h-3 text-amber-400 fill-current" />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUB-MODAL: Media Visibility Dialog (WhatsApp Spec) */}
      {showMediaVisibilityModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[650] flex items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-[#121824] border border-[#212a38] rounded-3xl p-5 shadow-2xl flex flex-col">
            <h3 className="text-base font-bold text-white mb-2">Media visibility</h3>
            <p className="text-xs text-[#8d97ab] leading-relaxed mb-4">
              Show newly downloaded media from this chat in your device's gallery?
            </p>

            <div className="space-y-2 mb-5">
              {[
                { id: 'default', label: 'Default (Yes)' },
                { id: 'always', label: 'Yes' },
                { id: 'never', label: 'No' },
              ].map((opt) => (
                <label
                  key={opt.id}
                  onClick={() => handleSaveMediaVisibility(opt.id as any)}
                  className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer transition-all"
                >
                  <span className="text-xs font-medium text-white">{opt.label}</span>
                  <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${mediaVisibility === opt.id ? 'border-[#20e3a2] bg-[#20e3a2]' : 'border-white/40'}`}>
                    {mediaVisibility === opt.id && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                  </div>
                </label>
              ))}
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowMediaVisibilityModal(false)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-[#8d97ab] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setShowMediaVisibilityModal(false)}
                className="px-4 py-2 rounded-xl bg-[#20e3a2] hover:bg-[#20e3a2]/90 text-xs font-bold text-black transition-all cursor-pointer shadow-md shadow-[#20e3a2]/20"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-MODAL: Share Profile to Chat Session (Requirement 10) */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-xl z-[600] flex flex-col items-center justify-center p-4 animate-fade-in">
          <div className="w-full max-w-md bg-[#121824] border border-[#212a38] rounded-3xl p-5 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#212a38] pb-3 mb-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm text-white">Share Contact Profile</h3>
                  <p className="text-[10px] text-[#8d97ab]">Send {title}'s profile card</p>
                </div>
              </div>
              <button
                onClick={() => setShowShareModal(false)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-[#8d97ab] hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Action Buttons: Copy / Native Share */}
            <div className="grid grid-cols-2 gap-2 mb-3 shrink-0">
              <button
                onClick={handleCopyProfileCard}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-white transition-all cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-[#20e3a2]" />
                <span>Copy Details</span>
              </button>
              <button
                onClick={handleNativeShare}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-white transition-all cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Share Externally</span>
              </button>
            </div>

            {/* Search filter for recipient chat rooms */}
            <div className="relative mb-3 shrink-0">
              <Search className="w-3.5 h-3.5 text-[#5a6478] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search contact or group to send to..."
                value={shareSearchQuery}
                onChange={(e) => setShareSearchQuery(e.target.value)}
                className="w-full bg-[#090d13] border border-[#212a38] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#5a6478] outline-none focus:border-[#20e3a2]"
              />
            </div>

            <p className="text-[10px] text-[#5a6478] font-mono uppercase font-black tracking-wider mb-2 shrink-0">
              Select Chat Session:
            </p>

            {/* Recipient Chats List */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
              {/* General Chat Option */}
              <div
                onClick={() => handleSendProfileToChat('general', null)}
                className="p-2.5 rounded-xl bg-[#161d28]/40 hover:bg-[#161d28] border border-[#212a38] flex items-center justify-between cursor-pointer group transition-all"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-[#20e3a2]/10 border border-[#20e3a2]/30 flex items-center justify-center text-[#20e3a2] font-black text-xs shrink-0">
                    #
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white group-hover:text-[#20e3a2] transition-colors truncate">
                      General Chat
                    </p>
                    <p className="text-[9.5px] text-[#8d97ab] font-mono">Public Channel</p>
                  </div>
                </div>
                <Send className="w-3.5 h-3.5 text-[#8d97ab] group-hover:text-[#20e3a2] transition-colors" />
              </div>

              {/* Groups Options */}
              {groupsList.map((grp) => {
                if (shareSearchQuery && !(grp.name || '').toLowerCase().includes(shareSearchQuery.toLowerCase())) {
                  return null;
                }
                return (
                  <div
                    key={grp.id}
                    onClick={() => handleSendProfileToChat(grp.id, null)}
                    className="p-2.5 rounded-xl bg-[#161d28]/40 hover:bg-[#161d28] border border-[#212a38] flex items-center justify-between cursor-pointer group transition-all"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-[#7c5cff]/10 border border-[#7c5cff]/30 flex items-center justify-center text-white text-xs font-bold shrink-0 overflow-hidden">
                        {(grp.icon?.startsWith('http') || grp.icon?.startsWith('/api/media/')) || grp.icon?.startsWith('data:image') ? (
                          <img loading="lazy" decoding="async" src={grp.icon} alt="" className="w-full h-full object-cover" />
                        ) : (
                          grp.icon || '👥'
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-white group-hover:text-[#7c5cff] transition-colors truncate">
                          {grp.name}
                        </p>
                        <p className="text-[9.5px] text-[#8d97ab] font-mono">{grp.members?.length || 0} members</p>
                      </div>
                    </div>
                    <Send className="w-3.5 h-3.5 text-[#8d97ab] group-hover:text-[#7c5cff] transition-colors" />
                  </div>
                );
              })}

              {/* Direct Messages / Contacts Options */}
              {allProfiles
                .filter((p) => p.id !== currentUser.id)
                .filter((p) => {
                  if (!shareSearchQuery) return true;
                  const q = shareSearchQuery.toLowerCase();
                  return (p.display_name || '').toLowerCase().includes(q) || (p.username || '').toLowerCase().includes(q);
                })
                .map((peer) => {
                  const sorted = [currentUser.id, peer.id].sort();
                  const dmChatId = `dm:${sorted[0]}:${sorted[1]}`;
                  return (
                    <div
                      key={peer.id}
                      onClick={() => handleSendProfileToChat(dmChatId, peer)}
                      className="p-2.5 rounded-xl bg-[#161d28]/40 hover:bg-[#161d28] border border-[#212a38] flex items-center justify-between cursor-pointer group transition-all"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-full bg-[#20e3a2]/10 border border-[#20e3a2]/30 flex items-center justify-center text-white text-[10px] font-black shrink-0 overflow-hidden">
                          {peer.avatar_url ? (
                            <img loading="lazy" decoding="async" src={peer.avatar_url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            getInitials(peer.display_name || peer.username || 'U')
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-white group-hover:text-[#20e3a2] transition-colors truncate">
                            {peer.display_name || peer.username}
                          </p>
                          <p className="text-[9.5px] text-[#8d97ab] font-mono">@{peer.username}</p>
                        </div>
                      </div>
                      <Send className="w-3.5 h-3.5 text-[#8d97ab] group-hover:text-[#20e3a2] transition-colors" />
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
