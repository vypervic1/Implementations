import { useEffect, useRef } from 'react';
/** Component-owned resources. Late media permission grants are stopped, never adopted. */
export class ResourceScope {
  private live = true;
  private epoch = 0;
  private timers = new Set<ReturnType<typeof setTimeout>>();
  private urls = new Set<string>();
  private readers = new Set<FileReader>();
  private streams = new Set<MediaStream>();
  private recorders = new Set<MediaRecorder>();
  activate() { this.live = true; this.epoch++; }
  capture() { const epoch = this.epoch; return () => this.live && this.epoch === epoch; }
  timeout = (callback: (...args: any[]) => any, ms?: number, ...args: any[]) => {
    const current = this.capture();
    const timer = setTimeout(() => { this.timers.delete(timer); if (current()) { const result = callback(...args); if (result?.catch) result.catch(() => console.warn('[Lifecycle] Deferred action failed')); } }, ms);
    this.timers.add(timer); return timer;
  };
  clearTimeout = (timer: ReturnType<typeof setTimeout> | undefined) => { if (timer) { this.timers.delete(timer); clearTimeout(timer); } };
  blob = (blob: Blob | MediaSource): string => { const url = URL.createObjectURL(blob); this.urls.add(url); return url; };
  revoke = (url: string) => { this.urls.delete(url); URL.revokeObjectURL(url); };
  reader = (): FileReader => { const reader = new FileReader(); this.readers.add(reader); reader.addEventListener('loadend', () => this.readers.delete(reader), { once: true }); return reader; };
  recorder = (recorder: MediaRecorder): MediaRecorder => { this.recorders.add(recorder); recorder.addEventListener('stop', () => this.recorders.delete(recorder), { once: true }); return recorder; };
  getUserMedia = async (constraints: MediaStreamConstraints): Promise<MediaStream> => {
    const current = this.capture(); if (!current()) throw new Error('Media view is closed');
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    if (!current()) { stream.getTracks().forEach(track => track.stop()); throw new Error('Media view closed while waiting for permission'); }
    for (const previous of this.streams) if (previous.getTracks().every(track => track.readyState === 'ended')) this.streams.delete(previous);
    this.streams.add(stream); return stream;
  };
  dispose() {
    this.live = false; this.epoch++;
    for (const timer of this.timers) clearTimeout(timer); this.timers.clear();
    for (const recorder of this.recorders) { recorder.onstop = null; recorder.ondataavailable = null; if (recorder.state !== 'inactive') recorder.stop(); } this.recorders.clear();
    for (const stream of this.streams) stream.getTracks().forEach(track => track.stop()); this.streams.clear();
    for (const reader of this.readers) { reader.onload = null; reader.onloadend = null; reader.onerror = null; if (reader.readyState === 1) reader.abort(); } this.readers.clear();
    for (const url of this.urls) URL.revokeObjectURL(url); this.urls.clear();
  }
}
export function useResources(): ResourceScope {
  const scope = useRef<ResourceScope | null>(null); if (!scope.current) scope.current = new ResourceScope();
  useEffect(() => { scope.current!.activate(); return () => scope.current!.dispose(); }, []);
  return scope.current;
}
