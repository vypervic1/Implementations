import { withDataMutation } from './mutationGate';
import { fetchRowsByFilter, fetchRowById, ordsFetch } from './oracleBackend';
import { getCallById, syncCallProjection } from './callState';
import { withLease, BusyError } from './sharedStore';
import { publishScopedEvent } from './realtimeBus';
export const callWorkerHealth = { lastPassAt: 0, failures: 0 };
let running = false;
let timer: ReturnType<typeof setInterval> | undefined;
/** Oracle is lifecycle authority. Recover partial projections and expire ringing calls independently of clients. */
export async function reconcileCalls(): Promise<void> {
  try { await withDataMutation(reconcileUnlocked); } catch { /* admission closed; retry next tick */ }
}
async function reconcileUnlocked(): Promise<void> {
  if (running) return;
  running = true;
  try {
    const ringing = await fetchRowsByFilter('calls', { STATUS: 'ringing' }, 50);
    const accepted = await fetchRowsByFilter('calls', { STATUS: 'accepted' }, 50);
    const rows = Array.from(new Map([...ringing, ...accepted].map(row => [row.id, row])).values());
    for (const snapshot of rows) {
      try {
        await withLease(`calls:${snapshot.id}`, async held => {
          const call = await fetchRowById('calls', snapshot.id); if (!call) return;
          const age = Date.now() - Date.parse(call.created_at);
          const status = call.status === 'ringing' && age >= 30000 ? 'missed' : call.status === 'accepted' && age >= 4 * 3600000 ? 'ended' : call.status;
          if (age > 5 * 3600000 && status === call.status) return;
          if (status !== call.status) {
            held(); const updated = await ordsFetch(`/calls/${encodeURIComponent(call.id)}`, { method: 'PATCH', body: { STATUS: status, UPDATED_AT: new Date().toISOString() } });
            if (!updated.ok) throw new Error('Call expiry was not persisted');
            call.status = status; call.updated_at = new Date().toISOString();
          }
          const projection = await getCallById(call.id);
          if (!projection || projection.status !== call.status) {
            held(); await syncCallProjection(call);
            await publishScopedEvent(call.status === 'ringing' ? 'call_invite' : 'call_status_update',
              call.status === 'ringing' ? { call } : { callId: call.id, status: call.status }, { userIds: [call.caller_id, call.receiver_id] });
          }
        });
      } catch (error: any) { if (!(error instanceof BusyError)) { callWorkerHealth.failures++; console.error('[Calls] Projection recovery pending:', error?.message || error); } }
    }
    callWorkerHealth.lastPassAt = Date.now();
  } catch (error: any) { callWorkerHealth.failures++; console.error('[Calls] Reconciliation failed:', error?.message || error); }
  finally { running = false; }
}
export function startCallWorker(): void {
  if (timer) return;
  timer = setInterval(() => void reconcileCalls(), 10000); timer.unref(); void reconcileCalls();
}
export function stopCallWorker(): void { if (timer) clearInterval(timer); timer = undefined; }
