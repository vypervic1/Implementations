import { OperationStatus } from './components/OperationStatus';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { capabilities } from './capabilities';
// Remove legacy Web Push workers when upgrading an older native wrapper. Never register one here.
if (capabilities().mode !== 'browser' && 'serviceWorker' in navigator) {
  void navigator.serviceWorker.getRegistrations().then(registrations => Promise.all(registrations.filter(r => r.active?.scriptURL.endsWith('/firebase-messaging-sw.js')).map(r => r.unregister())));
}

// Native Android loads the HTTPS VPS origin and uses native FCM, never a web push worker.
// Browser service workers are registered only after the user opts into real Web Push.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
    <OperationStatus />
  </StrictMode>,
);
