export class ApiError extends Error {
  constructor(public status: number, message: string, public code = 'request_failed') { super(message); }
}
export class OracleError extends ApiError {
  constructor(public upstreamStatus: number) { super(502, 'Database temporarily unavailable', 'upstream_error'); }
}
