import { readFileSync, readdirSync, statSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import path from 'node:path';
const manifest = JSON.parse(readFileSync('dist/.vite/manifest.json', 'utf8'));
const loaded = new Set();
function entryBytes(key) {
  if (loaded.has(key)) return 0;
  loaded.add(key);
  const entry = manifest[key];
  if (!entry) throw new Error(`Missing bundle entry: ${key}`);
  if (/vendor-web-push/.test(entry.file)) throw new Error('Web Push must not be in the unauthenticated startup graph');
  return gzipSync(readFileSync(path.join('dist', entry.file))).length + (entry.imports || []).reduce((n, dep) => n + entryBytes(dep), 0);
}
const bytes = entryBytes('index.html');
if (bytes > 420 * 1024) throw new Error(`Startup JS exceeds 420 KiB gzip budget: ${bytes}`);
for (const file of readdirSync('dist/assets')) {
  if (!file.endsWith('.js')) continue;
  const text = readFileSync(`dist/assets/${file}`, 'utf8');
  if (/-----BEGIN (RSA )?PRIVATE KEY-----/.test(text) || /https?:[^\s"']+\/ords\//.test(text)) throw new Error(`Server-only material in browser asset: ${file}`);
  if (statSync(`dist/assets/${file}`).size > 2 * 1024 * 1024) throw new Error(`Oversized lazy chunk: ${file}`);
}
console.log(`Startup JS: ${(bytes / 1024).toFixed(1)} KiB gzip; Web Push deferred; no private keys or ORDS endpoints detected.`);
