# AndroidX WebMessageListener is origin-scoped; no JavascriptInterface reflection bridge.
-keepattributes SourceFile,LineNumberTable
