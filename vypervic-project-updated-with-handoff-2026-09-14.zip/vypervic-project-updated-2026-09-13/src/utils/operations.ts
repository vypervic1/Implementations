export interface OperationProgress { operationId: string; status: 'queued'|'running'|'partial'|'failed'|'completed'; success: boolean; failedCount: number; results: Record<string, { deleted: number; failed: number }> }
const key = 'vyper_operation_pending';
const notify = (operation: OperationProgress) => window.dispatchEvent(new CustomEvent('vyper_operation', { detail: operation }));
export async function getOperation(id: string, signal?: AbortSignal): Promise<OperationProgress> {
  if (!/^(wipe_[a-f0-9-]{36}|delete_[a-f0-9]{40})$/.test(id)) throw new Error('Invalid operation ID');
  const response = await fetch(`/api/operations/${id}`, { credentials: 'same-origin', cache: 'no-store', signal });
  const body = await response.json(); if (!response.ok) throw new Error(body.error || 'Operation status unavailable');
  notify(body); return body;
}
export function pendingOperationId(): string | null { return localStorage.getItem(key); }
export function dismissOperation() { localStorage.removeItem(key); window.dispatchEvent(new Event('vyper_operation_dismissed')); }
export async function submitOperation(path: string, body: unknown): Promise<OperationProgress> {
  const response = await fetch(path, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const result = await response.json();
  if (!response.ok || !result.operationId) throw new Error(result.error || 'Operation was not accepted');
  localStorage.setItem(key, result.operationId); notify(result);
  // Bounded UI wait, not an all-or-nothing HTTP request. The cookie receipt survives session deletion.
  for (let attempt = 0; attempt < 12; attempt++) {
    const current = await getOperation(result.operationId);
    if (['completed','partial','failed'].includes(current.status)) return current;
    await new Promise(resolve => setTimeout(resolve, Math.min(3000, 300 * 2 ** attempt)));
  }
  return getOperation(result.operationId);
}
