import { sessionEpoch, SessionSupersededError } from './sessionEpoch';
// =========================================================================
// ORACLE AUTONOMOUS DATABASE (ORDS REST) CLIENT FOR VYPERVIC
// Replaces Supabase completely with Oracle Autonomous Database (ATP / 26ai)
// =========================================================================

import { Profile, Message, Call } from './types';
import { getSessionStatus, setSessionStatus } from './sessionStatus';
import { capabilities } from './capabilities';
import { 
  cacheMessagesLocally, 
  getCachedMessagesLocally, 
  cacheProfilesLocally, 
  getCachedProfilesLocally,
  deleteCachedProfileLocally,
  deleteCachedMessageLocally,
  clearCachedMessagesStore,
  clearCachedProfilesStore,
  clearAllCachedDataLocally,
  saveOfflineQueueMessageLocally,
  getOfflineQueueMessagesLocally,
  removeOfflineQueueMessageLocally
} from './utils/indexedDB';
// SECURITY (Issue 4): the browser may ONLY talk to our own server.ts proxy.
// The direct Oracle ORDS URL and every fallback path to it have been removed.
// There is no browser-facing way to reach the database without going through
// /api/oracle/*, which requires a verified JWT (see server.ts).
export const ORDS_BASE_URL = '/api/oracle';

// Public profile column set for client-facing queries (Issue 1).
// Credential fields (password_hash / password_salt) are NOT part of it and are
// additionally stripped server-side in the /api/oracle/* proxy, so a hashed
// password can no longer ship to any browser.
export const PUBLIC_PROFILE_COLUMNS =
  'id,email,username,display_name,about,avatar_url,cover_url,is_online,last_seen,created_at,role,is_admin,phone_number';

// H-07: the session JWT is NO LONGER stored in localStorage (XSS-stealable).
// The server delivers it in an HttpOnly SameSite cookie (sent automatically
// with same-origin requests); the token is additionally held in this
// module-scoped variable for the Authorization header path. Only a
// non-sensitive "has session" flag is persisted so the app knows to ask
// /api/auth/me (cookie-authenticated) to restore the session after a reload.
const HAS_SESSION_FLAG = 'vypervic_has_session';
// Browser/native WebView authentication is cookie-only. Never expose a session JWT to JS.
export function getAuthToken(): null { return null; }
export function hasServerSession(): boolean { return getSessionStatus().status === 'authenticated'; }
export function setAuthToken(marker: string | null) {
  try { if (marker) localStorage.setItem(HAS_SESSION_FLAG, '1'); else localStorage.removeItem(HAS_SESSION_FLAG); } catch { /* display hint only */ }
  if (!marker) setSessionStatus('signed-out');
}
function authHeaders(extra: Record<string, string> = {}): Record<string, string> { return extra; }
export class ClientApiError extends Error {
  constructor(message: string, public status = 0) { super(message); }
}

// Build the legacy session shape (still consumed by App.tsx / AuthScreen.tsx)
// from a user object that came back from the server (never contains hashes).
function buildSessionFromServerUser(user: any, token: string): any {
  return {
    user: {
      id: user.id,
      email: user.email,
      user_metadata: {
        username: user.username,
        display_name: user.display_name,
        phone_number: user.phone_number,
        role: user.role,
        is_admin: user.role === 'admin' || !!user.is_admin,
      },
    },
    profile: user,
  };
}

// -------------------------------------------------------------
// NATIVE WEB CRYPTO PBKDF2 PASSWORD HASHING & SALT GENERATION
// -------------------------------------------------------------
export function generateCryptoSalt(): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    try {
      const enc = new TextEncoder();
      const keyMaterial = await crypto.subtle.importKey(
        'raw',
        enc.encode(password),
        { name: 'PBKDF2' },
        false,
        ['deriveBits']
      );
      const derivedBits = await crypto.subtle.deriveBits(
        {
          name: 'PBKDF2',
          salt: enc.encode(salt),
          iterations: 100000,
          hash: 'SHA-256',
        },
        keyMaterial,
        256
      );
      return Array.from(new Uint8Array(derivedBits))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    } catch (e) {
      console.warn('Web Crypto PBKDF2 failed:', e);
      throw new Error(
        'Password hashing is unavailable in this browser (Web Crypto PBKDF2 failed). ' +
          'Weak fallback hashes are no longer permitted; please use a modern browser.'
      );
    }
  }
  // H-07: the SHA-256 / hash-trick fallbacks are REMOVED. A browser without
  // Web Crypto must fail closed instead of producing a weak verifier.
  throw new Error(
    'Password hashing is unavailable in this browser (Web Crypto not found). ' +
      'Weak fallback hashes are no longer permitted; please use a modern browser.'
  );
}

export interface OracleQueryResponse<T = any> {
  data: T | null;
  error: Error | null;
  count?: number;
  syncState?: 'synchronized' | 'cached';
}

type AuthCallback = (event: 'SIGNED_IN' | 'SIGNED_OUT' | 'USER_UPDATED', session: any) => void;

class OracleRealtimeChannel {
  name: string;
  listeners: Array<{ type: string; event: string; filter?: any; callback: (payload: any) => void }> = [];
  intervalId: any = null;
  lastTimestamp: string = new Date().toISOString();
  private broadcastChannel: BroadcastChannel | null = null;

  constructor(name: string) {
    this.name = name;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.broadcastChannel = new BroadcastChannel(`oracle_channel_${name}`);
        this.broadcastChannel.onmessage = (ev) => {
          if (ev.data && ev.data.event) {
            this.emitBroadcast(ev.data.event, ev.data.payload);
          }
        };
      } catch (e) {}
    }
  }

  on(type: string, filterConfig: any, callback: (payload: any) => void): this {
    this.listeners.push({
      type: type || 'postgres_changes',
      event: filterConfig?.event || '*',
      filter: filterConfig || {},
      callback,
    });
    return this;
  }

  async send(params: { type: string; event: string; payload: any }): Promise<'ok' | 'error'> {
    try {
      if (getSessionStatus().status !== 'authenticated') return 'error';
      // Durable transitions happen through typed state routes, never through a broadcast.
      if (params.event === 'call_status_update') { await oracleDB.updateRemoteCallStatus(params.payload.callId, params.payload.status); return 'ok'; }
      // Call creation/status routes publish their own committed state.
      const response = await fetch('/api/realtime/broadcast', {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel: this.name, event: params.event, payload: params.payload, clientId: oracleDB.getSSEClientId() }),
      });
      if (!response.ok) return 'error';
      // Do not re-emit the user's own reaction locally: its optimistic reducer already ran.
      return 'ok';
    } catch { return 'error'; }
  }

  emitBroadcast(event: string, payload: any) {
    for (const l of this.listeners) {
      if (l.type === 'broadcast') {
        if (l.event === '*' || l.event === event) {
          try {
            l.callback({ event, payload });
          } catch (err) {
            console.warn(`Error in broadcast listener on ${this.name}:`, err);
          }
        }
      }
    }
  }

  emit(eventType: string, payload: any) {
    for (const l of this.listeners) {
      if (l.type !== 'broadcast') {
        if (l.event === '*' || l.event === eventType) {
          // Check if table matches filter if table filter is specified
          if (l.filter?.table && payload.table && l.filter.table !== payload.table) {
            continue;
          }
          // Check if ID filter matches if specified (e.g., id=eq.xxx)
          if (l.filter?.filter && typeof l.filter.filter === 'string' && l.filter.filter.startsWith('id=eq.')) {
            const targetId = l.filter.filter.replace('id=eq.', '');
            const recordId = payload.new?.id || payload.old?.id;
            if (recordId && recordId !== targetId) {
              continue;
            }
          }
          try {
            l.callback(payload);
          } catch (err) {
            console.warn(`Error in postgres_changes listener on ${this.name}:`, err);
          }
        }
      }
    }
  }

  track(_state: any): Promise<'ok'> {
    return Promise.resolve('ok');
  }

  untrack(): Promise<'ok'> {
    return Promise.resolve('ok');
  }

  presenceState(): Record<string, any> {
    return {};
  }

  subscribe(statusCallback?: (status: string) => void): this {
    if (statusCallback) {
      setTimeout(() => statusCallback('SUBSCRIBED'), 10);
    }
    return this;
  }

  unsubscribe() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.close();
      } catch (e) {}
      this.broadcastChannel = null;
    }
    this.listeners = [];
  }
}

// Comprehensive helper for fetch with timeout.
// SECURITY (Issue 4): requests always carry the JWT Authorization header when a
// session exists, and there is NO fallback that bypasses our server — the old
// direct-to-Oracle fallback paths have been removed entirely.
async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs: number = 12000): Promise<Response> {
  if (typeof window !== 'undefined' && !capabilities().sameOriginApi) throw new ClientApiError('Load the HTTPS application origin; local asset API routing is unsupported');
  if (!['GET', 'HEAD'].includes(options.method || 'GET') && getSessionStatus().status !== 'authenticated') throw new ClientApiError('Account is offline or unverified; reconnect before making changes');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    try {
      controller.abort();
    } catch (e) {}
  }, timeoutMs);
  try {
    const mergedHeaders: Record<string, string> = {
      ...((options.headers as Record<string, string>) || {}),
      ...authHeaders(),
    };
    const res = await fetch(url, {
      ...options,
      headers: mergedHeaders,
      // H-07: same-origin cookies carry the HttpOnly session for requests
      // issued before an in-memory token exists (e.g. right after a reload).
      credentials: 'same-origin',
      signal: options.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal,
    });
    return res;
  } finally {
    clearTimeout(timeoutId);
  }
}

class OracleTableQuery<T = any> {
  private endpoint: string;
  private tableName: string;
  private operation: 'select' | 'insert' | 'upsert' | 'update' | 'delete' = 'select';
  private pendingPayload: any = null;
  private filters: Array<{ column: string; op: '$eq' | '$ne' | '$gt' | '$gte' | '$lt' | '$lte' | '$like' | '$ilike' | '$in' | '$contains'; value: any }> = [];
  private orFilters: string[] = [];
  private orQFilters: Array<Record<string, string>> = [];
  private orderColumn?: string;
  private isAscending: boolean = true;
  private limitCount?: number;
  private selectedFields: string = '*';

  constructor(tableName: string) {
    this.tableName = tableName.toLowerCase();
    this.endpoint = `${ORDS_BASE_URL}/${this.tableName}/`;
  }

  select(fields: string = '*'): this {
    this.selectedFields = fields;
    if (this.operation !== 'insert' && this.operation !== 'upsert' && this.operation !== 'update' && this.operation !== 'delete') {
      this.operation = 'select';
    }
    return this;
  }

  insert(data: any | any[]): this {
    this.operation = 'insert';
    this.pendingPayload = data;
    return this;
  }

  upsert(data: any | any[], _options?: any): this {
    this.operation = 'upsert';
    this.pendingPayload = data;
    return this;
  }

  update(data: any): this {
    this.operation = 'update';
    this.pendingPayload = data;
    return this;
  }

  delete(): this {
    this.operation = 'delete';
    return this;
  }

  eq(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$eq', value });
    return this;
  }

  neq(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$ne', value });
    return this;
  }

  gt(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$gt', value });
    return this;
  }

  gte(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$gte', value });
    return this;
  }

  lt(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$lt', value });
    return this;
  }

  lte(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$lte', value });
    return this;
  }

  like(column: string, pattern: string): this {
    this.filters.push({ column: column.toUpperCase(), op: '$like', value: pattern });
    return this;
  }

  ilike(column: string, pattern: string): this {
    this.filters.push({ column: column.toUpperCase(), op: '$ilike', value: pattern });
    return this;
  }

  in(column: string, values: any[]): this {
    this.filters.push({ column: column.toUpperCase(), op: '$in', value: values });
    return this;
  }

  contains(column: string, value: any): this {
    this.filters.push({ column: column.toUpperCase(), op: '$contains', value });
    return this;
  }

  is(column: string, value: any): this {
    return this.eq(column, value);
  }

  not(column: string, _operator: string, value: any): this {
    return this.neq(column, value);
  }

  filter(column: string, operator: string, value: any): this {
    const opLower = operator.toLowerCase();
    if (opLower === 'eq' || opLower === 'is') return this.eq(column, value);
    if (opLower === 'neq') return this.neq(column, value);
    if (opLower === 'gt') return this.gt(column, value);
    if (opLower === 'gte') return this.gte(column, value);
    if (opLower === 'lt') return this.lt(column, value);
    if (opLower === 'lte') return this.lte(column, value);
    if (opLower === 'in') return this.in(column, Array.isArray(value) ? value : [value]);
    return this.eq(column, value);
  }

  match(query: Record<string, any>): this {
    for (const [col, val] of Object.entries(query)) {
      this.eq(col, val);
    }
    return this;
  }

  or(condition: string): this {
    this.orFilters.push(condition);
    // G-01: `.or(caller_id.eq.X,receiver_id.eq.X)` conditions used to be
    // applied CLIENT-SIDE ONLY (the server saw an unfiltered query). The
    // server now REJECTS unfiltered reads, so the or-condition must also
    // travel in the ORDS q filter as {"$or":[...]}.
    try {
      const parts = String(condition)
        .split(',')
        .map((p) => p.trim())
        .map((p) => {
          const idx = p.indexOf('.');
          const rest = idx >= 0 ? p.slice(idx + 1) : p;
          const dot = rest.indexOf('.');
          if (idx < 0 || dot < 0) return null;
          const column = p.slice(0, idx);
          const value = rest.slice(dot + 1);
          return { [column.toUpperCase()]: value };
        })
        .filter(Boolean) as Array<Record<string, string>>;
      if (parts.length > 0) {
        this.orQFilters.push(...parts);
      }
    } catch (e) {
      /* keep client-side behavior */
    }
    return this;
  }

  order(column: string, options: { ascending?: boolean } = { ascending: true }): this {
    this.orderColumn = column.toUpperCase();
    this.isAscending = options.ascending ?? true;
    return this;
  }

  limit(count: number): this {
    this.limitCount = count;
    return this;
  }

  private normalizeRow(row: any): any {
    if (!row) return row;
    const normalized: any = {};
    for (const key of Object.keys(row)) {
      const lowerKey = key.toLowerCase();
      let val = row[key];

      // Oracle boolean emulation (0/1 to boolean)
      if (lowerKey === 'is_online' || lowerKey === 'is_voice' || lowerKey === 'is_edited' || lowerKey === 'is_encrypted') {
        val = val === 1 || val === true || val === '1';
      }

      // JSON string parsing if returned as string from Oracle
      if ((lowerKey === 'custom_names' || lowerKey === 'settings' || lowerKey === 'reactions' || lowerKey === 'ice_candidates') && typeof val === 'string') {
        try {
          val = JSON.parse(val);
        } catch (e) {}
      }

      normalized[lowerKey] = val;
    }

    if (this.tableName === 'profiles') {
      for (const key of ['password_hash', 'password_salt', 'password_storage']) delete normalized[key];
      if (typeof normalized.about === 'string') normalized.about = normalized.about.replace(/\[auth:[^\]]*\]/gi, '').trim();
    }

    // Ensure created_at is always a valid ISO string so UI never renders "Invalid date"
    if (normalized.created_at) {
      if (typeof normalized.created_at === 'string' && isNaN(Date.parse(normalized.created_at))) {
        const cleaned = normalized.created_at.replace(' ', 'T');
        normalized.created_at = !isNaN(Date.parse(cleaned)) ? cleaned : new Date().toISOString();
      }
    } else if (this.tableName === 'messages' || this.tableName === 'profiles') {
      normalized.created_at = new Date().toISOString();
    }

    return normalized;
  }

  private transformForOracle(data: any): any {
    const result: Record<string, any> = {};
    for (const [key, value] of Object.entries(data || {})) {
      const name = key.toLowerCase();
      if (this.tableName === 'profiles' && !['email', 'username', 'display_name', 'phone_number', 'avatar_url', 'cover_url', 'about', 'is_online', 'last_seen', 'updated_at'].includes(name)) continue;
      if (['is_pending', 'retry_count', 'last_attempt_at', 'next_attempt_at', 'last_error', 'sync_status', 'profiles', 'reply_to_id', 'reply_to_sender', 'reply_preview', 'poll_data'].includes(name)) continue;
      if (typeof value === 'string' && value.startsWith('/api/media/') && ['avatar_url','cover_url','icon'].includes(name)) continue;
      result[name] = value;
    }
    return result;
  }

  async single(): Promise<OracleQueryResponse<T>> {
    const res = await this.execute();
    if (res.error) return { data: null, error: res.error };
    const list = Array.isArray(res.data) ? res.data : [res.data];
    if (list.length === 0 || !list[0]) {
      return { data: null, error: new Error('Row not found') };
    }
    return { data: list[0] as T, error: null };
  }

  async maybeSingle(): Promise<OracleQueryResponse<T>> {
    const res = await this.execute();
    if (res.error) return { data: null, error: res.error };
    const list = Array.isArray(res.data) ? res.data : [res.data];
    return { data: (list[0] || null) as T, error: null };
  }

  async then<TResult1 = OracleQueryResponse<any>, TResult2 = never>(
    onfulfilled?: ((value: OracleQueryResponse<any>) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    return this.execute().then(onfulfilled as any, onrejected);
  }

  async catch<TResult = never>(
    onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | null
  ): Promise<OracleQueryResponse<any> | TResult> {
    return this.execute().catch(onrejected as any);
  }

  async finally(onfinally?: (() => void) | null): Promise<OracleQueryResponse<any>> {
    return this.execute().finally(onfinally as any);
  }

  private async execute(): Promise<OracleQueryResponse<any>> {
    if (this.operation === 'insert') {
      return this.executeInsert();
    }
    if (this.operation === 'upsert') {
      return this.executeUpsert();
    }
    if (this.operation === 'update') {
      return this.executeUpdate();
    }
    if (this.operation === 'delete') {
      return this.executeDelete();
    }
    return this.executeFetch();
  }

  private applyInClientFilters(rawList: any[]): any[] {
    let items = rawList.map((r: any) => this.normalizeRow(r));

    if (this.filters.length > 0) {
      items = items.filter((item: any) => {
        return this.filters.every((f) => {
          const key = f.column.toLowerCase();
          const val = item[key];
          const target = f.value;

          if (f.op === '$eq') {
            if (val === null || val === undefined || target === null || target === undefined) {
              return val === target;
            }
            if (typeof val === 'boolean' || typeof target === 'boolean') {
              return Boolean(val) === Boolean(target);
            }
            return String(val).toLowerCase() === String(target).toLowerCase();
          }

          if (f.op === '$ne') {
            return String(val ?? '').toLowerCase() !== String(target ?? '').toLowerCase();
          }

          if (f.op === '$gt') {
            const valTime = !isNaN(Date.parse(val)) ? new Date(val).getTime() : Number(val);
            const targetTime = !isNaN(Date.parse(target)) ? new Date(target).getTime() : Number(target);
            return valTime > targetTime;
          }

          if (f.op === '$gte') {
            const valTime = !isNaN(Date.parse(val)) ? new Date(val).getTime() : Number(val);
            const targetTime = !isNaN(Date.parse(target)) ? new Date(target).getTime() : Number(target);
            return valTime >= targetTime;
          }

          if (f.op === '$lt') {
            const valTime = !isNaN(Date.parse(val)) ? new Date(val).getTime() : Number(val);
            const targetTime = !isNaN(Date.parse(target)) ? new Date(target).getTime() : Number(target);
            return valTime < targetTime;
          }

          if (f.op === '$lte') {
            const valTime = !isNaN(Date.parse(val)) ? new Date(val).getTime() : Number(val);
            const targetTime = !isNaN(Date.parse(target)) ? new Date(target).getTime() : Number(target);
            return valTime <= targetTime;
          }

          if (f.op === '$in') {
            if (!Array.isArray(target)) return false;
            return target.some((t) => String(t).toLowerCase() === String(val ?? '').toLowerCase());
          }

          if (f.op === '$like' || f.op === '$ilike') {
            const cleanPattern = String(target).replace(/%/g, '').toLowerCase();
            return String(val ?? '').toLowerCase().includes(cleanPattern);
          }

          if (f.op === '$contains') {
            if (Array.isArray(val)) {
              return val.includes(target);
            }
            return String(val ?? '').includes(String(target));
          }

          return true;
        });
      });
    }

    if (this.orFilters.length > 0) {
      for (const orCond of this.orFilters) {
        const parts = orCond.split(',').map((p) => p.trim());
        items = items.filter((item: any) => {
          return parts.some((part) => {
            const [col, _op, val] = part.split('.');
            return String(item[col?.toLowerCase()]).toLowerCase() === String(val).toLowerCase();
          });
        });
      }
    }

    if (this.orderColumn) {
      const key = this.orderColumn.toLowerCase();
      items.sort((a: any, b: any) => {
        const valA = a[key] ?? '';
        const valB = b[key] ?? '';
        if (valA < valB) return this.isAscending ? -1 : 1;
        if (valA > valB) return this.isAscending ? 1 : -1;
        return 0;
      });
    }

    if (this.limitCount && items.length > this.limitCount) {
      items = items.slice(0, this.limitCount);
    }

    // Client-side column projection (defense-in-depth for Issue 1): when a
    // specific column set was requested, drop everything else so credential
    // fields can never reach the UI — even from stale local caches.
    if (this.selectedFields && this.selectedFields !== '*') {
      const allowed = new Set(this.selectedFields.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean));
      items = items.map((item: any) => {
        const projected: any = {};
        for (const key of Object.keys(item)) {
          if (allowed.has(key.toLowerCase())) projected[key] = item[key];
        }
        return projected;
      });
    }

    return items;
  }

  private async executeFetch(): Promise<OracleQueryResponse<T[]>> {
    const request = sessionEpoch.capture();
    const rawItems: any[] = [];
    try {
      const idFilter = this.filters.length === 1 && this.filters[0].column === 'ID' && this.filters[0].op === '$eq' ? this.filters[0] : null;
      const filter: Record<string, any> = {};
      for (const f of this.filters) filter[f.column] = f.op === '$eq' ? f.value : { [f.op]: f.value };
      const q = this.orQFilters.length ? (Object.keys(filter).length ? { $and: [filter, { $or: this.orQFilters }] } : { $or: this.orQFilters }) : filter;
      const pageSize = Math.min(this.limitCount || 200, 1000);
      const seen = new Set<string>();
      const inbox = this.tableName === 'messages' && !Object.keys(q).length;
      const before = new Date().toISOString();
      for (let offset = 0; offset < 10000;) {
        const params = new URLSearchParams();
        if (!idFilter && Object.keys(q).length) params.set('q', JSON.stringify(q));
        if (!idFilter) { params.set('limit', String(pageSize)); params.set('offset', String(offset)); }
        if (this.orderColumn && !idFilter) params.set('order', `${this.orderColumn.toLowerCase()}.${this.isAscending ? 'asc' : 'desc'}`);
        if (inbox) params.set('before', before);
        const url = inbox ? `/api/messages/feed?${params}` : idFilter ? `${this.endpoint}${encodeURIComponent(idFilter.value)}` : `${this.endpoint}?${params}`;
        const response = await fetchWithTimeout(url, { headers: { Accept: 'application/json' }, signal: request.signal });
        const json = await response.json();
        request.assertCurrent();
        if (!response.ok) {
          if (response.status === 401) await oracleDB.auth.invalidateSession();
          throw new ClientApiError(json.error || 'Could not load authoritative data', response.status);
        }
        const items = (Array.isArray(json) ? json : json.items || [json]).map((row: any) => this.normalizeRow(row));
        for (const row of items) {
          if (!row.id || seen.has(row.id)) throw new ClientApiError('Server pagination made no progress', 502);
          seen.add(row.id); rawItems.push(row);
        }
        if (idFilter || json.hasMore === false || json.hasMore == null && items.length < pageSize || this.limitCount && rawItems.length >= this.limitCount) break;
        const nextOffset = Number(json.nextOffset ?? offset + items.length);
        if (nextOffset <= offset) throw new ClientApiError('Server pagination made no progress', 502);
        offset = nextOffset;
        if (offset >= 10000) throw new ClientApiError('Query is too broad; choose a more specific scope', 400);
      }
      request.assertCurrent();
      if (this.tableName === 'profiles') await cacheProfilesLocally(rawItems, this.filters.length === 0 && this.orQFilters.length === 0 && !this.limitCount);
      if (this.tableName === 'messages') await cacheMessagesLocally(rawItems);
      const items = this.applyInClientFilters(rawItems);
      return { data: items, error: null, count: items.length, syncState: 'synchronized' };
    } catch (error) {
      if (!request.current()) return { data: null, error: new SessionSupersededError() };
      // An authorization or persistence failure is NOT a successful cached read.
      if (error instanceof ClientApiError && error.status) return { data: null, error };
      const cached = this.tableName === 'profiles' ? await getCachedProfilesLocally() : this.tableName === 'messages' ? await getCachedMessagesLocally() : [];
      return { data: this.applyInClientFilters(cached), error: new ClientApiError('Offline: displaying cached data'), syncState: 'cached' };
    } finally { request.release(); }
  }
  private async acknowledge(method: string, path: string, body?: unknown): Promise<any> {
    const version = sessionEpoch.version;
    const response = await fetchWithTimeout(path, { method, headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    const data = await response.json().catch(() => ({}));
    if (version !== sessionEpoch.version) throw new SessionSupersededError();
    if (!response.ok) {
      if (response.status === 401) await oracleDB.auth.invalidateSession();
      throw new ClientApiError(data.error || 'The server did not confirm persistence', response.status);
    }
    return this.normalizeRow(data);
  }
  private async cacheAcknowledged(row: any, event: 'INSERT' | 'UPDATE') {
    if (this.tableName === 'messages') await cacheMessagesLocally([row]);
    if (this.tableName === 'profiles') {
      await cacheProfilesLocally([row]);
      if (getSessionStatus().userId === row.id) {
        sessionStorage.setItem('vypervic_session_user', JSON.stringify(row));
        localStorage.setItem('vypervic_current_user_cache', JSON.stringify(row));
      }
    }
    oracleDB.broadcast(this.tableName, event, row);
  }
  private async executeInsert(): Promise<OracleQueryResponse<any>> {
    const version = sessionEpoch.version;
    const records = Array.isArray(this.pendingPayload) ? this.pendingPayload : [this.pendingPayload];
    const stored: any[] = [];
    try {
      for (const rec of records) {
        if (this.tableName === 'messages' && !rec.id && !rec.ID) rec.id = `msg_${crypto.randomUUID()}`;
        const body = this.transformForOracle(rec);
        if (this.tableName === 'messages') {
          const existing = (await getOfflineQueueMessagesLocally()).find(row => row.id === rec.id);
          await saveOfflineQueueMessageLocally({ ...rec, sender_id: rec.sender_id || getSessionStatus().userId,
            created_at: rec.created_at || new Date().toISOString(), ...existing, is_pending: true } as Message, () => version === sessionEpoch.version);
        }

        const endpoint = this.tableName === 'messages' ? `/api/chats/${encodeURIComponent(body.chat_id)}/messages` : this.tableName === 'calls' || this.tableName === 'groups' ? `/api/${this.tableName}` : this.endpoint;
        if (version !== sessionEpoch.version) throw new SessionSupersededError();
        const row = await this.acknowledge('POST', endpoint, body);
        if (!row.id || row.id !== (rec.id || rec.ID)) throw new ClientApiError('Invalid durable acknowledgment', 502);
        stored.push(row);
        if (this.tableName === 'messages') await import('./utils/offlineSync').then(sync => sync.removeOfflineMessage(row.id));
        await this.cacheAcknowledged({ ...row, is_pending: false }, 'INSERT');
      }
      return { data: Array.isArray(this.pendingPayload) ? stored : stored[0], error: null, syncState: 'synchronized' };
    } catch (error) { return { data: stored.length ? stored : null, error: error as Error }; }
  }
  private async executeUpsert(): Promise<OracleQueryResponse<any>> {
    if (this.tableName === 'profiles') return this.executeUpdate();
    // Stable IDs make inserts idempotent. Never retry a rejected insert as an unrestricted PUT.
    return this.executeInsert();
  }
  private targetId(): string {
    const id = this.filters.find(f => f.column === 'ID' && f.op === '$eq')?.value || this.pendingPayload?.id || this.pendingPayload?.ID;
    if (!id || this.filters.some(f => f.column !== 'ID' || f.op !== '$eq')) throw new ClientApiError('A single resource ID is required', 400);
    return String(id);
  }
  private async executeUpdate(): Promise<OracleQueryResponse<any>> {
    try {
      const id = this.targetId();
      const body = this.transformForOracle(this.pendingPayload);
      delete body.id;
      const endpoint = ['messages', 'calls', 'groups'].includes(this.tableName) ? `/api/${this.tableName}/${encodeURIComponent(id)}` : `${this.endpoint}${encodeURIComponent(id)}`;
      const row = await this.acknowledge('PATCH', endpoint, body);
      if (!row.id) throw new ClientApiError('Missing authoritative updated row', 502);
      await this.cacheAcknowledged(row, 'UPDATE');
      return { data: row, error: null, syncState: 'synchronized' };
    } catch (error) { return { data: null, error: error as Error }; }
  }
  private async executeDelete(): Promise<OracleQueryResponse<any>> {
    try {
      const id = this.targetId();
      await this.acknowledge('DELETE', `${this.endpoint}${encodeURIComponent(id)}`);
      if (this.tableName === 'messages') await deleteCachedMessageLocally(id);
      if (this.tableName === 'profiles') await deleteCachedProfileLocally(id);
      oracleDB.broadcast(this.tableName, 'DELETE', { id });
      return { data: { id }, error: null };
    } catch (error) { return { data: null, error: error as Error }; }
  }
}

// -------------------------------------------------------------
// ORACLE AUTHENTICATION MANAGER (Native & Password Hashing)
// -------------------------------------------------------------

class OracleAuthManager {
  private authListeners: AuthCallback[] = [];

  private validatedSession: any = null;
  private epoch = sessionEpoch;
  private restoration: Promise<{ data: { session: any | null } }> | null = null;
  private notify(event: 'SIGNED_IN' | 'SIGNED_OUT' | 'USER_UPDATED', session: any) {
    this.validatedSession = session;
    for (const cb of this.authListeners) cb(event, session);
  }
  getSession(): Promise<{ data: { session: any | null } }> {
    if (this.restoration) return this.restoration;
    const request = this.restoreSession();
    this.restoration = request;
    void request.finally(() => { if (this.restoration === request) this.restoration = null; }).catch(() => {});
    return request;
  }
  private async restoreSession(): Promise<{ data: { session: any | null } }> {
    const request = this.epoch.capture();
    try {
      if (localStorage.getItem('vyper_logout_pending') === '1') {
        const logout = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceId: localStorage.getItem('vyper_push_device_id') || undefined }) });
        if (!logout.ok) throw new Error('Logout revocation pending');
        localStorage.removeItem('vyper_logout_pending');
      }
      const res = await fetch('/api/auth/me', { credentials: 'same-origin', cache: 'no-store', signal: request.signal });
      request.assertCurrent();
      if (res.status === 401 || res.status === 403) {
        await this.clearIdentity();
        return { data: { session: null } };
      }
      const body = await res.json();
      if (!res.ok || !body.user?.id) throw new ClientApiError('Account synchronization is unavailable', res.status);
      await this.prepareCacheFor(body.user.id);
      request.assertCurrent();
      request.assertCurrent();
      const session = buildSessionFromServerUser(body.user, '');
      request.assertCurrent();
      this.validatedSession = session;
      setSessionStatus('authenticated', body.user.id);
      setAuthToken('cookie');
      sessionStorage.setItem('vypervic_session_user', JSON.stringify(body.user));
      localStorage.setItem('vypervic_current_user_cache', JSON.stringify(body.user));
      return { data: { session } };
    } catch (error) {
      if (!request.current() || error instanceof SessionSupersededError) throw new SessionSupersededError();
      setSessionStatus('offline', this.validatedSession?.user.id || null); throw error;
    } finally { request.release(); }
  }
  private async prepareCacheFor(userId: string) {
    let previous: string | undefined;
    try { previous = JSON.parse(localStorage.getItem('vypervic_current_user_cache') || 'null')?.id; } catch { /* invalid display cache */ }
    if (localStorage.getItem('vyper_cache_purge_pending') || previous && previous !== userId) {
      await clearAllCachedDataLocally();
      for (const key of Object.keys(localStorage)) if (key.startsWith('vyper') && !['vyper_push_device_id', 'vyper_logout_pending', 'vyper_operation_pending'].includes(key)) localStorage.removeItem(key);
    }
  }
  private getCurrentSession(): any | null { return this.validatedSession; }
  onAuthStateChange(callback: AuthCallback) {
    this.authListeners.push(callback);
    return { data: { subscription: { unsubscribe: () => { this.authListeners = this.authListeners.filter(cb => cb !== callback); } } } };
  }
  async invalidateSession() { return this.clearIdentity(); }
  private async clearIdentity() {
    this.epoch.invalidate(); this.restoration = null;
    const hadIdentity = !!this.validatedSession || localStorage.getItem(HAS_SESSION_FLAG) === '1';
    this.validatedSession = null;
    setAuthToken(null);
    for (const key of ['vypervic_session_user', 'vypervic_current_user_cache', 'vypervic_user_id', 'vypervic_pending_profile', 'vyper_device_push_token']) {
      sessionStorage.removeItem(key); localStorage.removeItem(key);
    }
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith('vyper') && !['vyper_logout_pending', 'vyper_push_device_id', 'vyper_operation_pending'].includes(key)) localStorage.removeItem(key);
    }
    oracleDB.stopRealtimeSSE(); oracleDB.clearEdgeSubscriptions();
    await clearAllCachedDataLocally().catch(() => { localStorage.setItem('vyper_cache_purge_pending', '1'); console.warn('[Auth] Local cache purge pending'); });
    if (hadIdentity && capabilities().nativePush) await import('./nativeBridge').then(bridge => bridge.nativeRequest('logout')).catch(() => console.warn('[Native] Identity cleanup pending'));
    this.notify('SIGNED_OUT', null);
  }

  async signUp({ email, password, options }: { email: string; password?: string; options?: any }): Promise<{ data: { user: any; session: any }; error: any }> {
    // SECURITY (Issues 2 & 3): account creation and password hashing now
    // happen EXCLUSIVELY on the server (POST /api/auth/signup). The browser
    // no longer generates or stores password hashes, and no sign-up path can
    // grant an admin role — the old self-service admin backdoor is gone.
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { data: { user: null, session: null }, error: new Error('Please enter a valid email address.') };
    }

    const inputPassword = password || '';
    if (!inputPassword || inputPassword.length < 6) {
      return { data: { user: null, session: null }, error: new Error('Password must be at least 6 characters.') };
    }

    const meta = options?.data || {};

    this.epoch.invalidate(); this.restoration = null;
    const request = this.epoch.capture();
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST', signal: request.signal,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: cleanEmail,
          password: inputPassword,
          username: meta.username || cleanEmail.split('@')[0],
          display_name: meta.display_name || meta.username || cleanEmail.split('@')[0],
          phone_number: meta.phone_number ? String(meta.phone_number) : null,
        }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || !body?.user?.id) {
        return { data: { user: null, session: null }, error: new Error(body?.error || 'Could not create account. Please try again.') };
      }

      request.assertCurrent();
      request.assertCurrent();
      await this.prepareCacheFor(body.user.id);
      request.assertCurrent();
      setAuthToken('cookie');
      setSessionStatus('authenticated', body.user.id);
      const safeProfile = { ...(body.user || {}), is_online: true };

      sessionStorage.setItem('vypervic_session_user', JSON.stringify(safeProfile));
      localStorage.setItem('vypervic_current_user_cache', JSON.stringify(safeProfile));
      localStorage.setItem('vypervic_user_id', safeProfile.id);

      const session = buildSessionFromServerUser(safeProfile, '');
      this.notify('SIGNED_IN', session);
      localStorage.removeItem('vyper_logout_pending');
      if (capabilities().nativePush) void import('./nativeBridge').then(m => { request.assertCurrent(); return m.nativeRequest<{ deviceId?: string }>('flushCookies'); }).then(result => { if (result.deviceId) localStorage.setItem('vyper_push_device_id', result.deviceId); }).catch(() => console.warn('[Native] Cookie flush pending'));

      return { data: { user: session.user, session }, error: null };
    } catch (err: any) {
      if (!request.current()) return { data: { user: null, session: null }, error: new SessionSupersededError() };
      return {
        data: { user: null, session: null },
        error: new Error('Unable to connect to the server. Please check your internet connection or try again in a moment.'),
      };
    } finally { request.release(); }
  }

  async signInWithPassword({ email, password }: { email: string; password?: string }): Promise<{ data: { session: any; user: any }; error: any }> {
    // SECURITY (Issue 2): the "is this password correct" decision is owned by
    // the server (POST /api/auth/login). The client no longer downloads
    // profiles or compares PBKDF2 hashes in JavaScript, so a session can no
    // longer be forged by writing a fake profile object into localStorage —
    // every authenticated request is checked against the server-issued JWT.
    const cleanInput = (email || '').trim();
    if (!cleanInput) {
      return { data: { session: null, user: null }, error: new Error('Please enter your email, username, or phone number.') };
    }

    const inputPassword = password || '';
    if (!inputPassword) {
      return { data: { session: null, user: null }, error: new Error('Please enter your password.') };
    }

    this.epoch.invalidate(); this.restoration = null;
    const request = this.epoch.capture();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', signal: request.signal,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanInput, password: inputPassword }),
      });
      const body = await res.json().catch(() => ({}));

      if (res.status === 401) {
        return {
          data: { session: null, user: null },
          error: new Error('Invalid login credentials. User account does not exist. Please check your details or create a new account.'),
        };
      }

      if (!res.ok || !body?.user?.id) {
        return { data: { session: null, user: null }, error: new Error(body?.error || 'Sign in failed. Please try again.') };
      }

      request.assertCurrent();
      request.assertCurrent();
      await this.prepareCacheFor(body.user.id);
      request.assertCurrent();
      setAuthToken('cookie');
      setSessionStatus('authenticated', body.user.id);
      const safeProfile = { ...(body.user || {}), is_online: true };

      sessionStorage.setItem('vypervic_session_user', JSON.stringify(safeProfile));
      localStorage.setItem('vypervic_current_user_cache', JSON.stringify(safeProfile));
      localStorage.setItem('vypervic_user_id', safeProfile.id);

      const session = buildSessionFromServerUser(safeProfile, '');
      this.notify('SIGNED_IN', session);
      localStorage.removeItem('vyper_logout_pending');
      if (capabilities().nativePush) void import('./nativeBridge').then(m => { request.assertCurrent(); return m.nativeRequest<{ deviceId?: string }>('flushCookies'); }).then(result => { if (result.deviceId) localStorage.setItem('vyper_push_device_id', result.deviceId); }).catch(() => console.warn('[Native] Cookie flush pending'));

      return { data: { session, user: session.user }, error: null };
    } catch (err: any) {
      if (!request.current()) return { data: { user: null, session: null }, error: new SessionSupersededError() };
      return {
        data: { session: null, user: null },
        error: new Error('Unable to connect to the server. Please check your internet connection or try again in a moment.'),
      };
    } finally { request.release(); }
  }

  async signOut(): Promise<{ error: Error | null }> {
    localStorage.setItem('vyper_logout_pending', '1');
    await this.clearIdentity();
    if (capabilities().nativePush) await import('./nativeBridge').then(m => m.nativeRequest('logout')).catch(() => console.warn('[Native] Logout cleanup pending'));
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ deviceId: localStorage.getItem('vyper_push_device_id') || undefined }) });
      if (!response.ok) throw new Error('Server session revocation pending');
      localStorage.removeItem('vyper_logout_pending');
      return { error: null };
    } catch (error) { return { error: error as Error }; }
  }

  // R-01: real password reset request. The server generates a single-use,
  // expiring numeric code and emails it. Returns an honest error when the
  // request or the email delivery fails (never a fake success).
  async resetPasswordForEmail(email: string, _options?: any): Promise<{ error: any }> {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        return { error: new Error(body?.error || 'Could not send the reset email. Please try again.') };
      }
      return { error: null };
    } catch (err: any) {
      return { error: new Error('Unable to reach the server. Please check your connection and try again.') };
    }
  }

  // R-01: real verification/confirmation resend.
  async resend(opts: { type?: string; email?: string }): Promise<{ error: any }> {
    try {
      const res = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email: opts?.email, type: opts?.type }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        return { error: new Error(body?.error || 'Could not resend the verification email. Please try again.') };
      }
      return { error: null };
    } catch (err: any) {
      return { error: new Error('Unable to reach the server. Please check your connection and try again.') };
    }
  }

  // R-01: complete a password reset with the six-digit email code.
  async confirmPasswordReset(code: string, password: string): Promise<{ error: any }> {
    try {
      const res = await fetch('/api/auth/reset-password/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ code, password }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        return { error: new Error(body?.error || 'Could not reset the password. Please try again.') };
      }
      return { error: null };
    } catch (err: any) {
      return { error: new Error('Unable to reach the server. Please check your connection and try again.') };
    }
  }
}

// -------------------------------------------------------------
// MAIN ORACLE AUTONOMOUS DATABASE CLIENT INSTANCE
// -------------------------------------------------------------

class OracleDatabaseClient {
  auth = new OracleAuthManager();
  private channels: Map<string, OracleRealtimeChannel> = new Map();
  private pollingTimer: any = null;
  private tableBroadcastChannel: BroadcastChannel | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.tableBroadcastChannel = new BroadcastChannel('oracle_table_sync_channel');
        this.tableBroadcastChannel.onmessage = (ev) => {
          if (ev.data && ev.data.table && ev.data.eventType) {
            const { table, eventType, record } = ev.data;
            const payload = {
              eventType,
              new: eventType !== 'DELETE' ? record : {},
              old: eventType === 'DELETE' ? record : {},
              table,
            };
            for (const ch of this.channels.values()) {
              ch.emit(eventType, payload);
            }
          }
        };
      } catch (e) {}
    }
  }

  // Realtime delivery is provided by the single authenticated SSE stream.
  initVpsRealtimeSync() {}
  subscribeEdgeChat(_chatId: string) {}
  unsubscribeEdgeChat(_chatId: string) {}
  clearEdgeSubscriptions() {}

  from<T = any>(table: string): OracleTableQuery<T> {
    return new OracleTableQuery<T>(table);
  }

  channel(name: string): OracleRealtimeChannel {
    if (!this.channels.has(name)) {
      this.channels.set(name, new OracleRealtimeChannel(name));
    }
    return this.channels.get(name)!;
  }

  removeChannel(channel: OracleRealtimeChannel) {
    channel.unsubscribe();
    this.channels.delete(channel.name);
  }

  async updateRemoteCallStatus(callId: string, status: string): Promise<void> {
    await this.from('calls').update({ status, updated_at: new Date().toISOString() }).eq('id', callId);
  }

  rpc(method: string, params?: any) {
    return Promise.resolve({ data: null, error: new ClientApiError('Unsupported RPC; use a typed API', 400) });
  }

  broadcast(table: string, eventType: 'INSERT' | 'UPDATE' | 'DELETE', record: any) {
    const payload = {
      eventType,
      new: eventType !== 'DELETE' ? record : {},
      old: eventType === 'DELETE' ? record : {},
      table,
    };

    // 1. Emit locally on this client instance
    for (const ch of this.channels.values()) {
      ch.emit(eventType, payload);
    }

    // 2. Broadcast across all tabs / windows on the device
    if (this.tableBroadcastChannel) {
      try {
        this.tableBroadcastChannel.postMessage({ table, eventType, record });
      } catch (e) {}
    }
  }

  broadcastEvent(channelName: string, event: string, payload: any, senderChannel?: OracleRealtimeChannel) {
    for (const ch of this.channels.values()) {
      if (ch.name === channelName && ch !== senderChannel) {
        ch.emitBroadcast(event, payload);
      }
    }
  }

  private sseEventSource: EventSource | null = null;
  private sseClientId: string | null = null;
  private sseReconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private sseHeartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private sseGeneration = 0;
  getSSEClientId(): string | null { return this.sseClientId; }
  stopRealtimeSSE() {
    this.sseGeneration++;
    this.sseEventSource?.close(); this.sseEventSource = null; this.sseClientId = null;
    if (this.sseReconnectTimer) clearTimeout(this.sseReconnectTimer);
    if (this.sseHeartbeatTimer) clearInterval(this.sseHeartbeatTimer);
    this.sseReconnectTimer = null; this.sseHeartbeatTimer = null;
  }
  initRealtimeSSE(_userId?: string) {
    this.stopRealtimeSSE();
    if (typeof window === 'undefined' || !('EventSource' in window) || !capabilities().sameOriginApi) return;
    const generation = this.sseGeneration;
    let attempts = 0;
    const connect = () => {
      if (generation !== this.sseGeneration || getSessionStatus().status !== 'authenticated') return;
      const es = new EventSource('/api/realtime/stream'); // HttpOnly same-origin cookie; NEVER URL credentials
      this.sseEventSource = es;
      let heartbeatAt = Date.now();
      const reconnect = () => {
        es.close(); this.sseEventSource = null; this.sseClientId = null;
        if (this.sseHeartbeatTimer) clearInterval(this.sseHeartbeatTimer);
        if (generation !== this.sseGeneration || this.sseReconnectTimer) return;
        const delay = Math.min(30000, 1000 * 2 ** Math.min(attempts++, 5)) * (0.8 + Math.random() * 0.4);
        this.sseReconnectTimer = setTimeout(async () => {
          this.sseReconnectTimer = null;
          try { await this.auth.getSession(); connect(); } catch { reconnect(); }
        }, delay);
      };
      es.addEventListener('connected', (event: MessageEvent) => {
        const data = JSON.parse(event.data); this.sseClientId = data.clientId; attempts = 0; heartbeatAt = Date.now();
        // Event IDs are hints, not a replay guarantee: always reload Oracle on every connection.
        window.dispatchEvent(new Event('vyper_realtime_reconcile'));
      });
      es.addEventListener('reconcile', () => window.dispatchEvent(new Event('vyper_realtime_reconcile')));
      es.addEventListener('heartbeat', () => { heartbeatAt = Date.now(); });
      for (const event of ['new_message','call_invite','webrtc_signal','webrtc_signaling','call_status_update','edit_message','delete_message','typing','reaction','read_receipt','pin_change','vyper_user_presence','vyper_group_created','vyper_group_updated','vyper_group_removed','vyper_call_live_reaction','vyper_group_call_heartbeat','vyper_group_call_leave']) {
        es.addEventListener(event, (message: MessageEvent) => {
          heartbeatAt = Date.now();
          try {
            const envelope = JSON.parse(message.data);
            this.broadcastEvent('chat_updates_global', event, envelope);
            if (event === 'webrtc_signal') {
              const signal = envelope.signalData ?? envelope;
              window.dispatchEvent(new CustomEvent('vypervic_webrtc_signal', {
                detail: { ...signal, callId: envelope.callId ?? signal.callId },
              }));
            }
          }
          catch { console.warn('[Realtime] Invalid event'); }
        });
      }
      es.onerror = reconnect;
      this.sseHeartbeatTimer = setInterval(() => { if (Date.now() - heartbeatAt > 45000) reconnect(); }, 15000);
    };
    connect();
  }

  private lastSyncedMsgIds = new Set<string>();
  private lastSyncedCallIds = new Set<string>();

  async deleteUserAccount(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { submitOperation } = await import('./utils/operations');
      const result = await submitOperation('/api/account/delete', { targetUserId: userId, confirmation: 'DELETE ACCOUNT' });
      if (!result.success) return { success: false, error: `Operation ${result.operationId}: ${result.status}. Use the status panel; no completion is assumed.` };
      if (getSessionStatus().userId === userId) await this.auth.invalidateSession();
      else await deleteCachedProfileLocally(userId);
      return { success: true };
    } catch (error) { return { success: false, error: error instanceof Error ? error.message : 'Deletion was not confirmed' }; }
  }

  async wipeAllSystemData(): Promise<{ success: boolean; error?: string; failedCount?: number }> {
    try {
      const { submitOperation } = await import('./utils/operations');
      const result = await submitOperation('/api/admin/wipe-all', { confirmation: 'WIPE ALL DATA' });
      if (result.success) await this.auth.invalidateSession();
      return { success: result.success, failedCount: result.failedCount, error: result.success ? undefined : `Operation ${result.operationId}: ${result.status}. Review the status panel.` };
    } catch (error) { return { success: false, error: error instanceof Error ? error.message : 'Wipe not confirmed' }; }
  }
}

export const oracleDB = new OracleDatabaseClient();
