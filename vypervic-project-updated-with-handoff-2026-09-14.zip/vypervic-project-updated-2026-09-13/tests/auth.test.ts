// =========================================================================
// AUTH SECURITY TESTS (G-02, G-03, G-05, G-06, H-06, R-01)
// =========================================================================
import { describe, it, expect, beforeAll, afterEach } from 'vitest';
import {
  getApp,
  seedUser,
  login,
  authHeader,
  seedRow,
  getRow,
  resetAllTables,
  credentialRowId,
  resetTokenRowId,
} from './helpers';

let app: any;

beforeAll(async () => {
  app = await getApp();
});

afterEach(() => {
  resetAllTables();
});

describe('POST /api/auth/login', () => {
  it('issues a token + HttpOnly session cookie for valid credentials', async () => {
    const u = seedUser();
    const res = await login(app, u.email, u.password);
    expect(res.status).toBe(200);
    expect(res.body.token).toBeTruthy();
    expect(res.body.user.id).toBe(u.id);
    // H-07: no credential material may ever reach the client
    expect(JSON.stringify(res.body.user)).not.toMatch(/password|auth:[a-f0-9]/i);
    expect(res.cookie).toMatch(/^vyper_session=/);
    expect(res.cookie).not.toBeUndefined();
  });

  it('rejects wrong passwords with a generic 401 (G-06)', async () => {
    const u = seedUser();
    const res = await login(app, u.email, 'wrong-password');
    expect(res.status).toBe(401);
    expect(res.body.error).toBe('Invalid credentials');
  });

  it('fails closed on malformed stored hashes (G-06)', async () => {
    const u = seedUser();
    const row = getRow('profiles', u.id)!;
    row.PASSWORD_HASH = 'not-a-hex-hash!!!';
    seedRow('profiles', row);
    const res = await login(app, u.email, u.password);
    expect(res.status).toBe(401);
  });

  it('logs in by username and does not reveal unknown accounts', async () => {
    const u = seedUser();
    const ok = await login(app, u.username, u.password);
    expect(ok.status).toBe(200);
    const unknown = await login(app, 'ghost_user_42', 'whatever-password');
    expect(unknown.status).toBe(401);
    expect(unknown.body.error).toBe('Invalid credentials');
  });

  it('locks out after repeated failures (G-02)', async () => {
    const u = seedUser();
    let lastStatus = 200;
    for (let i = 0; i < 12; i++) {
      const res: any = await new Promise((resolve) => {
        app
          .post('/api/auth/login')
          .set('X-Forwarded-For', '10.9.9.9') // fixed IP so the limiter counts up
          .send({ identifier: u.email, password: 'bad-pass-' + i })
          .end((err: any, r: any) => resolve(r));
      });
      lastStatus = res.status;
    }
    expect(lastStatus).toBe(429);
    // Even the CORRECT password is now locked out for that identifier
    const res: any = await new Promise((resolve) => {
      app
        .post('/api/auth/login')
        .set('X-Forwarded-For', '10.9.9.9')
        .send({ identifier: u.email, password: u.password })
        .end((err: any, r: any) => resolve(r));
    });
    expect(res.status).toBe(429);
  });
});

describe('POST /api/auth/signup', () => {
  it('creates an account with verifiers in the server-only credentials table (H-06)', async () => {
    const res: any = await new Promise((resolve) => {
      app
        .post('/api/auth/signup')
        .set('X-Forwarded-For', '10.1.1.1')
        .send({
          email: 'newuser@example.com',
          username: 'newuser',
          password: 'super-secret-7',
          display_name: 'New User',
        })
        .end((err: any, r: any) => resolve(r));
    });
    expect(res.status).toBe(200);
    expect(res.body.user.id).toBeTruthy();
    expect(JSON.stringify(res.body.user)).not.toMatch(/password/i);

    const credId = credentialRowId(res.body.user.id);
    const cred = getRow('user_credentials', credId);
    expect(cred).toBeTruthy();
    expect(cred!.PASSWORD_HASH).toMatch(/^[a-f0-9]{64}$/);
    // H-06: ABOUT must NOT carry the legacy [auth:...] tag
    const prof = getRow('profiles', res.body.user.id)!;
    expect(String(prof.ABOUT)).not.toMatch(/\[auth:/);
  });

  it('rejects duplicate email with 409 via targeted lookup (G-05)', async () => {
    const u = seedUser();
    const res: any = await new Promise((resolve) => {
      app
        .post('/api/auth/signup')
        .set('X-Forwarded-For', '10.1.1.2')
        .send({ email: u.email, username: 'someothername', password: 'whatever-1' })
        .end((err: any, r: any) => resolve(r));
    });
    expect(res.status).toBe(409);
  });

  it('rejects duplicate username with 409 via targeted lookup (G-05)', async () => {
    const u = seedUser();
    const res: any = await new Promise((resolve) => {
      app
        .post('/api/auth/signup')
        .set('X-Forwarded-For', '10.1.1.3')
        .send({ email: `other-${Math.random().toString(36).slice(2, 8)}@example.com`, username: u.username, password: 'whatever-1' })
        .end((err: any, r: any) => resolve(r));
    });
    expect(res.status).toBe(409);
  });

  it('converts a concurrent-insert unique violation into 409 (G-03)', async () => {
    // Simulate the race: the app-level pre-check passes (no dup yet) but the
    // insert hits the DB unique constraint (another request won the race).
    const u = seedUser();
    const res: any = await new Promise((resolve) => {
      app
        .post('/api/auth/signup')
        .set('X-Forwarded-For', '10.1.1.4')
        .send({ email: u.email.toUpperCase(), username: `race${Math.random().toString(36).slice(2, 8)}`, password: 'whatever-1' })
        .end((err: any, r: any) => resolve(r));
    });
    // The targeted pre-check already catches the email dup (normalized).
    expect(res.status).toBe(409);
  });
});

describe('GET /api/auth/me', () => {
  it('requires a valid session', async () => {
    const noAuth: any = await new Promise((resolve) => app.get('/api/auth/me').end((err: any, r: any) => resolve(r)));
    expect(noAuth.status).toBe(401);

    const u = seedUser();
    const { token } = await login(app, u.email, u.password);
    const ok: any = await new Promise((resolve) =>
      app.get('/api/auth/me').set(authHeader(token!)).end((err: any, r: any) => resolve(r))
    );
    expect(ok.status).toBe(200);
    expect(ok.body.user.id).toBe(u.id);
    expect(JSON.stringify(ok.body)).not.toMatch(/password/i);
  });
});

describe('password reset flow (R-01)', () => {
  it('request -> single-use confirm -> rejects reuse; honest when delivery fails', async () => {
    const u = seedUser();

    // No mail provider configured -> the endpoint must return an HONEST 503
    // (never a fake success) — and must not reveal account existence for
    // unknown addresses either.
    const unknown = await app.post('/api/auth/reset-password').send({ email: 'nobody@example.com' });
    const fail = await app.post('/api/auth/reset-password').send({ email: u.email });
    expect(unknown.status).toBe(503);
    expect(fail.status).toBe(503);
    // Explicit server test setup; recovery credentials are NEVER harvested from logs.
    const { generatePasswordResetToken, storePasswordResetToken } = await import('../src/server/oracleBackend');
    const token = generatePasswordResetToken();
    await storePasswordResetToken(u.id, token);
    const resetRow = getRow('password_resets', resetTokenRowId(token));
    expect(resetRow!.USED_AT).toBe(null);

    const confirm: any = await new Promise((resolve) =>
      app
        .post('/api/auth/reset-password/confirm')
        .set('X-Forwarded-For', '10.2.2.2')
        .send({ token, password: 'brand-new-pass-9' })
        .end((e: any, r: any) => resolve(r))
    );
    expect(confirm.status).toBe(200);

    // Single-use: replay must fail
    const replay: any = await new Promise((resolve) =>
      app
        .post('/api/auth/reset-password/confirm')
        .set('X-Forwarded-For', '10.2.2.2')
        .send({ token, password: 'another-pass-99' })
        .end((e: any, r: any) => resolve(r))
    );
    expect(replay.status).toBe(400);

    // The new password works; the old one does not.
    const relogin = await login(app, u.email, 'brand-new-pass-9');
    expect(relogin.status).toBe(200);
    const oldPw = await login(app, u.email, u.password);
    expect(oldPw.status).toBe(401);

    // Invalid token -> 400
    const bad: any = await new Promise((resolve) =>
      app
        .post('/api/auth/reset-password/confirm')
        .set('X-Forwarded-For', '10.2.2.3')
        .send({ token: 'deadbeef'.repeat(8), password: 'whatever-1' })
        .end((e: any, r: any) => resolve(r))
    );
    expect(bad.status).toBe(400);
  });
});
