package com.vyper.chat

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

class VyperApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val messages = NotificationChannel("vyper_messages", "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Chat messages and mentions"; enableVibration(true); setShowBadge(true)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            }
            val calls = NotificationChannel("vyper_calls", "Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Incoming calls"; enableVibration(true); setShowBadge(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build())
            }
            manager.createNotificationChannels(listOf(messages, calls))
        }
    }
}
