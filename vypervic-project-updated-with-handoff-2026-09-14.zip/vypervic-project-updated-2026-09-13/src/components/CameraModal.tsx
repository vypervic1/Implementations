import { useResources } from '../utils/resources';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Camera,
  X,
  RotateCw,
  Send,
  Trash2,
  Play,
  Pause,
  Square,
  Check,
  Video,
  AlertCircle,
  Sparkles
} from 'lucide-react';

export type CameraMode = 'photo' | 'video_note';

interface CameraModalProps {
  initialMode: CameraMode;
  onClose: () => void;
  onSendPhoto: (base64Data: string, caption?: string) => void;
  onSendVideoNote: (base64Data: string, caption?: string) => void;
}

export function CameraModal({
  initialMode,
  onClose,
  onSendPhoto,
  onSendVideoNote,
}: CameraModalProps) {
  const resources = useResources();
  const [mode, setMode] = useState<CameraMode>(initialMode);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>(
    initialMode === 'video_note' ? 'user' : 'environment'
  );

  // Camera stream & devices state
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSwitchingCamera, setIsSwitchingCamera] = useState(false);
  const [caption, setCaption] = useState('');

  // Photo snap states
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);

  // Video note states
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [capturedVideoUrl, setCapturedVideoUrl] = useState<string | null>(null);
  const [capturedVideoBase64, setCapturedVideoBase64] = useState<string | null>(null);

  // DOM Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const previewVideoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const captureGeneration = useRef(0);
  const mounted = useRef(false);
  const timeouts = useRef<ReturnType<typeof setTimeout>[]>([]);
  const readerRef = useRef<FileReader | null>(null);
  const videoUrlRef = useRef<string | null>(null);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false; captureGeneration.current++;
      timeouts.current.forEach(clearTimeout);
      readerRef.current?.abort();
      const recorder = mediaRecorderRef.current;
      if (recorder) { recorder.ondataavailable = null; recorder.onstop = null; if (recorder.state !== 'inactive') recorder.stop(); }
      streamRef.current?.getTracks().forEach(track => track.stop());
      if (videoUrlRef.current) resources.revoke(videoUrlRef.current);
    };
  }, []);
  // 1. Initialize and switch camera stream
  const startCamera = useCallback(async (facing: 'user' | 'environment', audioRequired: boolean) => {
    const generation = ++captureGeneration.current;
    try {
      setErrorMessage(null);
      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('MediaDevices API not supported on this device/browser context.');
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: facing,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: audioRequired,
      };

      let stream: MediaStream;
      try {
        stream = await resources.getUserMedia(constraints);
      } catch (err: any) {
        console.warn('Primary camera constraints failed, attempting fallback...', err);
        try {
          stream = await resources.getUserMedia({
            video: true,
            audio: audioRequired,
          });
        } catch (subErr: any) {
          // If audio was required for video note but mic was denied, try video only as fallback
          if (audioRequired) {
            console.warn('Audio+Video failed, trying video only fallback...', subErr);
            stream = await resources.getUserMedia({
              video: true,
              audio: false,
            });
          } else {
            throw subErr;
          }
        }
      }

      if (!mounted.current || generation !== captureGeneration.current) { stream.getTracks().forEach(track => track.stop()); return; }
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
        await videoRef.current.play().catch(() => {});
      }
      setHasPermission(true);
    } catch (err: any) {
      if (!mounted.current || generation !== captureGeneration.current) return;
      console.warn('Camera access unavailable');
      setHasPermission(false);
      const isPermission =
        err?.name === 'NotAllowedError' ||
        err?.name === 'PermissionDeniedError' ||
        err?.name === 'SecurityError' ||
        err?.message?.toLowerCase().includes('permission');

      if (isPermission) {
        setErrorMessage('Camera / microphone permission was denied. You can allow access in your browser settings (tap the lock icon in the URL bar), or select a file directly below.');
      } else if (err?.name === 'NotFoundError' || err?.name === 'DevicesNotFoundError') {
        setErrorMessage('No camera or microphone hardware found on this device. You can select a file from your device below.');
      } else {
        setErrorMessage('Unable to start camera stream. You can choose a photo or video from your device files.');
      }
    }
  }, []);

  // Effect to boot camera whenever mode or facingMode changes (if not viewing a captured asset)
  useEffect(() => {
    if (!capturedPhoto && !capturedVideoUrl) {
      startCamera(facingMode, mode === 'video_note');
    }

    return () => {
      captureGeneration.current++;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [facingMode, mode, capturedPhoto, capturedVideoUrl, startCamera]);

  // Handle switching front/back camera
  const handleSwitchCamera = async () => {
    setIsSwitchingCamera(true);
    const newFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newFacing);
    timeouts.current.push(resources.timeout(() => { if (mounted.current) setIsSwitchingCamera(false); }, 500));
  };

  // 2. Photo Snapping Logic
  const handleSnapPhoto = () => {
    if (!videoRef.current) return;
    setIsFlashing(true);
    timeouts.current.push(resources.timeout(() => { if (mounted.current) setIsFlashing(false); }, 150));

    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // If front camera, mirror image for natural selfie appearance
    if (facingMode === 'user') {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedPhoto(dataUrl);

    // Stop camera stream tracks to conserve power
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  const handleRetakePhoto = () => {
    setCapturedPhoto(null);
    setCaption('');
    // The capture-state effect restarts the camera exactly once.
  };

  const handleConfirmSendPhoto = () => {
    if (!capturedPhoto) return;
    onSendPhoto(capturedPhoto, caption.trim() || undefined);
    onClose();
  };

  // 3. Video Note Recording Logic (Max 59 seconds)
  const startVideoRecording = () => {
    if (!streamRef.current) return;
    recordedChunksRef.current = [];
    setRecordingSeconds(0);
    setIsPaused(false);

    try {
      let mimeType = 'video/webm;codecs=vp8,opus';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        if (MediaRecorder.isTypeSupported('video/mp4')) {
          mimeType = 'video/mp4';
        } else if (MediaRecorder.isTypeSupported('video/webm')) {
          mimeType = 'video/webm';
        } else {
          mimeType = '';
        }
      }

      const options = mimeType ? { mimeType } : undefined;
      const mediaRecorder = resources.recorder(new MediaRecorder(streamRef.current, options));
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        if (!mounted.current) return;
        const blobType = mimeType || 'video/webm';
        const blob = new Blob(recordedChunksRef.current, { type: blobType });
        if (videoUrlRef.current) resources.revoke(videoUrlRef.current);
        const videoUrl = resources.blob(blob);
        videoUrlRef.current = videoUrl;
        setCapturedVideoUrl(videoUrl);

        // Convert to base64 for persistent chat dispatch
        const reader = resources.reader();
        readerRef.current = reader;
        reader.onloadend = () => {
          if (!mounted.current) return;
          setCapturedVideoBase64(reader.result as string);
        };
        reader.readAsDataURL(blob);

        if (streamRef.current) {
          streamRef.current.getTracks().forEach((t) => t.stop());
          streamRef.current = null;
        }
      };

      mediaRecorder.start(250); // Slice data every 250ms
      setIsRecording(true);

      // Start 59-second ticker
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= 58) {
            // Auto stop at 59 seconds!
            stopVideoRecording();
            return 59;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (e) {
      console.error('Failed to start MediaRecorder:', e);
      setErrorMessage('Could not record video note on this browser.');
    }
  };

  const pauseVideoRecording = () => {
    if (mediaRecorderRef.current && isRecording && !isPaused) {
      if (mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.pause();
      }
      setIsPaused(true);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const resumeVideoRecording = () => {
    if (mediaRecorderRef.current && isRecording && isPaused) {
      if (mediaRecorderRef.current.state === 'paused') {
        mediaRecorderRef.current.resume();
      }
      setIsPaused(false);

      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= 58) {
            stopVideoRecording();
            return 59;
          }
          return prev + 1;
        });
      }, 1000);
    }
  };

  const stopVideoRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    setIsPaused(false);
  };

  const handleRetakeVideo = () => {
    if (capturedVideoUrl) {
      resources.revoke(capturedVideoUrl);
    }
    setCapturedVideoUrl(null);
    setCapturedVideoBase64(null);
    setRecordingSeconds(0);
    setIsRecording(false);
    setIsPaused(false);
    startCamera(facingMode, true);
  };

  const handleConfirmSendVideo = () => {
    if (!capturedVideoBase64 && !capturedVideoUrl) return;
    onSendVideoNote(capturedVideoBase64 || capturedVideoUrl!, caption.trim() || undefined);
    onClose();
  };

  // Video note circular progress math (59 max seconds)
  const progressPercent = Math.min(100, (recordingSeconds / 59) * 100);
  const strokeDashoffset = 283 - (283 * progressPercent) / 100;

  return (
    <div className="fixed inset-0 z-[99999] bg-[#05070a] text-white flex flex-col justify-between overflow-hidden select-none animate-fade-in">
      {/* Hidden canvas for photo capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Screen Shutter Flash FX */}
      {isFlashing && (
        <div className="absolute inset-0 bg-white z-[100000] pointer-events-none transition-opacity duration-150 opacity-100" />
      )}

      {/* TOP BAR: Navigation, Mode Switcher & Close */}
      <div className="relative z-40 w-full px-4 pt-[calc(var(--safe-top)+12px)] pb-3 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-black/60 border border-white/15 flex items-center justify-center text-white hover:text-[#ff5470] hover:bg-black/90 active:scale-95 transition-all shadow-xl backdrop-blur-md cursor-pointer"
          title="Close Camera"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Mode Toggle Pills (Photo vs Video Note) */}
        {!capturedPhoto && !capturedVideoUrl && !isRecording && (
          <div className="flex items-center bg-black/65 border border-white/15 rounded-full p-1 shadow-lg backdrop-blur-md">
            <button
              type="button"
              onClick={() => {
                setMode('photo');
                setFacingMode('environment');
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                mode === 'photo'
                  ? 'bg-gradient-to-r from-[#7c5cff] to-[#4a2fd1] text-white shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Snap</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('video_note');
                setFacingMode('user');
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                mode === 'video_note'
                  ? 'bg-gradient-to-r from-[#20e3a2] to-[#0ea5e9] text-black shadow-md'
                  : 'text-[#8d97ab] hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Video Note</span>
            </button>
          </div>
        )}

        {/* Live Video Recording Timer Badge */}
        {isRecording && (
          <div className="flex items-center gap-2 bg-black/75 border border-red-500/40 rounded-full px-3.5 py-1.5 shadow-lg backdrop-blur-md">
            <span className={`w-2.5 h-2.5 rounded-full ${isPaused ? 'bg-amber-400' : 'bg-red-500 animate-pulse'}`} />
            <span className="text-xs font-mono font-bold text-white tracking-wider">
              {String(Math.floor(recordingSeconds / 60)).padStart(2, '0')}:
              {String(recordingSeconds % 60).padStart(2, '0')} / 00:59
            </span>
            {isPaused && (
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 ml-1">
                PAUSED
              </span>
            )}
          </div>
        )}

        {/* Camera Flip / Switch Button */}
        {!capturedPhoto && !capturedVideoUrl && (
          <button
            type="button"
            onClick={handleSwitchCamera}
            className={`w-10 h-10 rounded-full bg-black/60 border border-white/15 flex items-center justify-center text-white hover:text-[#20e3a2] hover:bg-black/90 active:scale-95 transition-all shadow-xl backdrop-blur-md cursor-pointer ${
              isSwitchingCamera ? 'rotate-180 duration-500' : ''
            }`}
            title="Switch Camera (Front/Back)"
          >
            <RotateCw className="w-5 h-5" />
          </button>
        )}

        {(capturedPhoto || capturedVideoUrl) && <div className="w-10" />}
      </div>

      {/* MAIN VIEWPORT / VIEWFINDER */}
      <div className="relative flex-1 w-full flex items-center justify-center overflow-hidden">
        {/* Error / Permission Denied State */}
        {hasPermission === false && (
          <div className="max-w-xs mx-auto p-6 bg-[#161d28] border border-[#212a38] rounded-3xl text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-sm text-white mb-1">Camera / Mic Access</h4>
            <p className="text-xs text-[#8d97ab] mb-4 leading-relaxed">
              {errorMessage || 'Please enable camera and microphone permissions in your browser.'}
            </p>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={() => startCamera(facingMode, mode === 'video_note')}
                className="w-full py-2.5 rounded-xl bg-[#20e3a2] text-black font-bold text-xs cursor-pointer hover:opacity-90 active:scale-95 transition-all shadow-md"
              >
                Try Again
              </button>
              <label className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-bold text-xs cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-1.5">
                <span>Select {mode === 'photo' ? 'Photo' : 'Video'} File</span>
                <input
                  type="file"
                  accept={mode === 'photo' ? 'image/*' : 'video/*'}
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = resources.reader();
                    reader.onloadend = () => {
                      const base64 = reader.result as string;
                      if (mode === 'photo') {
                        setCapturedPhoto(base64);
                        setHasPermission(true);
                      } else {
                        setCapturedVideoBase64(base64);
                        setCapturedVideoUrl(resources.blob(file));
                        setHasPermission(true);
                      }
                    };
                    reader.readAsDataURL(file);
                  }}
                />
              </label>
            </div>
          </div>
        )}

        {/* Live Video Viewfinder (When not yet captured) */}
        {!capturedPhoto && !capturedVideoUrl && hasPermission !== false && (
          <div className={`relative w-full h-full flex items-center justify-center ${
            mode === 'video_note' ? 'p-6 sm:p-10' : ''
          }`}>
            {mode === 'video_note' ? (
              /* Video Note Circular Frame (WhatsApp / Telegram style with progress ring) */
              <div className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-full overflow-hidden border-4 border-white/20 shadow-[0_0_50px_rgba(32,227,162,0.25)] flex items-center justify-center bg-black">
                {/* SVG Progress Ring */}
                <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none z-30" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke={isRecording ? (isPaused ? '#f59e0b' : '#20e3a2') : 'rgba(255,255,255,0.1)'}
                    strokeWidth="3.5"
                    strokeDasharray="283"
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    className="transition-all duration-300"
                  />
                </svg>

                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${
                    facingMode === 'user' ? 'scale-x-[-1]' : ''
                  }`}
                />

                {/* Initial Guide Overlay */}
                {!isRecording && (
                  <div className="absolute bottom-4 z-20 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10.5px] font-bold text-[#20e3a2] flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Max 59s Video Note
                  </div>
                )}
              </div>
            ) : (
              /* Photo Fullscreen Viewfinder */
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover max-h-[82vh] rounded-3xl ${
                  facingMode === 'user' ? 'scale-x-[-1]' : ''
                }`}
              />
            )}
          </div>
        )}

        {/* Captured Photo Preview */}
        {capturedPhoto && (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
            <img loading="lazy" decoding="async"
              src={capturedPhoto}
              alt="Snap Preview"
              className="max-w-full max-h-[72vh] rounded-2xl object-contain shadow-2xl border border-white/10"
            />
          </div>
        )}

        {/* Captured Video Note Preview */}
        {capturedVideoUrl && (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-full overflow-hidden border-4 border-[#20e3a2] shadow-[0_0_40px_rgba(32,227,162,0.3)] bg-black">
              <video
                ref={previewVideoRef}
                src={capturedVideoUrl}
                autoPlay
                playsInline
                loop
                controls
                className="w-full h-full object-cover"
              />
            </div>
            <p className="text-xs font-bold text-[#8d97ab] mt-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#20e3a2]" /> Video Note Ready ({recordingSeconds}s)
            </p>
          </div>
        )}
      </div>

      {/* BOTTOM CONTROLS & ACTIONS */}
      <div className="relative z-40 w-full px-5 pb-[calc(var(--safe-bottom)+18px)] pt-3 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
        {/* Caption Input Bar (When an image or video is ready to send) */}
        {(capturedPhoto || capturedVideoUrl) && (
          <div className="max-w-md mx-auto mb-4 flex items-center bg-[#161d28]/90 border border-white/20 rounded-2xl px-4 py-2 shadow-2xl backdrop-blur-md">
            <input
              type="text"
              placeholder="Add a caption (optional)..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-xs text-white placeholder-[#8d97ab] font-medium"
            />
          </div>
        )}

        {/* 1. Live Camera Mode Controls (Before Capture) */}
        {!capturedPhoto && !capturedVideoUrl && (
          <div className="flex items-center justify-around max-w-sm mx-auto">
            {/* Left Action: Switch Camera or Retake */}
            <button
              type="button"
              onClick={handleSwitchCamera}
              className="w-12 h-12 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white hover:text-[#20e3a2] hover:bg-white/20 active:scale-90 transition-all cursor-pointer shadow-lg backdrop-blur-md"
              title="Switch Camera (Front/Back)"
            >
              <RotateCw className="w-5 h-5" />
            </button>

            {/* Center Main Action: Photo Shutter OR Video Note Record */}
            {mode === 'photo' ? (
              /* Photo Shutter Button */
              <button
                type="button"
                onClick={handleSnapPhoto}
                className="w-20 h-20 rounded-full border-4 border-white p-1 flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(255,255,255,0.4)]"
                title="Take Photo"
              >
                <div className="w-full h-full rounded-full bg-white active:bg-gray-200 transition-colors" />
              </button>
            ) : (
              /* Video Note Controls (Record / Pause / Stop) */
              <div className="flex items-center gap-4">
                {!isRecording ? (
                  <button
                    type="button"
                    onClick={startVideoRecording}
                    className="w-20 h-20 rounded-full border-4 border-[#20e3a2] p-1 flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-[0_0_35px_rgba(32,227,162,0.4)]"
                    title="Start Video Note Recording"
                  >
                    <div className="w-full h-full rounded-full bg-[#ff5470] flex items-center justify-center text-white">
                      <div className="w-5 h-5 rounded-full bg-white" />
                    </div>
                  </button>
                ) : (
                  <div className="flex items-center gap-4">
                    {/* Pause / Resume Button */}
                    <button
                      type="button"
                      onClick={isPaused ? resumeVideoRecording : pauseVideoRecording}
                      className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 hover:bg-amber-500/30 flex items-center justify-center cursor-pointer active:scale-95 transition-all shadow-lg"
                      title={isPaused ? 'Resume Recording' : 'Pause Recording'}
                    >
                      {isPaused ? <Play className="w-5 h-5 fill-current" /> : <Pause className="w-5 h-5 fill-current" />}
                    </button>

                    {/* Stop & Finish Button */}
                    <button
                      type="button"
                      onClick={stopVideoRecording}
                      className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center cursor-pointer active:scale-95 transition-all shadow-[0_0_25px_rgba(239,68,68,0.5)]"
                      title="Finish & Review Video Note"
                    >
                      <Square className="w-6 h-6 fill-current" />
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Right Helper / Mode Spacer */}
            <div className="w-12 h-12 flex items-center justify-center opacity-70">
              <span className="text-[10px] font-mono uppercase text-[#8d97ab] font-bold">
                {mode === 'photo' ? 'PHOTO' : '59s MAX'}
              </span>
            </div>
          </div>
        )}

        {/* 2. Review & Send Mode Controls (After Capture) */}
        {(capturedPhoto || capturedVideoUrl) && (
          <div className="flex items-center justify-between max-w-sm mx-auto gap-4">
            {/* Retake Button */}
            <button
              type="button"
              onClick={capturedPhoto ? handleRetakePhoto : handleRetakeVideo}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-white/10 border border-white/15 text-white hover:bg-white/20 flex items-center justify-center gap-2 font-bold text-xs cursor-pointer active:scale-95 transition-all backdrop-blur-md"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
              <span>Retake</span>
            </button>

            {/* Send Button */}
            <button
              type="button"
              onClick={capturedPhoto ? handleConfirmSendPhoto : handleConfirmSendVideo}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#20e3a2] to-[#1bc78e] text-black font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_25px_rgba(32,227,162,0.4)] hover:opacity-95 active:scale-95 transition-all"
            >
              <span>Send Now</span>
              <Send className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
