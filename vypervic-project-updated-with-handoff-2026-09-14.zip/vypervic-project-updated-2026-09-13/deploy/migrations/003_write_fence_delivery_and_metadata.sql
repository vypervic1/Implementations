-- Requires 000/001/002. Run as the application schema, with EXECUTE on DBMS_LOCK.
-- This is a database transaction fence, not a timed sleep or an HTTP-client lease.
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
SET SERVEROUTPUT ON
BEGIN
  EXECUTE IMMEDIATE 'CREATE TABLE APP_WRITE_GATE (ID NUMBER PRIMARY KEY, OWNER_JOB VARCHAR2(255), EPOCH NUMBER DEFAULT 0 NOT NULL)';
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -955 THEN RAISE; END IF;
END;
/
MERGE INTO app_write_gate t USING (SELECT 1 id FROM dual) s ON (t.id=s.id)
WHEN NOT MATCHED THEN INSERT(id, owner_job, epoch) VALUES(1,NULL,0);
BEGIN
  EXECUTE IMMEDIATE 'CREATE TABLE DELIVERY_OUTBOX (
    ID VARCHAR2(255) PRIMARY KEY, KIND VARCHAR2(20) NOT NULL, ENTITY_ID VARCHAR2(255) NOT NULL,
    SENDER_ID VARCHAR2(255) NOT NULL, STATUS VARCHAR2(20) DEFAULT ''queued'' NOT NULL,
    ATTEMPTS NUMBER DEFAULT 0 NOT NULL, NEXT_ATTEMPT_AT VARCHAR2(100) NOT NULL,
    UPDATED_AT VARCHAR2(100) NOT NULL, CREATED_AT VARCHAR2(100) NOT NULL,
    RESULTS CLOB CHECK (RESULTS IS JSON), LAST_ERROR VARCHAR2(1000))';
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -955 THEN RAISE; END IF;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'CREATE INDEX IX_DELIVERY_DUE ON DELIVERY_OUTBOX(STATUS,NEXT_ATTEMPT_AT)';
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -955 THEN RAISE; END IF;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'CREATE TABLE DELETION_RECEIPTS (ID VARCHAR2(64) PRIMARY KEY, JOB_ID VARCHAR2(255) NOT NULL, TABLE_NAME VARCHAR2(100) NOT NULL, AFFECTED NUMBER NOT NULL)';
EXCEPTION WHEN OTHERS THEN IF SQLCODE != -955 THEN RAISE; END IF;
END;
/
DECLARE n NUMBER;
BEGIN SELECT COUNT(*) INTO n FROM user_constraints WHERE constraint_name='CK_DELETION_KIND';
  IF n>0 THEN EXECUTE IMMEDIATE 'ALTER TABLE deletion_jobs DROP CONSTRAINT ck_deletion_kind'; END IF;
  EXECUTE IMMEDIATE 'ALTER TABLE deletion_jobs ADD CONSTRAINT ck_deletion_kind CHECK (kind IN (''wipe'',''account'',''messages'',''calls''))';
END;
/

DECLARE n NUMBER;
BEGIN SELECT COUNT(*) INTO n FROM user_tab_columns WHERE table_name='GROUPS' AND column_name='ADMINS';
  IF n=0 THEN EXECUTE IMMEDIATE 'ALTER TABLE GROUPS ADD ADMINS CLOB'; END IF;
END;
/
CREATE OR REPLACE PACKAGE vyper_write_fence AUTHID DEFINER AS
  PROCEDURE assert_write;
  PROCEDURE normal_dml(p_body CLOB);
  PROCEDURE gate_info;
  PROCEDURE begin_job(p_id VARCHAR2);
  PROCEDURE finish_job(p_id VARCHAR2);
  PROCEDURE maintenance_dml(p_body CLOB);
  PROCEDURE admin_stats;
  PROCEDURE deletion_counts(p_id VARCHAR2);
END;
/
CREATE OR REPLACE PACKAGE BODY vyper_write_fence AS
  g_owner VARCHAR2(255);
  g_epoch NUMBER;
  g_lock CONSTANT PLS_INTEGER := DBMS_UTILITY.GET_HASH_VALUE('vyper.write.v3.' || SYS_CONTEXT('USERENV','CURRENT_SCHEMA'),0,1073741823);
  PROCEDURE take_lock(p_mode NUMBER) IS result NUMBER;
  BEGIN
    result := DBMS_LOCK.REQUEST(g_lock,p_mode,15,TRUE);
    IF result NOT IN (0,4) THEN RAISE_APPLICATION_ERROR(-20901,'Write fence busy; retry'); END IF;
  END;
  PROCEDURE assert_write IS owner VARCHAR2(255); version NUMBER;
  BEGIN
    take_lock(DBMS_LOCK.S_MODE);
    SELECT owner_job, epoch INTO owner, version FROM app_write_gate WHERE id=1;
    IF g_owner IS NULL AND (g_epoch IS NULL OR g_epoch != version) THEN RAISE_APPLICATION_ERROR(-20906,'Stale or missing write epoch'); END IF;
    IF owner IS NOT NULL AND (g_owner IS NULL OR owner != g_owner) THEN
      RAISE_APPLICATION_ERROR(-20902,'Maintenance in progress');
    END IF;
  END;
  PROCEDURE normal_dml(p_body CLOB) IS
    j JSON_OBJECT_T := JSON_OBJECT_T.parse(p_body); d JSON_OBJECT_T; keys JSON_KEY_LIST;
    tab VARCHAR2(100); verb VARCHAR2(10); rid VARCHAR2(255); col VARCHAR2(100); dtype VARCHAR2(128);
    columns_sql VARCHAR2(32767); values_sql VARCHAR2(32767); update_sql VARCHAR2(32767); statement_sql VARCHAR2(32767);
    cursor_id INTEGER; affected INTEGER; text_value VARCHAR2(32767); lob_value CLOB; number_value NUMBER;
  BEGIN
    tab := UPPER(j.get_string('table_name')); verb := j.get_string('method'); rid := j.get_string('record_id');
    IF tab NOT IN ('PROFILES','MESSAGES','CALLS','GROUPS','VAULT','USER_PUSH_TOKENS','USER_CREDENTIALS','PASSWORD_RESETS','SCHEDULED_MESSAGES','DELIVERY_OUTBOX')
      OR verb NOT IN ('POST','PATCH','PUT','DELETE') THEN RAISE_APPLICATION_ERROR(-20905,'Invalid write resource'); END IF;
    g_epoch := j.get_number('epoch'); assert_write;
    d := j.get_object('data'); keys := d.get_keys;
    IF keys.count > 40 THEN RAISE_APPLICATION_ERROR(-20905,'Too many fields'); END IF;
    IF verb != 'POST' AND rid IS NULL THEN RAISE_APPLICATION_ERROR(-20905,'Resource ID required'); END IF;
    IF verb != 'DELETE' THEN
      FOR i IN 1..keys.count LOOP
        col := DBMS_ASSERT.SIMPLE_SQL_NAME(UPPER(keys(i)));
        SELECT data_type INTO dtype FROM user_tab_columns WHERE table_name=tab AND column_name=col AND virtual_column='NO';
        IF i>1 THEN columns_sql:=columns_sql||','; values_sql:=values_sql||','; update_sql:=update_sql||','; END IF;
        columns_sql:=columns_sql||col; values_sql:=values_sql||':b'||i; update_sql:=update_sql||col||'=:b'||i;
        IF col='ID' AND verb!='POST' AND d.get_string(keys(i))!=rid THEN RAISE_APPLICATION_ERROR(-20905,'Immutable resource ID'); END IF;
      END LOOP;
    END IF;
    IF verb='POST' THEN statement_sql := 'INSERT INTO '||tab||' ('||columns_sql||') VALUES ('||values_sql||')';
    ELSIF verb='DELETE' THEN statement_sql := 'DELETE FROM '||tab||' WHERE ID=:resource_id';
    ELSE statement_sql := 'UPDATE '||tab||' SET '||update_sql||' WHERE ID=:resource_id'; END IF;
    cursor_id := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(cursor_id,statement_sql,DBMS_SQL.NATIVE);
    IF verb!='DELETE' THEN
      FOR i IN 1..keys.count LOOP
        SELECT data_type INTO dtype FROM user_tab_columns WHERE table_name=tab AND column_name=UPPER(keys(i));
        IF dtype='CLOB' THEN lob_value:=d.get_clob(keys(i)); DBMS_SQL.BIND_VARIABLE(cursor_id,':b'||i,lob_value);
        ELSIF dtype='NUMBER' THEN number_value:=d.get_number(keys(i)); DBMS_SQL.BIND_VARIABLE(cursor_id,':b'||i,number_value);
        ELSE text_value:=d.get_string(keys(i)); DBMS_SQL.BIND_VARIABLE(cursor_id,':b'||i,text_value); END IF;
      END LOOP;
    END IF;
    IF verb!='POST' THEN DBMS_SQL.BIND_VARIABLE(cursor_id,':resource_id',rid); END IF;
    affected := DBMS_SQL.EXECUTE(cursor_id); DBMS_SQL.CLOSE_CURSOR(cursor_id);
    g_epoch := NULL; COMMIT;
    IF affected=0 AND verb IN ('PUT','PATCH') THEN owa_util.status_line(404,'Not Found',FALSE); END IF;
    owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn('{"ok":true,"affected":'||affected||'}');
  EXCEPTION WHEN OTHERS THEN
    IF cursor_id IS NOT NULL AND DBMS_SQL.IS_OPEN(cursor_id) THEN DBMS_SQL.CLOSE_CURSOR(cursor_id); END IF;
    g_epoch:=NULL; ROLLBACK; RAISE;
  END;
  PROCEDURE gate_info IS output CLOB;
  BEGIN
    SELECT JSON_OBJECT('owner' VALUE owner_job, 'epoch' VALUE epoch, 'schemaVersion' VALUE 3,
      'guardCount' VALUE (SELECT COUNT(*) FROM user_triggers WHERE trigger_name LIKE 'VYPER_GUARD_%' AND status='ENABLED'),
      'outboxTriggers' VALUE (SELECT COUNT(*) FROM user_triggers WHERE trigger_name IN ('VYPER_MESSAGE_DELIVERY','VYPER_CALL_DELIVERY') AND status='ENABLED')
      RETURNING CLOB) INTO output FROM app_write_gate WHERE id=1;
    owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn(output);
  END;
  PROCEDURE begin_job(p_id VARCHAR2) IS owner VARCHAR2(255); n NUMBER;
  BEGIN
    SELECT COUNT(*) INTO n FROM deletion_jobs WHERE id=p_id;
    IF n != 1 THEN RAISE_APPLICATION_ERROR(-20903,'Unknown maintenance job'); END IF;
    -- Exclusive acquisition waits for all previously-started DML transactions, including
    -- statements still executing after Node lost a lease or its HTTP connection.
    take_lock(DBMS_LOCK.X_MODE);
    SELECT owner_job INTO owner FROM app_write_gate WHERE id=1 FOR UPDATE;
    IF owner IS NOT NULL AND owner != p_id THEN RAISE_APPLICATION_ERROR(-20904,'Another maintenance job owns the fence'); END IF;
    IF owner IS NULL THEN UPDATE app_write_gate SET owner_job=p_id, epoch=epoch+1 WHERE id=1; END IF;
    COMMIT;
    gate_info;
  END;
  PROCEDURE finish_job(p_id VARCHAR2) IS owner VARCHAR2(255);
  BEGIN
    take_lock(DBMS_LOCK.X_MODE);
    SELECT owner_job INTO owner FROM app_write_gate WHERE id=1 FOR UPDATE;
    IF owner IS NOT NULL AND owner != p_id THEN RAISE_APPLICATION_ERROR(-20904,'Foreign maintenance fence'); END IF;
    UPDATE app_write_gate SET owner_job=NULL WHERE id=1;
    COMMIT;
    gate_info;
  END;
  PROCEDURE maintenance_dml(p_body CLOB) IS
    j JSON_OBJECT_T := JSON_OBJECT_T.parse(p_body);
    d JSON_OBJECT_T; tab VARCHAR2(100); verb VARCHAR2(10); record_id VARCHAR2(255);
    members CLOB; admins CLOB; creator VARCHAR2(255); owner VARCHAR2(255); affected NUMBER; receipt VARCHAR2(64); found NUMBER;
  BEGIN
    tab := UPPER(j.get_string('table_name')); verb := j.get_string('method'); record_id := j.get_string('record_id');
    IF tab NOT IN ('PROFILES','MESSAGES','CALLS','GROUPS','VAULT','USER_PUSH_TOKENS','USER_CREDENTIALS','PASSWORD_RESETS','SCHEDULED_MESSAGES','DELIVERY_OUTBOX') OR record_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20905,'Invalid maintenance resource');
    END IF;
    g_owner := j.get_string('job_id');
    SELECT owner_job INTO owner FROM app_write_gate WHERE id=1;
    IF g_owner IS NULL OR owner IS NULL OR g_owner != owner THEN RAISE_APPLICATION_ERROR(-20904,'Maintenance ownership required'); END IF;
    assert_write;
    SELECT LOWER(RAWTOHEX(STANDARD_HASH(g_owner || ':' || tab || ':' || record_id || ':' || verb,'SHA256'))) INTO receipt FROM dual;
    SELECT COUNT(*) INTO found FROM deletion_receipts WHERE id=receipt;
    IF found=1 THEN
      SELECT r.affected INTO affected FROM deletion_receipts r WHERE id=receipt;
      g_owner := NULL; COMMIT;
      owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn('{"ok":true,"affected":' || affected || '}'); RETURN;
    END IF;
    IF verb='DELETE' THEN
      EXECUTE IMMEDIATE 'DELETE FROM ' || DBMS_ASSERT.SIMPLE_SQL_NAME(tab) || ' WHERE ID=:id' USING record_id;
      affected := SQL%ROWCOUNT;
    ELSIF verb='PATCH' AND tab='GROUPS' THEN
      d := j.get_object('data'); members := d.get_clob('MEMBERS'); admins := d.get_clob('ADMINS'); creator := d.get_string('CREATOR_ID');
      -- Dynamic binds avoid PL/SQL variable/column-name ambiguity.
      EXECUTE IMMEDIATE 'UPDATE GROUPS SET MEMBERS=:members, ADMINS=:admins, CREATOR_ID=:creator WHERE ID=:id' USING members, admins, creator, record_id;
      affected := SQL%ROWCOUNT;
    ELSE RAISE_APPLICATION_ERROR(-20905,'Only scoped deletes and membership transfer are supported');
    END IF;
    INSERT INTO deletion_receipts(id,job_id,table_name,affected) VALUES(receipt,g_owner,LOWER(tab),affected);
    g_owner := NULL;
    COMMIT;
    owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn('{"ok":true,"affected":' || affected || '}');
  EXCEPTION WHEN OTHERS THEN g_owner := NULL; ROLLBACK; RAISE;
  END;
  PROCEDURE deletion_counts(p_id VARCHAR2) IS output CLOB;
  BEGIN
    SELECT JSON_OBJECTAGG(table_name VALUE total RETURNING CLOB) INTO output FROM
      (SELECT table_name, SUM(affected) total FROM deletion_receipts WHERE job_id=p_id GROUP BY table_name);
    owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn(NVL(output,'{}'));
  END;
  PROCEDURE admin_stats IS output CLOB;
  BEGIN
    SELECT JSON_OBJECT('totalUsers' VALUE (SELECT COUNT(*) FROM profiles),
      'onlineUsers' VALUE (SELECT COUNT(*) FROM profiles WHERE is_online=1),
      'totalMessages' VALUE (SELECT COUNT(*) FROM messages), 'totalCalls' VALUE (SELECT COUNT(*) FROM calls),
      'vaultItemsCount' VALUE (SELECT COUNT(*) FROM vault),
      'pendingDeliveries' VALUE (SELECT COUNT(*) FROM delivery_outbox WHERE status IN ('queued','sending')),
      'failedDeliveries' VALUE (SELECT COUNT(*) FROM delivery_outbox WHERE status='failed') RETURNING CLOB) INTO output FROM dual;
    owa_util.mime_header('application/json',FALSE); owa_util.http_header_close; htp.prn(output);
  END;
END;
/
-- SQL*Plus reports package compile errors but does not automatically fail on them.
DECLARE n NUMBER;
BEGIN SELECT COUNT(*) INTO n FROM user_errors WHERE name='VYPER_WRITE_FENCE';
  IF n != 0 THEN RAISE_APPLICATION_ERROR(-20910,'Write-fence package did not compile; inspect USER_ERRORS'); END IF;
END;
/
DECLARE
  PROCEDURE protect(t VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE 'CREATE OR REPLACE TRIGGER VYPER_GUARD_' || t ||
      ' BEFORE INSERT OR UPDATE OR DELETE ON ' || t || ' BEGIN vyper_write_fence.assert_write; END;';
  END;
BEGIN
  protect('PROFILES'); protect('MESSAGES'); protect('CALLS'); protect('GROUPS'); protect('VAULT');
  protect('USER_PUSH_TOKENS'); protect('USER_CREDENTIALS'); protect('PASSWORD_RESETS'); protect('SCHEDULED_MESSAGES'); protect('DELIVERY_OUTBOX');
END;
/
CREATE OR REPLACE TRIGGER vyper_message_delivery AFTER INSERT ON messages FOR EACH ROW
DECLARE stamp VARCHAR2(100) := TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP),'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"');
BEGIN
  INSERT INTO delivery_outbox(id,kind,entity_id,sender_id,status,attempts,next_attempt_at,created_at,updated_at,results)
    VALUES('msg_' || LOWER(RAWTOHEX(STANDARD_HASH(:new.id,'SHA256'))),'message',:new.id,:new.sender_id,'queued',0,stamp,stamp,stamp,'{}');
END;
/
CREATE OR REPLACE TRIGGER vyper_call_delivery AFTER INSERT ON calls FOR EACH ROW
DECLARE stamp VARCHAR2(100) := TO_CHAR(SYS_EXTRACT_UTC(SYSTIMESTAMP),'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"');
BEGIN
  IF :new.status='ringing' THEN
    INSERT INTO delivery_outbox(id,kind,entity_id,sender_id,status,attempts,next_attempt_at,created_at,updated_at,results)
      VALUES('call_' || LOWER(RAWTOHEX(STANDARD_HASH(:new.id,'SHA256'))),'call',:new.id,:new.caller_id,'queued',0,stamp,stamp,stamp,'{}');
  END IF;
END;
/
-- List views never serialize inline attachments or profile images across the ORDS boundary.
CREATE OR REPLACE VIEW messages_meta AS SELECT id,chat_id,sender_id,recipient_id,text,file_name,file_type,is_voice,duration,is_edited,is_encrypted,status,created_at,
  CASE WHEN file_data IS NULL THEN 0 ELSE 1 END has_media FROM messages;
CREATE OR REPLACE VIEW profiles_meta AS SELECT id,email,username,display_name,phone_number,about,is_online,last_seen,created_at,updated_at,role,
  CASE WHEN avatar_url IS NULL THEN 0 ELSE 1 END has_avatar, CASE WHEN cover_url IS NULL THEN 0 ELSE 1 END has_cover FROM profiles;
CREATE OR REPLACE VIEW calls_meta AS SELECT id,caller_id,receiver_id,type,status,created_at,updated_at FROM calls;
CREATE OR REPLACE VIEW groups_meta AS SELECT id,name,creator_id,members,admins,description,created_at,
  CASE WHEN DBMS_LOB.GETLENGTH(icon)<=32 THEN DBMS_LOB.SUBSTR(icon,32,1) ELSE NULL END icon,
  CASE WHEN icon IS NULL THEN 0 ELSE 1 END has_icon, CASE WHEN cover_url IS NULL THEN 0 ELSE 1 END has_cover FROM groups;
CREATE OR REPLACE VIEW vault_meta AS SELECT id,user_id,file_name,file_type,created_at FROM vault;
CREATE OR REPLACE VIEW scheduled_messages_meta AS SELECT id,user_id,chat_id,recipient_id,text,file_name,file_type,is_voice,scheduled_for,status,attempts,message_id,last_error,created_at,updated_at,next_attempt_at FROM scheduled_messages;
BEGIN
  ORDS.ENABLE_OBJECT(p_enabled=>TRUE,p_schema=>USER,p_object=>'DELIVERY_OUTBOX',p_object_type=>'TABLE',p_object_alias=>'delivery_outbox',p_auto_rest_auth=>TRUE);
  FOR v IN (SELECT column_value n FROM TABLE(SYS.ODCIVARCHAR2LIST('MESSAGES_META','PROFILES_META','CALLS_META','GROUPS_META','VAULT_META','SCHEDULED_MESSAGES_META'))) LOOP
    ORDS.ENABLE_OBJECT(p_enabled=>TRUE,p_schema=>USER,p_object=>v.n,p_object_type=>'VIEW',p_object_alias=>LOWER(v.n),p_auto_rest_auth=>TRUE);
  END LOOP;
  ORDS.DEFINE_MODULE(p_module_name=>'vyper.internal',p_base_path=>'/vyper-internal/',p_items_per_page=>50);
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'write');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'write',p_method=>'POST',p_source_type=>ORDS.source_type_plsql,p_source=>'BEGIN vyper_write_fence.normal_dml(:body_text); END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'gate/');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'gate/',p_method=>'GET',p_source_type=>ORDS.source_type_plsql,p_source=>'BEGIN vyper_write_fence.gate_info; END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'gate/begin');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'gate/begin',p_method=>'POST',p_source_type=>ORDS.source_type_plsql,p_source=>'DECLARE j JSON_OBJECT_T := JSON_OBJECT_T.parse(:body_text); BEGIN vyper_write_fence.begin_job(j.get_string(''job_id'')); END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'gate/end');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'gate/end',p_method=>'POST',p_source_type=>ORDS.source_type_plsql,p_source=>'DECLARE j JSON_OBJECT_T := JSON_OBJECT_T.parse(:body_text); BEGIN vyper_write_fence.finish_job(j.get_string(''job_id'')); END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'maintenance/dml');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'maintenance/dml',p_method=>'POST',p_source_type=>ORDS.source_type_plsql,p_source=>'BEGIN vyper_write_fence.maintenance_dml(:body_text); END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'maintenance/counts/:job_id');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'maintenance/counts/:job_id',p_method=>'GET',p_source_type=>ORDS.source_type_plsql,p_source=>'BEGIN vyper_write_fence.deletion_counts(:job_id); END;');
  ORDS.DEFINE_TEMPLATE(p_module_name=>'vyper.internal',p_pattern=>'admin/stats');
  ORDS.DEFINE_HANDLER(p_module_name=>'vyper.internal',p_pattern=>'admin/stats',p_method=>'GET',p_source_type=>ORDS.source_type_plsql,p_source=>'BEGIN vyper_write_fence.admin_stats; END;');
  COMMIT;
END;
/
DECLARE roles OWA.VC_ARR; patterns OWA.VC_ARR; n NUMBER;
BEGIN
  SELECT COUNT(*) INTO n FROM user_ords_roles WHERE name='vyper_backend';
  IF n=0 THEN ORDS.CREATE_ROLE(p_role_name=>'vyper_backend'); END IF;
  roles(1):='vyper_backend'; patterns(1):='/vyper-internal/*';
  ORDS.DEFINE_PRIVILEGE(p_privilege_name=>'vyper.internal',p_roles=>roles,p_patterns=>patterns,p_label=>'Vyper backend only',p_description=>'Write fencing and private administration');
  COMMIT;
END;
/
-- Grant the existing server OAuth client the vyper_backend role and protected view/table roles.
-- Anonymous /vyper-internal/* MUST return 401. Do not start the app before verifying the grant.
