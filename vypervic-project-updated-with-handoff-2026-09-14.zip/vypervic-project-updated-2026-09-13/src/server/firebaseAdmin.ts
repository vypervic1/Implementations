import { sessionIsActive, withSessionAccount } from './sessionState';
// =========================================================================
// FIREBASE ADMIN (server-only) — credentials come from ENVIRONMENT ONLY
// ------------------------------------------------------------------------
// The service-account private key that used to be hardcoded in this file
// has been removed from source and MUST be considered compromised:
//   1. Google Cloud / Firebase -> affected project -> IAM / service accounts ->
//      Service accounts -> DELETE the old key, generate a new one.
//   2. Put the new key in the deployment environment (NOT in this repo):
//        FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
//      (see .env.example).
//
// FCM is the only Firebase capability retained. Its credentials are server-only.
// =========================================================================

import { initializeApp, getApps, cert, type App, type ServiceAccount } from 'firebase-admin/app';
import { getMessaging, type MulticastMessage } from 'firebase-admin/messaging';
import { getTokensForUsers, revokePushToken, registrationsForUsers } from './pushTokenStore';

import { browserConfig } from '../shared/firebaseConfiguration';
import { isProduction } from './config';

export function getSwFirebaseConfig() {
  return browserConfig(process.env, isProduction());
}

function readServiceAccountFromEnv(
  prefix: string
): { projectId: string; clientEmail: string; privateKey: string } | null {
  const projectId = process.env[`${prefix}_PROJECT_ID`];
  const clientEmail = process.env[`${prefix}_CLIENT_EMAIL`];
  const privateKey = process.env[`${prefix}_PRIVATE_KEY`];
  if (!projectId || !clientEmail || !privateKey) return null;
  // Env vars may carry literal "\n" sequences for the PEM body
  return {
    projectId,
    clientEmail,
    privateKey: privateKey.replace(/\\n/g, '\n'),
  };
}

function getAppOrInit(name: string, sa: { projectId: string; clientEmail: string; privateKey: string } | null): App | null {
  if (!sa) return null;
  const existing = getApps().find((a) => a.name === name);
  if (existing) return existing;
  try {
    return initializeApp({ credential: cert(sa), projectId: sa.projectId }, name);
  } catch (err: any) {
    console.error(`[FirebaseAdmin] Failed to initialize admin app "${name}":`, err?.message);
    if (isProduction()) throw new Error('Firebase Admin initialization failed');
    return null;
  }
}

// FCM push project
let pushApp: App | null = null;
let pushAppResolved = false;

export function getFirebaseAdmin(): App | null {
  if (!pushAppResolved) {
    pushApp = getAppOrInit('vyper_push', readServiceAccountFromEnv('FIREBASE'));
    pushAppResolved = true;
  }
  return pushApp;
}

// ---------------------------------------------------------------------------
// FCM token registry — DURABLE (M-03).
// The old process-local Map lost every registration on restart. Tokens are
// persisted in the USER_PUSH_TOKENS table via pushTokenStore; the in-memory
// structures there are a read-cache only.
// ---------------------------------------------------------------------------

export async function getUserFcmTokens(userId: string): Promise<string[]> {
  return getTokensForUsers([userId]);
}

export async function removeInvalidToken(token: string): Promise<void> {
  await revokePushToken(token);
  console.log('[FCM Admin] Removed expired/invalid token from durable store');
}

/**
 * Dispatch multicast FCM push notification to target user(s)
 */
export async function sendPushToUsers(params: {
  targetUserIds: string[];
  eventId?: string;
  title: string;
  body: string;
  chatId?: string;
  senderId?: string;
  senderName?: string;
  type?: 'message' | 'call' | 'mention';
  callId?: string;
  avatarUrl?: string;
}) {
  const adminInstance = getFirebaseAdmin();
  if (!adminInstance) return { success: false, error: 'Push delivery is unavailable' };
  try {
    const rows = await registrationsForUsers(params.targetUserIds);
    if (!rows.length) return { success: false, error: 'No registered devices', successCount: 0, failureCount: 0 };
    const messaging = getMessaging(adminInstance);
    const data = Object.fromEntries(Object.entries({
      title: params.title, body: params.body, type: params.type || 'message', chatId: params.chatId, eventId: params.eventId,
      callId: params.callId, senderId: params.senderId, senderName: params.senderName,
    }).filter((entry): entry is [string, string] => typeof entry[1] === 'string'));
    let successCount = 0, failureCount = 0;
    // FCM multicast/sendEach accepts at most 500; token tables can be larger than one page.
    const uniqueRows = [...new Map(rows.map(row => [row.token, row])).values()];
    for (let i = 0; i < uniqueRows.length; i += 500) {
      const batch = uniqueRows.slice(i, i + 500);
      const response = await messaging.sendEach(batch.map(row => row.device_type === 'android' ? {
        token: row.token, data,
        // Data-only Android messages are rendered exactly once by FirebaseMessagingService.
        android: { priority: 'high' as const, ttl: params.type === 'call' ? 30_000 : 3600_000 },
      } : {
        token: row.token, data,
        webpush: { headers: { Urgency: 'high', TTL: params.type === 'call' ? '30' : '3600' } },
      }));
      successCount += response.successCount; failureCount += response.failureCount;
      for (let j = 0; j < response.responses.length; j++) {
        const code = response.responses[j].error?.code;
        if (code === 'messaging/invalid-registration-token' || code === 'messaging/registration-token-not-registered') await revokePushToken(batch[j].token);
      }
    }
    const unreachableUserCount = new Set(params.targetUserIds.filter(id => !rows.some(row => row.user_id === id))).size;
    return { success: successCount > 0 && failureCount === 0 && unreachableUserCount === 0, successCount, failureCount, unreachableUserCount };
  } catch {
    console.error('[FCM Admin] Durable lookup or delivery failed');
    return { success: false, error: 'Push delivery failed' };
  }
}

export async function validateTokenWithFcm(token: string): Promise<boolean> {
  if (process.env.NODE_ENV === 'test' && process.env.ALLOW_TEST_PUSH_TOKENS === 'true') return true;
  const app = getFirebaseAdmin();
  if (!app) throw new Error('FCM token validation is unavailable');
  try { await getMessaging(app).send({ token, data: { type: 'registration_validation' } }, true); return true; }
  catch { return false; }
}

