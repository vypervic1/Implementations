import { ApiError } from './errors';

export interface StoredCall { id: string; caller_id: string; receiver_id: string; type: string; status: string; created_at: string; updated_at: string }
const memory = new Map<string, StoredCall>();
export const callStoreIsDurable = () => false;
export const memoryCallCount = () => memory.size;
function normalize(call: any): StoredCall {
  return { id: String(call.id), caller_id: String(call.caller_id), receiver_id: String(call.receiver_id), type: String(call.type), status: String(call.status || 'ringing'), created_at: String(call.created_at || new Date().toISOString()), updated_at: String(call.updated_at || call.created_at || new Date().toISOString()) };
}
export async function storeCallInvite(call: any): Promise<void> {
  const row = normalize(call);
  const existing = memory.get(row.id);
  if (existing && (existing.caller_id !== row.caller_id || existing.receiver_id !== row.receiver_id)) throw new ApiError(409, 'Conflicting call identity');
  if (!existing || existing.status === 'ringing') memory.set(row.id, existing || row);
}
export async function updateCallStatus(callId: string, status: string): Promise<void> {
  const row = memory.get(callId);
  if (!row) return;
  const transitions: Record<string, string[]> = { ringing: ['accepted', 'rejected', 'ended', 'missed'], accepted: ['ended'] };
  if (status !== row.status && !transitions[row.status]?.includes(status)) throw new ApiError(409, 'Invalid call transition');
  row.status = status; row.updated_at = new Date().toISOString();
}
export async function deleteCall(callId: string): Promise<void> { memory.delete(callId); }
export async function getCallById(callId: string): Promise<StoredCall | null> { return memory.get(callId) || null; }
export async function getActiveRingingCalls(): Promise<StoredCall[]> {
  const cutoff = Date.now() - 30_000;
  for (const [id, row] of memory) if (Date.now() - Date.parse(row.created_at) > 4 * 3600_000) memory.delete(id);
  return [...memory.values()].filter(row => row.status === 'ringing' && Date.parse(row.created_at) >= cutoff);
}
export async function syncCallProjection(call: StoredCall): Promise<void> {
  const row = normalize(call);
  const existing = memory.get(row.id);
  if (existing && (existing.caller_id !== row.caller_id || existing.receiver_id !== row.receiver_id)) throw new ApiError(409, 'Conflicting call identity');
  memory.set(row.id, row);
}
