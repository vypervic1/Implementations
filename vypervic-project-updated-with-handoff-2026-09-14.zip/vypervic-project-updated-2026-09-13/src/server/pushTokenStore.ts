import { createHash } from 'node:crypto';
import { ordsFetch, fetchAllRows, fetchRowById, deleteRowsByFilter, isUniqueViolation } from './oracleBackend';
import { ApiError, OracleError } from './errors';
import { sessionIsActive, revokeSession, type SessionIdentity } from './sessionState';
import { withLease } from './sharedStore';

export type TokenSource = 'android_native' | 'web_fcm';
export interface PushTokenRow {
  id: string; user_id: string; token: string; device_type: 'android' | 'web'; token_source: TokenSource;
  session_jti: string; session_exp: number; session_auth_time: number;
  device_id: string | null; device_name: string | null; updated_at: string; created_at: string; revoked_at: string | null;
}
export function validatePushToken(token: unknown, deviceType: unknown, source?: unknown):
  { ok: true; token: string; deviceType: 'web' | 'android'; source: TokenSource } | { ok: false; error: string } {
  if (typeof token !== 'string' || token.length < 100 || token.length > 4096 || !/^[A-Za-z0-9_:.\-]+$/.test(token) || /^(device_fcm_|fcm_|mock|test[_-])/i.test(token)) {
    return { ok: false, error: 'A real FCM registration token is required' };
  }
  const dt = deviceType === 'web_fcm' ? 'web' : deviceType === 'android_native' ? 'android' : deviceType;
  if (dt !== 'web' && dt !== 'android') return { ok: false, error: 'deviceType must be web or android' };
  const expected = dt === 'android' ? 'android_native' : 'web_fcm';
  if (source !== undefined && source !== expected) return { ok: false, error: 'Token source does not match device type' };
  return { ok: true, token, deviceType: dt, source: expected };
}
const tokenId = (token: string) => `ptok_${createHash('sha256').update(token).digest('hex').slice(0, 48)}`;
/** No authoritative process cache. Every send reads Oracle so refresh/revocation is visible on all VPS instances. */
export async function registerPushToken(userId: string, token: string, deviceType: string, metadata: { deviceId?: string; deviceName?: string; source?: string; session?: SessionIdentity } = {}): Promise<boolean> {
  const valid = validatePushToken(token, deviceType, metadata.source);
  if (!valid.ok || !metadata.session || metadata.session.sub !== userId) return false;
  return withLease(`push-user:${userId}`, () => withLease(`push-token:${tokenId(token)}`, async () => {
    const devices = await fetchAllRows('user_push_tokens', { USER_ID: userId });
    if (!devices.some(row => row.device_id === metadata.deviceId || row.id === tokenId(token)) && (await registrationsForUsers([userId])).length >= 20) throw new ApiError(409, 'Device limit reached; revoke an old device first');
    const id = tokenId(token);
    const existing = await fetchRowById('user_push_tokens', id);
    const row = { ID: id, USER_ID: userId, TOKEN: token, DEVICE_TYPE: valid.deviceType, TOKEN_SOURCE: valid.source,
      SESSION_JTI: metadata.session!.jti, SESSION_EXP: metadata.session!.exp, SESSION_AUTH_TIME: metadata.session!.authTime,
      DEVICE_ID: metadata.deviceId || null, DEVICE_NAME: metadata.deviceName || null, REVOKED_AT: null,
      CREATED_AT: existing?.created_at || new Date().toISOString(), UPDATED_AT: new Date().toISOString() };
    let saved = await ordsFetch(existing ? `/user_push_tokens/${id}` : '/user_push_tokens/', { method: existing ? 'PUT' : 'POST', body: row });
    if (isUniqueViolation(saved)) saved = await ordsFetch(`/user_push_tokens/${id}`, { method: 'PUT', body: row });
    if (!saved.ok) return false;
    // Refresh only supersedes this account's previous token for this installation.
    if (metadata.deviceId) {
      const old = await fetchAllRows('user_push_tokens', { USER_ID: userId, DEVICE_ID: metadata.deviceId });
      for (const previous of old) if (previous.id !== id && !previous.revoked_at) {
        const retired = await ordsFetch(`/user_push_tokens/${encodeURIComponent(previous.id)}`, { method: 'PATCH', body: { REVOKED_AT: new Date().toISOString() } });
        if (!retired.ok) throw new OracleError(retired.status);
      }
    }
    return true;
  }));
}
export async function registrationsForUsers(userIds: string[]): Promise<PushTokenRow[]> {
  const rows = (await Promise.all(Array.from(new Set(userIds)).map(id => fetchAllRows('user_push_tokens', { USER_ID: id })))).flat();
  const active: PushTokenRow[] = [];
  for (const row of rows) {
    if (row.revoked_at || !row.session_jti || !validatePushToken(row.token, row.device_type, row.token_source).ok) continue;
    if (await sessionIsActive({ sub: row.user_id, jti: row.session_jti, exp: Number(row.session_exp), authTime: Number(row.session_auth_time) })) active.push(row as PushTokenRow);
  }
  return active;
}
export async function getTokensForUsers(userIds: string[]): Promise<string[]> {
  return [...new Set((await registrationsForUsers(userIds)).map(row => row.token))];
}
export async function listDevices(userId: string) {
  const rows = await registrationsForUsers([userId]);
  return rows.filter(row => !row.revoked_at && validatePushToken(row.token, row.device_type, row.token_source).ok).map(row => ({
    id: row.id, user_id: userId, device_type: row.device_type, token_source: row.token_source,
    device_name: row.device_name || row.device_type, created_at: row.created_at, updated_at: row.updated_at,
    is_active: true, fcm_token: '•••• (private device token)',
  }));
}
export async function revokeTokenById(userId: string, id: string): Promise<void> {
  const row = await fetchRowById('user_push_tokens', id);
  if (!row || row.user_id !== userId) throw new ApiError(403, 'Token not found or not owned by this account');
  const result = await ordsFetch(`/user_push_tokens/${encodeURIComponent(id)}`, { method: 'PATCH', body: { REVOKED_AT: new Date().toISOString() } });
  if (!result.ok) throw new OracleError(result.status);
  if (row.session_jti) await revokeSession({ sub: row.user_id, jti: row.session_jti, exp: Number(row.session_exp), authTime: Number(row.session_auth_time) });
}
export async function revokePushToken(token: string): Promise<void> {
  const result = await deleteRowsByFilter('user_push_tokens', { TOKEN: token });
  if (result.failed) throw new OracleError(502);
}
export async function revokeAllTokensForUser(userId: string): Promise<void> {
  const result = await deleteRowsByFilter('user_push_tokens', { USER_ID: userId });
  if (result.failed) throw new OracleError(502);
}
