import { createHash } from 'node:crypto';
import { getRedis } from './sharedStore';

interface Bucket {
  count: number;
  windowStart: number;
  // credential failure tracking
  failures: number;
  lockedUntil: number;
}

export interface RateLimiterOptions {
  /** Requests allowed per window (default window 10 minutes). */
  max: number;
  /** Window size in ms. */
  windowMs?: number;
  /** Extra lockout applied after repeated failures. */
  lockoutBaseMs?: number;
  /** Failures (within windowMs) that trigger the first lockout. */
  lockoutAfterFailures?: number;
  /** Cap for the exponential lockout. */
  lockoutMaxMs?: number;
}

export interface RateLimitResult {
  allowed: boolean;
  retryAfterSec: number;
  remaining: number;
  locked: boolean;
  reason?: 'rate_limited' | 'locked_out' | 'unavailable';
}

function nowMs(): number {
  return Date.now();
}

export class RateLimiter {
  private buckets = new Map<string, Bucket>();
  private opts: Required<RateLimiterOptions>;
  private lastSweep = nowMs();

  constructor(opts: RateLimiterOptions) {
    this.opts = {
      max: opts.max,
      windowMs: opts.windowMs ?? 10 * 60_000,
      lockoutBaseMs: opts.lockoutBaseMs ?? 60_000,
      lockoutAfterFailures: opts.lockoutAfterFailures ?? 8,
      lockoutMaxMs: opts.lockoutMaxMs ?? 60 * 60_000,
    };
  }

  private sweep(): void {
    const now = nowMs();
    if (now - this.lastSweep < 60_000) return;
    this.lastSweep = now;
    for (const [key, b] of this.buckets.entries()) {
      if (now - b.windowStart > this.opts.windowMs && b.lockedUntil < now) {
        this.buckets.delete(key);
      }
    }
  }

  private bucket(key: string): Bucket {
    let b = this.buckets.get(key);
    if (!b) {
      b = { count: 0, windowStart: nowMs(), failures: 0, lockedUntil: 0 };
      this.buckets.set(key, b);
    }
    const now = nowMs();
    if (now - b.windowStart >= this.opts.windowMs) {
      b.count = 0;
      b.windowStart = now;
      b.failures = 0;
    }
    return b;
  }

  /** Consume one request slot. Returns whether the request may proceed. */
  consume(key: string): RateLimitResult {
    this.sweep();
    const b = this.bucket(key);
    const now = nowMs();

    if (b.lockedUntil > now) {
      return {
        allowed: false,
        retryAfterSec: Math.ceil((b.lockedUntil - now) / 1000),
        remaining: 0,
        locked: true,
        reason: 'locked_out',
      };
    }

    if (b.count >= this.opts.max) {
      return {
        allowed: false,
        retryAfterSec: Math.ceil((b.windowStart + this.opts.windowMs - now) / 1000),
        remaining: 0,
        locked: false,
        reason: 'rate_limited',
      };
    }

    b.count++;
    return {
      allowed: true,
      retryAfterSec: 0,
      remaining: Math.max(0, this.opts.max - b.count),
      locked: false,
    };
  }

  /** Record a failed attempt (credentials endpoints). Applies exponential lockout. */
  recordFailure(key: string): void {
    const b = this.bucket(key);
    b.failures++;
    if (b.failures >= this.opts.lockoutAfterFailures) {
      const over = b.failures - this.opts.lockoutAfterFailures;
      const lockMs = Math.min(this.opts.lockoutBaseMs * Math.pow(2, over), this.opts.lockoutMaxMs);
      b.lockedUntil = nowMs() + lockMs;
    }
  }

  /** Successful auth resets the failure/lockout state for the key. */
  recordSuccess(key: string): void {
    const b = this.buckets.get(key);
    if (b) {
      b.failures = 0;
      b.lockedUntil = 0;
    }
  }

  /** Combined check used by credential endpoints: both keys must pass. */
  consumeBoth(keyA: string, keyB: string): RateLimitResult {
    const a = this.consume(keyA);
    if (!a.allowed) return a;
    const b = this.consume(keyB);
    if (!b.allowed) {
      // refund A so a lockout on B doesn't burn A's window
      this.refund(keyA);
      return b;
    }
    return b;
  }

  refund(key: string): void {
    const b = this.buckets.get(key);
    if (b && b.count > 0) b.count--;
  }
}

// Atomic Redis script. All instances share count, expiry and exponential lockout.
// Redis TIME avoids VPS clock skew. The complete bucket expires even after lockout.
const LIMIT_SCRIPT = `
local t = redis.call('TIME')
local now = tonumber(t[1])*1000 + math.floor(tonumber(t[2])/1000)
local v = redis.call('HMGET',KEYS[1],'count','start','failures','locked')
local count,start,failures,locked = tonumber(v[1]) or 0,tonumber(v[2]) or now,tonumber(v[3]) or 0,tonumber(v[4]) or 0
local action,max,window,threshold,base,cap = ARGV[1],tonumber(ARGV[2]),tonumber(ARGV[3]),tonumber(ARGV[4]),tonumber(ARGV[5]),tonumber(ARGV[6])
if now-start >= window then count,start,failures = 0,now,0 end
local allowed,retry,islocked = 1,0,0
if action == 'consume' then
  if locked > now then allowed,retry,islocked = 0,math.ceil((locked-now)/1000),1
  elseif count >= max then allowed,retry = 0,math.ceil((start+window-now)/1000)
  else count = count+1 end
elseif action == 'failure' then
  failures = failures+1
  if failures >= threshold then locked = now + math.min(base*2^math.min(failures-threshold,30),cap) end
elseif action == 'success' then failures,locked = 0,0
elseif action == 'refund' then count = math.max(0,count-1) end
redis.call('HSET',KEYS[1],'count',count,'start',start,'failures',failures,'locked',locked)
redis.call('PEXPIRE',KEYS[1],math.max(window,locked-now)+1000)
return {allowed,retry,math.max(0,max-count),islocked}
`;
export class SharedRateLimiter {
  private local: RateLimiter;
  constructor(private name: string, private options: RateLimiterOptions) { this.local = new RateLimiter(options); }
  private async run(action: string, key: string): Promise<RateLimitResult> {
    const redis = await getRedis();
    if (!redis) {
      if (action === 'consume') return this.local.consume(key);
      if (action === 'failure') this.local.recordFailure(key);
      if (action === 'success') this.local.recordSuccess(key);
      if (action === 'refund') this.local.refund(key);
      return { allowed: true, retryAfterSec: 0, remaining: 0, locked: false };
    }
    const o = this.options;
    const result = await redis.eval(LIMIT_SCRIPT, { keys: [`vyper:limit:${this.name}:${key}`], arguments: [
      action, String(o.max), String(o.windowMs ?? 600000), String(o.lockoutAfterFailures ?? 8),
      String(o.lockoutBaseMs ?? 60000), String(o.lockoutMaxMs ?? 3600000),
    ] }) as number[];
    return { allowed: result[0] === 1, retryAfterSec: result[1], remaining: result[2], locked: result[3] === 1,
      ...(result[0] === 0 ? { reason: result[3] === 1 ? 'locked_out' as const : 'rate_limited' as const } : {}) };
  }
  async consume(key: string): Promise<RateLimitResult> {
    try { return await this.run('consume', key); }
    catch { return { allowed: false, retryAfterSec: 30, remaining: 0, locked: false, reason: 'unavailable' }; }
  }
  async consumeBoth(a: string, b: string): Promise<RateLimitResult> {
    const first = await this.consume(a);
    if (!first.allowed) return first;
    const second = await this.consume(b);
    if (!second.allowed) await this.run('refund', a).catch(() => {});
    return second;
  }
  async recordFailure(key: string): Promise<void> { await this.run('failure', key); }
  async recordSuccess(key: string): Promise<void> { await this.run('success', key); }
}
export const loginLimiter = new SharedRateLimiter('login', { max: 20, windowMs: 600000 });
export const signupLimiter = new SharedRateLimiter('signup', { max: 10, windowMs: 3600000 });
export const passwordResetLimiter = new SharedRateLimiter('reset', { max: 10, windowMs: 3600000 });
export const pushLimiter = new SharedRateLimiter('push', { max: 60, windowMs: 600000 });
export const oracleProxyLimiter = new SharedRateLimiter('oracle', { max: 600, windowMs: 60000 });
export const broadcastLimiter = new SharedRateLimiter('broadcast', { max: 300, windowMs: 60000 });
export const streamLimiter = new SharedRateLimiter('stream', { max: 30, windowMs: 60000 });

/** Express computes req.ip using the configured trusted proxies. Never trust raw XFF. */
export function clientIp(req: { ip?: string; socket?: { remoteAddress?: string } }): string {
  return req.ip || req.socket?.remoteAddress || 'unknown';
}
export function hashKey(prefix: string, value: string): string {
  return `${prefix}:${createHash('sha256').update(value).digest('hex')}`;
}
