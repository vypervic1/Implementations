import { getApps, initializeApp } from 'firebase/app';
import { defaultFirebaseConfig } from './firebaseConfig';
export const defaultApp = getApps()[0] || initializeApp(defaultFirebaseConfig);
