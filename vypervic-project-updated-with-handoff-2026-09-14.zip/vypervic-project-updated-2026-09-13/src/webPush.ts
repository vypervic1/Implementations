import { getMessaging, getToken, isSupported, onMessage } from 'firebase/messaging';
import { defaultApp } from './firebaseApp';
import { VAPID_KEY } from './firebaseConfig';
import { capabilities } from './capabilities';
export async function acquireWebFcmToken(): Promise<string | null> {
  if (!capabilities().webPush || !await isSupported() || !('Notification' in window) || !('serviceWorker' in navigator)) throw new Error('Web Push is unsupported');
  const permission = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission;
  if (permission !== 'granted') throw new Error('Notification permission was not granted');
  if (!VAPID_KEY) throw new Error('Browser push is not configured');
  const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js', { scope: '/' });
  await navigator.serviceWorker.ready;
  return getToken(getMessaging(defaultApp), { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration });
}
export async function listen(onPush: (payload: unknown) => void): Promise<(() => void) | undefined> {
  if (!capabilities().webPush || !await isSupported()) return;
  return onMessage(getMessaging(defaultApp), onPush);
}
