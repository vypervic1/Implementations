package com.vyper.chat

import android.content.Context
import android.webkit.CookieManager
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection

/** Native refresh is retried durably. Authentication uses the same origin's HttpOnly cookie; no bearer token is stored. */
class TokenRegistrationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object {
        @Synchronized fun deviceId(context: Context): String {
            val prefs = context.getSharedPreferences("push", Context.MODE_PRIVATE)
            return prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("device_id", it).apply() }
        }
        fun enqueue(context: Context) {
            val request = OneTimeWorkRequestBuilder<TokenRegistrationWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build()
            WorkManager.getInstance(context).enqueueUniqueWork("fcm-token-registration", ExistingWorkPolicy.REPLACE, request)
        }
        fun cancel(context: Context) { WorkManager.getInstance(context).cancelUniqueWork("fcm-token-registration") }
    }
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val prefs = applicationContext.getSharedPreferences("push", Context.MODE_PRIVATE)
        val token = prefs.getString("token", null) ?: return@withContext Result.success()
        if (!prefs.getBoolean("session_bound", false)) return@withContext Result.success() // after login the bridge enqueues again
        val cookie = withContext(Dispatchers.Main) { CookieManager.getInstance().getCookie(BuildConfig.APP_ORIGIN) }
        if (cookie.isNullOrBlank()) return@withContext Result.success()
        var connection: HttpsURLConnection? = null
        try {
            connection = URL("${BuildConfig.APP_ORIGIN}/api/push/register-token").openConnection() as HttpsURLConnection
            connection.instanceFollowRedirects = false
            connection.requestMethod = "POST"; connection.connectTimeout = 15000; connection.readTimeout = 15000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Cookie", cookie)
            connection.doOutput = true
            val payload = JSONObject().put("token", token).put("deviceType", "android").put("source", "android_native")
                .put("deviceId", deviceId(applicationContext)).put("deviceName", "Vyper Android").toString().toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(payload.size)
            connection.outputStream.use { it.write(payload) }
            when (connection.responseCode) {
                200 -> {
                    val response = connection.inputStream.bufferedReader().use { reader ->
                        val buffer = CharArray(4097)
                        var length = 0
                        while (length < buffer.size) { val n = reader.read(buffer, length, buffer.size - length); if (n < 0) break; length += n }
                        require(length <= 4096) { "Oversized registration response" }
                        String(buffer, 0, length)
                    }
                    if (JSONObject(response).optBoolean("success")) Result.success() else Result.retry()
                }
                401, 403 -> { prefs.edit().putBoolean("session_bound", false).apply(); Result.success() } // wait for a verified login
                400 -> Result.failure()
                429, in 500..599 -> if (runAttemptCount < 8) Result.retry() else Result.failure()
                else -> Result.failure() // includes redirects; never forward cookies off-origin
            }
        } catch (_: Exception) { if (runAttemptCount < 8) Result.retry() else Result.failure() }
        finally { connection?.disconnect() }
    }
}
