// =========================================================================
// SCHEDULED MESSAGE TESTS (M-06) + CORS/config unit tests (G-07, H-05)
// =========================================================================
import { describe, it, expect, beforeAll, afterEach } from 'vitest';
import {
  getApp,
  seedUser,
  login,
  authHeader,
  seedRow,
  allRows,
  getRow,
  resetAllTables,
  type TestUser,
} from './helpers';

let app: any;
let user: TestUser;
let token: string;

beforeAll(async () => {
  app = await getApp();
});

afterEach(() => {
  resetAllTables();
});

async function setupUser() {
  user = seedUser({ username: 'scheduler' });
  token = (await login(app, user.email, user.password)).token!;
}

describe('scheduled messages API (M-06)', () => {
  it('creates a schedule on the server (durable, not localStorage)', async () => {
    await setupUser();
    const when = new Date(Date.now() + 60 * 60_000).toISOString();
    const res: any = await new Promise((resolve) =>
      app
        .post('/api/scheduler/messages')
        .set(authHeader(token))
        .send({ chat_id: 'general', text: 'future hello', scheduled_for: when })
        .end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(200);
    expect(res.body.item.status).toBe('scheduled');

    const list: any = await new Promise((resolve) =>
      app.get('/api/scheduler/messages').set(authHeader(token)).end((e: any, r: any) => resolve(r))
    );
    expect(list.status).toBe(200);
    expect(list.body.items.length).toBe(1);
    expect(list.body.items[0].text).toBe('future hello');
    // The durable row exists in the server-only table
    expect(allRows('scheduled_messages').length).toBe(1);
  });

  it('validates inputs', async () => {
    await setupUser();
    const past: any = await new Promise((resolve) =>
      app
        .post('/api/scheduler/messages')
        .set(authHeader(token))
        .send({ chat_id: 'general', text: 'x', scheduled_for: new Date(Date.now() - 60_000).toISOString() })
        .end((e: any, r: any) => resolve(r))
    );
    expect(past.status).toBe(400);

    const missing: any = await new Promise((resolve) =>
      app
        .post('/api/scheduler/messages')
        .set(authHeader(token))
        .send({ text: 'x', scheduled_for: new Date(Date.now() + 3600_000).toISOString() })
        .end((e: any, r: any) => resolve(r))
    );
    expect(missing.status).toBe(400);
  });

  it('rejects scheduling into a chat the user is not a member of', async () => {
    await setupUser();
    const other = seedUser({ username: 'otheruser' });
    void other;
    const foreignChat = 'dm:someoneelse:andanother';
    const res: any = await new Promise((resolve) =>
      app
        .post('/api/scheduler/messages')
        .set(authHeader(token))
        .send({ chat_id: foreignChat, text: 'x', scheduled_for: new Date(Date.now() + 3600_000).toISOString() })
        .end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(403);
  });

  it('delivers due messages idempotently via the server worker', async () => {
    await setupUser();
    // Schedule 1 minute in the past is rejected at creation, so create via
    // the API then backdate the stored row to simulate time passing.
    const when = new Date(Date.now() + 3600_000).toISOString();
    const created: any = await new Promise((resolve) =>
      app
        .post('/api/scheduler/messages')
        .set(authHeader(token))
        .send({ chat_id: 'general', text: 'due now', scheduled_for: when })
        .end((e: any, r: any) => resolve(r))
    );
    const id = created.body.item.id;
    const row = getRow('scheduled_messages', id)!;
    row.SCHEDULED_FOR = new Date(Date.now() - 60_000).toISOString();
    seedRow('scheduled_messages', row);

    const { runSchedulerPass } = await import('../src/server/scheduler');
    await runSchedulerPass();

    const messages = allRows('messages');
    expect(messages.length).toBe(1);
    expect(messages[0].TEXT).toBe('due now');
    expect(messages[0].ID).toBe(`schedm_${id}`);
    expect(getRow('scheduled_messages', id)!.STATUS).toBe('sent');

    // Idempotent: a second pass must NOT duplicate the message
    await runSchedulerPass();
    expect(allRows('messages').length).toBe(1);
  });

  it('cannot cancel or list other users\' schedules', async () => {
    await setupUser();
    const other = seedUser({ username: 'other' });
    const when = new Date(Date.now() + 3600_000).toISOString();
    seedRow('scheduled_messages', {
      ID: 'sched-other',
      USER_ID: other.id,
      CHAT_ID: 'general',
      TEXT: 'not yours',
      SCHEDULED_FOR: when,
      STATUS: 'scheduled',
      ATTEMPTS: 0,
      CREATED_AT: new Date().toISOString(),
      UPDATED_AT: new Date().toISOString(),
    });

    const del: any = await new Promise((resolve) =>
      app.delete('/api/scheduler/messages/sched-other').set(authHeader(token)).end((e: any, r: any) => resolve(r))
    );
    expect(del.status).toBe(403);

    const list: any = await new Promise((resolve) =>
      app.get('/api/scheduler/messages').set(authHeader(token)).end((e: any, r: any) => resolve(r))
    );
    expect(list.body.items.length).toBe(0);
  });
});

describe('CORS allowlist (G-07)', () => {
  // The SSE stream never ends, so resolve as soon as response headers arrive.
  function probeStream(_ORIGIN: string, tok: string): Promise<any> {
    return new Promise((resolve) => {
      app
        .get('/api/realtime/stream')
        .set('Cookie', `vyper_session=${tok}`)
        .set('Origin', _ORIGIN)
        .parse((res: any, cb: any) => {
          resolve({ status: res.statusCode, headers: res.headers });
          res.resume();
          cb(null, {});
          res.destroy();
        })
        .end(() => {});
    });
  }

  it('grants CORS only to allowed origins and never "*"', async () => {
    await setupUser();
    const allowed = await probeStream('https://app.example.com', token);
    expect(allowed.status).toBe(200);
    expect(allowed.headers['access-control-allow-origin']).toBe('https://app.example.com');
    expect(allowed.headers['vary']).toMatch(/Origin/i);
    expect(allowed.headers['access-control-allow-origin']).not.toBe('*');

    const denied = await probeStream('https://evil.example.net', token);
    expect(denied.status).toBe(403);
  });
});

describe('server-only tables are invisible to the proxy', () => {
  it('scheduled_messages is not proxy-reachable even by admins', async () => {
    await setupUser();
    const res: any = await new Promise((resolve) =>
      app.get('/api/oracle/scheduled_messages/?limit=10').set(authHeader(token)).end((e: any, r: any) => resolve(r))
    );
    expect(res.status).toBe(404);
  });
});
