import { withSessionAccount, sessionIsActive } from './sessionState';
import { fetchProfileById } from './oracleBackend';
import type { Express, Request, Response, RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { ApiError } from './errors';
import { isProduction } from './config';
import { beginDeletionJob, getDeletionJob, jobResponse, kickDeletionJob, type DeletionJob } from './destructiveJobs';
const operationId = z.string().regex(/^(wipe_[a-f0-9-]{36}|delete_[a-f0-9]{40})$/);
const cookieName = 'vyper_operation';
function cookie(req: Request) { const raw = req.headers.cookie?.split(';').map(v => v.trim()).find(v => v.startsWith(cookieName + '='))?.slice(cookieName.length + 1); try { return decodeURIComponent(raw || ''); } catch { return ''; } }
export function operationControls(secret: string) {
  function accepted(res: Response, job: DeletionJob, actorId: string) {
    const receipt = jwt.sign({ purpose: 'operation-status', operationId: job.id, actorId: job.actor_id }, secret, { algorithm: 'HS256', expiresIn: '2h' });
    res.append('Set-Cookie', `${cookieName}=${encodeURIComponent(receipt)}; HttpOnly; SameSite=Strict; Path=/api/operations/; Max-Age=7200${isProduction() ? '; Secure' : ''}`);
    res.status(202).json({ ...jobResponse(job), statusUrl: `/api/operations/${job.id}` });
    kickDeletionJob(job.id);
  }
  async function submit(req: Request, res: Response, kind: DeletionJob['kind'], target?: string, existingId?: string) {
    const user = req.user!;
    const job = await withSessionAccount(user.sub, async () => {
      if (!await sessionIsActive(user)) throw new ApiError(401, 'Session revoked');
      const profile = await fetchProfileById(user.sub);
      if (!profile) throw new ApiError(401, 'Account unavailable');
      if ((kind !== 'account' || target !== user.sub) && profile.role !== 'admin') throw new ApiError(403, 'Current admin role required');
      return beginDeletionJob(kind, user.sub, target, existingId);
    });
    accepted(res, job, user.sub);
  }
  return {
    accepted, submit,
    install(app: Express, auth: RequestHandler, admin: RequestHandler, recent: RequestHandler) {
      app.get('/api/operations/:id', async (req, res) => {
        const id = operationId.safeParse(req.params.id); if (!id.success) throw new ApiError(400, 'Invalid operation ID');
        let claims: jwt.JwtPayload;
        try { const value = jwt.verify(cookie(req), secret, { algorithms: ['HS256'] }); if (typeof value === 'string') throw new Error(); claims = value; }
        catch { throw new ApiError(401, 'Operation receipt expired or unavailable'); }
        if (claims.purpose !== 'operation-status' || claims.operationId !== id.data) throw new ApiError(403, 'Receipt is not for this operation');
        const job = await getDeletionJob(id.data);
        if (!job || job.actor_id !== claims.actorId) throw new ApiError(404, 'Unknown operation');
        // Only status/counts. This receipt cannot authenticate the account, change targets or retry a job.
        res.json(jobResponse(job));
      });
      app.post('/api/admin/operations', auth, admin, recent, async (req, res) => {
        const parsed = z.object({ kind: z.enum(['messages','calls']), confirmation: z.string() }).strict().safeParse(req.body);
        if (!parsed.success || parsed.data.confirmation !== `DELETE ALL ${parsed.data.kind.toUpperCase()}`) throw new ApiError(400, 'Literal destructive confirmation required');
        await submit(req, res, parsed.data.kind);
      });
    },
  };
}
