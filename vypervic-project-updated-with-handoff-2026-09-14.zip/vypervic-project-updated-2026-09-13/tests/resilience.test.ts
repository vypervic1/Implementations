import { beforeEach, describe, expect, it } from 'vitest';
import { getApp, seedUser, login, authHeader, resetAllTables, seedRow, allRows, getRow, type TestUser } from './helpers';
import { failRequests, failNthRequest, setPageCap } from './mockOrds';
import { fetchAllRows } from '../src/server/oracleBackend';
import { runSchedulerPass } from '../src/server/scheduler';
import { reconcileCalls } from '../src/server/callWorker';
import { getCallById } from '../src/server/callState';
import { registrationsForUsers } from '../src/server/pushTokenStore';
let app: Awaited<ReturnType<typeof getApp>>, alice: TestUser, bob: TestUser, eve: TestUser, token: string;
beforeEach(async () => { resetAllTables(); app = await getApp(); alice = seedUser(); bob = seedUser(); eve = seedUser(); token = (await login(app, alice.email, alice.password)).token!; });
const headers = () => authHeader(token);

describe('authoritative read/write regression coverage', () => {
  it('does not skip records when ORDS caps page size below the requested size', async () => {
    for (let i = 0; i < 17; i++) seedRow('messages', { ID: `capped_${String(i).padStart(2, '0')}`, CHAT_ID: 'general', SENDER_ID: alice.id });
    setPageCap(3);
    expect((await fetchAllRows('messages', {}, 200)).map(row => row.id)).toHaveLength(17);
  });
  it('fails closed if an upstream resource lookup returns a different identity', async () => {
    failRequests('GET', new RegExp(`/profiles/${alice.id}$`), 1, 200, { ID: bob.id, ROLE: 'admin' });
    expect((await app.get('/api/auth/me').set(headers())).status).toBe(502);
  });
  it('inbox feed returns only current memberships, including after a group removal', async () => {
    const now = new Date().toISOString();
    seedRow('groups', { ID: 'group:kept', CREATOR_ID: alice.id, MEMBERS: JSON.stringify([alice.id, bob.id]) });
    seedRow('groups', { ID: 'group:left', CREATOR_ID: bob.id, MEMBERS: JSON.stringify([bob.id]) });
    for (const [id, chat, sender, recipient] of [
      ['public', 'general', eve.id, null], ['mine', `dm:${alice.id}:${bob.id}`, alice.id, bob.id],
      ['foreign', `dm:${bob.id}:${eve.id}`, bob.id, eve.id], ['group_ok', 'group:kept', bob.id, null], ['group_left', 'group:left', alice.id, null],
    ]) seedRow('messages', { ID: id, CHAT_ID: chat, SENDER_ID: sender, RECIPIENT_ID: recipient, TEXT: id, CREATED_AT: now });
    const res = await app.get('/api/messages/feed').set(headers());
    expect(res.status).toBe(200);
    expect(res.body.items.map((row: any) => row.id).sort()).toEqual(['group_ok', 'mine', 'public']);
  });
  it('persists groups and covers through owned APIs, not only display caches', async () => {
    const group = await app.post('/api/groups').set(headers()).send({ id: 'group:durable', name: 'Real group', icon: '👥', members: [alice.id, bob.id] });
    expect(group.status).toBe(201);
    expect((await app.get('/api/groups').set(headers())).body.items[0].id).toBe(group.body.id);
    const cover = 'data:image/png;base64,AAAA';
    const profile = await app.patch('/api/profile').set(headers()).send({ cover_url: cover });
    expect(profile.status).toBe(200); expect(getRow('profiles', alice.id)!.COVER_URL).toBe(cover);
  });
  it('requires a current password to issue a fresh destructive-operation cookie', async () => {
    expect((await app.post('/api/auth/reauth').set(headers()).send({ password: 'wrong' })).status).toBe(401);
    const res = await app.post('/api/auth/reauth').set(headers()).send({ password: alice.password });
    expect(res.status).toBe(200); expect(res.body.token).toBeUndefined();
    expect((await app.get('/api/auth/me').set(headers())).status).toBe(401);
    expect((await app.get('/api/auth/me').set('Cookie', res.headers['set-cookie'][0].split(';')[0])).status).toBe(200);
  });
  it('stops delivering push for revoked/expired sessions', async () => {
    const res = await app.post('/api/push/register-token').set(headers()).send({ token: 'Z'.repeat(150), deviceType: 'web', source: 'web_fcm', deviceId: 'test-expired-device' });
    expect(res.status).toBe(200); expect(await registrationsForUsers([alice.id])).toHaveLength(1);
    await app.post('/api/auth/logout').set(headers());
    expect(await registrationsForUsers([alice.id])).toHaveLength(0);
  });
});

describe('restartable worker failure boundaries', () => {
  it('recovers commit-before-mark-sent without creating another scheduled message', async () => {
    const created = await app.post('/api/scheduler/messages').set(headers()).send({ chat_id: 'general', text: 'exactly one row', scheduled_for: new Date(Date.now() + 60000).toISOString() });
    const id = created.body.item.id;
    const row = getRow('scheduled_messages', id)!;
    row.SCHEDULED_FOR = new Date(Date.now() - 1000).toISOString(); row.NEXT_ATTEMPT_AT = row.SCHEDULED_FOR;
    failNthRequest('PATCH', new RegExp(`/scheduled_messages/${id}$`), 2);
    await runSchedulerPass();
    expect(allRows('messages')).toHaveLength(1); expect(getRow('scheduled_messages', id)!.STATUS).toBe('scheduled');
    getRow('scheduled_messages', id)!.NEXT_ATTEMPT_AT = new Date(Date.now() - 1000).toISOString();
    await runSchedulerPass();
    expect(allRows('messages')).toHaveLength(1); expect(getRow('scheduled_messages', id)!.STATUS).toBe('sent');
    expect(allRows('messages')[0].ID).toBe(`schedm_${id}`);
  });
  it('does not persist a scheduled message when its claim cannot be saved', async () => {
    const created = await app.post('/api/scheduler/messages').set(headers()).send({ chat_id: 'general', text: 'not claimed', scheduled_for: new Date(Date.now() + 60000).toISOString() });
    const id = created.body.item.id, row = getRow('scheduled_messages', id)!;
    row.SCHEDULED_FOR = new Date(Date.now() - 1000).toISOString(); row.NEXT_ATTEMPT_AT = row.SCHEDULED_FOR;
    failNthRequest('PATCH', new RegExp(`/scheduled_messages/${id}$`), 1);
    await runSchedulerPass(); expect(allRows('messages')).toHaveLength(0); expect(getRow('scheduled_messages', id)!.STATUS).toBe('scheduled');
  });
  it('expires stale ringing calls and repairs their projection without browser activity', async () => {
    const id = `stale_${alice.id}`;
    seedRow('calls', { ID: id, CALLER_ID: alice.id, RECEIVER_ID: bob.id, TYPE: 'voice', STATUS: 'ringing', CREATED_AT: new Date(Date.now() - 60000).toISOString(), UPDATED_AT: new Date().toISOString() });
    await reconcileCalls();
    expect(getRow('calls', id)!.STATUS).toBe('missed'); expect((await getCallById(id))!.status).toBe('missed');
  });
});
