import { withDataMutation } from './mutationGate';
import { fetchRowById, fetchRowsByFilter, fetchProfileById, fetchGroupById, groupMembers, ordsFetch } from './oracleBackend';
import { isChatParticipant } from './authz';
import { sendPushToUsers } from './firebaseAdmin';
import { registrationsForUsers } from './pushTokenStore';
import { ApiError } from './errors';
export const deliveryHealth = { lastPassAt: 0, failures: 0 };
let timer: ReturnType<typeof setInterval> | undefined;
let processing = false;
async function checkpoint(id: string, data: Record<string, unknown>) {
  const result = await ordsFetch(`/delivery_outbox/${encodeURIComponent(id)}`, { method: 'PATCH', body: { ...data, UPDATED_AT: new Date().toISOString() } });
  if (!result.ok) throw new Error('Delivery checkpoint was not persisted');
}
export async function runDeliveryPass(): Promise<void> {
  if (processing) return;
  processing = true;
  try {
    await withDataMutation(async () => {
      const now = Date.now();
      const staleBefore = now - 120000;
      // ORDS rejects compound/range worker filters. Fetch each status with a
      // simple equality filter and apply due-time checks locally.
      const [queued, sending] = await Promise.all([
        fetchRowsByFilter('delivery_outbox', { STATUS: 'queued' }, 50),
        fetchRowsByFilter('delivery_outbox', { STATUS: 'sending' }, 50),
      ]);
      const due = [...queued.filter(row => !row.next_attempt_at || Date.parse(row.next_attempt_at) <= now),
        ...sending.filter(row => !row.updated_at || Date.parse(row.updated_at) <= staleBefore)].slice(0, 10);
      for (const record of due) await deliver(record.id);
      deliveryHealth.lastPassAt = Date.now();
    });
  } catch (error) {
    deliveryHealth.failures++;
    console.error('[DeliveryWorker] Pass failed:', error instanceof Error ? error.message : String(error));
  }
  finally { processing = false; }
}
async function deliver(id: string): Promise<void> {
  const job = await fetchRowById('delivery_outbox', id);
  if (!job || ['sent','cancelled','failed'].includes(job.status)) return;
  const attempts = Number(job.attempts) + 1;
  const receipts: Record<string, string> = typeof job.results === 'string' ? JSON.parse(job.results || '{}') : job.results || {};
  if (attempts > 5) { await checkpoint(id, { STATUS: 'failed', LAST_ERROR: 'Retry limit reached' }); return; }
  await checkpoint(id, { STATUS: 'sending', ATTEMPTS: attempts });
  try {
    const isCall = job.kind === 'call';
    const entity = await fetchRowById(isCall ? 'calls' : 'messages', job.entity_id);
    if (!entity || (isCall ? entity.caller_id : entity.sender_id) !== job.sender_id) { await checkpoint(id, { STATUS: 'cancelled', LAST_ERROR: 'Source no longer available' }); return; }
    if (isCall && (entity.status !== 'ringing' || Date.now() - Date.parse(entity.created_at) >= 30000)) { await checkpoint(id, { STATUS: 'cancelled', LAST_ERROR: 'Call invitation expired' }); return; }
    const sender = await fetchProfileById(job.sender_id);
    if (!sender) { await checkpoint(id, { STATUS: 'cancelled', LAST_ERROR: 'Sender account deleted' }); return; }
    const chatId = isCall ? `dm:${[entity.caller_id, entity.receiver_id].sort().join(':')}` : entity.chat_id;
    let targets: string[] = [];
    if (isCall) targets = [entity.receiver_id];
    else if (chatId.startsWith('dm:')) targets = chatId.split(':').slice(1).filter((uid: string) => uid !== job.sender_id);
    else if (chatId.startsWith('group:')) targets = groupMembers(await fetchGroupById(chatId) || await fetchGroupById(chatId.slice(6))).filter(uid => uid !== job.sender_id);
    // Public-room posts are live/reconciled; they do not wake every installation.
    const name = sender.display_name || sender.username || 'Contact';
    for (const target of [...new Set(targets)]) {
      if (receipts[target]) continue;
      if (!await fetchProfileById(target) || !await isChatParticipant(chatId, target) || !await isChatParticipant(chatId, job.sender_id)) { receipts[target] = 'no_longer_authorized'; }
      else if (!(await registrationsForUsers([target])).length) receipts[target] = 'no_registered_device';
      else {
        const result = await sendPushToUsers({ targetUserIds: [target], eventId: job.id,
          title: isCall ? `Incoming call from ${name}` : name, body: isCall ? `Incoming ${entity.type} call` : String(entity.text || (entity.is_voice ? 'Voice message' : 'Attachment')).slice(0, 500),
          type: isCall ? 'call' : 'message', callId: isCall ? entity.id : undefined, chatId, senderId: job.sender_id, senderName: name });
        if (!result.success) throw new Error('FCM did not accept all device deliveries');
        receipts[target] = 'accepted_by_fcm'; // not proof that an OS displayed it
      }
      await checkpoint(id, { RESULTS: JSON.stringify(receipts) });
    }
    await checkpoint(id, { STATUS: 'sent', RESULTS: JSON.stringify(receipts), LAST_ERROR: null });
  } catch {
    deliveryHealth.failures++;
    await checkpoint(id, { STATUS: attempts >= 5 ? 'failed' : 'queued', RESULTS: JSON.stringify(receipts), LAST_ERROR: 'Delivery interrupted; retry pending',
      NEXT_ATTEMPT_AT: new Date(Date.now() + Math.min(300000, 1000 * 2 ** attempts)).toISOString() });
  }
}
export async function retryDelivery(id: string) {
  const job = await fetchRowById('delivery_outbox', id); if (!job || job.status !== 'failed') throw new ApiError(409, 'Only failed delivery jobs can be retried');
  await checkpoint(id, { STATUS: 'queued', ATTEMPTS: 0, NEXT_ATTEMPT_AT: new Date().toISOString(), LAST_ERROR: null });
}
export function startDeliveryWorker() { if (!timer) { timer = setInterval(() => void runDeliveryPass(), 3000); timer.unref(); void runDeliveryPass(); } }
export function stopDeliveryWorker() { if (timer) clearInterval(timer); timer = undefined; }
