import { beforeEach, expect, it } from 'vitest';
import { getApp, login, seedUser, resetAllTables, authHeader, seedRow, getRow, settleOperation } from './helpers';
let app: Awaited<ReturnType<typeof getApp>>, admin: ReturnType<typeof seedUser>, user: ReturnType<typeof seedUser>, a: string, u: string;
beforeEach(async()=>{resetAllTables();app=await getApp();admin=seedUser({role:'admin'});user=seedUser();a=(await login(app,admin.email,admin.password)).token!;u=(await login(app,user.email,user.password)).token!;});
it('counts the database, not the displayed page, and serves bounded metadata',async()=>{
 for(let i=0;i<123;i++) seedRow('messages',{ID:`row_${i}`,CHAT_ID:'general',SENDER_ID:user.id,TEXT:'x',FILE_DATA:'data:text/plain;base64,'+'A'.repeat(1000000),CREATED_AT:new Date().toISOString()});
 const stats=await app.get('/api/admin/stats').set(authHeader(a)); expect(stats.body.totalMessages).toBe(123);
 const page=await app.get('/api/admin/resources/messages').set(authHeader(a)); expect(page.body.items).toHaveLength(50); expect(page.text.length).toBeLessThan(50000);expect(page.body.hasMore).toBe(true);
 expect((await app.get('/api/admin/stats').set(authHeader(u))).status).toBe(403);
});
it('role changes are typed, audited and rejected after demotion',async()=>{
 const result=await app.patch(`/api/admin/users/${user.id}/role`).set(authHeader(a)).send({role:'admin',confirmation:'CHANGE ROLE'});expect(result.status).toBe(200);expect(getRow('profiles',user.id)!.ROLE).toBe('admin');
 getRow('profiles',admin.id)!.ROLE='user';
 expect((await app.patch(`/api/admin/users/${user.id}/role`).set(authHeader(a)).send({role:'user',confirmation:'CHANGE ROLE'})).status).toBe(403);
});
it('admin bulk message deletion uses a job and preserves unrelated calls/profiles',async()=>{
 seedRow('messages',{ID:'owned',CHAT_ID:'general',SENDER_ID:user.id,TEXT:'x'});seedRow('calls',{ID:'keep-call',CALLER_ID:admin.id,RECEIVER_ID:user.id});
 const result=await app.post('/api/admin/operations').set(authHeader(a)).send({kind:'messages',confirmation:'DELETE ALL MESSAGES'});expect(result.status).toBe(202);await settleOperation(result);expect(result.body.success).toBe(true);expect(getRow('calls','keep-call')).not.toBeNull();expect(getRow('profiles',user.id)).not.toBeNull();
});
it('delegated group admins can edit members but cannot promote themselves/others or disband',async()=>{
 const peer=seedUser();
 const created=await app.post('/api/groups').set(authHeader(a)).send({id:'group:roles',name:'Role test',members:[admin.id,user.id,peer.id],admins:[user.id]});expect(created.status).toBe(201);
 expect((await app.patch('/api/groups/group:roles').set(authHeader(u)).send({name:'Renamed'})).status).toBe(200);
 expect((await app.patch('/api/groups/group:roles').set(authHeader(u)).send({admins:[user.id,peer.id]})).status).toBe(403);
 expect((await app.delete('/api/groups/group:roles').set(authHeader(u))).status).toBe(403);
});
