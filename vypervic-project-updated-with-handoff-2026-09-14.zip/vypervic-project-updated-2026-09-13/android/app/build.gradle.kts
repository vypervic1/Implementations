import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}
fun originFor(flavor: String): String {
    val value = providers.environmentVariable("${flavor.uppercase()}_APP_ORIGIN").orNull
        ?: providers.gradleProperty("${flavor}AppOrigin").orNull
        ?: error("${flavor.uppercase()}_APP_ORIGIN must be supplied; local assets and localhost are unsupported")
    val uri = URI(value)
    require(uri.scheme == "https" && uri.host != null && uri.userInfo == null && uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) { "An HTTPS application origin is required" }
    require(uri.host !in listOf("localhost", "127.0.0.1", "0.0.0.0")) { "Device API routing cannot use localhost" }
    return value.trimEnd('/')
}
android {
    namespace = "com.vyper.chat"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vyper.chat"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    flavorDimensions += "environment"
    productFlavors {
        listOf("development", "staging", "production").forEach { name ->
            create(name) {
                dimension = "environment"
                if (name != "production") applicationIdSuffix = ".${name}"
                val origin = originFor(name)
                buildConfigField("String", "APP_ORIGIN", "\"$origin\"")
                manifestPlaceholders["appHost"] = URI(origin).host
            }
        }
    }
    signingConfigs {
        create("release") {
            val path = providers.environmentVariable("ANDROID_KEYSTORE_PATH").orNull
            if (path != null) {
                storeFile = file(path)
                storePassword = providers.environmentVariable("ANDROID_KEYSTORE_PASSWORD").orNull
                keyAlias = providers.environmentVariable("ANDROID_KEY_ALIAS").orNull
                keyPassword = providers.environmentVariable("ANDROID_KEY_PASSWORD").orNull
            }
        }
    }
    buildTypes {
        debug { isDebuggable = true }
        release {
            isDebuggable = false
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isReturnDefaultValues = true }
    lint { abortOnError = true; checkReleaseBuilds = true }
}
// Never emit an unsigned release artifact while reporting release success.
gradle.taskGraph.whenReady {
    if (allTasks.any { it.name.contains("Release") && (it.name.startsWith("assemble") || it.name.startsWith("bundle")) }) {
        require(System.getenv("VYPER_CI_BUILD") != "1") { "CI contract builds cannot produce release APKs" }
        require(listOf("ANDROID_KEYSTORE_PATH", "ANDROID_KEYSTORE_PASSWORD", "ANDROID_KEY_ALIAS", "ANDROID_KEY_PASSWORD").all { !System.getenv(it).isNullOrBlank() }) { "Release signing secrets are required" }
    }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.12.0"))
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.webkit:webkit:1.13.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}

androidComponents {
    onVariants(selector().all()) { variant ->
        val flavor = variant.productFlavors.first { it.first == "environment" }.second
        val capitalized = variant.name.replaceFirstChar { it.uppercaseChar() }
        val verify = tasks.register("verify${capitalized}FirebaseConfiguration") {
            doLast {
                val source = file("src/$flavor/google-services.json")
                require(source.isFile) { "Supply the $flavor Android Firebase configuration securely" }
                val raw = source.readText()
                require(!raw.contains("private_key")) { "Admin credentials are forbidden in an APK" }
                val parsed = groovy.json.JsonSlurper().parseText(raw) as Map<*, *>
                val project = parsed["project_info"] as Map<*, *>
                val expected = System.getenv("${flavor.uppercase()}_FIREBASE_PROJECT_ID")
                require(!expected.isNullOrBlank() && project["project_id"] == expected) { "Native/canonical Firebase project mismatch" }
                require(!expected.startsWith("demo-") || System.getenv("VYPER_CI_BUILD") == "1") { "Demo configuration cannot be deployed" }
                val packageName = "com.vyper.chat" + if (flavor == "production") "" else ".$flavor"
                val clients = parsed["client"] as List<*>
                require(clients.any { entry ->
                    val info = (entry as Map<*, *>)["client_info"] as Map<*, *>
                    val pkg = info["android_client_info"] as Map<*, *>
                    pkg["package_name"] == packageName && (info["mobilesdk_app_id"] as String).startsWith("1:${project["project_number"]}:android:")
                }) { "Firebase package, app ID or sender mismatch" }
            }
        }
        tasks.matching { it.name == "pre${capitalized}Build" || it.name == "process${capitalized}GoogleServices" }.configureEach { dependsOn(verify) }
    }
}
