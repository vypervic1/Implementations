import { capabilities } from './capabilities';
import { oracleDB } from './oracleDB';
import { Profile } from './types';

export interface PushToken {
  id: string;
  user_id: string;
  fcm_token: string;
  device_name: string;
  is_active: boolean;
  created_at: string;
}

export interface TriggeredPush {
  id: string;
  user_id: string;
  title: string;
  body: string;
  type: 'dm_message' | 'mention';
  status: string;
  created_at: string;
}

// Check if user has notification permissions
export function checkNotificationPermission(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

// Request permission for push notifications
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (err) {
    console.warn('Error requesting notification permission:', err);
    return 'default';
  }
}

// Only real FCM transports may register a device. No synthetic subscriptions/tokens.
export async function getOrRegisterDevicePushToken(userId: string): Promise<string> {
  const { registerForPushNotifications } = await import('./firebaseClient');
  return await registerForPushNotifications(userId) || '';
}
export async function registerPushToken(userId: string, token: string, _deviceName?: string): Promise<{ success: boolean; error?: unknown }> {
  try {
    const { saveTokenToBackend } = await import('./firebaseClient');
    const { capabilities } = await import('./capabilities');
    await saveTokenToBackend(userId, token, capabilities().mode === 'native-android' ? 'android' : 'web');
    return { success: true };
  } catch (error) { return { success: false, error }; }
}
export async function fetchRegisteredTokens(_userId: string): Promise<PushToken[]> {
  const response = await fetch('/api/push/devices', { credentials: 'same-origin' });
  if (!response.ok) throw new Error('Could not load registered devices');
  return (await response.json()).items;
}
export async function deletePushToken(tokenId: string): Promise<boolean> {
  const response = await fetch(`/api/push/devices/${encodeURIComponent(tokenId)}`, { method: 'DELETE', credentials: 'same-origin' });
  return response.ok && (await response.json()).success === true;
}

// Helper to raise browser notification or play ambient Android sound
export function displayLocalPushNotification(title: string, body: string, iconUrl?: string | null) {
  // 1. Browser Native Notification
  if (capabilities().webPush && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: iconUrl || '/icon.png',
        tag: 'vypervic-push',
      });
    } catch (e) {
      console.warn('Native notification failed:', e);
    }
  }

  // 2. Play ambient Android notification sound (subtle beep)
  try {
    const context = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = context.createOscillator();
    const gain = context.createGain();
    
    osc.connect(gain);
    gain.connect(context.destination);
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, context.currentTime); // High pitch notification bell
    gain.gain.setValueAtTime(0.08, context.currentTime);
    
    // Quick dual-chime "ding ding"
    osc.start();
    osc.frequency.setValueAtTime(1500, context.currentTime + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.3);
    osc.onended = () => { osc.disconnect(); gain.disconnect(); void context.close(); };
    osc.stop(context.currentTime + 0.3);
  } catch (audioErr) {
    // Browser audio policy might block until user interaction, skip silently
  }
}
