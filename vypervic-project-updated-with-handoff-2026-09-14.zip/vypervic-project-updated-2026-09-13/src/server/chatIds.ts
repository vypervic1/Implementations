export function canonicalDmChatId(a: string, b: string): string {
  const ids = [String(a), String(b)].sort();
  if (!ids[0] || !ids[1] || ids[0] === ids[1]) throw new Error('A direct message requires two distinct users');
  return `dm:${ids[0]}:${ids[1]}`;
}

export function parseDmChatId(chatId: string): [string, string] | null {
  if (!chatId.startsWith('dm:')) return null;
  const parts = chatId.slice(3).split(':');
  if (parts.length !== 2 || !parts[0] || !parts[1] || parts[0] === parts[1]) return null;
  return [parts[0], parts[1]];
}

export function dmIncludesUser(chatId: string, userId: string): boolean {
  const parts = parseDmChatId(chatId);
  return !!parts && parts.includes(userId);
}
