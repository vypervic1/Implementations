# VPS setup — VyperVic (Arena ChatApp), step by step

Target architecture (do not change it):

```text
Android APK / browser
        |  HTTPS, HttpOnly cookie (vyper_session)
        v
VPS: Caddy (TLS) -> Node 127.0.0.1:3000
        |-- authenticated ORDS -----> Oracle ADB VYPERVIC1 (durable truth)
        |-- Firebase Admin SDK ------> vypervic-chatapp (presence/signaling/FCM)
        |-- shared Redis (private)    (sessions, revocation, locks, realtime)
        +-- private coturn (REST)     (WebRTC relay; secret stays on VPS)
```

The client never talks to Oracle directly and never holds Oracle, Firebase
Admin, Redis, TURN-secret, or mail credentials. The VPS derives identity from
the verified `vyper_session` JWT (`req.user.sub`), never from client payloads.

> Companion docs: `deploy/README-AZURE.md` (hardening detail),
> `docs/STAGING-ACCEPTANCE.md` (acceptance tests),
> `SESSION_HANDOVER_DIRECTIVE.md` + `VYPERVIC_MASTER_SPECIFICATION.md`
> (architecture contract). This file is the ordered runbook.

---

## 0. Collect these before you touch the VPS

| # | Item | Where to get it |
|---|------|-----------------|
| 1 | A domain name, e.g. `chat.example.com` | Your registrar |
| 2 | Oracle Cloud access to ADB **VYPERVIC1** (ADMIN schema) | OCI Console -> Autonomous Database |
| 3 | Firebase project **vypervic-chatapp**, database **(default)** | Firebase Console (Blaze plan needed for FCM + Admin SDK at scale) |
| 4 | Firebase **web app** public config: API key, auth domain, storage bucket, messaging sender ID, app ID | Firebase Console -> Project settings -> General -> Your apps -> Web |
| 5 | Firebase **Web Push (VAPID) key** | Firebase Console -> Project settings -> Cloud Messaging -> Web Push certificates |
| 6 | Firebase **service-account key** for the VPS only (`FIREBASE_*`) | IAM -> Service Accounts -> `firebase-adminsdk-fbsvc@vypervic-chatapp...` -> Keys -> Add key -> JSON. Copy the three fields into the runtime env, then delete the downloaded JSON from your workstation |
| 7 | `google-services.json` for Android (package `com.vyper.chat`, project `vypervic-chatapp`) | Firebase Console -> Project settings -> Your apps -> Android |
| 8 | A transactional-mail sender (Resend recommended): API key + verified `MAIL_FROM` | Resend dashboard / your mail provider |
| 9 | Android release keystore + App Links `assetlinks.json` (SHA-256 of signing cert) | Your keystore; see step 11 |

Keep every private value in a password manager. Nothing private goes into Git,
the APK, the browser bundle, or chat logs.

---

## 1. Wipe and rebuild Oracle (removes all ghost tables/config)

1. OCI Console -> Autonomous Database -> **VYPERVIC1** -> Database Actions -> SQL.
2. Optional but recommended: OCI -> Backups -> create a manual backup first.
3. Paste and run **`deploy/vypervic_wipe_and_reset.sql`** (F5). It:
   - drops all 14 app tables + stale ORDS bindings + legacy FKs,
   - recreates the exact schema the server expects (incl. `UQ_PROFILES_PHONE`),
   - re-enables ORDS **with authentication** (anonymous -> 401),
   - creates the `vypervic_app_server` OAuth client and grants it the AutoREST roles,
   - seeds the Super Admin: `vypervic1@gmail.com` / `VyperVic2008.` (trailing dot included).
4. The script prints a table with **`client_id` / `client_secret`**.
   Copy both into your password manager as `ORDS_OAUTH_CLIENT_ID` /
   `ORDS_OAUTH_CLIENT_SECRET`. You will paste them into the VPS env in step 7.
   The PART 6 self-check must show all 11 tables as `PRESENT`; anything
   `MISSING` means a REST binding failed — stop and paste the output back.
5. Still in SQL Worksheet, run **`deploy/migrations/003_write_fence_delivery_and_metadata.sql`**
   (write fence + delivery outbox; needs `EXECUTE` on `DBMS_LOCK`).
6. OCI -> VYPERVIC1 -> Manage access control lists: allow **only** the VPS
   egress IP(s) (plus your admin IP while testing, remove afterwards).

Sanity check from any outside network (replace host with your ADB host):

```sh
# Anonymous access must be DENIED:
curl -si https://<adb-host>/ords/admin/profiles/ | head -n 1
# expect: HTTP/2 401

# With an OAuth token it must work:
TOKEN=$(curl -s -X POST https://<adb-host>/ords/admin/oauth/token \
  -u "<ORDS_OAUTH_CLIENT_ID>:<ORDS_OAUTH_CLIENT_SECRET>" \
  -d "grant_type=client_credentials" | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
curl -si -H "Authorization: Bearer $TOKEN" https://<adb-host>/ords/admin/profiles/ | head -n 1
# expect: HTTP/2 200
```

---

## 2. Provision the VPS

- OS: **Ubuntu 24.04 LTS**, 2 vCPU / 4 GB RAM minimum (4 GB+ recommended with coturn).
- Open firewall ports: **22 (SSH, your IP only), 80 + 443 (public, for Caddy/ACME)**.
  Keep Node (3000), Redis (6379), coturn relay ports **off the public internet**
  except the TURN ports your mobile clients need (3478/5349, restricted as below).
- Create a non-root sudo user, disable password SSH, enable automatic security updates:

```sh
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git ufw fail2ban
sudo ufw allow 22/tcp && sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo ufw --force enable
```

---

## 3. Point DNS at the VPS

Create an `A` (and `AAAA` if you have IPv6) record:

```text
chat.example.com.   A   <VPS-IP>
```

Wait until `dig +short chat.example.com` returns the VPS IP. Caddy cannot
issue TLS certificates before this resolves.

---

## 4. Install base software on the VPS

```sh
# Node 22 (required: >=22.14, <25)
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs && node -v

# Caddy (TLS reverse proxy)
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
  | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
  | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update && sudo apt install -y caddy

# Private Redis + coturn + build tools
sudo apt install -y redis-server coturn python3 build-essential jq
```

---

## 5. Lock down Redis (private, authenticated, persistent)

Edit `/etc/redis/redis.conf`:

```conf
bind 127.0.0.1 ::1
protected-mode yes
port 6379
requirepass <STRONG-REDIS-PASSWORD-32+-CHARS>
appendonly yes
appendfsync everysec
```

```sh
sudo systemctl enable --now redis-server
redis-cli -a '<STRONG-REDIS-PASSWORD>' ping   # expect: PONG
```

The app env will use:
`REDIS_URL=redis://:<STRONG-REDIS-PASSWORD>@127.0.0.1:6379`
(All app instances must share this one Redis; a data-loss event means you must
rotate/invalidate sessions as part of recovery.)

---

## 6. Configure private coturn (TURN REST, secret never leaves the VPS)

1. Generate the shared secret (or reuse your already-provisioned one from the
   password manager — never commit it anywhere):

   ```sh
   openssl rand -hex 32
   ```

2. Edit `/etc/turnserver.conf`:

   ```conf
   listening-port=3478
   tls-listening-port=5349
   realm=chat.example.com
   server-name=chat.example.com
   use-auth-secret
   static-auth-secret=<TURN_SHARED_SECRET>
   realm=chat.example.com
   no-cli
   no-tcp-relay
   denied-peer-ip=0.0.0.0-0.255.255.255
   denied-peer-ip=10.0.0.0-10.255.255.255
   denied-peer-ip=172.16.0.0-172.31.255.255
   denied-peer-ip=192.168.0.0-192.168.255.255
   cert=/var/lib/caddy/.local/share/caddy/certificates/acme-v02.api.letsencrypt.org-directory/chat.example.com/chat.example.com.crt
   pkey=/var/lib/caddy/.local/share/caddy/certificates/acme-v02.api.letsencrypt.org-directory/chat.example.com/chat.example.com.key
   ```

   > The `cert`/`pkey` paths above are where Caddy stores the ACME certificate
   > after first issuance (step 8). Start coturn **after** the first deploy, or
   > point it at certificates you provision another way, then restart it.

3. Open only the TURN ports, then enable (after step 8's first TLS issuance,
   restart coturn so it picks up the certificate):

   ```sh
   sudo ufw allow 3478/tcp && sudo ufw allow 3478/udp
   sudo ufw allow 5349/tcp && sudo ufw allow 5349/udp
   sudo systemctl enable --now coturn
   ```

4. The app env will use (UDP + TCP + TLS are all required):

   ```text
   TURN_URLS=turn:chat.example.com:3478?transport=udp,turn:chat.example.com:3478?transport=tcp,turns:chat.example.com:5349?transport=tcp
   ```

---

## 7. Create the VPS runtime env file (the ONLY place secrets live)

Create `/secure/runtime.env` (or `/etc/vyper/runtime.env`), owned by root,
mode `600`:

```sh
sudo install -m 600 /dev/null /secure/runtime.env
sudo nano /secure/runtime.env
```

Fill it using this template. **Every `<...>` is a placeholder** — paste the
real values from your password manager / Firebase Console / step 1:

```env
NODE_ENV=production
HOST=127.0.0.1
PORT=3000
TRUST_PROXY=loopback
APP_URL=https://chat.example.com

# At least 32 chars. Generate: openssl rand -hex 48
JWT_SECRET=<PASTE-GENERATED-JWT-SECRET>

# Oracle ORDS (server-only; the app never sees these)
ORDS_BASE_URL=https://g9ebaca3b1e2945-vypervic1.adb.us-ashburn-1.oraclecloudapps.com/ords/admin
ORDS_OAUTH_CLIENT_ID=<FROM-STEP-1-PART-6>
ORDS_OAUTH_CLIENT_SECRET=<FROM-STEP-1-PART-6>
# (No ORDS_API_KEY: use exactly ONE auth mode — OAuth above.)

# Private Redis from step 5
REDIS_URL=redis://:<STRONG-REDIS-PASSWORD>@127.0.0.1:6379

# Firebase Admin SDK (VPS only). Private key on ONE line with literal \n.
FIREBASE_PROJECT_ID=vypervic-chatapp
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-fbsvc@vypervic-chatapp.iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n<...>\n-----END PRIVATE KEY-----\n"
FIRESTORE_DATABASE_ID=(default)

# Public browser Firebase config — MUST name the same project/database.
VITE_RUNTIME_MODE=browser
VITE_FIREBASE_PROJECT_ID=vypervic-chatapp
VITE_FIREBASE_API_KEY=<FIREBASE-WEB-API-KEY>
VITE_FIREBASE_AUTH_DOMAIN=vypervic-chatapp.firebaseapp.com
VITE_FIREBASE_STORAGE_BUCKET=<STORAGE-BUCKET>
VITE_FIREBASE_MESSAGING_SENDER_ID=<NUMERIC-SENDER-ID>
VITE_FIREBASE_APP_ID=1:<NUMERIC-SENDER-ID>:web:<WEB-APP-SUFFIX>
VITE_FIREBASE_DATABASE_ID=(default)
VITE_FIREBASE_VAPID_KEY=<WEB-PUSH-VAPID-KEY>

# Private coturn from step 6
TURN_URLS=turn:chat.example.com:3478?transport=udp,turn:chat.example.com:3478?transport=tcp,turns:chat.example.com:5349?transport=tcp
TURN_SHARED_SECRET=<FROM-STEP-6>

# Optional account-recovery mail. If omitted, reset requests return an honest
# 503 until a provider and verified sender are configured.
# RESEND_API_KEY=<RESEND-API-KEY>
# MAIL_FROM=VyperVic <no-reply@example.com>
```

### Variable-name translation (handover draft -> this repo)

Older planning notes used different names. **The repo names (right column)
are authoritative** — the server reads only these:

| Draft / planning name | Real variable in this repo |
|---|---|
| `ORACLE_ORDS_BASE_URL` | `ORDS_BASE_URL` |
| `ORACLE_CLIENT_ID` / `ORACLE_CLIENT_SECRET` | `ORDS_OAUTH_CLIENT_ID` / `ORDS_OAUTH_CLIENT_SECRET` |
| `APP_ORIGIN` | `APP_URL` (canonical `https://host`, no path) |
| `COOKIE_DOMAIN` | *(unused — `vyper_session` is a host-only cookie)* |
| `VITE_ORACLE_ORDS_URL` | **FORBIDDEN** — client must use same-origin `/api/oracle/*` only |
| `TURN_SERVER_URL` | `TURN_URLS` (UDP + TCP + TLS, comma-separated) |
| `FIREBASE_PRIVATE_KEY=" FIREBASE_PRIVATE_KEY="...` | single `FIREBASE_PRIVATE_KEY="-----BEGIN ...-----\n"` (one assignment, `\n` escapes, quoted) |

Validate the file before deploying (from your reviewed checkout, with the
file present on the VPS or securely copied):

```sh
npm ci
DOTENV_CONFIG_PATH=/secure/runtime.env npm run check:config
```

It must print no `Refusing unsafe production configuration` errors.

---

## 8. Deploy the app (first time and every update)

On the VPS as root, with DNS resolving and `/secure/runtime.env` in place:

```sh
# one-time: reviewed checkout the release is archived from
git clone <your-repo-url> /opt/vypervic-checkout
cd /opt/vypervic-checkout && git checkout <reviewed-commit> && git status --porcelain
# must print NOTHING (clean tree), then:
python3 scripts/scan-private-material.py --history   # must pass: no secrets in history

# deploy (builds a versioned release, validates, switches symlink, installs services)
sudo bash deploy/setup.sh --app-dir /opt/vypervic-checkout \
  --env-file /secure/runtime.env \
  --admin-cidrs '127.0.0.1/32 ::1/128 <YOUR-ADMIN-IP>/32'
```

The script installs `vyper.service` + the `vyper-edge-cleanup.timer`, writes
`/etc/caddy/sites.d/vyper.caddy`, and probes `/api/ready`. It refuses to
activate on failure and rolls the symlink back.

Finish Caddy once (the script tells you if this is missing):

```sh
grep -q 'import /etc/caddy/sites.d/\*.caddy' /etc/caddy/Caddyfile \
  || echo 'import /etc/caddy/sites.d/*.caddy' | sudo tee -a /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile && sudo systemctl reload caddy
```

Then restart coturn so it loads the freshly issued TLS certificate:

```sh
sudo systemctl restart coturn && sudo systemctl status coturn --no-pager
```

Check health:

```sh
curl -s http://127.0.0.1:3000/api/ready; echo
curl -sk https://chat.example.com/api/health; echo
```

---

## 9. Deploy Firestore rules + indexes + TTL

From your workstation (Firebase CLI, logged in, project `vypervic-chatapp`):

```sh
firebase use vypervic-chatapp
firebase deploy --only firestore:rules --project vypervic-chatapp
firebase deploy --only firestore:indexes --project vypervic-chatapp
```

- Database must be **(default)** (matches `FIRESTORE_DATABASE_ID` and
  `VITE_FIREBASE_DATABASE_ID`). For a named database, extend `firebase.json`
  / CLI config so you do not deploy to the wrong database.
- Wait for index builds to finish in the Console.
- Deploy the TTL policies for ephemeral edge collections (delivery-copy
  cleanup is namespace-scoped by the worker; native TTL is the backup).

---

## 10. Verify end to end (do not skip)

1. **Config gate:** `DOTENV_CONFIG_PATH=/secure/runtime.env npm run check:config` passes.
2. **Readiness:** `curl https://chat.example.com/api/ready` returns 200 with all checks ok.
3. **Admin login:** sign in as `vypervic1@gmail.com` / `VyperVic2008.`
   (trailing dot). DevTools -> Application -> Cookies must show an
   **HttpOnly** `vyper_session` cookie; `localStorage` must NOT contain the JWT.
4. **Oracle truth:** send a message; confirm the row exists in `MESSAGES` and a
   retry with the same client message id does not duplicate it.
5. **Presence/signaling:** two sessions see presence + typing; start a call,
   confirm TURN credentials are short-lived and media flows on two different
   mobile networks.
6. **Push:** on a physical Android device, background the app, send a message
   from another account, confirm exactly one notification (no duplicates).
7. **Logout:** revokes server session + Firebase session + push binding; no
   notifications arrive afterwards.
8. **Admin routes:** `/api/admin/*` is 403 from the public internet, allowed
   from your admin CIDR.
9. Full pass: work through `docs/STAGING-ACCEPTANCE.md` and record results.

---

## 11. Build the Android APK (same VPS build, native shell)

The Android app is a thin native shell (`android/`) that loads the VPS origin
in a locked-down WebView. Build flavors: `development`, `staging`, `production`.

```sh
# Per flavor: origin + Firebase project (production shown)
export PRODUCTION_APP_ORIGIN=https://chat.example.com
export PRODUCTION_FIREBASE_PROJECT_ID=vypervic-chatapp

# Per-flavor Firebase config (NEVER commit these; gitignored):
cp /secure/android/production-google-services.json \
   android/app/src/production/google-services.json

cd android
./gradlew :app:assembleProductionRelease \
  -PproductionAppOrigin=https://chat.example.com
```

Release signing values (`ANDROID_KEYSTORE_*`) live only in CI secret storage.
Serve `assetlinks.json` from the VPS origin with your package
(`com.vyper.chat`) + signing-cert SHA-256 so App Links verify:

```sh
curl -s https://chat.example.com/.well-known/assetlinks.json
```

On-device checks: cookie persists across restart, camera/mic prompts appear
only on the approved origin, FCM token registers after login (logcat:
`TokenRegistrationWorker`), deep links open inside the app, external links
open in the browser.

---

## 12. Operate it

```sh
journalctl -u vyper -f                        # app logs
systemctl status vyper-edge-cleanup.timer     # retention cleanup (runs ~1/min)
```

- **Update:** commit -> review -> `git pull` in the checkout ->
  re-run `deploy/setup.sh` (same command as step 8).
- **Rollback:** previous release dirs stay under `/var/lib/vyper/releases/`;
  re-point `/var/lib/vyper/current` at the last good one only if schema/config
  compatible, then `systemctl restart vyper`.
- **Rotate secrets:** JWT secret, Redis password, TURN secret, ORDS OAuth
  client (re-run PART 5 of the SQL), Firebase key (IAM -> delete old key).
  After Redis data loss, force session rotation.
- **Backups:** encrypted ADB backups (restore-tested) + Redis RDB/AOF copies.
  Never restore a backup that resurrects revoked sessions/tokens.
- **Monitoring:** alert on repeated `/api/ready` 503s, worker staleness,
  queued/failed/expired delivery growth, OAuth refresh failures, FCM error
  spikes, and rate-limit error bursts.

---

## Troubleshooting (fast answers)

| Symptom | Most likely cause |
|---|---|
| `check:config` refuses `FIREBASE_PRIVATE_KEY` | Key not quoted, real newlines instead of `\n`, or wrong project email |
| Server 401s to ORDS / token failures | Wrong `ORDS_OAUTH_*` pair, or AutoREST roles not granted (re-run SQL PART 5) |
| Anonymous `curl .../ords/...` returns 200 | ORDS auth not enabled — re-run SQL PART 4, verify 401 |
| Login says wrong password for the seeded admin | Password is `VyperVic2008.` **with** the trailing dot; verify the `USER_CREDENTIALS` row exists |
| Browser push fails, Android works | Missing/invalid `VITE_FIREBASE_VAPID_KEY` |
| Calls connect on Wi-Fi, fail on mobile data | coturn unreachable on 3478/5349, expired cert, or `TURN_URLS` missing a transport |
| `/api/admin/*` 403 for you too | Your IP is not in `--admin-cidrs` |
| `setup.sh` refuses: dirty tree / shallow clone | Commit everything; clone with full history (secret scan needs it) |
