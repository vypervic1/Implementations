-- VyperVic Oracle ORDS OAuth client regeneration
-- Database: VYPERVIC1 / schema: ADMIN
--
-- Purpose: replace only the application-server OAuth client and grant the
-- exact protected AutoREST roles required by the current VyperVic server.
-- This script does NOT wipe tables, delete users, or alter application rows.
-- Run in Oracle Database Actions -> SQL as the ADMIN schema owner.
-- Execute as a script (F5 / Run Script), not as a single statement.

SET SERVEROUTPUT ON

DECLARE
  TYPE role_list_t IS TABLE OF VARCHAR2(128);
  v_roles role_list_t := role_list_t(
    'oracle.dbtools.role.autorest.ADMIN.PROFILES',
    'oracle.dbtools.role.autorest.ADMIN.MESSAGES',
    'oracle.dbtools.role.autorest.ADMIN.CALLS',
    'oracle.dbtools.role.autorest.ADMIN.GROUPS',
    'oracle.dbtools.role.autorest.ADMIN.VAULT',
    'oracle.dbtools.role.autorest.ADMIN.AUDIT_LOGS',
    'oracle.dbtools.role.autorest.ADMIN.USER_PUSH_TOKENS',
    'oracle.dbtools.role.autorest.ADMIN.USER_CREDENTIALS',
    'oracle.dbtools.role.autorest.ADMIN.PASSWORD_RESETS',
    'oracle.dbtools.role.autorest.ADMIN.SCHEDULED_MESSAGES',
    'oracle.dbtools.role.autorest.ADMIN.DELETION_JOBS',
    'oracle.dbtools.role.autorest.ADMIN.DELIVERY_OUTBOX',
    'oracle.dbtools.role.autorest.ADMIN.MESSAGES_META',
    'oracle.dbtools.role.autorest.ADMIN.PROFILES_META',
    'oracle.dbtools.role.autorest.ADMIN.CALLS_META',
    'oracle.dbtools.role.autorest.ADMIN.GROUPS_META',
    'oracle.dbtools.role.autorest.ADMIN.VAULT_META',
    'oracle.dbtools.role.autorest.ADMIN.SCHEDULED_MESSAGES_META'
  );
  PROCEDURE grant_role(p_role VARCHAR2) IS
  BEGIN
    OAUTH.grant_client_role(
      p_client_name => 'vypervic_app_server',
      p_role_name   => p_role
    );
    DBMS_OUTPUT.PUT_LINE('GRANTED: ' || p_role);
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20011, 'ROLE GRANT FAILED [' || p_role || ']: ' || SQLERRM);
  END;
BEGIN
  -- Rotate only this named application client. Other ORDS clients are untouched.
  BEGIN
    OAUTH.delete_client(p_name => 'vypervic_app_server');
    DBMS_OUTPUT.PUT_LINE('OLD CLIENT REMOVED: vypervic_app_server');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('NO EXISTING CLIENT TO REMOVE: vypervic_app_server');
  END;

  OAUTH.create_client(
    p_name            => 'vypervic_app_server',
    p_grant_type      => 'client_credentials',
    p_owner           => 'VyperVic Messenger',
    p_description     => 'VyperVic Messenger application server',
    p_support_email   => 'vypervic1@gmail.com',
    p_privilege_names => NULL
  );
  DBMS_OUTPUT.PUT_LINE('NEW CLIENT CREATED: vypervic_app_server');

  -- Backend gate role used by /vyper-internal/* and the write gateway.
  grant_role('vyper_backend');

  -- Exact role names verified on the live ORDS instance.
  FOR i IN 1 .. v_roles.COUNT LOOP
    grant_role(v_roles(i));
  END LOOP;

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('SUCCESS: OAuth client rotated and 19 roles granted.');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RAISE;
END;
/

-- Copy both values exactly, including any trailing dots.
SELECT client_id, client_secret
FROM user_ords_clients
WHERE name = 'vypervic_app_server';

-- Expected external checks after updating the VPS:
-- Anonymous request: 401
-- Authenticated /profiles/: 200
-- Authenticated /vyper-internal/gate/: JSON with guardCount 10 and outboxTriggers 2
