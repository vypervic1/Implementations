import { metadataPage, publicMetadata } from './metadata';
import { withDataMutation } from './mutationGate';
import type { Express, Request, Response, RequestHandler } from 'express';
import { z } from 'zod';
import { ApiError, OracleError } from './errors';
import {
  ordsFetch, extractItems, normalizeServerRow, sanitizeProfileForClient, fetchRowById,
  fetchAllRows, fetchProfileById, fetchProfileByPhone, fetchGroupById, groupMembers, canInteractWith, isUniqueViolation, isValidPhoneNumber, normalizePhoneNumber, migrateLegacyCredentials,
} from './oracleBackend';
import { isChatParticipant } from './authz';
import { canonicalDmChatId, parseDmChatId } from './chatIds';
import { storeCallInvite, syncCallProjection, deleteCall } from './callState';
import { publishScopedEvent } from './realtimeBus';
import { sendPushToUsers } from './firebaseAdmin';
import { assertAccountsWritable } from './destructiveJobs';
import { withLease } from './sharedStore';

export const identifier = z.string().min(1).max(255).regex(/^[A-Za-z0-9_:-]+$/);
const timestamp = z.string().datetime({ offset: true });
const bool = z.union([z.boolean(), z.literal(0), z.literal(1)]).transform(v => v === true || v === 1);
const shortText = z.string().max(32000).nullable();
const image = z.string().max(1_000_000).refine(s => /^https:\/\/[^\s]+$/.test(s) || /^data:image\/(png|jpe?g|webp);base64,[A-Za-z0-9+/=]+$/.test(s)).nullable();
const messageFields = {
  id: identifier, chat_id: identifier, sender_id: identifier.optional(), recipient_id: identifier.nullable().optional(),
  text: shortText.optional(), file_name: z.string().max(500).nullable().optional(), file_type: z.string().max(255).nullable().optional(),
  file_data: z.string().max(4_000_000).refine(value => value !== '[stored_in_indexeddb]', 'Attachment placeholder is not content').nullable().optional(), is_voice: bool.optional(), duration: z.number().min(0).max(86400).nullable().optional(),
  is_edited: bool.optional(), is_encrypted: bool.optional(), status: z.literal('sent').optional(), created_at: timestamp.optional(),
};
export const messageCreateSchema = z.object(messageFields).strict();
const messageEditSchema = z.object({ text: shortText, is_edited: bool.optional() }).strict();
const profileEditSchema = z.object({
  display_name: z.string().trim().min(1).max(255).optional(), username: z.string().trim().toLowerCase().regex(/^[a-z0-9_]{3,100}$/).optional(),
  email: z.string().trim().toLowerCase().email().max(254).optional(), phone_number: z.union([z.string().max(100), z.null()]).optional(),
  about: z.string().max(1000).refine(s => !/\[auth:/i.test(s), 'Credential tags are forbidden').optional(),
  avatar_url: image.optional(), cover_url: image.optional(), is_online: bool.optional(), last_seen: timestamp.optional(), updated_at: timestamp.optional(),
}).strict();
const callCreateSchema = z.object({
  id: identifier, caller_id: identifier.optional(), receiver_id: identifier, type: z.enum(['voice', 'video']).default('voice'),
  status: z.literal('ringing').optional(), signal_data: z.null().optional(), created_at: timestamp.optional(), updated_at: timestamp.optional(),
}).strict();
const callEditSchema = z.object({
  status: z.enum(['ringing', 'accepted', 'ended', 'rejected', 'missed']).optional(),
  signal_data: z.string().max(64000).nullable().optional(), updated_at: timestamp.optional(),
}).strict();
const members = z.preprocess(v => {
  if (typeof v !== 'string') return v;
  try { return JSON.parse(v); } catch { return v; }
}, z.array(identifier).min(1).max(200).refine(v => new Set(v).size === v.length));
const adminIds = z.preprocess(v => { if (typeof v !== 'string') return v; try { return JSON.parse(v); } catch { return v; } }, z.array(identifier).max(200).refine(v => new Set(v).size === v.length));
const groupFields = { admins: adminIds.optional(), name: z.string().trim().min(1).max(255), members, icon: z.union([image, z.string().min(1).max(32).refine(value => !/[<>:\s]/.test(value))]).optional(), cover_url: image.optional(), description: z.string().max(1000).nullable().optional() };
const groupCreateSchema = z.object({ id: identifier, creator_id: identifier.optional(), ...groupFields, created_at: timestamp.optional() }).strict();
const groupEditSchema = z.object(groupFields).partial().strict();
const columns: Record<string, Set<string>> = {
  profiles: new Set(['ID', 'EMAIL', 'USERNAME', 'DISPLAY_NAME', 'PHONE_NUMBER', 'IS_ONLINE', 'CREATED_AT', 'LAST_SEEN']),
  messages: new Set(['ID', 'CHAT_ID', 'SENDER_ID', 'RECIPIENT_ID', 'CREATED_AT', 'STATUS']),
  calls: new Set(['ID', 'CALLER_ID', 'RECEIVER_ID', 'CREATED_AT', 'STATUS', 'TYPE']),
  groups: new Set(['ID', 'CREATOR_ID', 'CREATED_AT', 'NAME']),
};
export type Filter = Record<string, any>;
function parse<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) throw new ApiError(400, 'Invalid request fields', 'validation');
  return result.data;
}
export function canonicalBody(body: unknown): Record<string, any> {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new ApiError(400, 'JSON object required');
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(body)) {
    const name = key.toLowerCase();
    if (Object.hasOwn(out, name) || ['__proto__', 'constructor', 'prototype'].includes(name)) throw new ApiError(400, 'Duplicate or invalid column');
    out[name] = value;
  }
  return out;
}
function toOracle(row: Record<string, any>) {
  return Object.fromEntries(Object.entries(row).map(([k, v]) => [k.toUpperCase(), typeof v === 'boolean' ? Number(v) : v && typeof v === 'object' ? JSON.stringify(v) : v]));
}
export function validateFilter(input: unknown, table: string, depth = 0): Filter {
  if (depth > 4 || !input || typeof input !== 'object' || Array.isArray(input)) throw new ApiError(400, 'Invalid filter');
  const result: Filter = {};
  const entries = Object.entries(input);
  if (!entries.length || entries.length > 20) throw new ApiError(400, 'Empty or oversized filter');
  for (const [key, value] of entries) {
    if (key === '$or' || key === '$and') {
      if (!Array.isArray(value) || value.length < 1 || value.length > 20) throw new ApiError(400, 'Invalid logical filter');
      result[key] = value.map(v => validateFilter(v, table, depth + 1)); continue;
    }
    const name = key.toUpperCase();
    if (!columns[table]?.has(name) || Object.hasOwn(result, name)) throw new ApiError(400, 'Unsupported or duplicate filter column');
    const scalar = (v: unknown) => v === null || typeof v === 'boolean' || (typeof v === 'number' && Number.isFinite(v)) || (typeof v === 'string' && v.length <= 255);
    if (scalar(value)) result[name] = value;
    else {
      if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 1) throw new ApiError(400, 'Unsupported operator');
      const [op, operand] = Object.entries(value)[0];
      if (op === '$in' && Array.isArray(operand) && operand.length > 0 && operand.length <= 20 && operand.every(scalar)) result[name] = { $in: operand };
      else if (['$eq', '$gt', '$gte', '$lt', '$lte'].includes(op) && scalar(operand)) result[name] = { [op]: operand };
      else throw new ApiError(400, 'Unsupported operator');
    }
  }
  return result;
}
const equalValues = (v: any): unknown[] => v && typeof v === 'object' ? ('$eq' in v ? [v.$eq] : '$in' in v ? v.$in : []) : [v];
/** Every OR branch must be scoped; an AND may add restrictions but never widen a scoped branch. */
export async function filterIsScoped(filter: Filter, table: string, userId: string): Promise<boolean> {
  for (const [key, value] of Object.entries(filter)) {
    if (key === '$or' && (await Promise.all(value.map((v: Filter) => filterIsScoped(v, table, userId)))).every(Boolean)) return true;
    if (key === '$and' && (await Promise.all(value.map((v: Filter) => filterIsScoped(v, table, userId)))).some(Boolean)) return true;
    const values = equalValues(value);
    if (!values.length) continue;
    if (table === 'messages' && key === 'CHAT_ID' && (await Promise.all(values.map(v => typeof v === 'string' && isChatParticipant(v, userId)))).every(Boolean)) return true;
    if (table === 'messages' && key === 'SENDER_ID' && values.every(v => v === userId)) return true;
    if (table === 'calls' && key === 'CALLER_ID' && values.every(v => v === userId)) return true;
    if (table === 'calls' && key === 'RECEIVER_ID' && values.every(v => v === userId || v === 'general')) return true;
    if (key === 'ID' && (await Promise.all(values.map(async id => typeof id === 'string' && canReadRow(table, await fetchRowById(table, id), userId)))).every(Boolean)) return true;
  }
  return false;
}
async function canReadRow(table: string, row: any, userId: string): Promise<boolean> {
  if (!row) return false;
  if (table === 'messages') return isChatParticipant(String(row.chat_id || ''), userId);
  if (table === 'calls') return row.caller_id === userId || row.receiver_id === userId || row.receiver_id === 'general';
  if (table === 'groups') return groupMembers(row).includes(userId);
  return table === 'profiles';
}
export function assertCallTransition(call: any, status: string, userId: string): void {
  if (![call.caller_id, call.receiver_id].includes(userId)) throw new ApiError(403, 'Not a call participant');
  if (status === call.status) return;
  const allowed: Record<string, string[]> = { ringing: ['accepted', 'rejected', 'ended', 'missed'], accepted: ['ended'] };
  if (!allowed[call.status]?.includes(status)) throw new ApiError(409, 'Invalid call state transition');
  if (['accepted', 'rejected'].includes(status) && userId !== call.receiver_id) throw new ApiError(403, 'Only the receiver may answer this call');
  if (status === 'missed' && Date.now() - Date.parse(call.created_at) < 30000) throw new ApiError(409, 'Call has not expired');
}
export async function persistMessage(input: unknown, userId: string): Promise<any> {
  return withDataMutation(() => persistMessageUnlocked(input, userId));
}
async function persistMessageUnlocked(input: unknown, userId: string): Promise<any> {
  await assertAccountsWritable([userId]);
  const data = parse(messageCreateSchema, canonicalBody(input));
  const sender = await fetchProfileById(userId);
  if (!sender) throw new ApiError(403, 'Sender account is unavailable');
  if (data.sender_id && data.sender_id !== userId) throw new ApiError(403, 'Forged sender');
  if (!(await isChatParticipant(data.chat_id, userId))) throw new ApiError(403, 'Not a chat member');
  const dm = parseDmChatId(data.chat_id);
  const recipient = dm ? dm.find(id => id !== userId)! : null;
  if (dm && data.chat_id !== canonicalDmChatId(dm[0], dm[1])) throw new ApiError(400, 'Direct-message chat ID must use canonical ordering');
  if (data.recipient_id && data.recipient_id !== recipient) throw new ApiError(403, 'Recipient does not match chat');
  if (recipient) await assertAccountsWritable([recipient]);
  if (recipient && !(await fetchProfileById(recipient))) throw new ApiError(400, 'Unknown recipient');
  if (!data.text && !data.file_data) throw new ApiError(400, 'Message content required');
  const row = { ...data, sender_id: userId, recipient_id: recipient, status: 'sent', is_edited: false, created_at: new Date().toISOString() };
  const inserted = await ordsFetch('/messages/', { method: 'POST', body: toOracle(row) });
  if (!inserted.ok && !isUniqueViolation(inserted)) throw new OracleError(inserted.status);
  const saved = await fetchRowById('messages', data.id);
  if (!saved || saved.sender_id !== userId || saved.chat_id !== data.chat_id) throw new ApiError(409, 'Message ID is already in use');
  for (const key of ['text', 'file_name', 'file_type', 'file_data', 'duration', 'recipient_id'] as const) {
    if ((saved[key] ?? null) !== (row[key] ?? null)) throw new ApiError(409, 'Message ID was reused with different content');
  }
  for (const key of ['is_voice', 'is_encrypted']) if (!!saved[key] !== !!row[key as keyof typeof row]) throw new ApiError(409, 'Message ID content conflict');
  // Oracle is authoritative; secondary delivery failures never turn a committed insert into an unacknowledged message.
  try { await publishScopedEvent('new_message', { message: publicMetadata('messages', saved) }, { chatId: saved.chat_id }); }
  catch { console.error('[Messages] Realtime projection failed after commit; Oracle reconciliation required'); }
  return saved;
}

export function installOracleRoutes(app: Express, requireAuth: RequestHandler, rateLimit: RequestHandler) {
  const handle = (req: Request, res: Response, table: string, rowId?: string) => ['GET', 'HEAD'].includes(req.method) ? handleUnlocked(req, res, table, rowId) : withDataMutation(() => handleUnlocked(req, res, table, rowId));
  const handleUnlocked = async (req: Request, res: Response, table: string, rowId?: string) => {
    if (!columns[table]) throw new ApiError(404, 'Unknown table');
    if (rowId) parse(identifier, rowId);
    const userId = req.user!.sub;
    const method = req.method === 'HEAD' ? 'GET' : req.method;
    if (!['GET', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(method) || (method === 'POST' && rowId) || (['PUT', 'PATCH', 'DELETE'].includes(method) && !rowId)) throw new ApiError(405, 'Unsupported method');
    if (Object.keys(req.query).some(key => !['q', 'limit', 'offset', 'order'].includes(key))) throw new ApiError(400, 'Unsupported query parameter');
    const limit = req.query.limit === undefined ? 100 : Number(req.query.limit);
    const offset = req.query.offset === undefined ? 0 : Number(req.query.offset);
    if (!Number.isInteger(limit) || limit < 1 || limit > 1000 || !Number.isInteger(offset) || offset < 0 || offset > 1_000_000) throw new ApiError(400, 'Invalid pagination');
    let filter: Filter = {};
    if (req.query.q !== undefined) {
      if (typeof req.query.q !== 'string' || req.query.q.length > 4096) throw new ApiError(400, 'Invalid filter');
      let raw: unknown; try { raw = JSON.parse(req.query.q); } catch { throw new ApiError(400, 'Invalid filter JSON'); }
      filter = validateFilter(raw, table);
    }
    let order: Record<string, string> = { ID: 'asc' };
    if (req.query.order !== undefined) {
      if (typeof req.query.order !== 'string' || !/^[a-z_]+\.(asc|desc)$/i.test(req.query.order)) throw new ApiError(400, 'Invalid order');
      const [col, dir] = req.query.order.split('.');
      if (!columns[table].has(col.toUpperCase())) throw new ApiError(400, 'Unsupported order column');
      order = { [col.toUpperCase()]: dir.toLowerCase(), ID: 'asc' };
    }
    if (method === 'GET') {
      if (rowId) {
        if (req.query.q !== undefined) throw new ApiError(400, 'Row reads do not accept filters');
        const row = await fetchRowById(table, rowId);
        if (!(await canReadRow(table, row, userId))) throw new ApiError(403, 'Row not found or inaccessible');
        return res.json(table === 'profiles' ? sanitizeProfileForClient(row) : row);
      }
      if (table === 'groups') {
        const rows = (await fetchAllRows('groups', filter)).filter(row => groupMembers(row).includes(userId));
        const items = rows.slice(offset, offset + limit).map(row => publicMetadata('groups', row));
        return res.json(req.path.startsWith('/api/oracle') ? items : { items, hasMore: rows.length > offset + limit, offset, limit });
      }
      if (table !== 'profiles' && !(await filterIsScoped(filter, table, userId))) throw new ApiError(403, 'Private reads require an authorized scope');
      const page = await metadataPage(table, { ...filter, $orderby: order }, limit, offset);
      for (const row of page.rows) if (!await canReadRow(table, row, userId)) throw new ApiError(502, 'Database returned an out-of-scope row');
      return res.json({ ...page, rows: undefined, items: page.rows.map(row => publicMetadata(table, row)), count: page.rows.length });
    }
    if (Object.keys(req.query).length) throw new ApiError(400, 'Mutation queries are not supported');
    await assertAccountsWritable([userId]);
    const body = canonicalBody(req.body || {});
    if (table === 'profiles' && (method === 'POST' || method === 'DELETE')) throw new ApiError(405, 'Use account endpoints');
    if (method === 'POST' && table === 'messages') return res.status(201).json(await persistMessage(body, userId));
    if (method === 'POST' && table === 'calls') {
      const call = parse(callCreateSchema, body);
      if (call.caller_id && call.caller_id !== userId) throw new ApiError(403, 'Forged caller');
      if (call.receiver_id === 'general' || call.receiver_id.startsWith('group:')) throw new ApiError(409, 'Group calling is disabled until durable participant signaling is supported');
      if (call.receiver_id === userId || call.receiver_id !== 'general' && !(await canInteractWith(userId, call.receiver_id))) throw new ApiError(403, 'Unauthorized call recipient');
      await assertAccountsWritable([call.receiver_id]);
      const row = { ...call, caller_id: userId, status: 'ringing', created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      const inserted = await ordsFetch('/calls/', { method: 'POST', body: toOracle(row) });
      if (!inserted.ok && !isUniqueViolation(inserted)) throw new OracleError(inserted.status);
      const saved = await fetchRowById('calls', call.id);
      if (!saved || saved.caller_id !== userId || saved.receiver_id !== row.receiver_id || saved.type !== row.type) throw new ApiError(409, 'Call ID is already in use');
      if (saved.status === 'ringing') await storeCallInvite(saved);
      if (inserted.ok) {
        try { await publishScopedEvent('call_invite', { call: saved }, { userIds: [userId, saved.receiver_id] }); } catch { console.error('[Calls] Realtime projection unavailable'); }
      }
      return res.status(201).json(saved);
    }
    if (method === 'POST' && table === 'groups') {
      const group = parse(groupCreateSchema, body);
      if (group.creator_id && group.creator_id !== userId || !group.members.includes(userId)) throw new ApiError(403, 'Creator must be a member');
      if ((group.admins || []).some(uid => !group.members.includes(uid))) throw new ApiError(400, 'Administrators must be group members');
      await assertAccountsWritable(group.members);
      for (const member of group.members) if (!(await fetchProfileById(member))) throw new ApiError(400, 'Unknown group member');
      const row = { ...group, creator_id: userId, created_at: new Date().toISOString() };
      const inserted = await ordsFetch('/groups/', { method: 'POST', body: toOracle(row) });
      if (isUniqueViolation(inserted)) throw new ApiError(409, 'Group ID is already in use');
      if (!inserted.ok) throw new OracleError(inserted.status);
      try { await publishScopedEvent('vyper_group_created', { group: row }, { userIds: row.members }); } catch { console.error('[Groups] Realtime projection pending'); }
      return res.status(201).json(row);
    }
    return withLease(`${table}:${rowId}`, async assertHeld => {
      const existing = await fetchRowById(table, rowId!);
      if (!existing || !(await canReadRow(table, existing, userId))) throw new ApiError(403, 'Row not found or inaccessible');
      if (table === 'profiles' && rowId !== userId || table === 'messages' && existing.sender_id !== userId || table === 'groups' && existing.creator_id !== userId && !(Array.isArray(existing.admins) && existing.admins.includes(userId))) throw new ApiError(403, 'Only the owner may modify this resource');
      if (table === 'calls' && ![existing.caller_id, existing.receiver_id].includes(userId)) throw new ApiError(403, 'Only call participants may modify this resource');
      if (method === 'DELETE' && table === 'groups' && existing.creator_id !== userId) throw new ApiError(403, 'Only the creator can disband a group');
      if (method === 'DELETE') {
        if (table === 'calls') await deleteCall(rowId!);
        assertHeld();
        const deleted = await ordsFetch(`/${table}/${encodeURIComponent(rowId!)}`, { method: 'DELETE' });
        if (!deleted.ok && deleted.status !== 404) throw new OracleError(deleted.status);
        try {
          if (table === 'messages') await publishScopedEvent('delete_message', { messageId: rowId, chatId: existing.chat_id }, { chatId: existing.chat_id });
          if (table === 'groups') await publishScopedEvent('vyper_group_removed', { groupId: rowId }, { userIds: groupMembers(existing) });
        } catch { console.error('[API] Deletion committed; realtime reconciliation required'); }
        return res.json({ ok: true });
      }
      let changes: Record<string, any>;
      if (table === 'profiles') {
        changes = parse(profileEditSchema, body);
        if (Object.hasOwn(changes, 'phone_number')) {
          changes.phone_number = normalizePhoneNumber(changes.phone_number);
          if (!isValidPhoneNumber(changes.phone_number)) throw new ApiError(400, 'Enter a valid phone number with at least 7 digits.');
          if (changes.phone_number) {
            const duplicate = await fetchProfileByPhone(changes.phone_number);
            if (duplicate && duplicate.id !== userId) throw new ApiError(409, 'That phone number is already bound to another account.');
          }
        }
        if (existing.password_hash && !(await migrateLegacyCredentials(existing))) throw new ApiError(503, 'Credential migration required');
      } else if (table === 'messages') changes = { ...parse(messageEditSchema, body), is_edited: true };
      else if (table === 'groups') {
        changes = parse(groupEditSchema, body);
        const oldAdmins: string[] = Array.isArray(existing.admins) ? existing.admins : [];
        const nextAdmins: string[] = changes.admins || oldAdmins;
        const nextMembers: string[] = changes.members || groupMembers(existing);
        const changedRoles = JSON.stringify([...oldAdmins].sort()) !== JSON.stringify([...nextAdmins].sort());
        if (existing.creator_id !== userId && (changedRoles || oldAdmins.some(id => !nextMembers.includes(id)))) throw new ApiError(403, 'Only the creator can change group administrator roles');
        if (nextAdmins.some(id => !nextMembers.includes(id))) throw new ApiError(400, 'Administrators must remain group members');
        if (changes.members && !changes.members.includes(existing.creator_id)) throw new ApiError(400, 'Creator must remain a member');
        if (changes.members) await assertAccountsWritable(changes.members);
        for (const member of changes.members || []) if (!(await fetchProfileById(member))) throw new ApiError(400, 'Unknown member');
      } else {
        changes = { ...parse(callEditSchema, body), updated_at: new Date().toISOString() };
        if (changes.status) assertCallTransition(existing, changes.status, userId);
      }
      if (!Object.keys(changes).length) throw new ApiError(400, 'No mutable fields');
      assertHeld();
      const updated = await ordsFetch(`/${table}/${encodeURIComponent(rowId!)}`, { method: 'PATCH', body: toOracle(changes) });
      if (isUniqueViolation(updated)) throw new ApiError(409, table === 'profiles' && Object.hasOwn(changes, 'phone_number')
        ? 'That phone number is already bound to another account.' : 'Value already exists');
      if (!updated.ok) throw new OracleError(updated.status);
      const row = await fetchRowById(table, rowId!);
      if (table === 'groups') { try {
        const remaining = groupMembers(row), removed = groupMembers(existing).filter(id => !remaining.includes(id));
        await publishScopedEvent('vyper_group_updated', { group: row }, { userIds: remaining });
        if (removed.length) await publishScopedEvent('vyper_group_removed', { groupId: row.id }, { userIds: removed });
      } catch { console.error('[Groups] Realtime projection pending'); } }
      if (table === 'calls') await syncCallProjection(row);
      if (table === 'calls') { try { await publishScopedEvent('call_status_update', { callId: row.id, status: row.status }, { userIds: [row.caller_id, row.receiver_id] }); } catch { console.error('[Calls] Realtime update unavailable'); } }
      return res.json(table === 'profiles' ? sanitizeProfileForClient(row) : row);
    });
  };
  app.get('/api/messages/feed', requireAuth, rateLimit, async (req, res) => {
    const query = z.object({ limit: z.coerce.number().int().min(1).max(1000).default(200), offset: z.coerce.number().int().min(0).max(10000).default(0),
      before: timestamp.optional(), after: timestamp.optional(), afterId: identifier.optional(), order: z.enum(['created_at.asc', 'created_at.desc']).optional() }).strict().safeParse(req.query);
    if (!query.success) throw new ApiError(400, 'Invalid inbox query');
    const { limit, offset } = query.data, userId = req.user!.sub;
    const groups = (await fetchAllRows('groups')).filter(row => groupMembers(row).includes(userId));
    const chats = new Set(['general', ...groups.map(row => row.id.startsWith('group:') ? row.id : `group:${row.id}`)]);
    const rows = (await fetchAllRows('messages')).filter(row => {
      const dm = parseDmChatId(String(row.chat_id || ''));
      const visibleDm = !!dm && dm.includes(userId);
      return chats.has(row.chat_id) || visibleDm || row.sender_id === userId || row.recipient_id === userId;
    }).filter(row => !query.data.before || Date.parse(row.created_at) <= Date.parse(query.data.before))
      .filter(row => !query.data.after || Date.parse(row.created_at) > Date.parse(query.data.after) || (Date.parse(row.created_at) === Date.parse(query.data.after) && query.data.afterId && String(row.id) > query.data.afterId))
      .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || String(a.id).localeCompare(String(b.id)));
    const visible = [];
    for (const row of rows) if (await canReadRow('messages', row, userId)) visible.push(publicMetadata('messages', row));
    const items = visible.slice(offset, offset + limit);
    res.json({ items, count: items.length, offset, limit, hasMore: offset + limit < visible.length, nextOffset: offset + items.length, cursor: items.at(-1)?.created_at || null });
  });
  // Typed routes are the preferred contract. The legacy adapter invokes the exact same policy.
  app.get('/api/chats/:chatId/messages', requireAuth, rateLimit, (req, res) => {
    if (req.query.q !== undefined) throw new ApiError(400, 'Use the chat path for scope');
    req.query.q = JSON.stringify({ CHAT_ID: parse(identifier, req.params.chatId) });
    return handle(req, res, 'messages');
  });
  app.post('/api/chats/:chatId/messages', requireAuth, rateLimit, (req, res) => {
    const body = canonicalBody(req.body);
    if (body.chat_id && body.chat_id !== req.params.chatId) throw new ApiError(400, 'Chat path mismatch');
    req.body = { ...body, chat_id: req.params.chatId };
    return handle(req, res, 'messages');
  });
  for (const table of ['messages', 'calls', 'groups']) {
    app.all(`/api/${table}/:id`, requireAuth, rateLimit, (req, res) => handle(req, res, table, req.params.id));
  }
  for (const table of ['groups', 'calls']) app.all(`/api/${table}`, requireAuth, rateLimit, (req, res) => handle(req, res, table));
  app.all('/api/profile', requireAuth, rateLimit, (req, res) => handle(req, res, 'profiles', req.user!.sub));
  app.all('/api/oracle/*', requireAuth, rateLimit, (req, res) => {
    const path = req.path.slice('/api/oracle/'.length).replace(/\/$/, '');
    const parts = path.split('/');
    if (parts.length > 2) throw new ApiError(404, 'Invalid resource path');
    let id: string | undefined;
    try { id = parts[1] ? decodeURIComponent(parts[1]) : undefined; } catch { throw new ApiError(400, 'Invalid resource ID'); }
    return handle(req, res, parts[0], id);
  });
}
