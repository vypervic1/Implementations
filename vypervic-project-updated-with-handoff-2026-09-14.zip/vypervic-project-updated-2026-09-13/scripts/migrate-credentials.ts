import 'dotenv/config';
import { fetchAllRows, fetchProfileById, normalizeServerRow, migrateLegacyCredentials, fetchCredentials, ordsFetch } from '../src/server/oracleBackend';
const apply = process.argv.includes('--apply');
let found = 0, migrated = 0;
for (const raw of await fetchAllRows('profiles')) {
  const profile = await fetchProfileById(raw.id);
  if (!profile) continue;
  if (!profile.id) throw new Error('Profile without ID');
  if (profile.password_hash && profile.password_salt) {
    found++;
    if (apply) { if (!await migrateLegacyCredentials(profile)) throw new Error('Credential migration incomplete'); migrated++; }
  } else if (apply && await fetchCredentials(profile.id)) {
    const result = await ordsFetch(`/profiles/${encodeURIComponent(profile.id)}`, { method: 'PATCH', body: { ABOUT: String(profile.about || '').replace(/\[auth:[^\]]*\]/gi, '').trim(), PASSWORD_HASH: null, PASSWORD_SALT: null } });
    if (!result.ok) throw new Error('Profile scrubbing incomplete');
  }
}
console.log(JSON.stringify({ mode: apply ? 'apply' : 'dry-run', profilesWithLegacyVerifiers: found, migrated }));
