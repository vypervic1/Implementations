export type SessionStatus = 'checking' | 'authenticated' | 'offline' | 'signed-out';
let status: SessionStatus = 'checking';
let userId: string | null = null;
let edgeReady = false;
export function setEdgeReady(ready: boolean) { edgeReady = ready; }
export function getSessionStatus() { return { status, userId, edgeReady }; }
export function setSessionStatus(next: SessionStatus, id: string | null = null) {
  status = next; userId = id;
  if (next === 'signed-out') edgeReady = false;
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('vyper_session_status', { detail: { status, userId } }));
}
