# Arena ChatApp remediation status

**Status: substantial implementation completed; NOT production-ready or deployment-accepted.**

This pass implements a real native Android project using the VPS HTTPS origin, hardens the server boundary, and adapts the client. It does not claim a signed/device-tested APK, deployed Firebase rules, live Oracle acceptance, cloud credential rotation or a history purge.

## Important release blocker

A full fetched-history scan found **one usable historical Firebase private key** in `src/server/firebaseAdmin.ts` (blob `596fcdda0370`). No key value is reproduced. Current source is clean of that material; production rejects its non-secret public-key fingerprint. The key still needs **provider-side revocation and repository-wide history/cache cleanup**. The CI secret gate intentionally fails until this is resolved. See [incident response](docs/SECURITY-INCIDENT.md).

## Follow-up status

The subsequent user-requested implementation pass is documented in [REMAINING-FIXES-PASS.md](docs/REMAINING-FIXES-PASS.md). It closes the listed session races, adds epoch-fenced maintenance and asynchronous operation receipts, rewires the admin dashboard, adds transactional notification intents/retries, improves outbox/cache/media lifecycle behavior, and restores server-enforced delegated group administration. **Migration 003 is mandatory and has not been validated on real Oracle.**

GitHub API repository reads are working again, but **Git push still fails authentication** (including through the existing `gh` credential helper). The implementation is committed locally on the session branch; remote CI has not run and nothing was merged/deployed. Reconnect GitHub in Arena to restore push authentication. Latest local verification: **124 tests across 13 files passed**, plus **5 real Redis multi-process tests on the current revision**; typecheck, lint, build and audit passed. Startup JS is **202.2 KiB gzip**. Native/emulator/live-service acceptance remains outstanding.

## Implemented in this checkout

### Server and data boundary

- Typed message/chat/group/call/profile APIs and a legacy adapter sharing strict schemas, operator/column/method bounds and row/relationship checks. Server credentials and direct ORDS endpoints remain server-only; backend bundles are not served as public assets.
- Verified cookie identity, current database role, explicit reauthentication, distributed Redis limits/leases/revocation and no long-lived application JWT in browser storage/SSE URLs.
- Real ORDS OAuth caching/expiry/401 retry, response bounds, normalized uniqueness migration and deterministic pagination that advances by actual rows when ORDS caps page sizes.
- Durable message acknowledgment and stable IDs; broadcasts verify persisted state and do not create call/message/group state. Explicit-audience SSE/Redis fan-out, heartbeat/backoff/reconciliation and slower periodic recovery.
- Oracle-backed FCM registration, source/device/session metadata, provider validation, expiry/revocation, device cap, masked device listing and invalid-token removal. Sends derive identity and authorize recipients; FCM acceptance is not a device-delivery receipt.
- Oracle-authoritative calls with transactional Firestore projection/recovery; no configured-production memory fallback. Private short-lived TURN credentials, reconnect/ICE-restart/failure handling; general/group calling is explicitly disabled.
- Deny-by-default Firestore rules, account-version and session gates, immutable signaling identity/path/retention, bounded payloads/presence, server-only outbox and namespace-scoped delivery cleanup.
- Resumable account deletion/wipe jobs with confirmations, fresh authentication, durable steps/counts/audit, retries and profile-last deletion; unrelated calls are scoped out. These are **not globally atomic cross-store transactions**.
- Durable scheduler leases, deterministic message IDs, checked claim/ack writes, stale recovery, bounded retry/dead letters. Browser fallback delivery of a failed server schedule has been removed.

### Browser and Android

- Cached profiles are display-only; authenticated state comes from `/api/auth/me`. Failed signup/profile writes no longer fabricate an account or report success. Offline/read-only/sync-pending state is visible; logout/revocation clears application caches and native notification state.
- IndexedDB outbox writes await transaction commit before network send; stable IDs/attachment bytes/retry metadata survive reopening. Legacy cached verifiers are scrubbed. Listener/media cleanup and lazy Firestore/browser-only Web Push separation were improved.
- Profile, cover and group writes wait for Oracle. Group creation is no longer a local-only broadcast; delegated group-admin UI is disabled rather than pretending to grant an unsupported permission.
- Native Android WebView, origin-restricted v1 bridge, camera/mic/notification permission handling, FirebaseMessagingService, WorkManager token refresh, monochrome icons, exact notification channels and validated deep links. Web Push workers are not registered in native mode.
- Debug/staging/production flavors, public Firebase configuration validation, protected signing inputs, Gradle wrapper and CI candidate workflows. Ongoing calls are foreground-only; there is no Android Telecom/foreground-call service.

### Delivery and verification tooling

- Additive SQL/bootstrap/ORDS protection scripts; deprecated destructive SQL now stops by default. Firebase rules/index/TTL deployment files and credential-scrubbing tooling.
- Real ESLint, separate TypeScript checks, npm lockfile, unit/integration contracts, isolated real-Redis multi-process tests, emulator abuse/recovery suites, build/bundle budget checks and non-optional secret-scanning CI.
- Versioned VPS deployment with protected runtime environment, private Node boundary, admin CIDR restrictions, readiness probes and an independent cleanup timer. CI/demo artifacts cannot be accepted as production configuration.

## Earlier-pass evidence (superseded by the follow-up above)

Final local verification for this pass (2026-09-08):

- TypeScript and ESLint passed.
- **103 tests across 8 files passed** (HTTP authorization/ORDS mock, scheduler/deletion failure paths, configuration, IndexedDB and native bridge contracts).
- **5 real Redis tests passed on an earlier revision in this session**: independent-process limits and revocation, competing leases, crashed-worker expiry recovery and fail-closed outage behavior. The latest session-gate changes still need that suite rerun: the final attempt was blocked while fetching test tooling by a GitHub authentication failure, and no local Redis service remained available.
- The final client/server/service-worker/cleanup-worker contract build passed. Startup JavaScript is **198.5 KiB gzip** (420 KiB budget); Firestore and Web Push are absent from the unauthenticated startup graph. Dependency audit reported **0 vulnerabilities**. Workflow YAML parsing, shell syntax, `git diff --check`, and rejection of missing production configuration also passed.
- Private-material scan: no current private-key material; the known historical key remains. A full 22-commit history was inspected earlier; the final restored checkout is shallow and its refresh was blocked by GitHub authentication. **This is a failed release gate, not a passing complete secret audit.**
- Firestore emulator tests and native Gradle/device tests are provided but have **not run locally**; Java/Android tooling downloads were unavailable. No cloud deployment, real FCM delivery, private TURN call, actual ORDS CRUD acceptance or signed APK has been verified.

The earlier GitHub authentication failure was resolved for repository reads in the follow-up. No credentials should be supplied in chat.

## Earlier-pass backlog (see the follow-up for implemented fixes and current remaining boundaries)

1. Revoke exposed credentials, complete repository-wide history/cache cleanup, verify IAM and install real environment secrets.
2. Execute the real migrations, OAuth/CRUD/pagination checks, Firebase rule/index/TTL deployment and durable-service outage/restart tests. Confirm current project/database/version settings against live services.
3. Build and validate the Android project in CI/an SDK-equipped environment; fix any native compile/lint issues before producing a signed candidate. Complete physical-device permission, notification, session, network and lifecycle tests.
4. Exercise concurrent/in-flight writers during deletion/wipe, cross-store partial failures and large datasets. A global wipe requires writer quiescence/draining; the implemented checkpoints alone do not prove isolation or globally atomic deletion.
5. Finish integration/performance review of the remaining legacy UI (including privileged aggregate views, cache eviction, large inline attachments, detailed failed-outbox UX and repeated navigation/media lifetimes). Generic APIs were intentionally restricted; unit mocks/type checks do not certify every screen or every large-data scenario.
6. Verify production firewall/backup/restore/monitoring/incident controls. Revisit disabled group/delegated-admin/background-call features only with a durable authorization and lifecycle design.

## Run and deploy references

- [Native Android build and limitations](docs/ANDROID.md)
- [VPS deployment and migrations](deploy/README-AZURE.md)
- [Mandatory staging acceptance](docs/STAGING-ACCEPTANCE.md)
- [Credential incident response](docs/SECURITY-INCIDENT.md)

```sh
npm ci
npm run lint
npm run typecheck
npm test
TEST_REDIS_URL=redis://127.0.0.1:6379/15 npm run test:redis
npm run build:ci && npm run check:bundle      # explicitly non-deployable build
npm audit --audit-level=high
npm run scan:private                       # expected to fail on the historical key
# With Java and the emulator available:
npx --yes firebase-tools@15.29.0 emulators:exec --only firestore --project demo-arena-chatapp 'npm run test:rules'
```
