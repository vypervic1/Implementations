import { createPrivateKey, createPublicKey, createHash } from 'node:crypto';
import compromised from './compromisedKeyFingerprints.json';
import { browserConfig } from '../shared/firebaseConfiguration';

export const isProduction = (): boolean => process.env.NODE_ENV === 'production';
export interface ConfigProblem { var: string; problem: string }
function httpsUrl(value: string | undefined, originOnly = false): boolean {
  try {
    const u = new URL(value || '');
    return u.protocol === 'https:' && !u.username && !u.password && !u.search && !u.hash &&
      (!originOnly || u.pathname === '/');
  } catch { return false; }
}
export function allowedOrigins(): string[] {
  return [process.env.APP_URL, process.env.CORS_ORIGIN].filter(Boolean).join(',').split(',')
    .map(s => s.trim().replace(/\/+$/, '')).filter(s => /^https?:\/\//.test(s) && s !== '*');
}
export function resolveCorsOrigin(origin: string | undefined): string | null {
  const clean = origin?.trim().replace(/\/+$/, '');
  return clean && allowedOrigins().includes(clean) ? clean : null;
}
export function collectProductionConfigProblems(): ConfigProblem[] {
  if (!isProduction()) return [];
  const problems: ConfigProblem[] = [];
  const add = (name: string, problem: string) => problems.push({ var: name, problem });
  if (process.env.VYPER_CI_BUILD === '1' || process.env.VITE_FIREBASE_PROJECT_ID?.startsWith('demo-')) add('VYPER_CI_BUILD', 'test/demo builds must never run in production');
  if (process.env.ALLOW_TEST_PUSH_TOKENS === 'true') add('ALLOW_TEST_PUSH_TOKENS', 'test-only bypass is forbidden in production');
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) add('JWT_SECRET', 'must be a secret of at least 32 characters');
  if (!httpsUrl(process.env.APP_URL, true)) add('APP_URL', 'must be the canonical HTTPS origin (no path or credentials)');
  if (!httpsUrl(process.env.ORDS_BASE_URL)) add('ORDS_BASE_URL', 'must be an explicit HTTPS schema URL');
  if (!process.env.ORDS_API_KEY && !(process.env.ORDS_OAUTH_CLIENT_ID && process.env.ORDS_OAUTH_CLIENT_SECRET)) {
    add('ORDS_API_KEY', 'configure ORDS_OAUTH_CLIENT_ID and ORDS_OAUTH_CLIENT_SECRET, or a gateway API key');
  }
  if (!!process.env.ORDS_OAUTH_CLIENT_ID !== !!process.env.ORDS_OAUTH_CLIENT_SECRET) add('ORDS_OAUTH_*', 'partial credentials');
  if (process.env.ORDS_API_KEY && process.env.ORDS_OAUTH_CLIENT_ID) add('ORDS_*', 'select exactly one authentication mode');
  if (!/^rediss?:\/\//.test(process.env.REDIS_URL || '')) add('REDIS_URL', 'required for shared rate limits, revocation, locks and realtime');
  const fields = ['PROJECT_ID', 'CLIENT_EMAIL', 'PRIVATE_KEY'];
  const count = fields.filter(f => process.env[`FIREBASE_${f}`]).length;
  if (count !== fields.length) add('FIREBASE_*', 'project ID, client email and private key are all required for FCM');
  else {
    if (process.env.FIRESTORE_PROJECT_ID && process.env.FIRESTORE_PROJECT_ID !== process.env.FIREBASE_PROJECT_ID) {
      add('FIREBASE_PROJECT_ID', 'must match FIRESTORE_PROJECT_ID; split Firebase projects are not supported');
    }
    try {
      const key = createPrivateKey(process.env.FIREBASE_PRIVATE_KEY!.replace(/\\n/g, '\n'));
      if (key.asymmetricKeyType !== 'rsa') throw new Error('not RSA');
      const fingerprint = createHash('sha256').update(createPublicKey(key).export({ type: 'spki', format: 'der' })).digest('hex');
      if (compromised.spkiSha256.includes(fingerprint)) add('FIREBASE_PRIVATE_KEY', 'historically exposed key is not accepted');
    } catch { add('FIREBASE_PRIVATE_KEY', 'must be a valid RSA PEM private key'); }
    if (!process.env.FIREBASE_CLIENT_EMAIL!.endsWith(`@${process.env.FIREBASE_PROJECT_ID}.iam.gserviceaccount.com`)) add('FIREBASE_CLIENT_EMAIL', 'service account must belong to the Firebase project');
  }
  try {
    const web = browserConfig(process.env, true);
    if (web.projectId !== process.env.FIREBASE_PROJECT_ID) add('VITE_FIREBASE_PROJECT_ID', 'must equal FIREBASE_PROJECT_ID');
    for (const suffix of ['API_KEY', 'AUTH_DOMAIN', 'STORAGE_BUCKET', 'MESSAGING_SENDER_ID', 'APP_ID']) {
      if (process.env[`FIREBASE_${suffix}`] && process.env[`FIREBASE_${suffix}`] !== process.env[`VITE_FIREBASE_${suffix}`]) {
        add(`FIREBASE_${suffix}`, 'server and browser public configuration disagree');
      }
    }
  } catch (error) { add('VITE_FIREBASE_*', (error as Error).message); }
  if (process.env.VITE_RUNTIME_MODE && !['browser', 'android-webview', 'native-android'].includes(process.env.VITE_RUNTIME_MODE)) add('VITE_RUNTIME_MODE', 'unsupported runtime capability mode');
  if (process.env.VITE_ORDS_BASE_URL && process.env.VITE_ORDS_BASE_URL !== '/api/oracle') add('VITE_ORDS_BASE_URL', 'direct ORDS configuration is forbidden');
  const turns = (process.env.TURN_URLS || '').split(',').filter(Boolean);
  if (!turns.some(u => /^turn:.+\?transport=udp$/.test(u)) || !turns.some(u => /^turn:.+\?transport=tcp$/.test(u)) ||
      !turns.some(u => /^turns:.+\?transport=tcp$/.test(u)) || turns.some(u => !/^turns?:[a-z0-9.-]+:\d+\?transport=(udp|tcp)$/i.test(u))) {
    add('TURN_URLS', 'private TURN UDP, TCP and TLS endpoints are required');
  }
  if ((process.env.TURN_SHARED_SECRET || '').length < 32) add('TURN_SHARED_SECRET', 'private coturn REST secret must be at least 32 characters');
  // Mail is an optional deployment capability. When it is not configured,
  // password-reset requests fail honestly with 503 via mailer.ts rather than
  // claiming that a recovery message was delivered.
  return problems;
}
export function formatConfigProblems(problems: ConfigProblem[]): string {
  return 'Refusing unsafe production configuration:\n' + problems.map(p => `  - ${p.var}: ${p.problem}`).join('\n');
}
