# VyperVic Remaining Implementation Handoff

This file intentionally excludes requirements already implemented and covered by the current project. It contains only missing, disabled, incomplete, or not-yet-accepted items that remain from `pasted_content.txt`, followed by the confirmed decisions.

## Verified existing functionality intentionally removed from this handoff

The current project already contains the core offline outbox with queued/sending/failed states, bounded retries, same-ID retry and cancel controls, draft persistence, durable delivery intents and worker recovery, authenticated server-side authorization, session/device revocation foundations, account recovery, deletion-operation receipts, delegated group-admin enforcement, basic message editing/deletion/forwarding/reporting/blocking controls, baseline notification registration and deduplication, durable server scheduling, basic calls and TURN minting, light/dark theme support, reduced-motion/focus support, basic Media Vault storage, and the existing test/build/lint/typecheck pipeline. These are not to be reimplemented unless a remaining item below explicitly extends them.

## Remaining implementation requirements

### 1. Group and multiparty calling

The current project does not provide the requested completed multiparty experience. Implement authenticated, durable group voice/video calls with no application-imposed participant limit. Add participant lifecycle authorization, participant grid, active-speaker view, incoming-call handling, ringing/missed-call behavior, mute, speaker, camera, device selection, Bluetooth/headset routing where supported, call-quality status, reconnect after network changes, ICE restart, permission recovery, picture-in-picture, and call links for invited participants.

Add screen sharing with a server-authorized single active sharer. When one participant is sharing, all other participants must be prevented from starting another share until the current share ends. Add recording. During a video call, provide audio-only recording and screen-recording choices. Show recording permission, active-state, stop, failure, and saved-output states. Do not fake recording or media delivery.

Android ongoing calls must use both a foreground service and Android Telecom integration where supported so calls can continue when the app leaves the foreground. Use application ID `com.vypechat.app`. Leave the release unsigned and do not add signing keys. Use `vypechat.cloud-ip.cc` for App Links configuration. Physical-device testing is excluded; provide code and validation configuration only.

### 2. Media and file handling extensions

Extend the existing attachment flow so one upload action rejects files over 500 MB. Accept all file types without adding malware or virus scanning. Add view-once media with clear sender and recipient states, one-time consumption enforcement, expiry handling, and safe failure behavior.

Complete the attachment queue with pause, cancel, retry, progress, and resumable state where supported. Add image-compression choices, video thumbnails and duration, PDF/document previews, audio waveform/playback speed/scrubbing/transcription where supported, automatic link previews with user controls, and shared media/files/links tabs per conversation.

Complete Media Vault as an explicit user-facing feature with storage usage, search, filtering, preview, download, and deletion controls. Preserve pending outbox data and saved files during cache cleanup.

### 3. Conversation organization gaps

Add persistent chat folders for Work, Family, Projects, Communities, and user-created folders. Add favorites and priority chats if not already covered by the existing starred-message behavior. Complete per-chat notification settings, mark unread from a selected message, an unread divider, and jump-to-first-unread behavior.

Add a conversation notes/shared information panel and topic channels within groups. These are ordinary conversation/group features only; do not turn them into the excluded Conversation OS.

### 4. Search gaps

Extend search to combine local cached results with authenticated online server results whenever the user is online. Include messages, profiles, groups, media, calls, links, saved items, and attachments in matching suggestions. Add filters for sender, conversation, date range, file type, links, voice notes, mentions, pinned items, and unread items.

Highlight matching text, preserve surrounding message context, deep-link to the exact message, and add recent searches, saved searches, and keyboard shortcuts. Ensure offline search remains useful when no server connection exists.

### 5. Privacy and discoverability

Add a global-search discoverability setting for each user. Add separate online-status and last-seen visibility controls with Everyone, Nobody, and Select Contacts choices. Add profile-photo, cover-photo, typing, read-receipt, disappearing-message, and retention controls where absent.

The read-receipt disable confirmation must explicitly state that disabling read receipts also prevents the user from seeing other users’ read receipts. Blocking must prevent the blocked user from messaging the blocker while preserving access to the existing chat. When blocked, the blocker’s profile photo and cover photo must be hidden from the blocked user. Enforce these rules server-side and reflect them in the UI.

### 6. Security and account controls

Complete two-factor authentication or passkey support, recovery controls, active sessions, device list, individual device revocation, security status, and account recovery explanations. Complete discoverability controls by username, phone, and email. Add blocked-user list management, personal-data export controls, and delete-account completion status where absent.

The trust/privacy dashboard must show conversation participants, signed-in devices, local and remote data categories, message delivery/read state, active permissions, and one-click device revocation.

### 7. Notification and presence extensions

Extend the existing notification foundation with per-chat notification levels, quiet hours and notification schedules, mention-only group mode, custom sounds, synchronized notification history, actionable reply/mute/mark-read/call actions, and notify-when-online for selected contacts.

Add presence choices for online, busy, away, invisible, and custom status. Keep recipients and sender identity server-authoritative. Preserve the existing authenticated device-registration and deduplication protections.

### 8. Group and community features

Complete all group features not already present: invites and invite links, owner/admin/moderator/member/guest roles, approval-based joining, rules, welcome messages, announcements-only mode, member verification, slow mode, polls, quizzes, events, RSVPs, shared files/resources, admin analytics, moderation queue, custom group themes, and cover images.

Extend group reactions with configurable reaction sets, reaction disabling where moderation requires it, reaction-picker customization, reaction summaries, reaction notifications, and a view of who reacted.

Extend pinned messages into a permission-controlled information panel with Important, Decision, Link, File, and Reminder categories, search, and a show-all-pinned view.

### 9. Data export

Do not implement data import. Implement authorized conversation export as TXT and HTML. HTML exports must preserve chat layout, with sender messages on the right and receiver messages on the left. Provide export with or without media. Export with media must generate a ZIP containing the messages and all selected files/attachments.

Provide fixed ranges All, Today, and Last 7 Days, plus a custom start/end date range. Add progress, completion, cancellation, authorization failure, and error states. Do not expose data belonging to conversations or users the requester is not authorized to export.

### 10. Themes, profiles, and expressive features

The basic light/dark theme is already present. Add system mode, per-conversation themes, accessibility contrast validation, wallpaper blur/readability controls, and optional seasonal/event themes without reducing message readability or obscuring status indicators.

Add profile pronouns, location/timezone, custom status, work hours, links, profile history controls, separate public/private profile fields, and an exact preview of how a profile appears to another user.

Add remaining expressive requirements that are not already present: custom reaction packs, voice reactions, animated status cards, mood/status indicators, shared conversation ambience, collaborative doodles or temporary canvas messages, and acknowledgement-required heads-up messages. Keep the visual treatment calm and accessible.

### 11. Production acceptance that remains external

The following cannot be marked operationally complete by source edits alone: provider-side credential revocation and history purge, real Oracle/ORDS migration acceptance, deployed Firebase rules/indexes/TTL verification, live FCM delivery, real mail delivery, private TURN deployment and cross-network verification, backup/restore drills, Redis recovery, monitoring, alerting, rollback, and production DNS/HTTPS configuration. The repository may include scripts and runbooks for these items, but the next session must not claim live acceptance without exercising the real services.

## Confirmed exclusions

Do not add malware or virus scanning. Do not add data import. Do not implement Conversation OS functionality, including automatic summaries, tasks, decisions, events, shared-note OS behavior, or follow-up automation. Do not require physical-device testing. Do not add a release signing key or claim that an unsigned Android build is signed.

## Completion evidence

For every item implemented from this handoff, add server authorization where shared state is involved, durable persistence where required, loading/empty/offline/error/retry states, and focused regression tests. Run TypeScript validation, lint, the complete automated test suite, production build, bundle checks, and applicable Android configuration checks. The final report must distinguish implemented source behavior, automated-test coverage, and external-service acceptance.

## Source reference

The complete original requirements remain available in `pasted_content.txt` at the project root. This handoff deliberately removes requirements verified as already implemented from that source.
