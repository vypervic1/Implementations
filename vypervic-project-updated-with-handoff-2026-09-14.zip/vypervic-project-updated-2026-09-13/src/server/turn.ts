import { createHmac, createHash } from 'node:crypto';
import type { Express, RequestHandler } from 'express';
import { fetchCallById } from './oracleBackend';
import { ApiError } from './errors';
export function issueTurnCredentials(userId: string, callId: string, now = Date.now()) {
  const urls = (process.env.TURN_URLS || '').split(',').map(s => s.trim()).filter(Boolean);
  const secret = process.env.TURN_SHARED_SECRET;
  if (!secret || secret.length < 32 || !urls.length) throw new ApiError(503, 'TURN relay is unavailable', 'turn_unavailable');
  if (urls.some(u => !/^turns?:[a-z0-9.-]+:\d+\?transport=(udp|tcp)$/i.test(u))) throw new ApiError(503, 'TURN relay configuration is invalid', 'turn_auth_failed');
  const expiresAt = Math.floor(now / 1000) + 600;
  const subject = createHash('sha256').update(`${userId}:${callId}`).digest('hex').slice(0, 24);
  const username = `${expiresAt}:${subject}`;
  const credential = createHmac('sha1', secret).update(username).digest('base64');
  const stunUrls = (process.env.STUN_URLS || 'stun:stun.l.google.com:19302').split(',').map(s => s.trim()).filter(Boolean);
  return { iceServers: [{ urls, username, credential }, { urls: stunUrls }], expiresAt };
}
export function installTurnRoutes(app: Express, auth: RequestHandler, limiter: RequestHandler) {
  app.get('/api/calls/:callId/ice-servers', auth, limiter, async (req, res) => {
    const call = await fetchCallById(req.params.callId);
    if (!call || ![call.caller_id, call.receiver_id].includes(req.user!.sub)) throw new ApiError(403, 'Not a call participant');
    if (!['ringing', 'accepted'].includes(call.status) || Date.now() - Date.parse(call.created_at) > 4 * 3600_000) throw new ApiError(409, 'Call is no longer active');
    res.setHeader('Cache-Control', 'no-store');
    res.json(issueTurnCredentials(req.user!.sub, call.id));
  });
}
