import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ArrowLeft, ZoomIn, ZoomOut, RotateCcw, Share2, Download } from 'lucide-react';

interface InteractiveImageViewerProps {
  src: string;
  alt?: string;
  title?: string;
  subtitle?: string;
  isAvatar?: boolean;
  onClose: () => void;
  onShare?: () => void;
}

export function InteractiveImageViewer({
  src,
  alt = 'Image preview',
  title,
  subtitle,
  isAvatar = false,
  onClose,
  onShare,
}: InteractiveImageViewerProps) {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [isPinching, setIsPinching] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const posStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const initialDistanceRef = useRef<number | null>(null);
  const initialScaleRef = useRef<number>(1);
  const lastTapRef = useRef<number>(0);

  // Reset transformations
  const handleReset = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev + 0.5, 5));
  };

  const handleZoomOut = () => {
    setScale((prev) => {
      const next = Math.max(prev - 0.5, 1);
      if (next === 1) setPosition({ x: 0, y: 0 });
      return next;
    });
  };

  // Helper for touch distance
  const getTouchDistance = (e: React.TouchEvent) => {
    if (e.touches.length < 2) return 0;
    const dx = e.touches[0].clientX - e.touches[1].clientX;
    const dy = e.touches[0].clientY - e.touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  };

  // Helper for touch midpoint
  const getTouchMidpoint = (e: React.TouchEvent) => {
    if (e.touches.length < 2) {
      return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
    return {
      x: (e.touches[0].clientX + e.touches[1].clientX) / 2,
      y: (e.touches[0].clientY + e.touches[1].clientY) / 2,
    };
  };

  // Touch handlers for multi-touch (pinch-to-zoom & pan)
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      // 2-finger gesture initiated
      setIsPinching(true);
      setIsDragging(false);
      initialDistanceRef.current = getTouchDistance(e);
      initialScaleRef.current = scale;
      posStartRef.current = { ...position };
      const mid = getTouchMidpoint(e);
      dragStartRef.current = mid;
    } else if (e.touches.length === 1) {
      // Check for double tap
      const now = Date.now();
      if (now - lastTapRef.current < 300) {
        // Double tap toggle
        if (scale > 1.2) {
          handleReset();
        } else {
          setScale(2.5);
        }
        lastTapRef.current = 0;
        return;
      }
      lastTapRef.current = now;

      // 1-finger drag
      if (scale > 1) {
        setIsDragging(true);
        dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        posStartRef.current = { ...position };
      }
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialDistanceRef.current !== null) {
      // Pinching
      const currentDist = getTouchDistance(e);
      if (currentDist > 0) {
        const factor = currentDist / initialDistanceRef.current;
        const newScale = Math.min(Math.max(initialScaleRef.current * factor, 0.8), 6);
        setScale(newScale);

        // Also track translation while pinching
        const mid = getTouchMidpoint(e);
        const dx = mid.x - dragStartRef.current.x;
        const dy = mid.y - dragStartRef.current.y;
        setPosition({
          x: posStartRef.current.x + dx,
          y: posStartRef.current.y + dy,
        });
      }
    } else if (e.touches.length === 1 && isDragging && scale > 1) {
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      setPosition({
        x: posStartRef.current.x + dx,
        y: posStartRef.current.y + dy,
      });
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (e.touches.length === 0) {
      setIsPinching(false);
      setIsDragging(false);
      initialDistanceRef.current = null;
      // Snap back if scale was squeezed < 1
      if (scale < 1) {
        setScale(1);
        setPosition({ x: 0, y: 0 });
      }
    } else if (e.touches.length === 1) {
      setIsPinching(false);
      initialDistanceRef.current = null;
      if (scale > 1) {
        setIsDragging(true);
        dragStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        posStartRef.current = { ...position };
      }
    }
  };

  // Mouse handlers for desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale > 1) {
      setIsDragging(true);
      dragStartRef.current = { x: e.clientX, y: e.clientY };
      posStartRef.current = { ...position };
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && scale > 1) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      setPosition({
        x: posStartRef.current.x + dx,
        y: posStartRef.current.y + dy,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Mouse wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY * -0.005;
    setScale((prev) => {
      const next = Math.min(Math.max(prev + delta, 1), 6);
      if (next === 1) setPosition({ x: 0, y: 0 });
      return next;
    });
  };

  // Keyboard navigation & Esc to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === '+' || e.key === '=') handleZoomIn();
      else if (e.key === '-') handleZoomOut();
      else if (e.key === '0') handleReset();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-[#030508]/96 backdrop-blur-xl z-[999] flex flex-col justify-between select-none animate-fade-in touch-none overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onWheel={handleWheel}
    >
      {/* Top Header Bar */}
      <div className="w-full flex items-center justify-between px-4 py-3.5 bg-gradient-to-b from-black/80 to-transparent z-50 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:text-[#20e3a2] hover:bg-white/20 transition-all cursor-pointer shadow-lg backdrop-blur-md"
            title="Close"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          {(title || subtitle) && (
            <div className="flex flex-col">
              {title && <h3 className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-xs">{title}</h3>}
              {subtitle && <p className="text-[11px] text-[#8d97ab] font-mono truncate">{subtitle}</p>}
            </div>
          )}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {onShare && (
            <button
              onClick={onShare}
              className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:text-[#20e3a2] hover:bg-white/20 transition-all cursor-pointer"
              title="Share"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}
          <a
            href={src}
            download={alt || 'image'}
            className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:text-[#20e3a2] hover:bg-white/20 transition-all cursor-pointer"
            title="Download full image"
          >
            <Download className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Interactive Main Viewport Canvas */}
      <div
        ref={containerRef}
        className="flex-1 w-full h-full flex items-center justify-center relative overflow-hidden cursor-grab active:cursor-grabbing"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onDoubleClick={() => {
          if (scale > 1.2) handleReset();
          else setScale(2.5);
        }}
      >
        <div
          className="transition-transform duration-75 ease-out flex items-center justify-center will-change-transform"
          style={{
            transform: `translate3d(${position.x}px, ${position.y}px, 0px) scale(${scale})`,
            transformOrigin: 'center center',
          }}
        >
          {isAvatar ? (
            <div className="w-[78vw] h-[78vw] max-w-[440px] max-h-[440px] rounded-full border-4 border-white/20 shadow-[0_0_90px_rgba(32,227,162,0.25)] overflow-hidden bg-[#161d28] flex items-center justify-center">
              <img loading="lazy" decoding="async"
                src={src}
                alt={alt}
                className="w-full h-full object-cover select-none pointer-events-none"
                draggable={false}
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            <div className="max-w-[92vw] max-h-[75vh] rounded-2xl border border-white/15 shadow-2xl overflow-hidden bg-[#161d28] flex items-center justify-center">
              <img loading="lazy" decoding="async"
                src={src}
                alt={alt}
                className="max-w-full max-h-[75vh] object-contain select-none pointer-events-none"
                draggable={false}
                referrerPolicy="no-referrer"
              />
            </div>
          )}
        </div>
      </div>

      {/* Floating Bottom Control Bar */}
      <div className="w-full flex items-center justify-center pb-6 pt-2 z-50 shrink-0 pointer-events-auto">
        <div className="flex items-center gap-2 bg-black/80 border border-white/15 rounded-full px-4 py-2 backdrop-blur-md shadow-2xl">
          <button
            onClick={handleZoomOut}
            disabled={scale <= 1}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/90 hover:text-white hover:bg-white/10 active:bg-white/20 disabled:opacity-30 disabled:hover:bg-transparent transition-all cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <span className="text-xs font-mono font-bold text-[#20e3a2] min-w-[48px] text-center">
            {Math.round(scale * 100)}%
          </span>

          <button
            onClick={handleZoomIn}
            disabled={scale >= 6}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/90 hover:text-white hover:bg-white/10 active:bg-white/20 disabled:opacity-30 disabled:hover:bg-transparent transition-all cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          {scale !== 1 && (
            <button
              onClick={handleReset}
              className="w-8 h-8 rounded-full flex items-center justify-center text-[#8d97ab] hover:text-white hover:bg-white/10 transition-all cursor-pointer ml-1"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default InteractiveImageViewer;
