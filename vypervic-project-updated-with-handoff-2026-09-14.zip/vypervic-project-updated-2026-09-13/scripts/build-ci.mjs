import { spawnSync } from 'node:child_process';
// Explicit, NON-DEPLOYABLE contract-build configuration. Production refuses this project.
const project = 'demo-ci-contract';
const env = { ...process.env, VYPER_CI_BUILD: '1', VITE_RUNTIME_MODE: 'browser',
  VITE_FIREBASE_PROJECT_ID: project, VITE_FIREBASE_API_KEY: 'ci-public-config-only', VITE_FIREBASE_AUTH_DOMAIN: `${project}.firebaseapp.com`,
  VITE_FIREBASE_STORAGE_BUCKET: `${project}.appspot.com`, VITE_FIREBASE_MESSAGING_SENDER_ID: '100000000001',
  VITE_FIREBASE_APP_ID: '1:100000000001:web:000000000000000000000001', VITE_FIREBASE_VAPID_KEY: 'A'.repeat(87) };
const result = spawnSync('npm', ['run', 'build'], { env, stdio: 'inherit' });
process.exitCode = result.status ?? 1;
