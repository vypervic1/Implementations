-- Run as the application's own Oracle schema. Adds no users and prints no OAuth secrets.
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
SET SERVEROUTPUT ON
DECLARE
  PROCEDURE enable_object(n VARCHAR2) IS
  BEGIN
    ORDS.ENABLE_OBJECT(p_enabled => TRUE, p_schema => USER, p_object => n,
      p_object_type => 'TABLE', p_object_alias => LOWER(n), p_auto_rest_auth => TRUE);
  END;
BEGIN
  enable_object('PROFILES'); enable_object('MESSAGES'); enable_object('CALLS');
  enable_object('GROUPS'); enable_object('VAULT'); enable_object('AUDIT_LOGS');
  enable_object('USER_PUSH_TOKENS'); enable_object('USER_CREDENTIALS');
  enable_object('PASSWORD_RESETS'); enable_object('SCHEDULED_MESSAGES'); enable_object('DELETION_JOBS');
  COMMIT;
END;
/
-- IMPORTANT: grant this server's client-credentials OAuth client the generated AutoREST roles
-- for these objects, INCLUDING DELETION_JOBS. Use Database Actions/ORDS administration for
-- your installed ORDS version. Do not reuse a public browser/API credential.
-- After grant, verify authenticated CRUD + OAuth refresh and anonymous HTTP 401 for every
-- object in docs/STAGING-ACCEPTANCE.md. Authentication configuration is not inferred from DDL success.
