# VyperVic Project Package

This archive contains the complete current project tree from the working source directory, including source, Android files, tests, documentation, deployment files, lockfiles, public assets, and the current production `dist` output.

Excluded only: `node_modules/`, `.git/`, coverage/cache directories, temporary directories, and log files. Dependencies can be restored with `npm ci`; the lockfile is included.

A scan of the packaged project found no project-local `.env`, private-key, certificate, or credential files. Credential-like filenames in the archive are application source/configuration modules or test-safe metadata, not secret values.
