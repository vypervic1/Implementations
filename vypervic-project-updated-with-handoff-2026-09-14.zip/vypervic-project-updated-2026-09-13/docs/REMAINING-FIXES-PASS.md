# Follow-up implementation pass

## Fixed in code

- **Session races:** auth requests carry a generation/abort scope; stale `/me` and sign-in responses cannot publish state after logout/account switching. Firebase auth operations are serialized. Server mint/revoke operations share an account lease, and mint checks session revocation after acquiring it.
- **Destructive isolation:** logical writes share an admission gate. Migration 003 adds an Oracle transaction lock plus an epoch-fenced write gateway and DML triggers. A queued/executing request with an obsolete epoch is rejected even after maintenance reopens. Firebase writers check an in-transaction gate/epoch; clients are denied during maintenance. Partial jobs keep admission closed.
- **Operation progress:** destructive starts return HTTP 202. A short-lived **HttpOnly, read-only operation receipt** supports status polling after the initiating login is revoked/deleted. The UI retains a non-secret operation ID and displays authoritative state. Oracle deletions and their count receipts commit together; Firebase deletion counts also have transactional receipts. No global cross-service transaction is claimed.
- **Admin UI:** removed client-generated wipe SQL, inferred “test-account” purges, generic role/audit writes, fabricated totals and optimistic deletion success. New typed admin APIs provide exact database counts, paginated metadata, checked role/record changes, server audit and resumable bulk-message/call operations. Privileged actions reauthenticate and require literal confirmation.
- **Notification recovery:** Oracle message/call triggers create delivery intents in the same transaction. The worker rechecks entities/membership/sessions, checkpoints per-recipient outcomes, recovers stale sending claims and retries with stable event IDs. Native/browser receivers suppress repeated alerts. This is at-least-once transport, not a claim that FCM guarantees device delivery.
- **Offline UX:** explicit queued/sending/failed states, bounded retries, manual same-ID retry and cancel-local-retry controls. A logout/account switch prevents stale retries from recreating an old account's outbox.
- **Media/cache:** Oracle metadata views omit inline attachment/image bytes; list APIs and SSE remain bounded. Visible attachments are loaded with two-request concurrency. Images are lazy-decoded. Profile snapshots replace stale/deleted records. Disposable caches are capped without evicting pending outbox entries or explicitly saved files.
- **Lifecycle:** owned timeout, FileReader, blob, recorder and media-stream scopes dispose on unmount. Late permission grants are stopped; stale callbacks do not revive after a StrictMode-style remount.
- **Group administration:** delegated group admins are now persisted and enforced server-side. Only the creator can grant/revoke admin roles or disband; delegates cannot elevate themselves or remove peer admins.
- **Native hardening:** Gradle validates the supplied environment's Firebase configuration automatically. Native notifications use durable bounded event-ID deduplication; unsafe local asset/API-origin fallbacks remain absent.

## Required rollout changes (do not skip)

1. Review and apply `003_write_fence_delivery_and_metadata.sql` **after** 000/001/002 as applicable. It requires `EXECUTE` on `DBMS_LOCK` and includes private definer-rights procedures. Run in a maintenance window with the old app stopped. Review `USER_ERRORS`; verify every generated trigger is enabled.
2. Grant the server's ORDS OAuth client `vyper_backend` and the generated protected roles for the new metadata views and `DELIVERY_OUTBOX`. Confirm all `/vyper-internal/*` endpoints are anonymous-denied. Normal domain writes now use `/vyper-internal/write`; raw AutoREST DML is intentionally rejected by the fence triggers.
3. Deploy the updated rules/indexes and initialize/verify `_service_state/write_gate` through startup readiness. Its epoch must match the Oracle fence. Do not manually reopen one store while the other is fenced.
4. All app instances and workers must use the same new version. An older app without epoch-bearing writes cannot safely coexist. Code rollback requires reviewing the new gateway/rule/schema compatibility, not just swapping files.
5. Once a job is accepted, closing a tab or losing HTTP does not cancel it. Use the persistent operation status panel. If accounts/credentials are gone and automatic retries are exhausted, an authorized VPS operator can run `npm run operations:resume -- <existing-operation-id>` with runtime secrets securely injected. The command cannot change the approved job's target.

## Still not claimed

- No cloud key revocation or repository-wide history purge has been performed.
- Migration 003 is tested against the modeled ORDS contract, **not a real Oracle database**. Its package/trigger syntax, privileges, transaction ordering, response types and crash semantics must pass staging before production.
- No deployed Firebase rules/TTLs or live FCM/TURN/mail acceptance is claimed.
- Android SDK/emulator downloads remain blocked locally. The native Gradle project, signed APK and physical-device tests still need an SDK-equipped CI/device environment.
- Group/multiparty calling and Android Telecom/foreground-service ongoing background calls remain disabled; they need a separate durable participant/media lifecycle implementation. This pass does not pretend the previous simulated group-call UI is a working replacement.
- The global write admission gate intentionally prioritizes correctness over throughput. Measure real contention and large-dataset behavior before production scaling.

## Verification completed locally

- 124 tests across 13 files: passed.
- 5 real Redis tests (independent processes, leases/revocation/outage): passed on the final source revision.
- ESLint, TypeScript, contract build and dependency audit: passed; 0 reported vulnerabilities.
- Startup JavaScript: 202.2 KiB gzip; Firestore/Web Push excluded from the unauthenticated startup graph.
- Working-tree private-material scan and diff whitespace check: passed. Historical credential cleanup is still outstanding.
- GitHub repository reads recovered, but both Git push attempts failed authentication. No remote CI, merge, cloud deployment, or signed APK is claimed.
