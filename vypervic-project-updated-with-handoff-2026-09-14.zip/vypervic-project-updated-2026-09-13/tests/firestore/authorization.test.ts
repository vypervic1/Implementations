import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import { initializeTestEnvironment, assertSucceeds, assertFails, type RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, setDoc, getDoc, getDocs, collection, updateDoc, deleteDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
if (!process.env.FIRESTORE_EMULATOR_HOST) throw new Error('Firestore emulator required; never run rules abuse tests against a real project');
let env: RulesTestEnvironment;
const expiry = () => Timestamp.fromMillis(Date.now() + 240000);
const callId = 'authorized-call';
const signal = (sender = 'alice') => ({ call_id: callId, caller_id: 'alice', receiver_id: 'bob', type: 'offer',
  payload: { callId, senderId: sender, receiverId: sender === 'alice' ? 'bob' : 'alice', type: 'offer', sdp: { type: 'offer', sdp: 'v=0' } },
  timestamp: Date.now() });
beforeAll(async () => {
  const [host, port] = process.env.FIRESTORE_EMULATOR_HOST!.split(':');
  env = await initializeTestEnvironment({ projectId: 'demo-arena-chatapp', firestore: { host, port: Number(port), rules: readFileSync('firestore.rules', 'utf8') } });
});
afterAll(async () => { await env?.cleanup(); });
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async ctx => {
    const db = ctx.firestore(); const expires_at = expiry();
    for (const uid of ['alice', 'bob', 'eve', 'a_b', 'a']) {
      await setDoc(doc(db, 'edge_accounts', uid), { active: true, version: 'v1' });
      await setDoc(doc(db, 'edge_sessions', `s_${uid}`), { user_id: uid, expires_at });
    }
    await setDoc(doc(db, 'ephemeral_calls', callId), { caller_id: 'alice', receiver_id: 'bob', status: 'ringing', expires_at });
    await setDoc(doc(db, 'ephemeral_signaling', callId), { ...signal(), published_at: Timestamp.now(), expires_at });
    await setDoc(doc(db, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message'), { id: 'message', text: 'private' });
    await setDoc(doc(db, 'ephemeral_messages', 'message'), { id: 'message', status: 'queued', attempts: 0 });
    await setDoc(doc(db, 'ephemeral_presence', 'bob'), { is_online: true });
    await setDoc(doc(db, 'user_contacts', 'alice_bob'), { reader_id: 'alice', owner_id: 'bob' });
  });
});
describe('deny-by-default Firestore boundary', () => {
  it('denies anonymous/foreign DM reads and all client delivery/outbox writes', async () => {
    const anonymous = env.unauthenticatedContext().firestore(), eve = env.authenticatedContext('eve', { accountVersion: 'v1', sessionId: 's_eve' }).firestore(), alice = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice' }).firestore();
    await assertFails(getDoc(doc(anonymous, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
    await assertFails(getDoc(doc(eve, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
    await assertSucceeds(getDoc(doc(alice, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
    await assertFails(getDocs(collection(alice, 'ephemeral_messages')));
    await assertFails(updateDoc(doc(alice, 'ephemeral_messages', 'message'), { status: 'archived' }));
    await assertFails(setDoc(doc(alice, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'forged'), { text: 'forged' }));
    await assertFails(setDoc(doc(alice, 'any_other_collection', 'one'), { admin: true }));
  });
  it('allows canonical participant signaling but rejects forged path/identities/retention', async () => {
    const db = env.authenticatedContext('bob', { accountVersion: 'v1', sessionId: 's_bob' }).firestore(), ref = doc(db, 'ephemeral_signaling', callId);
    await assertSucceeds(updateDoc(ref, signal('bob')));
    await assertFails(updateDoc(ref, { ...signal('bob'), caller_id: 'eve' }));
    await assertFails(updateDoc(ref, { ...signal('bob'), receiver_id: 'eve' }));
    await assertFails(updateDoc(ref, { ...signal('bob'), call_id: 'another-call' }));
    await assertFails(updateDoc(ref, { ...signal('bob'), expires_at: Timestamp.fromMillis(Date.now() + 86400000) }));
    await assertFails(updateDoc(ref, { ...signal('alice') }));
    await assertFails(updateDoc(ref, { ...signal('bob'), lifecycle: 'archived' }));
    await assertFails(setDoc(doc(db, 'ephemeral_signaling', 'another-call'), { ...signal('bob'), published_at: serverTimestamp(), expires_at: expiry() }));
  });
  it('bounds SDP and prevents signaling on terminated calls', async () => {
    const db = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice' }).firestore(), ref = doc(db, 'ephemeral_signaling', callId);
    const oversized = signal(); oversized.payload.sdp.sdp = 'x'.repeat(48001);
    await assertFails(updateDoc(ref, oversized));
    await env.withSecurityRulesDisabled(async ctx => { await updateDoc(doc(ctx.firestore(), 'ephemeral_calls', callId), { status: 'ended' }); });
    await assertFails(updateDoc(ref, signal()));
    await assertFails(updateDoc(doc(db, 'ephemeral_calls', callId), { status: 'accepted' }));
  });
  it('restricts presence identity, types, lifetime and relationship reads', async () => {
    const db = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice' }).firestore(), ref = doc(db, 'ephemeral_presence', 'alice');
    const valid = { user_id: 'alice', is_online: true, typing_to: 'dm:alice:bob', last_seen: serverTimestamp(), updated_at: serverTimestamp(), expires_at: expiry() };
    await assertSucceeds(setDoc(ref, valid));
    await assertSucceeds(getDoc(doc(db, 'ephemeral_presence', 'bob')));
    await assertFails(getDoc(doc(env.authenticatedContext('eve', { accountVersion: 'v1', sessionId: 's_eve' }).firestore(), 'ephemeral_presence', 'bob')));
    await assertFails(setDoc(ref, { ...valid, role: 'admin' }));
    await assertFails(setDoc(ref, { ...valid, typing_to: 'dm:bob:eve' }));
    await assertFails(setDoc(ref, { ...valid, expires_at: Timestamp.fromMillis(Date.now() + 86400000) }));
    await assertFails(setDoc(doc(db, 'ephemeral_presence', 'bob'), valid));
    await assertFails(setDoc(doc(db, 'user_contacts', 'alice_eve'), { reader_id: 'alice', owner_id: 'eve' }));
  });
  it('does not grant contact access solely because a concatenated key exists', async () => {
    await env.withSecurityRulesDisabled(async ctx => {
      await setDoc(doc(ctx.firestore(), 'user_contacts', 'a_b_c'), { reader_id: 'a_b', owner_id: 'c' });
      await setDoc(doc(ctx.firestore(), 'ephemeral_presence', 'b_c'), { is_online: true });
    });
    await assertFails(getDoc(doc(env.authenticatedContext('a', { accountVersion: 'v1', sessionId: 's_a' }).firestore(), 'ephemeral_presence', 'b_c')));
  });
  it('immediately disables a deleted account even with a still-issued Firebase ID token', async () => {
    const db = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice' }).firestore();
    await env.withSecurityRulesDisabled(async ctx => { await deleteDoc(doc(ctx.firestore(), 'edge_accounts', 'alice')); });
    await assertFails(getDoc(doc(db, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
    await assertFails(updateDoc(doc(db, 'ephemeral_signaling', callId), signal()));
  });
  it('revokes one device session without invalidating another device of the same account', async () => {
    const alice = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice' }).firestore();
    await env.withSecurityRulesDisabled(async ctx => {
      await setDoc(doc(ctx.firestore(), 'edge_sessions', 's_alice_second'), { user_id: 'alice', expires_at: expiry() });
      await deleteDoc(doc(ctx.firestore(), 'edge_sessions', 's_alice'));
    });
    const otherDevice = env.authenticatedContext('alice', { accountVersion: 'v1', sessionId: 's_alice_second' }).firestore();
    await assertFails(getDoc(doc(alice, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
    await assertSucceeds(getDoc(doc(otherDevice, 'ephemeral_chats', 'dm:alice:bob', 'messages', 'message')));
  });

});
