import { useResources } from './utils/resources';
import { SessionSupersededError } from './sessionEpoch';
import { getSessionStatus, setSessionStatus } from './sessionStatus';
import { capabilities } from './capabilities';
import { useState, useEffect, useRef, useMemo, useCallback, type ReactNode } from 'react';
import NotificationCard from './components/NotificationCard';
import { PushNotification, Profile, Message, Call, Group, ThemeConfig } from './types';
import { Bell, AtSign, Smartphone, MessageSquare, X, Send, Loader2, Sparkles, AlertTriangle, Phone, Users, Settings } from 'lucide-react';
import { oracleDB, getAuthToken, setAuthToken, hasServerSession, PUBLIC_PROFILE_COLUMNS } from './oracleDB';
import { motion, AnimatePresence } from 'motion/react';
// R-04: the notifications module statically pulls the whole Firebase
// messaging SDK. It is only needed after user interaction / on push events,
// so it is loaded on demand instead of in the initial chat bundle.
const loadNotifications = () => import('./notifications');
const requestNotificationPermission = (...args: Parameters<typeof import('./notifications').requestNotificationPermission>) =>
  loadNotifications().then((m) => m.requestNotificationPermission(...args));
const displayLocalPushNotification = (...args: Parameters<typeof import('./notifications').displayLocalPushNotification>) =>
  loadNotifications().then((m) => m.displayLocalPushNotification(...args));

import { lazy, Suspense } from 'react';

// Import sub-components
// R-04 (bundle size): rarely-visited screens and heavy media components are
// code-split with React.lazy so the initial chat bundle stays small. They
// render inside <Suspense> further below.
import Splash from './components/Splash';
import AuthScreen from './components/AuthScreen';
import ChatListScreen from './components/ChatListScreen';
import ChatScreen from './components/ChatScreen';
const SearchScreen = lazy(() => import('./components/SearchScreen'));
const SettingsScreen = lazy(() => import('./components/SettingsScreen'));
const CallsScreen = lazy(() => import('./components/CallsScreen'));
const CallOverlay = lazy(() => import('./components/CallOverlay'));
const AdminDashboard = lazy(() => import('./components/AdminDashboard').then((m) => ({ default: m.AdminDashboard })));
const FullscreenProfile = lazy(() => import('./components/FullscreenProfile'));
const GlobalAudioBanner = lazy(() => import('./components/GlobalAudioBanner').then((m) => ({ default: m.GlobalAudioBanner })));
import {
  saveFileToLocalStorage,
  cacheMessagesLocally,
  getCachedMessagesLocally,
  cacheProfilesLocally,
  getCachedProfilesLocally
} from './utils/indexedDB';
import { flushOfflineQueue, getOfflineQueue, queueOfflineMessage } from './utils/offlineSync';
import { isUserOnline, getContactDisplayName, compareMessagesChronologically, extractMessageTimestamp } from './utils/customNames';
import { refreshScheduledMessages } from './utils/scheduledMessages';
import { sendCallHangup } from './callSignalingService';

// R-04: minimal Suspense boundary for the lazily-loaded screens.
function LazyBoundary({ children }: { children: ReactNode }) {
  return <Suspense fallback={null}>{children}</Suspense>;
}

// Helper to gracefully merge/append optimistic and database messages, maintaining strict monotonic chronological ordering
export function addOrUpdateMessage(prev: Message[], newMsg: Message): Message[] {
  const isTemp = typeof newMsg.id === 'string' && newMsg.id.startsWith('temp_');

  const matchIndex = prev.findIndex((m) => {
    if (m.id === newMsg.id) return true;

    // Check if the message in the list is an optimistic copy matching this database message
    if (!isTemp && typeof m.id === 'string' && m.id.startsWith('temp_')) {
      return (
        m.sender_id === newMsg.sender_id &&
        m.chat_id === newMsg.chat_id &&
        m.text === newMsg.text &&
        m.file_name === newMsg.file_name &&
        m.is_voice === newMsg.is_voice
      );
    }

    // Check if we are inserting an optimistic message that is already in the list
    if (isTemp && typeof m.id === 'string' && m.id.startsWith('temp_')) {
      return m.id === newMsg.id;
    }

    return false;
  });

  if (matchIndex >= 0) {
    const updated = [...prev];
    updated[matchIndex] = { ...updated[matchIndex], ...newMsg };
    return updated.sort(compareMessagesChronologically);
  } else {
    return [...prev, newMsg].sort(compareMessagesChronologically);
  }
}

export default function App() {
  const resources = useResources();
  const [showSplash, setShowSplash] = useState(true);
  const [currentUser, setCurrentUser] = useState<Profile | null>(() => {
    try {
      const saved = localStorage.getItem('vypervic_current_user_cache');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);

  // Real-time synchronization state
  const [allProfiles, setAllProfiles] = useState<Profile[]>([]);
  const [messagesList, setMessagesList] = useState<Message[]>([]);
  const [activeCall, setActiveCall] = useState<Call | null>(null);
  const [groupCallStatuses, setGroupCallStatuses] = useState<Record<string, string>>({});
  const [callHistory, setCallHistory] = useState<Call[]>([]);

  // Track contacts that the user has chatted or interacted with
  const existingContactIds = useMemo(() => {
    if (!currentUser) return [];
    const set = new Set<string>();

    messagesList.forEach((m) => {
      if (m.sender_id && m.sender_id !== currentUser.id) set.add(m.sender_id);
      if (m.receiver_id && m.receiver_id !== currentUser.id) set.add(m.receiver_id);
      if (m.chat_id && m.chat_id.startsWith('dm:')) {
        const parts = m.chat_id.replace('dm:', '').split(':');
        parts.forEach((id) => {
          if (id && id !== currentUser.id) set.add(id);
        });
      }
    });

    try {
      const saved = localStorage.getItem('vyper_custom_display_names');
      if (saved) {
        const map = JSON.parse(saved);
        Object.keys(map).forEach((id) => set.add(id));
      }
    } catch (e) {}

    return Array.from(set);
  }, [currentUser, messagesList]);

  const [appTheme, setAppTheme] = useState<string>(() => {
    const saved = localStorage.getItem('vypervic_app_theme');
    return saved === 'light' ? 'light-cosmic' : saved || 'liquid-glass';
  });

  const applyAppTheme = (theme: string) => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.style.colorScheme = theme.startsWith('light') ? 'light' : 'dark';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme.startsWith('light') ? '#f8fafc' : '#07090e');
  };

  useEffect(() => {
    applyAppTheme(appTheme);
    localStorage.setItem('vypervic_app_theme', appTheme);
  }, [appTheme]);

  // Auto-flush queued offline messages when network connection is restored
  useEffect(() => {
    const handleOnline = () => {
      flushOfflineQueue();
    };
    window.addEventListener('online', handleOnline);
    // Flush on initial mount if online
    if (navigator.onLine) {
      flushOfflineQueue();
    }
    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  // Request notification permissions on first open (PWA-to-Android conversion/Capacitor compatibility)
  useEffect(() => {
    if (currentUser) {
      const askPermission = async () => {
        if (capabilities().webPush && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
          try {
            const perm = await requestNotificationPermission();
            setNotifPermission(perm);
          } catch (err) {
            console.warn('Failed to automatically request notification permission:', err);
          }
        }
      };
      // Delay slightly on first load so interface is visible and polished
      const timer = resources.timeout(askPermission, 1200);
      return () => resources.clearTimeout(timer);
    }
  }, [currentUser]);

  // Active Push Notification states
  const [notifications, setNotifications] = useState<PushNotification[]>(() => {
    try {
      const saved = localStorage.getItem('vypervic_unread_notifications');
      if (!saved) return [];
      const parsed: PushNotification[] = JSON.parse(saved);
      const cutoff = Date.now() - 48 * 3600 * 1000;
      return parsed.filter((n) => {
        const t = n.timestamp ? new Date(n.timestamp).getTime() : 0;
        return t > cutoff;
      });
    } catch {
      return [];
    }
  });
  const [headsUpNotification, setHeadsUpNotification] = useState<PushNotification | null>(null);
  const [showHeadsUpReply, setShowHeadsUpReply] = useState(false);
  const [headsUpReplyText, setHeadsUpReplyText] = useState('');
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
  };

  const [currentSimulatedTime, setCurrentSimulatedTime] = useState('');

  // Clock effect
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      let hours = d.getHours();
      const minutes = d.getMinutes();
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // 12 instead of 0
      const minutesStr = minutes < 10 ? '0' + minutes : minutes;
      setCurrentSimulatedTime(`${hours}:${minutesStr} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Save notifications to local storage
  useEffect(() => {
    try {
      localStorage.setItem('vypervic_unread_notifications', JSON.stringify(notifications));
    } catch (e) {
      console.warn('Failed to save unread notifications to localStorage:', e);
    }
  }, [notifications]);

  // Track read notification IDs so notifications remain in history as read items
  const [readNotifIds, setReadNotifIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('vypervic_read_notifications');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_read_notifications', JSON.stringify(readNotifIds));
    } catch (e) {
      console.warn('Failed to save read notifications to localStorage:', e);
    }
  }, [readNotifIds]);

  // Track dismissed notification and message IDs for the Notifications page
  const [dismissedFeedItemIds, setDismissedFeedItemIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('vypervic_dismissed_feed_items');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_dismissed_feed_items', JSON.stringify(dismissedFeedItemIds));
    } catch (e) {
      console.warn('Failed to save dismissed feed items:', e);
    }
  }, [dismissedFeedItemIds]);

  // Helper to compile the dynamic feed of messages and notifications
  const getUnifiedFeed = (): PushNotification[] => {
    // 1. Map system/push notifications
    const mappedNotifs = notifications
      .map((n) => ({
        id: n.id,
        chatId: n.chatId,
        senderId: n.senderId,
        senderName: n.senderName,
        title: n.title,
        body: n.body,
        isMention: n.isMention,
        timestamp: n.timestamp,
        isRead: readNotifIds.includes(n.id) || !!n.isRead,
      }));

    // 2. Map recent directed chat messages for the current user (DMs, mentions, replies)
    const mappedMessages = messagesList
      .filter((m) => {
        if (!currentUser?.id || m.sender_id === currentUser.id) return false;
        if (!m.chat_id) return false;

        // DMs involving current user
        if (m.chat_id.startsWith('dm:')) {
          if (m.chat_id === 'dm:system:test') return true;
          const parts = m.chat_id.split(':');
          return parts[1] === currentUser.id || parts[2] === currentUser.id;
        }

        // Mentions of current user in groups or general
        if (m.text && currentUser.username) {
          const isMention = m.text.toLowerCase().includes(`@${currentUser.username.toLowerCase()}`);
          if (isMention) return true;
        }

        // Direct replies to current user's message
        if (m.text && m.text.includes('"reply_to_user_id":"' + currentUser.id + '"')) {
          return true;
        }

        return false;
      })
      .slice(-40)
      .map((m) => {
        const sender = allProfiles.find((p) => p.id === m.sender_id);
        const senderName = sender?.display_name || sender?.username || 'User';
        const isMention = !!(m.text && currentUser?.username && m.text.toLowerCase().includes(`@${currentUser.username.toLowerCase()}`));
        const isDM = m.chat_id.startsWith('dm:');
        const title = isDM ? `Message from ${senderName}` : isMention ? `${senderName} mentioned you` : `Reply from ${senderName}`;
        const body = m.is_voice
          ? '🎤 Sent a voice note'
          : m.file_name
            ? `📎 Sent attachment: ${m.file_name}`
            : (m.text || '');

        const receipt = myReadReceipts[m.chat_id];
        let isReadByReceipt = false;
        if (receipt) {
          const msgTime = new Date(m.created_at).getTime();
          const receiptTime = new Date(receipt.timestamp).getTime();
          isReadByReceipt = msgTime <= receiptTime || m.id === receipt.lastReadMessageId;
        }

        const isRead = isReadByReceipt || readNotifIds.includes(m.id);

        return {
          id: m.id,
          chatId: m.chat_id,
          senderId: m.sender_id,
          senderName,
          title,
          body,
          isMention,
          timestamp: m.created_at,
          isRead,
        };
      });

    // 3. Merge, filter out manually dismissed items, and sort descending
    const combined = [...mappedNotifs, ...mappedMessages]
      .filter((item) => !dismissedFeedItemIds.includes(item.id));

    combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Deduplicate
    const unique: typeof combined = [];
    const seen = new Set<string>();
    for (const item of combined) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        unique.push(item);
      }
    }

    return unique;
  };

  // App navigation state
  const [activeScreen, setActiveScreen] = useState<'chatList' | 'chat' | 'search' | 'settings' | 'calls' | 'admin'>('chatList');
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [selectedPeerProfile, setSelectedPeerProfile] = useState<Profile | undefined>(undefined);
  const [selectedTargetMsgId, setSelectedTargetMsgId] = useState<string | null>(null);
  const [activeProfileView, setActiveProfileView] = useState<{ type: 'user' | 'group' | 'general'; data?: any } | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Register custom listeners for local UI/recording events
  useEffect(() => {
    const handleDeleteMessageEvent = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.messageId) {
        setMessagesList((prev) => prev.map((m) => m.id === detail.messageId ? { ...m, text: '_vyper_deleted_::', is_voice: false, file_name: undefined, file_url: undefined, file_data: undefined, file_type: undefined } : m));
      }
    };

    const handleNewLocalMessage = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        setMessagesList((prev) => addOrUpdateMessage(prev, detail));
      }
    };

    window.addEventListener('vyper_delete_message', handleDeleteMessageEvent);
    window.addEventListener('vyper_new_local_message', handleNewLocalMessage);

    return () => {
      window.removeEventListener('vyper_delete_message', handleDeleteMessageEvent);
      window.removeEventListener('vyper_new_local_message', handleNewLocalMessage);
    };
  }, []);

  // Groups state
  const [groups, setGroups] = useState<Group[]>(() => {
    try {
      const local = localStorage.getItem('vypervic_secure_groups_v1');
      return local ? JSON.parse(local) : [];
    } catch (e) {
      return [];
    }
  });

  // Automatically save all media, documents & files and voice records (sent or received) to device local storage
  const processedFileMsgIdsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    messagesList.forEach((msg) => {
      if (msg.file_data && msg.file_name && !processedFileMsgIdsRef.current.has(msg.id)) {
        processedFileMsgIdsRef.current.add(msg.id);

        const isSentByMe = currentUser && msg.sender_id === currentUser.id;
        const direction: 'to' | 'from' = isSentByMe ? 'to' : 'from';

        let targetName = 'Recipient';
        if (isSentByMe) {
          if (msg.chat_id.startsWith('dm:')) {
            const parts = msg.chat_id.split(':');
            const otherId = parts.find(id => id !== currentUser.id);
            const peer = allProfiles.find(p => p.id === otherId);
            targetName = peer?.display_name || peer?.username || 'Recipient';
          } else {
            const grp = groups.find(g => g.id === msg.chat_id);
            targetName = grp?.name || (msg.chat_id === 'general' ? 'VyperVic General' : 'Group Chat');
          }
        } else {
          const sender = allProfiles.find(p => p.id === msg.sender_id) || msg.profiles;
          targetName = sender?.display_name || sender?.username || 'Contact';
        }

        const effectiveFileType = msg.is_voice
          ? 'audio/voice-note'
          : (msg.file_type || 'application/octet-stream');

        // Save to IndexedDB
        saveFileToLocalStorage(
          msg.file_name,
          effectiveFileType,
          msg.file_data,
          msg.id,
          direction,
          targetName
        )
          .then(() => {
            console.log(`Automatically cached/saved ${msg.file_name} to local storage`);
          })
          .catch((e) => {
            console.warn(`Failed to auto-cache ${msg.file_name}:`, e);
          });
      }

      // Automatically parse and save links to local storage
      if (msg.text && !msg.file_data && !processedFileMsgIdsRef.current.has(msg.id + '_link')) {
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        const urls = msg.text.match(urlRegex);
        if (urls && urls.length > 0) {
          processedFileMsgIdsRef.current.add(msg.id + '_link');

          const isSentByMe = currentUser && msg.sender_id === currentUser.id;
          const direction: 'to' | 'from' = isSentByMe ? 'to' : 'from';

          let targetName = 'Operator';
          if (isSentByMe) {
            if (msg.chat_id.startsWith('dm:')) {
              const parts = msg.chat_id.split(':');
              const otherId = parts.find(id => id !== currentUser.id);
              const peer = allProfiles.find(p => p.id === otherId);
              targetName = peer?.display_name || peer?.username || 'User';
            } else {
              const grp = groups.find(g => g.id === msg.chat_id);
              targetName = grp?.name || (msg.chat_id === 'general' ? 'VyperVic General' : 'Group Chat');
            }
          } else {
            const sender = allProfiles.find(p => p.id === msg.sender_id) || msg.profiles;
            targetName = sender?.display_name || sender?.username || 'Operator';
          }

          urls.forEach((url, index) => {
            saveFileToLocalStorage(
              url,
              'link',
              url,
              `${msg.id}_link_${index}`,
              direction,
              targetName
            )
              .then(() => {
                console.log(`Automatically cached link ${url} to local storage`);
              })
              .catch((e) => {
                console.warn(`Failed to auto-cache link ${url}:`, e);
              });
          });
        }
      }
    });
  }, [messagesList, currentUser, allProfiles, groups]);

  // Global roast toast event listener
  useEffect(() => {
    const handleRoastToast = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        showToast(detail);
      }
    };
    window.addEventListener('vyper_show_roast_toast', handleRoastToast);
    return () => window.removeEventListener('vyper_show_roast_toast', handleRoastToast);
  }, []);
  const [typingState, setTypingState] = useState<Record<string, Record<string, { username: string; timestamp: number }>>>({});

  // Load and persist read receipts
  const [readReceipts, setReadReceipts] = useState<Record<string, { readerId: string; lastReadMessageId: string; timestamp: string }>>(() => {
    const local = localStorage.getItem('vypervic_read_receipts_v2');
    return local ? JSON.parse(local) : {};
  });

  // Read receipts privacy toggle (defaults to enabled, syncs with localStorage)
  const [readReceiptsEnabled, setReadReceiptsEnabled] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('vypervic_read_receipts_enabled');
      return stored !== 'false';
    } catch {
      return true;
    }
  });

  const handleToggleReadReceipts = (enabled: boolean) => {
    setReadReceiptsEnabled(enabled);
    try {
      localStorage.setItem('vypervic_read_receipts_enabled', String(enabled));
    } catch {
      // Ignore
    }
  };

  // Load and persist our own read receipts for unread badge counts
  const [myReadReceipts, setMyReadReceipts] = useState<Record<string, { lastReadMessageId: string; timestamp: string }>>(() => {
    const local = localStorage.getItem('vypervic_my_read_receipts_v1');
    return local ? JSON.parse(local) : {};
  });

  const wasNotificationCenterOpenRef = useRef(false);

  useEffect(() => {
    if (showNotificationCenter) {
      wasNotificationCenterOpenRef.current = true;
    } else if (wasNotificationCenterOpenRef.current) {
      wasNotificationCenterOpenRef.current = false;

      // 1. Mark notifications as read instead of deleting them from the list
      const allFeedIds = getUnifiedFeed().map((item) => item.id);
      setReadNotifIds((prev) => Array.from(new Set([...prev, ...allFeedIds])));

      // 2. Mark all other users' messages in our chats as read (by setting our read receipts to the latest message)
      setMyReadReceipts((prev) => {
        const next = { ...prev };
        const roomsWithUnread = new Set<string>();

        messagesList.forEach((m) => {
          if (m.sender_id !== currentUser?.id) {
            roomsWithUnread.add(m.chat_id);
          }
        });

        roomsWithUnread.forEach((chatId) => {
          const roomMsgs = messagesList.filter((m) => m.chat_id === chatId);
          if (roomMsgs.length > 0) {
            const lastMsg = roomMsgs[roomMsgs.length - 1];
            next[chatId] = {
              lastReadMessageId: lastMsg.id,
              timestamp: new Date().toISOString(),
            };

            // Broadcast read receipt
            const lastPeerMsg = [...roomMsgs].reverse().find((m) => m.sender_id !== (currentUser?.id || ''));
            if (readReceiptsEnabled && lastPeerMsg && currentUser) {
              sendBroadcastEvent('read_receipt', {
                chatId,
                readerId: currentUser.id,
                lastReadMessageId: lastPeerMsg.id,
                timestamp: new Date().toISOString(),
              });
            }
          }
        });

        return next;
      });

      showToast('Marked all as read');
    }
  }, [showNotificationCenter, currentUser, messagesList]);

  // Load and persist message reactions
  const [reactions, setReactions] = useState<Record<string, Record<string, string[]>>>(() => {
    const local = localStorage.getItem('vypervic_reactions_v2');
    return local ? JSON.parse(local) : {};
  });

  // Load and persist pinned messages per chat room
  const [pinnedState, setPinnedState] = useState<Record<string, string[]>>(() => {
    try {
      const local = localStorage.getItem('vypervic_pinned_messages_v3');
      return local ? JSON.parse(local) : {};
    } catch (e) {
      return {};
    }
  });

  // Custom Themes (Requirement 3.1 & 3.2)

  const [chatThemes, setChatThemes] = useState<Record<string, ThemeConfig>>(() => {
    try {
      const local = localStorage.getItem('vypervic_chat_themes_v1');
      return local ? JSON.parse(local) : {};
    } catch (e) {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_secure_groups_v1', JSON.stringify(groups));
    } catch (e) {
      // Ignore
    }
  }, [groups]);

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_chat_themes_v1', JSON.stringify(chatThemes));
    } catch (e) {
      // Ignore
    }
  }, [chatThemes]);

  // Redirect to active chat when notification is clicked
  const selectChatFromNotification = (chatId: string) => {
    setSelectedChatId(chatId);
    if (chatId === 'general') {
      setSelectedPeerProfile(undefined);
    } else {
      const peerId = chatId.split(':').find((id) => id !== currentUser?.id);
      const peer = allProfiles.find((p) => p.id === peerId);
      setSelectedPeerProfile(peer);
    }
    setActiveScreen('chat');
    setShowNotificationCenter(false);
    setHeadsUpNotification(null);
  };

  // Quick reply directly from the notification center
  const handleReplyFromNotification = async (notifId: string, text: string) => {
    const unified = getUnifiedFeed();
    const item = unified.find((u) => u.id === notifId) || (headsUpNotification?.id === notifId ? headsUpNotification : null);
    if (!item) return;

    const replyMsg = {
      id: 'msg_' + crypto.randomUUID(),
      chat_id: item.chatId,
      sender_id: currentUser?.id || '',
      text: text,
      file_name: null,
      file_type: null,
      file_data: null,
      is_voice: false,
      created_at: new Date().toISOString(),
    };

    // Insert to local optimistic list
    setMessagesList((prev) => addOrUpdateMessage(prev, replyMsg));

    // Try sending to Oracle DB
    try {
      const { data, error } = await oracleDB.from('messages').insert(replyMsg);
      if (!error && data?.id) setMessagesList(prev => addOrUpdateMessage(prev, data));
      else await queueOfflineMessage(replyMsg as Message);
    } catch {
      await queueOfflineMessage(replyMsg as Message);
      showToast('Reply pending synchronization');
    }

    // Server publishes the persisted reply; there is no client-only durable event.


    // Remove notification from tray
    setNotifications((prev) => prev.filter((n) => n.id !== notifId));
    if (headsUpNotification?.id === notifId) {
      setHeadsUpNotification(null);
    }
    showToast('Sent');
  };

  const chatUpdatesChannelRef = useRef<any>(null);

  const currentUserRef = useRef<Profile | null>(null);
  const selectedChatIdRef = useRef<string | null>(null);
  const allProfilesRef = useRef<Profile[]>([]);
  const groupsRef = useRef<Group[]>([]);
  const activeCallRef = useRef<Call | null>(null);
  const isInitiatingCallRef = useRef<boolean>(false);
  const activeScreenRef = useRef<'chatList' | 'chat' | 'search' | 'settings' | 'calls' | 'admin'>('chatList');
  const activeProfileViewRef = useRef<{ type: 'user' | 'group' | 'general'; data?: any } | null>(null);
  const showNotificationCenterRef = useRef<boolean>(false);
  const sessionStartRef = useRef<number>(Date.now());
  const processedPushNotifIdsRef = useRef<Set<string>>((() => {
    try {
      const set = new Set<string>();
      const saved = localStorage.getItem('vyper_processed_notif_ids');
      if (saved) JSON.parse(saved).forEach((id: string) => set.add(id));
      return set;
    } catch {
      return new Set<string>();
    }
  })());

  const markNotifProcessed = (id: string) => {
    if (!id) return;
    processedPushNotifIdsRef.current.add(id);
    try {
      const arr = [...processedPushNotifIdsRef.current].slice(-400);
      localStorage.setItem('vyper_processed_notif_ids', JSON.stringify(arr));
    } catch {}
  };

  // Set of dismissed/ended/rejected call IDs to prevent ghost re-rings or loops
  const dismissedCallIdsRef = useRef<Set<string>>((() => {
    try {
      const set = new Set<string>();
      const saved1 = sessionStorage.getItem('vyper_dismissed_calls');
      const saved2 = localStorage.getItem('vyper_dismissed_calls_v2');
      if (saved1) JSON.parse(saved1).forEach((id: string) => set.add(id));
      if (saved2) JSON.parse(saved2).forEach((id: string) => set.add(id));
      return set;
    } catch {
      return new Set<string>();
    }
  })());

  const markCallDismissed = (callId: string) => {
    if (!callId) return;
    dismissedCallIdsRef.current.add(callId);
    try {
      const arr = [...dismissedCallIdsRef.current].slice(-200);
      sessionStorage.setItem('vyper_dismissed_calls', JSON.stringify(arr));
      localStorage.setItem('vyper_dismissed_calls_v2', JSON.stringify(arr));
    } catch {}
  };

  const groupCallStatusesRef = useRef<Record<string, string>>({});

  useEffect(() => {
    groupCallStatusesRef.current = groupCallStatuses;
  }, [groupCallStatuses]);

  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  useEffect(() => {
    selectedChatIdRef.current = selectedChatId;
  }, [selectedChatId]);

  useEffect(() => {
    allProfilesRef.current = allProfiles;
  }, [allProfiles]);

  useEffect(() => {
    groupsRef.current = groups;
  }, [groups]);

  useEffect(() => {
    activeCallRef.current = activeCall;
  }, [activeCall]);

  useEffect(() => {
    activeScreenRef.current = activeScreen;
  }, [activeScreen]);

  useEffect(() => {
    activeProfileViewRef.current = activeProfileView;
  }, [activeProfileView]);

  useEffect(() => {
    showNotificationCenterRef.current = showNotificationCenter;
  }, [showNotificationCenter]);

  // Global Android Hardware / Gesture Back Button & History Navigation Stack
  useEffect(() => {
    if (typeof window === 'undefined') return;

    if (!window.history.state || !window.history.state.root) {
      window.history.replaceState({ screen: 'chatList', root: true }, '');
    }

    const handlePopState = () => {
      // 1. If notification drawer is open, close it
      if (showNotificationCenterRef.current) {
        setShowNotificationCenter(false);
        return;
      }

      // 2. If viewing a full-screen profile, close it
      if (activeProfileViewRef.current) {
        setActiveProfileView(null);
        return;
      }

      // 3. If in a chat screen, return to chat list
      if (activeScreenRef.current === 'chat') {
        setSelectedChatId(null);
        setSelectedPeerProfile(undefined);
        setSelectedTargetMsgId(null);
        setActiveScreen('chatList');
        return;
      }

      // 4. If in search, settings, calls, or admin, return to chat list
      if (activeScreenRef.current !== 'chatList') {
        setActiveScreen('chatList');
        return;
      }

      // 5. If already at chatList root, re-anchor state so user doesn't accidentally exit
      window.history.pushState({ screen: 'chatList', root: true }, '');
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const openScreen = (screen: 'chatList' | 'chat' | 'search' | 'settings' | 'calls' | 'admin') => {
    if (activeScreen !== screen) {
      window.history.pushState({ screen }, '');
      setActiveScreen(screen);
    }
  };

  const openChat = (chatId: string, peer?: Profile, targetMessageId?: string) => {
    setSelectedChatId(chatId);
    setSelectedPeerProfile(peer);
    setSelectedTargetMsgId(targetMessageId || null);
    setActiveScreen('chat');
    window.history.pushState({ screen: 'chat', chatId }, '');
  };

  const openProfileView = (type: 'user' | 'group' | 'general', data?: any) => {
    setActiveProfileView({ type, data });
    window.history.pushState({ modal: 'profile' }, '');
  };

  const openNotifications = () => {
    setShowNotificationCenter(true);
    window.history.pushState({ modal: 'notifications' }, '');
  };

  const handleNavigateBack = () => {
    window.history.back();
  };

  // Trigger beautiful heads-up notification drawer and sound for background messages or mentions
  const triggerPushNotification = (newMsg: Message) => {
    if (!currentUserRef.current) return;
    if (!newMsg || !newMsg.id) return;

    // Avoid duplicate notification triggers for the same message ID
    if (processedPushNotifIdsRef.current.has(newMsg.id)) return;

    // Ignore messages sent by current user or in current active chat room
    if (newMsg.sender_id === currentUserRef.current.id) return;
    if (newMsg.chat_id === selectedChatIdRef.current) return;

    // Parse message timestamp safely (handling UTC and ISO formats)
    const parseMsgTime = (createdStr?: string | null): number => {
      if (!createdStr) return 0;
      let s = String(createdStr).trim();
      if (!s.endsWith('Z') && !/[+-]\d{2}(:\d{2})?$/.test(s)) {
        s = s.replace(' ', 'T') + 'Z';
      }
      const parsed = Date.parse(s);
      return isNaN(parsed) ? 0 : parsed;
    };

    const msgTime = parseMsgTime(newMsg.created_at);
    const now = Date.now();
    // Strictly ignore messages older than 25 seconds or created prior to session start
    if (!msgTime || (now - msgTime > 25000) || msgTime < sessionStartRef.current - 3000) {
      markNotifProcessed(newMsg.id);
      return;
    }

    // Privacy & Relevance Filters
    const isDM = newMsg.chat_id.startsWith('dm:');
    let isRecipientOfDM = false;
    if (isDM && newMsg.chat_id !== 'dm:system:test') {
      const parts = newMsg.chat_id.split(':');
      const u1 = parts[1];
      const u2 = parts[2];
      if (currentUserRef.current.id === u1 || currentUserRef.current.id === u2) {
        isRecipientOfDM = true;
      } else {
        return; // Ignore other users' private DMs completely
      }
    }

    const isGroup = newMsg.chat_id.startsWith('group:');
    if (isGroup) {
      const targetGroup = groupsRef.current.find((g) => g.id === newMsg.chat_id);
      if (!targetGroup || !targetGroup.members || !targetGroup.members.includes(currentUserRef.current.id)) {
        return; // Ignore groups user is not a member of
      }
    }

    const isMention = !!(
      newMsg.text &&
      currentUserRef.current?.username &&
      (newMsg.text || '').toLowerCase().includes(`@${(currentUserRef.current.username || '').toLowerCase()}`)
    );

    // CRITICAL: Only notify if it is a DM sent to user or an explicit @mention in a group/general chat!
    const shouldNotify = isRecipientOfDM || isMention;

    if (!shouldNotify) {
      return;
    }

    markNotifProcessed(newMsg.id);

    const sender = allProfilesRef.current.find((p) => p.id === newMsg.sender_id);
    const senderName = sender?.display_name || sender?.username || 'Somebody';
    const avatarUrl = sender?.avatar_url;

    // Vibrate if supported
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([100, 50, 100]);
      } catch (e) {}
    }

    // Play sound
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContext) {
        const ctx = new AudioContext();
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc1.frequency.exponentialRampToValueAtTime(880.00, ctx.currentTime + 0.15);

        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(698.46, ctx.currentTime + 0.05);
        osc2.frequency.exponentialRampToValueAtTime(1174.66, ctx.currentTime + 0.2);

        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start();
        osc2.start();
        osc1.stop(ctx.currentTime + 0.35);
        osc2.stop(ctx.currentTime + 0.35);
      }
    } catch (audioErr) {}

    const notificationTitle = isDM
      ? `New message from ${senderName}`
      : isMention
        ? `${senderName} mentioned you`
        : `New message`;
    const notificationBody = newMsg.is_voice
      ? '🎤 Sent a voice note'
      : newMsg.text || 'Sent an attachment 📎';

    const newNotif: PushNotification = {
      id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
      chatId: newMsg.chat_id,
      senderId: newMsg.sender_id,
      senderName,
      title: notificationTitle,
      body: notificationBody,
      isMention: !!isMention,
      timestamp: new Date().toISOString(),
    };

    setNotifications((prev) => [newNotif, ...prev].slice(0, 20));
    setHeadsUpNotification(newNotif);
    setShowHeadsUpReply(false);
    setHeadsUpReplyText('');

    // Auto-dismiss heads-up banner after 6 seconds
    resources.timeout(() => {
      setHeadsUpNotification((current) => current?.id === newNotif.id ? null : current);
    }, 6000);

    // System notification
    displayLocalPushNotification(notificationTitle, notificationBody, avatarUrl);
  };

  useEffect(() => {
    activeCallRef.current = activeCall;
  }, [activeCall]);

  useEffect(() => {
    activeScreenRef.current = activeScreen;
  }, [activeScreen]);

  // Sync state to local storage
  useEffect(() => {
    try {
      localStorage.setItem('vypervic_read_receipts_v2', JSON.stringify(readReceipts));
    } catch (e) {
      console.warn('Failed to save read receipts to localStorage:', e);
    }
  }, [readReceipts]);

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_my_read_receipts_v1', JSON.stringify(myReadReceipts));
    } catch (e) {
      console.warn('Failed to save my read receipts to localStorage:', e);
    }
  }, [myReadReceipts]);

  useEffect(() => {
    try {
      localStorage.setItem('vypervic_reactions_v2', JSON.stringify(reactions));
    } catch (e) {
      console.warn('Failed to save reactions to localStorage:', e);
    }
  }, [reactions]);

  // Global toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Show a visual toast
  const showToast = (msg: string) => {
    setToastMessage(msg);
    const timer = resources.timeout(() => setToastMessage(null), 1500);
    return () => resources.clearTimeout(timer);
  };



  // Local profiles are display caches, not authenticated identities.
  const [sessionVerified, setSessionVerified] = useState(false);
  useEffect(() => {
    if (!sessionVerified) return;
    const prune = () => { void import('./utils/indexedDB').then(storage => storage.pruneDisposableCache()).catch(() => console.warn('[Cache] Pruning deferred')); };
    prune(); const timer = setInterval(prune, 5 * 60000);
    return () => clearInterval(timer);
  }, [sessionVerified]);

  useEffect(() => {
    if (!sessionVerified || !currentUser) return;
    let disposed = false;
    const openTarget = async () => {
      const query = new URLSearchParams(window.location.search);
      if (query.has('reset')) { await oracleDB.auth.signOut(); setCurrentUser(null); return; }
      const chat = query.get('chat'), callId = query.get('call');
      if (chat && /^(general|dm:[A-Za-z0-9_-]+:[A-Za-z0-9_-]+|group:[A-Za-z0-9_-]+)$/.test(chat)) { setSelectedChatId(chat); setActiveScreen('chat'); }
      if (callId && /^[A-Za-z0-9_-]{1,255}$/.test(callId)) {
        const response = await fetch(`/api/calls/${encodeURIComponent(callId)}`, { credentials: 'same-origin' });
        if (response.ok) { const call = await response.json(); if (!disposed && call.receiver_id === currentUser.id && call.status === 'ringing' && Date.now() - Date.parse(call.created_at) < 30000) setActiveCall(call); }
      }
    };
    const navigate = () => { void openTarget().catch(() => showToast('Notification target unavailable; reconnect to retry')); };
    navigate(); window.addEventListener('vyper_native_navigation', navigate);
    return () => { disposed = true; window.removeEventListener('vyper_native_navigation', navigate); };
  }, [currentUser?.id, sessionVerified]);

  useEffect(() => {
    if (!sessionVerified) return;
    void flushOfflineQueue();
    const timer = setInterval(() => void flushOfflineQueue(), 30000);
    return () => clearInterval(timer);
  }, [sessionVerified]);

  useEffect(() => {
    let disposed = false;
    const checkAuth = async () => {
      try {
        if (new URLSearchParams(window.location.search).has('reset')) { await oracleDB.auth.signOut(); setCurrentUser(null); return; }
        const { data: { session } } = await oracleDB.auth.getSession();
        if (disposed) return;
        setCurrentUser(session?.profile || null);
        setSessionVerified(!!session?.user);
        if (session?.user) await flushOfflineQueue();
      } catch (error) {
        if (disposed || error instanceof SessionSupersededError) return;
        setSessionVerified(false);
        // Never fabricate or create a profile after a failed remote operation.
        try {
          const raw = sessionStorage.getItem('vypervic_session_user') || localStorage.getItem('vypervic_current_user_cache');
          if (raw) setCurrentUser(JSON.parse(raw));
        } catch { /* no readable display cache */ }
      } finally { if (!disposed) setLoading(false); }
    };
    const changed = () => {
      const state = getSessionStatus();
      setSessionVerified(state.status === 'authenticated');
      if (state.status === 'signed-out') setCurrentUser(null);
    };
    const offline = () => { setSessionStatus('offline', currentUserRef.current?.id || null); oracleDB.stopRealtimeSSE(); };
    const storage = (event: StorageEvent) => { if (event.key === 'vypervic_current_user_cache' || event.key === 'vyper_logout_pending') void checkAuth(); };
    const { data: { subscription } } = oracleDB.auth.onAuthStateChange((_event, session) => {
      if (disposed) return;
      setCurrentUser(session?.profile || null);
      setSessionVerified(!!session?.user);
      setLoading(false);
    });
    window.addEventListener('online', checkAuth);
    window.addEventListener('offline', offline);
    window.addEventListener('storage', storage);
    window.addEventListener('vyper_session_status', changed);
    window.addEventListener('vyper_retry_session', checkAuth);
    void checkAuth();
    return () => {
      disposed = true; subscription.unsubscribe(); oracleDB.stopRealtimeSSE();
      window.removeEventListener('online', checkAuth);
      window.removeEventListener('offline', offline);
      window.removeEventListener('storage', storage);
      window.removeEventListener('vyper_session_status', changed);
      window.removeEventListener('vyper_retry_session', checkAuth);
    };
  }, []);

  // 2. Fetch authoritative data and subscribe only after session validation.
  useEffect(() => {
    if (!currentUser || !sessionVerified) return;

    // Fetch initial profiles list with IndexedDB priority
    const fetchProfiles = async () => {
      // Step 1: Immediately load profiles from IndexedDB local storage
      try {
        const localProfs = await getCachedProfilesLocally();
        if (localProfs && localProfs.length > 0) {
          setAllProfiles(localProfs);
        }
      } catch (e) {}

      // Step 2: Query remote database if online and update local cache
      try {
        const { data, error } = await oracleDB.from('profiles').select(PUBLIC_PROFILE_COLUMNS);
        if (!error && data) {
          setAllProfiles(data);
          await cacheProfilesLocally(data, true);
          try {
            localStorage.setItem('vypervic_profiles_cache', JSON.stringify(data));
          } catch (e) {}
        }
      } catch (err) {
        console.warn('Network issue fetching profiles, maintaining local mirror:', err);
      }
    };

    // Fetch message history with IndexedDB local storage priority
    const fetchMessages = async () => {
      // Step 1: Immediately load all cached messages from IndexedDB and pending offline queue
      try {
        const localMsgs = await getCachedMessagesLocally();
        const offlineQueue = getOfflineQueue();

        // Merge offline queue into local messages if not already present
        const combined = [...localMsgs];
        for (const offMsg of offlineQueue) {
          if (!combined.some((m) => m.id === offMsg.id)) {
            combined.push({ ...offMsg, is_pending: true });
          }
        }

        if (combined.length > 0) {
          const filteredLocal = combined.filter((m) => {
            if (!m.chat_id) return true;
            if (m.chat_id.startsWith('dm:')) {
              if (m.chat_id === 'dm:system:test') return true;
              const parts = m.chat_id.split(':');
              const u1 = parts[1];
              const u2 = parts[2];
              return currentUserRef.current && (currentUserRef.current.id === u1 || currentUserRef.current.id === u2);
            }
            return true;
          });
          // Sort chronologically
          filteredLocal.sort(compareMessagesChronologically);
          for (const m of filteredLocal) {
            if (m?.id) processedPushNotifIdsRef.current.add(m.id);
          }
          setMessagesList(filteredLocal);
        }
      } catch (e) {}

      // Step 2: Query database for new messages and persist to IndexedDB
      try {
        const { data, error } = await oracleDB
          .from('messages')
          .select('*')
          .order('created_at', { ascending: true }).limit(1000);

        if (!error && data) {
          const filteredData = data.filter((m) => {
            if (!m.chat_id) return true;
            if (m.chat_id.startsWith('dm:')) {
              if (m.chat_id === 'dm:system:test') return true;
              const parts = m.chat_id.split(':');
              const u1 = parts[1];
              const u2 = parts[2];
              return currentUserRef.current && (currentUserRef.current.id === u1 || currentUserRef.current.id === u2);
            }
            return true;
          });

          // Always merge any pending offline messages that haven't synced yet
          const pendingQueue = getOfflineQueue();
          const completeList = [...filteredData];
          for (const pendingMsg of pendingQueue) {
            if (!completeList.some((m) => m.id === pendingMsg.id)) {
              completeList.push({ ...pendingMsg, is_pending: true });
            }
          }
          completeList.sort(compareMessagesChronologically);
          for (const m of completeList) {
            if (m?.id) processedPushNotifIdsRef.current.add(m.id);
          }

          setMessagesList((prev) => {
            const map = new Map<string, Message>();
            // Reconciliation is an upsert, not replacement: a partial feed page must
            // never delete older messages from the local authoritative cache.
            for (const m of prev) {
              map.set(m.id, m);
            }
            // Overlay verified database messages
            for (const m of completeList) {
              map.set(m.id, m);
            }
            return Array.from(map.values()).sort(compareMessagesChronologically);
          });
          // Persist all messages to IndexedDB
          cacheMessagesLocally(filteredData);
          try {
            const cachedMessages = completeList
              .slice(-50)
              .map(({ file_data, ...message }) => ({
                ...message,
                file_data: null,
                has_media: Boolean(file_data),
              }));
            localStorage.setItem('vypervic_messages_cache', JSON.stringify(cachedMessages));
          } catch (cacheErr) {}
        }
      } catch (err) {
        console.warn('Network issue fetching messages, offline local data active:', err);
      }
    };

    const fetchCallStatuses = async () => {
      try {
        // G-01: call reads must be authorization-scoped. Group-call room
        // statuses (receiver_id = 'general') plus the user's own calls.
        const { data: roomData } = await oracleDB
          .from('calls')
          .select('id, status')
          .eq('receiver_id', 'general');
        const { data: mineData } = await oracleDB
          .from('calls')
          .select('id, status')
          .eq('caller_id', currentUser?.id || '');
        const statuses: Record<string, string> = {};
        [...(roomData || []), ...(mineData || [])].forEach((c: any) => {
          statuses[c.id] = c.status;
        });
        setGroupCallStatuses(statuses);
      } catch (err) {
        console.error('Error fetching call statuses:', err);
      }
    };

    const fetchGroups = async () => {
      const { data, error } = await oracleDB.from('groups').select('*');
      if (!error && data) setGroups(data);
    };
    const fetchCallHistory = async () => {
      try {
        let combined: any[] = [];

        // 1. Fetch direct calls involving the current user as caller or receiver
        const { data: directData, error: directError } = await oracleDB
          .from('calls')
          .select('*')
          .or(`caller_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
          .order('created_at', { ascending: false })
          .limit(40);

        if (!directError && directData) {
          combined = [...directData];
        } else if (directError) {
          console.warn('Direct calls fetch error:', directError);
        }

        // 2. Fetch group calls (where receiver_id is 'general') inside a separate try-catch block
        // to gracefully recover if receiver_id is of type UUID in PostgreSQL.
        try {
          const { data: groupData, error: groupError } = await oracleDB
            .from('calls')
            .select('*')
            .eq('receiver_id', 'general')
            .order('created_at', { ascending: false })
            .limit(25);

          if (!groupError && groupData) {
            combined = [...combined, ...groupData];
          }
        } catch (gErr) {
          console.warn('Group call fetch bypassed (receiver_id is likely UUID type):', gErr);
        }

        // Sort combined array in descending order by created_at
        combined.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setCallHistory(combined.slice(0, 40));
        const ringing = combined.find(c => c.receiver_id === currentUser.id && c.status === 'ringing' && Date.now() - Date.parse(c.created_at) < 30000);
        if (ringing && !activeCallRef.current && !dismissedCallIdsRef.current.has(ringing.id)) setActiveCall(ringing);

        // Notify recipient of missed calls upon reconnecting
        if (currentUserRef.current) {
          const recentMissed = combined.filter((c) => {
            if (c.receiver_id !== currentUserRef.current?.id || c.status !== 'missed') return false;
            const age = Date.now() - new Date(c.created_at).getTime();
            return age < 24 * 60 * 60 * 1000;
          });
          if (recentMissed.length > 0) {
            const notifiedMissedKey = `vyper_notified_missed_${currentUserRef.current.id}`;
            try {
              const notified = JSON.parse(sessionStorage.getItem(notifiedMissedKey) || '[]');
              const unnotified = recentMissed.filter((c) => !notified.includes(c.id));
              if (unnotified.length > 0) {
                const latestCall = unnotified[0];
                const caller = allProfilesRef.current.find((p) => p.id === latestCall.caller_id);
                const callerName = caller ? getContactDisplayName(caller) : 'Contact';
                showToast(`Missed ${latestCall.type === 'video' ? 'video' : 'voice'} call from ${callerName}`);
                displayLocalPushNotification(
                  'Missed Call',
                  `You have a missed ${latestCall.type || 'voice'} call from ${callerName}`,
                  caller?.avatar_url
                );
                sessionStorage.setItem(notifiedMissedKey, JSON.stringify([...notified, ...unnotified.map((c) => c.id)]));
              }
            } catch {}
          }
        }
      } catch (err) {
        console.warn('Failed to fetch initial call history:', err);
      }
    };

    fetchProfiles();
    void fetchGroups();
    fetchMessages();
    fetchCallStatuses();
    fetchCallHistory();

    // Initialize instant SSE realtime stream for sub-20ms message and call sync
    if (currentUser?.id) {
      oracleDB.initRealtimeSSE(currentUser.id);
    }

    const checkAndTriggerIncomingCall = async (messageText: string) => {
      if (!messageText || !messageText.startsWith('_vyper_call_::')) return;
      try {
        const jsonStr = messageText.substring('_vyper_call_::'.length);
        const callMeta = JSON.parse(jsonStr);
        if (!callMeta || !callMeta.callId) return;
        const callResponse = await fetch(`/api/calls/${encodeURIComponent(callMeta.callId)}`, { credentials: 'same-origin' });
        if (!callResponse.ok) return;
        const durableCall = await callResponse.json();
        callMeta.callerId = durableCall.caller_id; callMeta.receiverId = durableCall.receiver_id;
        callMeta.status = durableCall.status; callMeta.type = durableCall.type; callMeta.created_at = durableCall.created_at;


        // If message indicates call ended, rejected, or missed, immediately mark dismissed & tear down
        if (callMeta.status === 'ended' || callMeta.status === 'rejected' || callMeta.status === 'missed') {
          markCallDismissed(callMeta.callId);
          setGroupCallStatuses((prev) => ({ ...prev, [callMeta.callId]: callMeta.status }));
          if (activeCallRef.current && activeCallRef.current.id === callMeta.callId) {
            setActiveCall(null);
          }
          return;
        }

        if (durableCall.receiver_id === 'general' || durableCall.receiver_id?.startsWith('group:')) return;
        if (callMeta.status === 'ringing') {
          if (dismissedCallIdsRef.current.has(callMeta.callId)) return;
          if (callMeta.callerId === currentUserRef.current?.id) return;

          const currentStatus = groupCallStatusesRef.current[callMeta.callId];
          if (currentStatus === 'ended' || currentStatus === 'rejected' || currentStatus === 'missed') return;

          const msgTime = (callMeta.created_at && !isNaN(Date.parse(callMeta.created_at)))
            ? new Date(callMeta.created_at).getTime()
            : 0;
          // Disallow calls older than 20 seconds
          if (!msgTime || Date.now() - msgTime > 20000) {
            markCallDismissed(callMeta.callId);
            return;
          }

          const isTarget = callMeta.receiverId === currentUserRef.current?.id ||
                         (callMeta.receiverId === 'general' && callMeta.callerId !== currentUserRef.current?.id);

          if (isTarget && !activeCallRef.current) {
            const incomingCall: Call = {
              id: callMeta.callId,
              caller_id: callMeta.callerId,
              receiver_id: callMeta.receiverId || 'general',
              type: callMeta.type,
              status: 'ringing',
              signal_data: null,
              created_at: callMeta.created_at || new Date().toISOString(),
              updated_at: new Date().toISOString()
            };
            setActiveCall(incomingCall);
          }
        }
      } catch (e) {
        console.warn('Failed to parse incoming call metadata from message:', e);
      }
    };

    // A. Listen to profiles table updates (status, display name edits, avatar changes)
    const profilesChannel = oracleDB
      .channel('realtime_profiles')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'profiles' },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newProfile = payload.new as Profile;
            setAllProfiles((prev) => {
              if (prev.some((p) => p.id === newProfile.id)) return prev;
              return [...prev, newProfile];
            });
          } else if (payload.eventType === 'UPDATE') {
            const updatedProfile = payload.new as Profile;
            if (!updatedProfile || !updatedProfile.id) return;
            setAllProfiles((prev) =>
              prev.map((p) => {
                if (p.id === updatedProfile.id) {
                  return {
                    ...p,
                    ...updatedProfile,
                    display_name: updatedProfile.display_name || p.display_name,
                    username: updatedProfile.username || p.username,
                    email: updatedProfile.email || p.email,
                  };
                }
                return p;
              })
            );
            if (updatedProfile.id === currentUserRef.current?.id) {
              setCurrentUser((prev) => {
                if (!prev) return updatedProfile;
                return {
                  ...prev,
                  ...updatedProfile,
                  display_name: updatedProfile.display_name || prev.display_name,
                  username: updatedProfile.username || prev.username,
                  email: updatedProfile.email || prev.email,
                };
              });
            }
          } else if (payload.eventType === 'DELETE') {
            const deletedId = payload.old.id;
            setAllProfiles((prev) => prev.filter((p) => p.id !== deletedId));
          }
        }
      )
      .subscribe();

    // B. Listen to messages table updates (real-time chat messaging)
    const messagesChannel = oracleDB
      .channel('realtime_messages')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'messages' },
        (payload) => {
          const msg = (payload.new || payload.old) as Message;
          if (msg && msg.chat_id) {
            if (msg.chat_id.startsWith('dm:')) {
              if (msg.chat_id !== 'dm:system:test') {
                const parts = msg.chat_id.split(':');
                const u1 = parts[1];
                const u2 = parts[2];
                if (currentUserRef.current && currentUserRef.current.id !== u1 && currentUserRef.current.id !== u2) {
                  return; // Ignore other users' private DMs completely
                }
              }
            } else if (msg.chat_id.startsWith('me:')) {
              const targetUserId = msg.chat_id.substring(3);
              if (currentUserRef.current && currentUserRef.current.id !== targetUserId) {
                return; // Ignore other users' private self-chats completely
              }
            }
          }

          if (payload.eventType === 'INSERT') {
            const newMsg = payload.new as Message;
            setMessagesList((prev) => addOrUpdateMessage(prev, newMsg));

            if (newMsg.text) {
              checkAndTriggerIncomingCall(newMsg.text);
            }

            // Trigger background push notification checks and sliding banners
            // Explicitly filter message inserts by chat_id before triggering push notification
            if (newMsg && newMsg.chat_id) {
              const currentUserId = currentUserRef.current?.id;
              let isTargetedToUser = false;

              if (currentUserId) {
                if (newMsg.chat_id.startsWith('dm:')) {
                  const parts = newMsg.chat_id.split(':');
                  isTargetedToUser = (parts[1] === currentUserId || parts[2] === currentUserId);
                } else if (newMsg.chat_id.startsWith('me:')) {
                  isTargetedToUser = newMsg.chat_id === `me:${currentUserId}`;
                } else if (newMsg.chat_id.startsWith('group:')) {
                  const targetGroup = groupsRef.current.find((g) => g.id === newMsg.chat_id);
                  isTargetedToUser = !!(targetGroup?.members?.includes(currentUserId));
                } else if (newMsg.chat_id === 'general') {
                  const isMention = !!(
                    newMsg.text &&
                    currentUserRef.current?.username &&
                    (newMsg.text || '').toLowerCase().includes(`@${(currentUserRef.current.username || '').toLowerCase()}`)
                  );
                  isTargetedToUser = isMention;
                }
              }

              if (isTargetedToUser) {
                triggerPushNotification(newMsg);
              }
            }
          } else if (payload.eventType === 'UPDATE') {
            const updatedMsg = payload.new as Message;
            setMessagesList((prev) => prev.map((m) => (m.id === updatedMsg.id ? updatedMsg : m)));
          } else if (payload.eventType === 'DELETE') {
            const deletedId = payload.old.id;
            setMessagesList((prev) => prev.map((m) => m.id === deletedId ? { ...m, text: '_vyper_deleted_::', is_voice: false, file_name: undefined, file_url: undefined, file_data: undefined, file_type: undefined } : m));
          }
        }
      )
      .subscribe();

    // C. Listen to calls table updates (real-time voice/video call request alerts)
    const callsChannel = oracleDB
      .channel('realtime_calls')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'calls' },
        (payload) => {
          const newCall = payload.new as Call;
          setGroupCallStatuses((prev) => ({ ...prev, [newCall.id]: newCall.status }));
          if (newCall.status === 'rejected' || newCall.status === 'ended') {
            dismissedCallIdsRef.current.add(newCall.id);
            if (activeCallRef.current?.id === newCall.id) {
              setActiveCall(null);
            }
            return;
          }

          if (
            newCall.receiver_id === currentUserRef.current?.id &&
            newCall.status === 'ringing' &&
            newCall.caller_id !== currentUserRef.current?.id &&
            !dismissedCallIdsRef.current.has(newCall.id) &&
            groupCallStatusesRef.current[newCall.id] !== 'ended' &&
            groupCallStatusesRef.current[newCall.id] !== 'rejected' &&
            !activeCallRef.current
          ) {
            const age = Date.now() - new Date(newCall.created_at).getTime();
            if (age < 20000) {
              setActiveCall(newCall);
            }
          }
          setCallHistory((prev) => {
            if (prev.some((c) => c.id === newCall.id)) return prev;
            return [newCall, ...prev];
          });
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'calls' },
        (payload) => {
          const updatedCall = payload.new as Call;
          setGroupCallStatuses((prev) => ({ ...prev, [updatedCall.id]: updatedCall.status }));
          if (updatedCall.status === 'rejected' || updatedCall.status === 'ended' || updatedCall.status === 'missed') {
            dismissedCallIdsRef.current.add(updatedCall.id);
          }
          if (updatedCall.id === activeCallRef.current?.id) {
            if (updatedCall.status === 'rejected' || updatedCall.status === 'ended' || updatedCall.status === 'missed') {
              setActiveCall(null);
            } else if (updatedCall.status === 'accepted') {
              setActiveCall(updatedCall);
            }
          }
          setCallHistory((prev) => {
            return prev.map((c) => (c.id === updatedCall.id ? updatedCall : c));
          });
        }
      )
      .subscribe();

    // D. Global Real-time Broadcast updates (typing indicators, read receipts, message reactions, real-time calling signaling)
    const chatUpdatesChannel = oracleDB
      .channel('chat_updates_global')
      .on('broadcast', { event: 'typing' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { chatId, userId, username, isTyping } = payload;
        setTypingState((prev) => {
          const chatState = { ...(prev[chatId] || {}) };
          if (isTyping) {
            chatState[userId] = { username, timestamp: Date.now() };
          } else {
            delete chatState[userId];
          }
          return { ...prev, [chatId]: chatState };
        });
      })
      .on('broadcast', { event: 'read_receipt' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { chatId, readerId, lastReadMessageId, timestamp } = payload;
        if (readerId !== currentUserRef.current?.id) {
          setReadReceipts((prev) => ({
            ...prev,
            [chatId]: { readerId, lastReadMessageId, timestamp },
          }));
        }
      })
      .on('broadcast', { event: 'reaction' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { messageId, userId, emoji } = payload;
        setReactions((prev) => {
          const msgReactions = { ...(prev[messageId] || {}) } as Record<string, string[]>;

          let existingEmoji: string | null = null;
          for (const [key, users] of Object.entries(msgReactions)) {
            if (users.includes(userId)) {
              existingEmoji = key;
              break;
            }
          }

          const updatedMsgReactions = { ...msgReactions };

          if (existingEmoji === emoji) {
            const users = [...(updatedMsgReactions[emoji] || [])];
            const idx = users.indexOf(userId);
            if (idx >= 0) {
              users.splice(idx, 1);
            }
            if (users.length === 0) {
              delete updatedMsgReactions[emoji];
            } else {
              updatedMsgReactions[emoji] = users;
            }
          } else {
            if (existingEmoji) {
              const users = [...(updatedMsgReactions[existingEmoji] || [])];
              const idx = users.indexOf(userId);
              if (idx >= 0) {
                users.splice(idx, 1);
              }
              if (users.length === 0) {
                delete updatedMsgReactions[existingEmoji];
              } else {
                updatedMsgReactions[existingEmoji] = users;
              }
            }

            const users = [...(updatedMsgReactions[emoji] || [])];
            if (!users.includes(userId)) {
              users.push(userId);
            }
            updatedMsgReactions[emoji] = users;
          }
          return { ...prev, [messageId]: updatedMsgReactions };
        });
      })
      .on('broadcast', { event: 'pin_change' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { chatId, pinnedMessageIds } = payload;
        setPinnedState((prev) => {
          const updated = { ...prev, [chatId]: pinnedMessageIds };
          try {
            localStorage.setItem('vypervic_pinned_messages_v3', JSON.stringify(updated));
          } catch (e) {
            console.warn('Failed to save pinned messages to localStorage:', e);
          }
          return updated;
        });
      })
      .on('broadcast', { event: 'vyper_call_participant_added' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        window.dispatchEvent(new CustomEvent('vyper_call_participant_added', { detail: payload }));
      })
      .on('broadcast', { event: 'vyper_call_live_reaction' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        window.dispatchEvent(new CustomEvent('vyper_call_live_reaction', { detail: payload }));
      })
      .on('broadcast', { event: 'vyper_group_call_heartbeat' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        window.dispatchEvent(new CustomEvent('vyper_group_call_heartbeat', { detail: payload }));
      })
      .on('broadcast', { event: 'vyper_group_call_leave' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        window.dispatchEvent(new CustomEvent('vyper_group_call_leave', { detail: payload }));
      })
      .on('broadcast', { event: 'call_invite' }, (response: any) => {
        const payload = response.payload;
        if (!payload || !currentUserRef.current) return;
        const { call } = payload;
        if (!call || !call.id || dismissedCallIdsRef.current.has(call.id)) return;
        if (call.caller_id === currentUserRef.current.id) return;
        if (call.status !== 'ringing') return;

        const currentStatus = groupCallStatusesRef.current[call.id];
        if (currentStatus === 'ended' || currentStatus === 'rejected' || currentStatus === 'missed') return;

        const callAge = (call.created_at && !isNaN(Date.parse(call.created_at)))
          ? Date.now() - new Date(call.created_at).getTime()
          : 99999999;
        if (callAge > 20000) {
          markCallDismissed(call.id);
          return;
        }

        if (call.receiver_id === 'general' && call.status === 'ringing') {
          setGroupCallStatuses((prev) => ({ ...prev, [call.id]: 'ringing' }));
        } else if (call.receiver_id === currentUserRef.current.id && call.status === 'ringing' && !activeCallRef.current) {
          setActiveCall(call);
        }
      })
      .on('broadcast', { event: 'call_status_update' }, (response: any) => {
        const payload = response.payload;
        if (!payload || !currentUserRef.current) return;
        const { callId, status } = payload;
        setGroupCallStatuses((prev) => ({ ...prev, [callId]: status }));
        if (status === 'rejected' || status === 'ended' || status === 'missed') {
          markCallDismissed(callId);
          try {
            sessionStorage.setItem('vyper_dismissed_calls', JSON.stringify([...dismissedCallIdsRef.current]));
          } catch {}

          // Update messagesList so any _vyper_call_ message status is marked ended/rejected/missed
          setMessagesList((prev) =>
            prev.map((m) => {
              if (m.text && m.text.startsWith('_vyper_call_::')) {
                try {
                  const meta = JSON.parse(m.text.substring('_vyper_call_::'.length));
                  if (meta.callId === callId && meta.status === 'ringing') {
                    meta.status = status;
                    return { ...m, text: `_vyper_call_::${JSON.stringify(meta)}` };
                  }
                } catch {}
              }
              return m;
            })
          );

          // Update callHistory
          setCallHistory((prev) =>
            prev.map((c) => (c.id === callId ? { ...c, status, updated_at: new Date().toISOString() } : c))
          );
        }
        if (activeCallRef.current && activeCallRef.current.id === callId) {
          if (status === 'accepted') {
            setActiveCall((prev) => prev ? { ...prev, status: 'accepted' } : null);
          } else if (status === 'rejected' || status === 'ended' || status === 'missed') {
            setActiveCall(null);
          }
        }
      })
      .on('broadcast', { event: 'new_message' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { message } = payload;
        if (!message || !message.chat_id) return;

        // Apply strict privacy filters to real-time broadcast messages
        if (message.chat_id.startsWith('dm:')) {
          if (message.chat_id !== 'dm:system:test') {
            const parts = message.chat_id.split(':');
            const u1 = parts[1];
            const u2 = parts[2];
            if (currentUserRef.current && currentUserRef.current.id !== u1 && currentUserRef.current.id !== u2) {
              return; // Ignore other users' private DMs completely
            }
          }
        } else if (message.chat_id.startsWith('me:')) {
          const targetUserId = message.chat_id.substring(3);
          if (currentUserRef.current && currentUserRef.current.id !== targetUserId) {
            return; // Ignore other users' private self-chats completely
          }
        }

        setMessagesList((prev) => addOrUpdateMessage(prev, message));

        if (message.text) {
          checkAndTriggerIncomingCall(message.text);
        }

        // Trigger notification if not in the current active chat
        triggerPushNotification(message);
      })
      .on('broadcast', { event: 'delete_message' }, (response: any) => {
        const payload = response.payload;
        if (payload && payload.messageId) {
          setMessagesList((prev) => prev.map((m) => m.id === payload.messageId ? { ...m, text: '_vyper_deleted_::', is_voice: false, file_name: undefined, file_url: undefined, file_data: undefined, file_type: undefined } : m));
        }
      })
      .on('broadcast', { event: 'vyper_group_created' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { group } = payload;
        if (!group) return;
        setGroups((prev) => {
          if (prev.some((g) => g.id === group.id)) return prev;
          return [...prev, group];
        });
      })
      .on('broadcast', { event: 'vyper_group_removed' }, ({ payload }: any) => {
        setGroups(prev => prev.filter(group => group.id !== payload?.groupId));
        setMessagesList(prev => prev.filter(message => message.chat_id !== payload?.groupId));
      })
      .on('broadcast', { event: 'vyper_group_updated' }, (response: any) => {
        const payload = response.payload;
        if (!payload) return;
        const { group } = payload;
        if (!group) return;
        setGroups(prev => group.members?.includes(currentUserRef.current?.id) ? [...prev.filter(g => g.id !== group.id), group] : prev.filter(g => g.id !== group.id));
      })
      .on('broadcast', { event: 'vyper_user_presence' }, (response: any) => {
        const payload = response.payload;
        if (!payload || !payload.userId) return;
        const isOnline = payload.is_online !== false;
        const lastSeen = payload.last_seen || new Date().toISOString();
        setAllProfiles((prev) =>
          prev.map((p) =>
            p.id === payload.userId
              ? { ...p, is_online: isOnline, last_seen: lastSeen }
              : p
          )
        );
      })
      .subscribe();

    // D. Real-time subscription to the custom `triggered_pushes` table
    let triggeredPushesChannel: any = null;
    if (currentUser) {
      triggeredPushesChannel = oracleDB
        .channel(`realtime_triggered_pushes:${currentUser.id}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'triggered_pushes', filter: `user_id=eq.${currentUser.id}` },
          (payload) => {
            const push = payload.new as any;
            if (push) {
              // Construct a mock message to trigger unified notifications engine
              const mockMsg: Message = {
                id: push.id || 'notif_' + Date.now(),
                chat_id: push.type === 'mention' ? 'general' : `dm:system:test`,
                sender_id: '00000000-0000-0000-0000-000000000000', // support/bot
                text: push.body,
                file_name: null,
                file_type: null,
                file_data: null,
                is_voice: false,
                created_at: new Date().toISOString(),
              };
              triggerPushNotification(mockMsg);
            }
          }
        )
        .subscribe();
    }

    chatUpdatesChannelRef.current = chatUpdatesChannel;

    // Periodic profile sync to keep active presence accurate (optimized 30s to conserve battery)
    const profilesSyncInterval = setInterval(async () => {
      if (!navigator.onLine || document.hidden) return;
      try {
        const { data, error } = await oracleDB.from('profiles').select(PUBLIC_PROFILE_COLUMNS);
        if (!error && data && data.length > 0) {
          setAllProfiles((prev) => {
            const map = new Map<string, Profile>(prev.map((p) => [p.id, p]));
            for (const p of (data as Profile[])) {
              const existing = map.get(p.id);
              map.set(p.id, existing ? { ...existing, ...p } : p);
            }
            return Array.from(map.values());
          });
          cacheProfilesLocally(data);
        }
      } catch (e) {}
    }, 30000);

    const handleReconnectOnline = () => {
      void fetchGroups();
      fetchProfiles();
      fetchMessages();
      fetchCallStatuses();
      fetchCallHistory();
    };
    const visible = () => { if (!document.hidden) handleReconnectOnline(); };
    document.addEventListener('visibilitychange', visible);
    window.addEventListener('online', handleReconnectOnline);
    window.addEventListener('vyper_realtime_reconcile', handleReconnectOnline);
    const reconciliationTimer = setInterval(() => { if (!document.hidden) handleReconnectOnline(); }, 60000);

    return () => {
      document.removeEventListener('visibilitychange', visible);
      window.removeEventListener('online', handleReconnectOnline);
      window.removeEventListener('vyper_realtime_reconcile', handleReconnectOnline);
      clearInterval(reconciliationTimer);
      oracleDB.stopRealtimeSSE();
      clearInterval(profilesSyncInterval);
      oracleDB.removeChannel(profilesChannel);
      oracleDB.removeChannel(messagesChannel);
      oracleDB.removeChannel(callsChannel);
      oracleDB.removeChannel(chatUpdatesChannel);
      if (triggeredPushesChannel) {
        oracleDB.removeChannel(triggeredPushesChannel);
      }
    };
  }, [currentUser?.id, sessionVerified]);

  // Handle setting user online/offline on load or exit
  useEffect(() => {
    if (!currentUser) return;

    const emitPresenceUpdate = async (isOnline = true) => {
      if (!currentUser?.id) return;
      const nowIso = new Date().toISOString();

      // 1. Immediately update local state
      setAllProfiles((prev) =>
        prev.map((p) => (p.id === currentUser.id ? { ...p, is_online: isOnline, last_seen: nowIso } : p))
      );

      // 2. Broadcast presence event in real-time across tabs & network peers
      sendBroadcastEvent('vyper_user_presence', {
        userId: currentUser.id,
        is_online: isOnline,
        last_seen: nowIso,
      });

      // 3. Persist to database
      try {
        await oracleDB
          .from('profiles')
          .update({ is_online: isOnline, last_seen: nowIso })
          .eq('id', currentUser.id);
      } catch (err) {
        console.warn('Presence update error:', err);
      }
    };

    // Set online immediately on mount
    emitPresenceUpdate(true);

    // Heartbeat every 30 seconds to keep presence alive while saving battery
    const heartbeatInterval = setInterval(() => {
      if (navigator.onLine === false || document.hidden) return;
      emitPresenceUpdate(true);
    }, 30000);

    const handleFocus = () => {
      if (navigator.onLine) emitPresenceUpdate(true);
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && navigator.onLine) {
        emitPresenceUpdate(true);
      }
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const handleBeforeUnload = async () => {
      try {
        if (activeCallRef.current) {
          await oracleDB
            .from('calls')
            .update({ status: 'ended', updated_at: new Date().toISOString() })
            .eq('id', activeCallRef.current.id);
        }
        await emitPresenceUpdate(false);
      } catch (err) {
        console.warn('Error in handleBeforeUnload:', err);
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      clearInterval(heartbeatInterval);
    };
  }, [currentUser?.id]);

  // Fallback Polling for Active Calls to guarantee 100% calling reliability across devices
  useEffect(() => {
    if (!currentUser) return;

    const pollCalls = async () => {
      try {
        if (document.hidden || activeCallRef.current) return;

        const twentySecsAgo = new Date(Date.now() - 20000).toISOString();
        const { data, error } = await oracleDB
          .from('calls')
          .select('*')
          .eq('receiver_id', currentUser.id)
          .eq('status', 'ringing')
          .gt('created_at', twentySecsAgo)
          .order('created_at', { ascending: false })
          .limit(1);

        if (!error && data && data.length > 0) {
          const call = data[0];
          const callAge = (call.created_at && !isNaN(Date.parse(call.created_at)))
            ? Date.now() - new Date(call.created_at).getTime()
            : 99999999;
          const currentStatus = groupCallStatusesRef.current[call.id];

          // If stale, ended, or rejected, purge immediately and never pop up
          if (callAge > 20000 || currentStatus === 'ended' || currentStatus === 'rejected' || currentStatus === 'missed') {
            markCallDismissed(call.id);
            // Stale call visibility is filtered locally; durable history is retained.
            return;
          }

          if (
            !dismissedCallIdsRef.current.has(call.id) &&
            call.caller_id !== currentUser.id &&
            !activeCallRef.current
          ) {
            setActiveCall(call);
          }
        }
      } catch (err) {
        console.error('Error polling active calls:', err);
      }
    };

    const interval = setInterval(pollCalls, 2500);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Fallback Polling for Call Status updates (accepted, rejected, ended)
  useEffect(() => {
    if (!currentUser || !activeCall) return;

    const pollCallStatus = async () => {
      try {
        if (document.hidden) return;
        const currentCallId = activeCall.id;
        if (dismissedCallIdsRef.current.has(currentCallId)) {
          setActiveCall(null);
          return;
        }

        const { data, error } = await oracleDB
          .from('calls')
          .select('*')
          .eq('id', currentCallId)
          .single();

        if (!error && data) {
          if (data.status === 'rejected' || data.status === 'ended' || data.status === 'missed') {
            markCallDismissed(data.id);
            setGroupCallStatuses((prev) => ({ ...prev, [data.id]: data.status }));
            setActiveCall(null);
          } else if (data.status !== activeCallRef.current?.status) {
            // Never revert an already accepted call back to ringing due to replication lag
            if (activeCallRef.current?.status === 'accepted' && data.status === 'ringing') {
              return;
            }
            setGroupCallStatuses((prev) => ({ ...prev, [data.id]: data.status }));
            setActiveCall(data);
          }
        }
      } catch (err) {
        console.error('Error polling call status:', err);
      }
    };

    const interval = setInterval(pollCallStatus, 2000);
    return () => clearInterval(interval);
  }, [currentUser, activeCall?.id]);

  // Broadcast Helper
  const sendBroadcastEvent = useCallback((event: string, payload: any) => {
    if (chatUpdatesChannelRef.current) {
      chatUpdatesChannelRef.current.send({
        type: 'broadcast',
        event,
        payload,
      });
    }
  }, []);


  // M-06: scheduled messages are created on the SERVER and delivered by the
  // server scheduler worker (atomic claims + idempotent message ids). The
  // client only keeps its display cache fresh; due messages arrive like any
  // other message through SSE / edge / polling — no more per-tab double
  // sends and no more lost schedules on browser crashes.
  useEffect(() => {
    if (!currentUser) return;
    void refreshScheduledMessages();
    const interval = setInterval(() => {
      void refreshScheduledMessages();
    }, 60_000);
    const onOnline = () => {
      void refreshScheduledMessages();
    };
    window.addEventListener('online', onOnline);
    return () => {
      clearInterval(interval);
      window.removeEventListener('online', onOnline);
    };
  }, [currentUser?.id]);

  // Handle Call End or Dismissal cleanly
  const handleCallEndOrClose = (statusMessage?: string, callStatus: Call['status'] = 'ended') => {
    const currentCallId = activeCallRef.current?.id;
    if (currentCallId) {
      markCallDismissed(currentCallId);
      const terminalStatus = callStatus === 'rejected' || callStatus === 'missed' ? callStatus : 'ended';
      void sendCallHangup(currentCallId, terminalStatus, undefined, oracleDB.getSSEClientId()).catch(() => showToast('Call ended locally; signaling synchronization pending'));
      // Clean up from calls table
      void oracleDB.from('calls').update({ status: callStatus }).eq('id', currentCallId).then(result => { if (result.error) showToast('Call ended locally; server synchronization pending'); });

      setGroupCallStatuses((prev) => ({ ...prev, [currentCallId]: callStatus }));

      // Update messagesList so any _vyper_call_ message is updated
      setMessagesList((prev) =>
        prev.map((m) => {
          if (m.text && m.text.startsWith('_vyper_call_::')) {
            try {
              const meta = JSON.parse(m.text.substring('_vyper_call_::'.length));
              if (meta.callId === currentCallId) {
                meta.status = callStatus;
                const newText = `_vyper_call_::${JSON.stringify(meta)}`;
                // Persist updated call status into message record in Oracle DB
                oracleDB.from('messages').update({ text: newText }).eq('id', m.id).then(() => {});
                sendBroadcastEvent('edit_message', { messageId: m.id, text: newText });
                return { ...m, text: newText };
              }
            } catch {}
          }
          return m;
        })
      );

      // Update callHistory
      setCallHistory((prev) =>
        prev.map((c) => (c.id === currentCallId ? { ...c, status: callStatus, updated_at: new Date().toISOString() } : c))
      );

      // Broadcast status update
      sendBroadcastEvent('call_status_update', {
        callId: currentCallId,
        status: callStatus,
      });

      // Update database asynchronously
      (async () => {
        try {
          await oracleDB.from('calls').update({ status: callStatus, updated_at: new Date().toISOString() }).eq('id', currentCallId);
        } catch {}
      })();
    }

    setActiveCall(null);
    if (statusMessage) {
      showToast(statusMessage);
    }
  };

  // Do not open a simulated call before the server has durably accepted it.
  const handleInitiateCall = async (targetOrType: string, maybeType?: 'voice' | 'video') => {
    if (!currentUser || !sessionVerified || isOffline) { showToast('Reconnect and verify your session before calling'); return; }
    if (activeCallRef.current || isInitiatingCallRef.current) return;
    const type = maybeType || (targetOrType === 'video' ? 'video' : 'voice');
    let receiver = maybeType ? targetOrType : selectedPeerProfile?.id || selectedChatId?.split(':').find(p => p !== 'dm' && p !== currentUser.id);
    if (!receiver && selectedChatId === 'general') {
      const operator = allProfiles.find((profile) => profile.id !== currentUser.id && isUserOnline(profile));
      if (operator) {
        receiver = operator.id;
        setSelectedPeerProfile(operator);
        const ids = [currentUser.id, operator.id].sort();
        setSelectedChatId(`dm:${ids[0]}:${ids[1]}`);
      }
    }
    if (!receiver || receiver === 'general' || selectedChatId?.startsWith('group:') || receiver.startsWith('group:')) {
      showToast('Group calling is not available yet. Start a direct call instead.'); return;
    }
    isInitiatingCallRef.current = true;
    try {
      const { data, error } = await oracleDB.from('calls').insert({ id: `call_${crypto.randomUUID()}`, receiver_id: receiver, type });
      if (error || !data?.id) throw error || new Error('Call could not be persisted');
      setActiveCall(data); setCallHistory(prev => [data, ...prev.filter(c => c.id !== data.id)]);
    } catch (error) { showToast(error instanceof Error ? error.message : 'Could not place call'); }
    finally { isInitiatingCallRef.current = false; }
  };
  const handleJoinGroupCall = (_callId: string, _type: 'voice' | 'video', _callerId: string) => {
    showToast('Group calling is disabled until participant authorization and signaling are supported');
  };

  // Toggle Message Reaction
  const handleToggleReaction = (messageId: string, emoji: string) => {
    if (!currentUser) return;
    setReactions((prev) => {
      const msgReactions = { ...(prev[messageId] || {}) } as Record<string, string[]>;

      let existingEmoji: string | null = null;
      for (const [key, users] of Object.entries(msgReactions)) {
        if (users.includes(currentUser.id)) {
          existingEmoji = key;
          break;
        }
      }

      const updatedMsgReactions = { ...msgReactions };

      if (existingEmoji === emoji) {
        const users = [...(updatedMsgReactions[emoji] || [])];
        const idx = users.indexOf(currentUser.id);
        if (idx >= 0) {
          users.splice(idx, 1);
        }
        if (users.length === 0) {
          delete updatedMsgReactions[emoji];
        } else {
          updatedMsgReactions[emoji] = users;
        }
      } else {
        if (existingEmoji) {
          const users = [...(updatedMsgReactions[existingEmoji] || [])];
          const idx = users.indexOf(currentUser.id);
          if (idx >= 0) {
            users.splice(idx, 1);
          }
          if (users.length === 0) {
            delete updatedMsgReactions[existingEmoji];
          } else {
            updatedMsgReactions[existingEmoji] = users;
          }
        }

        const users = [...(updatedMsgReactions[emoji] || [])];
        if (!users.includes(currentUser.id)) {
          users.push(currentUser.id);
        }
        updatedMsgReactions[emoji] = users;
      }

      const updatedAll = { ...prev, [messageId]: updatedMsgReactions };

      // Broadcast reaction update in real time
      sendBroadcastEvent('reaction', {
        messageId,
        userId: currentUser.id,
        emoji,
      });

      return updatedAll;
    });
  };

  // Toggle Message Pinning status
  const handleTogglePin = (chatId: string, messageId: string) => {
    setPinnedState((prev) => {
      const pins = [...(prev[chatId] || [])];
      const idx = pins.indexOf(messageId);
      if (idx >= 0) {
        pins.splice(idx, 1);
      } else {
        pins.push(messageId);
      }
      const updated = { ...prev, [chatId]: pins };
      try {
        localStorage.setItem('vypervic_pinned_messages_v3', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save pinned messages to localStorage:', e);
      }
      // Broadcast this change to all active peers
      sendBroadcastEvent('pin_change', { chatId, pinnedMessageIds: pins });
      return updated;
    });
  };

  // Periodically prune stale typing indicator states (older than 4 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      let changed = false;
      setTypingState((prev) => {
        const next = { ...prev };
        Object.entries(next).forEach(([chatId, users]) => {
          const typedUsers = users as Record<string, { username: string; timestamp: number }>;
          const nextUsers = { ...typedUsers };
          let chatChanged = false;
          Object.entries(nextUsers).forEach(([userId, info]) => {
            const typedInfo = info as { username: string; timestamp: number };
            if (now - typedInfo.timestamp > 4000) {
              delete nextUsers[userId];
              chatChanged = true;
              changed = true;
            }
          });
          if (chatChanged) {
            next[chatId] = nextUsers;
          }
        });
        return changed ? next : prev;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleOutgoingMessage = useCallback((msg: Message) => {
    setMessagesList((prev) => addOrUpdateMessage(prev, msg));
  }, []);

  const handleFullscreenProfileSendMessage = useCallback((msg: Message) => {
    setMessagesList((prev) => addOrUpdateMessage(prev, msg));
    sendBroadcastEvent('message', msg);
  }, [sendBroadcastEvent]);

  // Send read receipt when selecting a chat room or receiving a new message while inside it
  useEffect(() => {
    if (!currentUser || !selectedChatId || messagesList.length === 0) return;

    // Clear unread system/push notifications for this chat room (Requirement 3)
    setNotifications((prev) => prev.filter((n) => n.chatId !== selectedChatId));

    // Find the last message in this room
    const chatMsgs = messagesList.filter((m) => m.chat_id === selectedChatId);
    if (chatMsgs.length === 0) return;

    const lastMsg = chatMsgs[chatMsgs.length - 1];

    // Mark it locally as read in our separate state
    setMyReadReceipts((prev) => ({
      ...prev,
      [selectedChatId]: {
        lastReadMessageId: lastMsg.id,
        timestamp: new Date().toISOString(),
      },
    }));

    // Find the last message in this room sent by other users
    const lastPeerMsg = [...chatMsgs].reverse().find((m) => m.sender_id !== currentUser.id);
    if (!lastPeerMsg) return;

    // Broadcast the read receipt to others in real-time if enabled or in group
    if (readReceiptsEnabled || selectedChatId.startsWith('group:') || selectedChatId === 'general') {
      sendBroadcastEvent('read_receipt', {
        chatId: selectedChatId,
        readerId: currentUser.id,
        lastReadMessageId: lastPeerMsg.id,
        timestamp: new Date().toISOString(),
      });
    }
  }, [selectedChatId, messagesList.length, currentUser, readReceiptsEnabled]);

  if (showSplash) {
    return <Splash onComplete={() => setShowSplash(false)} />;
  }

  const generalProfile: Profile = {
    id: 'general',
    email: 'general@vypervic.net',
    username: 'general',
    display_name: 'VyperVic General',
    is_online: true,
    avatar_url: null,
    about: 'VyperVic general broadcast calling room',
    last_seen: new Date().toISOString(),
    created_at: new Date().toISOString(),
  };

  // Find calling partner profile details with resilient fallback
  const getCallPartnerProfile = () => {
    if (!activeCall) return undefined;
    const partnerId = activeCall.receiver_id === 'general'
      ? (activeCall.caller_id === currentUser?.id ? 'general' : activeCall.caller_id)
      : (activeCall.caller_id === currentUser?.id ? activeCall.receiver_id : activeCall.caller_id);

    if (partnerId === 'general') return generalProfile;

    const found = allProfiles.find((p) => p.id === partnerId);
    if (found) return found;

    // Direct fallback mapping to prevent UI blocking during sync lag
    return {
      id: partnerId,
      username: 'operator_peer',
      display_name: 'Operator Peer',
      email: '',
      is_online: true,
      last_seen: new Date().toISOString(),
      created_at: new Date().toISOString(),
      about: 'Securing satellite link...',
      avatar_url: null,
    } as Profile;
  };

  const activeCallPartnerProfile = getCallPartnerProfile();

  const getUnreadCount = (chatId: string) => {
    if (selectedChatId === chatId && activeScreen === 'chat') return 0;

    const chatMsgs = messagesList.filter((m) => m.chat_id === chatId && m.sender_id !== currentUser?.id);
    if (chatMsgs.length === 0) return 0;

    const receipt = myReadReceipts[chatId];
    const receiptTime = receipt ? new Date(receipt.timestamp).getTime() : 0;
    return chatMsgs.filter((m) => {
      const msgTime = new Date(m.created_at).getTime();
      if (receipt) {
        return msgTime > receiptTime && m.id !== receipt.lastReadMessageId;
      } else {
        return msgTime > sessionStartRef.current;
      }
    }).length;
  };

  return (
    <div className="w-full h-full min-h-[100dvh] h-[100dvh] max-h-[100dvh] flex items-center justify-center bg-[#05070a] overflow-hidden overflow-x-hidden relative">
      <div className="phone relative w-full max-w-lg md:max-w-xl h-full h-[100dvh] max-h-[100dvh] bg-[#080b10] sm:border-x sm:border-[#1e2634] shadow-2xl overflow-hidden flex flex-col mx-auto">
      {/* Accessible Liquid Glass Heads-Up Notification Banner */}
      {headsUpNotification && (
        <div
          role="region"
          aria-label="New message notification"
          aria-live="polite"
          className="absolute top-3 left-1/2 -translate-x-1/2 z-[1000] flex flex-col items-center pointer-events-auto w-[calc(100%-24px)] max-w-[400px]"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key="heads-up-notification-banner"
              initial={{ y: -20, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -20, opacity: 0, scale: 0.95 }}
              transition={{ type: 'spring', damping: 24, stiffness: 320 }}
              className="glass-surface border border-white/25 text-white shadow-[0_16px_48px_rgba(0,0,0,0.65)] overflow-hidden p-3.5 flex flex-col gap-2.5 rounded-2xl w-full"
            >
              <div className="flex items-start justify-between gap-3">
                <button
                  type="button"
                  className="flex items-center gap-3 flex-1 text-left cursor-pointer min-w-0 bg-transparent border-none p-0"
                  onClick={() => selectChatFromNotification(headsUpNotification.chatId)}
                  aria-label={`Open conversation with ${headsUpNotification.senderName}`}
                >
                  {/* Sender Avatar / Icon */}
                  <div className="relative shrink-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#20e3a2] to-[#7c5cff] flex items-center justify-center text-white text-xs font-black shadow-md">
                      {headsUpNotification.senderName.substring(0, 1).toUpperCase()}
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-black flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-[#20e3a2] animate-ping" />
                    </div>
                  </div>

                  {/* Notification Content */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-display font-extrabold text-[13px] text-white truncate max-w-[160px]">
                        {headsUpNotification.senderName}
                      </span>
                      <span className="text-[9px] font-bold text-[#20e3a2] bg-[#20e3a2]/15 px-2 py-0.5 rounded-full uppercase shrink-0">
                        now
                      </span>
                    </div>
                    <p className="text-[12px] text-white/75 truncate mt-0.5 font-medium leading-snug">
                      {headsUpNotification.body}
                    </p>
                  </div>
                </button>

                {/* Controls */}
                <div className="flex items-center gap-1.5 shrink-0 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setShowHeadsUpReply(!showHeadsUpReply)}
                    className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-[#20e3a2] transition-colors cursor-pointer"
                    aria-label="Quick reply to message"
                    title="Quick Reply"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setHeadsUpNotification(null)}
                    className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors cursor-pointer"
                    aria-label="Dismiss notification"
                    title="Dismiss"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Quick Reply Form */}
              {showHeadsUpReply && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!headsUpReplyText.trim()) return;
                    handleReplyFromNotification(headsUpNotification.id, headsUpReplyText);
                  }}
                  className="flex items-center gap-2 bg-black/40 border border-white/15 rounded-xl px-3 py-1.5 animate-fade-in mt-0.5"
                >
                  <input
                    type="text"
                    placeholder="Type a quick reply..."
                    aria-label="Quick reply text"
                    value={headsUpReplyText}
                    onChange={(e) => setHeadsUpReplyText(e.target.value)}
                    className="flex-1 bg-transparent border-none outline-none text-[12px] text-white placeholder-white/40 py-1 font-medium"
                    autoFocus
                  />
                  <button
                    type="submit"
                    aria-label="Send quick reply"
                    className="p-1.5 rounded-lg bg-[#20e3a2] text-black font-bold cursor-pointer hover:bg-[#20e3a2]/90 shadow-sm"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* Sleek Smartphone Status Bar space */}
      <div
        className="absolute top-0 left-0 right-0 h-8 bg-transparent flex items-center justify-center pointer-events-none z-50"
      >
      </div>

      {/* Slide-down Notification Center Drawer */}
      <AnimatePresence>
        {showNotificationCenter && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Notification Center"
            initial={{ y: '-100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '-100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 180 }}
            className="absolute inset-0 bg-[#030509]/90 backdrop-blur-2xl z-[550] flex flex-col"
          >
            <div className="pt-12 px-5 pb-4 flex items-center justify-between border-b border-[#212a38] bg-[#0c1017]/95 sticky top-0">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-display font-black text-[15px] text-white tracking-wide">NOTIFICATION CENTER</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-[#20e3a2] animate-pulse" />
                </div>
                <p className="text-[10px] text-[#5a6478] font-medium mt-0.5">
                  Keep track of direct messages, system alerts, and mentions.
                </p>
              </div>
              <div className="flex items-center gap-2">
                {getUnifiedFeed().some((n) => !n.isRead) && (
                  <button
                    type="button"
                    onClick={() => {
                      const allIds = getUnifiedFeed().map((n) => n.id);
                      setReadNotifIds((prev) => Array.from(new Set([...prev, ...allIds])));
                      showToast('Marked all read');
                    }}
                    aria-label="Mark all notifications as read"
                    className="text-[11px] font-extrabold text-[#20e3a2] bg-[#20e3a2]/10 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-[#20e3a2]/20 transition-colors"
                  >
                    Mark Read
                  </button>
                )}
                {getUnifiedFeed().length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const ids = getUnifiedFeed().map((item) => item.id);
                      setDismissedFeedItemIds((prev) => [...prev, ...ids]);
                      setNotifications([]);
                      showToast('Cleared All');
                    }}
                    aria-label="Clear all notifications"
                    className="text-[11px] font-extrabold text-[#ff5470] bg-[#ff5470]/10 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-[#ff5470]/20"
                  >
                    Clear All
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowNotificationCenter(false)}
                  aria-label="Close notification center"
                  className="w-8 h-8 rounded-full bg-[#161d28] border border-[#212a38] flex items-center justify-center text-white cursor-pointer active:bg-[#1d2531]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
              {/* System Push Delivery Card */}
              <div className="bg-[#161d28]/90 border border-[#212a38] rounded-2xl p-4 flex flex-col gap-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-[#7c5cff]/10 flex items-center justify-center text-[#7c5cff]">
                      <Sparkles className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <h4 className="text-[13px] font-bold text-white leading-tight">System Push Delivery</h4>
                      <p className="text-[11px] text-[#8d97ab] mt-0.5">
                        {notifPermission === 'granted' ? 'Active & Reliable' : 'Requires browser permissions'}
                      </p>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    notifPermission === 'granted' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                  }`}>
                    {notifPermission === 'granted' ? 'ACTIVE' : 'OFF'}
                  </span>
                </div>
                {notifPermission !== 'granted' && (
                  <button
                    onClick={handleRequestPermission}
                    className="w-full bg-gradient-to-r from-[#20e3a2] to-[#7c5cff] py-2.5 rounded-xl text-xs font-bold text-black cursor-pointer shadow-md hover:opacity-90"
                  >
                    Enable Background Alerts
                  </button>
                )}
              </div>

              {/* Dynamic Notifications Map */}
              {getUnifiedFeed().length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="w-12 h-12 rounded-full bg-[#161d28] flex items-center justify-center text-[#5a6478] mb-3">
                    <Bell className="w-5 h-5 text-[#20e3a2]" />
                  </div>
                  <span className="text-[13px] font-bold text-[#8d97ab]">Inbox is pristine</span>
                  <p className="text-[11px] text-[#5a6478] max-w-[200px] mt-1 leading-normal">
                    New alerts, mentions, and private messages will be captured here in real-time.
                  </p>
                </div>
              ) : (
                getUnifiedFeed().map((notif) => (
                  <NotificationCard
                    key={notif.id}
                    notification={notif}
                    allProfiles={allProfiles}
                    onSelect={selectChatFromNotification}
                    onReply={handleReplyFromNotification}
                    onDismiss={(id) => {
                      setDismissedFeedItemIds((prev) => [...prev, id]);
                      setNotifications((prev) => prev.filter((n) => n.id !== id));
                    }}
                  />
                ))
              )}
            </div>

            <div
              onClick={() => setShowNotificationCenter(false)}
              className="bg-[#0c1017] py-3.5 flex flex-col items-center justify-center border-t border-[#212a38] cursor-pointer hover:bg-white/5"
            >
              <div className="w-12 h-1.5 bg-[#212a38] rounded-full" />
              <span className="text-[9px] font-bold tracking-widest text-[#5a6478] uppercase mt-1.5">Close Drawer</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Primary Screen Container */}
      <div className="screen-stack w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
        {!currentUser ? (
          <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
            <AuthScreen onAuthComplete={(profile) => setCurrentUser(profile)} />
          </div>
        ) : (
          <>
            {/* Global Persistent Audio Player Banner across screens */}
            <LazyBoundary>
            <GlobalAudioBanner
              currentActiveScreen={activeScreen}
              currentChatId={selectedChatId}
              onNavigateToChat={(targetChatId) => {
                const targetPeer = allProfiles.find((p) => {
                  const sortedIds = [currentUser.id, p.id].sort();
                  return `dm:${sortedIds[0]}:${sortedIds[1]}` === targetChatId;
                });
                setSelectedChatId(targetChatId);
                if (targetPeer) {
                  setSelectedPeerProfile(targetPeer);
                }
                setActiveScreen('chat');
              }}
            />
            </LazyBoundary>

            {/* Navigational Screens with GPU Acceleration */}
            {activeScreen === 'chatList' && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <ChatListScreen
                  currentUser={currentUser}
                  isOffline={isOffline || !sessionVerified}
                  onSelectChat={(chatId, peer, targetMessageId) => {
                    setSelectedChatId(chatId);
                    setSelectedPeerProfile(peer);
                    setSelectedTargetMsgId(targetMessageId || null);
                    setActiveScreen('chat');
                  }}
                  onOpenSettings={() => setActiveScreen('settings')}
                  onOpenSearch={() => setActiveScreen('search')}
                  onOpenNotifications={() => setShowNotificationCenter(true)}
                  allProfiles={allProfiles}
                  messagesList={messagesList}
                  readReceipts={readReceipts}
                  getUnreadCount={getUnreadCount}
                  unreadNotificationsCount={getUnifiedFeed().filter((n) => !n.isRead).length}
                  groups={groups}
                  groupCallStatuses={groupCallStatuses}
                  onViewProfileDetail={(type, data) => setActiveProfileView({ type, data })}
                />
              </div>
            )}

            {activeScreen === 'chat' && selectedChatId && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <ChatScreen
                  chatId={selectedChatId}
                  peerProfile={selectedPeerProfile ? (allProfiles.find((p) => p.id === selectedPeerProfile.id) || selectedPeerProfile) : undefined}
                  currentUser={currentUser}
                  targetMessageId={selectedTargetMsgId}
                  onBack={() => {
                    setSelectedChatId(null);
                    setSelectedPeerProfile(undefined);
                    setSelectedTargetMsgId(null);
                    setActiveScreen('chatList');
                  }}
                  onCall={handleInitiateCall}
                  onJoinGroupCall={handleJoinGroupCall}
                  groupCallStatuses={groupCallStatuses}
                  messagesList={messagesList}
                  allProfiles={allProfiles}
                  callHistory={callHistory}
                  typingUsers={typingState[selectedChatId] || {}}
                  readReceipts={readReceipts}
                  reactions={reactions}
                  onToggleReaction={handleToggleReaction}
                  sendBroadcastEvent={sendBroadcastEvent}
                  pinnedMessageIds={pinnedState[selectedChatId] || []}
                  onTogglePin={(msgId) => handleTogglePin(selectedChatId, msgId)}
                  onSelectChat={(chatId, peer, targetMessageId) => {
                    setSelectedChatId(chatId);
                    setSelectedPeerProfile(peer);
                    setSelectedTargetMsgId(targetMessageId || null);
                    setActiveScreen('chat');
                  }}
                  onSendMessage={handleOutgoingMessage}
                  groups={groups}
                  chatTheme={chatThemes[selectedChatId]}
                  onUpdateChatTheme={(cid, theme) => {
                    setChatThemes((prev) => ({ ...prev, [cid]: theme }));
                  }}
                  onUpdateGroup={async (updatedGrp) => {
                    const { data, error } = await oracleDB.from('groups').update({ name: updatedGrp.name, members: updatedGrp.members, admins: updatedGrp.admins || [],
                      icon: updatedGrp.icon || null, description: updatedGrp.description || null, cover_url: updatedGrp.cover_url || null }).eq('id', updatedGrp.id);
                    if (error) { showToast(error.message); return false; }
                    setGroups(prev => prev.map(g => g.id === data.id ? data : g)); return true;
                  }}
                  onDisbandGroup={async (groupId) => {
                    const { error } = await oracleDB.from('groups').delete().eq('id', groupId);
                    if (error) { showToast(error.message); return; }
                    setGroups((prev) => prev.filter((g) => g.id !== groupId));
                    setSelectedChatId(null);
                    setSelectedPeerProfile(undefined);
                    setActiveScreen('chatList');
                  }}
                  onViewProfileDetail={(type, data) => setActiveProfileView({ type, data })}
                  readReceiptsEnabled={readReceiptsEnabled}
                />
              </div>
            )}

            {activeScreen === 'search' && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <LazyBoundary>
                <SearchScreen
                  currentUser={currentUser}
                  onCancel={() => setActiveScreen('chatList')}
                  allProfiles={allProfiles}
                  existingContactIds={existingContactIds}
                  onSelectUser={(peer) => {
                    setActiveProfileView({ type: 'user', data: peer });
                  }}
                  onCreateGroup={async (name, icon, memberIds) => {
                    const result = await oracleDB.from('groups').insert({ id: `group:${crypto.randomUUID()}`, name, icon: icon || '👥',
                      members: [...new Set([currentUser.id, ...memberIds])] });
                    if (result.error || !result.data?.id) { showToast(result.error?.message || 'Group could not be persisted'); return; }
                    const group = result.data;
                    setGroups(prev => [...prev.filter(g => g.id !== group.id), group]);
                    setSelectedChatId(group.id); setSelectedPeerProfile(undefined); setActiveScreen('chat');
                    // Creation and welcome messages are never fabricated from a local-only group cache.
                  }}
                />
              </LazyBoundary>
              </div>
            )}

            {activeScreen === 'calls' && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <LazyBoundary>
                <CallsScreen
                  currentUser={currentUser}
                  allProfiles={allProfiles}
                  callHistory={callHistory}
                  onInitiateCall={handleInitiateCall}
                  onViewProfileDetail={(type, data) => setActiveProfileView({ type, data })}
                />
                </LazyBoundary>
              </div>
            )}

            {activeScreen === 'settings' && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <LazyBoundary>
                <SettingsScreen
                  currentUser={currentUser}
                  allProfiles={allProfiles}
                  appTheme={appTheme}
                  onUpdateAppTheme={setAppTheme}
                  onBack={() => setActiveScreen('chatList')}
                  onLogout={async () => {
                    try {
                      await oracleDB
                        .from('profiles')
                        .update({ ...currentUser, is_online: false, last_seen: new Date().toISOString() })
                        .eq('id', currentUser.id);
                    } catch (e) {
                      console.warn('Failed to update online status on logout:', e);
                    }
                    try {
                      const result = await oracleDB.auth.signOut();
                      if (result.error) showToast('Signed out locally. Server revocation will retry when connected.');
                    } catch (e) {
                      console.warn('Failed to sign out of Oracle:', e);
                    }
                    // Reset states
                    setMessagesList([]);
                    setAllProfiles([]);
                    setActiveCall(null);
                    setGroupCallStatuses({});
                    setCallHistory([]);
                    setNotifications([]);
                    setSelectedChatId(null);
                    setSelectedPeerProfile(undefined);
                    setActiveScreen('chatList');

                    // Clear user session without deleting offline cached profiles
                    localStorage.removeItem('vypervic_session_user');
                    localStorage.removeItem('vypervic_current_user_cache');
                    localStorage.removeItem('vypervic_user_id');
                    localStorage.removeItem('vypervic_pending_profile');
                    if (currentUser?.id) {
                      localStorage.removeItem(`vyper_avatar_${currentUser.id}`);
                      localStorage.removeItem(`vyper_cover_${currentUser.id}`);
                    }
                    sessionStorage.clear();
                    setCurrentUser(null);
                  }}
                  onUpdateProfile={(updated) => setCurrentUser(updated)}
                  onToast={showToast}
                  onOpenAdminDashboard={() => setActiveScreen('admin')}
                  readReceiptsEnabled={readReceiptsEnabled}
                  onToggleReadReceipts={handleToggleReadReceipts}
                />
                </LazyBoundary>
              </div>
            )}

            {activeScreen === 'admin' && (
              <div className="w-full h-full transform-gpu [will-change:transform] [backface-visibility:hidden]" style={{ willChange: 'transform', backfaceVisibility: 'hidden' }}>
                <LazyBoundary>
                <AdminDashboard
                  currentUser={currentUser}
                  onBack={() => setActiveScreen('settings')}
                  onToast={showToast}
                />
                </LazyBoundary>
              </div>
            )}

            {/* Floating Pill Navigation Bar (Liquid Glass or Neumorphism based on theme) */}
            {(activeScreen === 'chatList' || activeScreen === 'calls' || activeScreen === 'search') && !activeProfileView && !showNotificationCenter && (
              <nav
                role="navigation"
                aria-label="Main navigation"
                className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-sm"
              >
                {(() => {
                  const isLiquidGlassTheme = appTheme === 'liquid-glass' || appTheme === 'light-liquid-glass';
                  const isLight = appTheme.startsWith('light');

                  const containerClass = isLiquidGlassTheme
                    ? isLight
                      ? 'bg-white/75 backdrop-blur-3xl border border-white/80 shadow-[0_16px_40px_rgba(0,0,0,0.12),inset_0_1.5px_2px_rgba(255,255,255,0.95)]'
                      : 'bg-slate-950/60 backdrop-blur-3xl border border-white/20 shadow-[0_16px_48px_rgba(0,0,0,0.6),inset_0_1.5px_2px_rgba(255,255,255,0.35)]'
                    : isLight
                      ? 'bg-[#e6ecf5] border border-white/80 shadow-[8px_8px_20px_rgba(163,177,198,0.7),-6px_-6px_16px_rgba(255,255,255,0.95)]'
                      : 'bg-[#121824] border border-white/10 shadow-[8px_8px_22px_rgba(0,0,0,0.75),-6px_-6px_16px_rgba(255,255,255,0.05)]';

                  const getButtonClass = (screen: 'chatList' | 'calls' | 'search' | 'settings') => {
                    const isActive = activeScreen === screen;
                    if (isLiquidGlassTheme) {
                      if (isActive) {
                        return isLight
                          ? 'bg-white/90 backdrop-blur-2xl border border-white/90 text-[#007aff] shadow-[inset_0_1px_1.5px_rgba(255,255,255,1),0_4px_16px_rgba(0,122,255,0.2)] scale-105'
                          : 'bg-gradient-to-r from-white/30 to-white/10 backdrop-blur-2xl border border-white/40 text-white shadow-[inset_0_1px_1.5px_rgba(255,255,255,0.6),0_4px_20px_rgba(255,255,255,0.2)] scale-105';
                      }
                      return isLight
                        ? 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
                        : 'text-white/60 hover:text-white hover:bg-white/5';
                    } else {
                      // Neumorphism style for all other themes
                      if (isActive) {
                        return isLight
                          ? 'bg-[#d8e0ed] border border-white/60 text-[#007aff] shadow-[inset_3px_3px_6px_rgba(163,177,198,0.8),inset_-3px_-3px_6px_rgba(255,255,255,0.95)] scale-105 font-black'
                          : 'bg-[#0c1018] border border-white/5 text-[#20e3a2] shadow-[inset_3px_3px_6px_rgba(0,0,0,0.85),inset_-2px_-2px_5px_rgba(255,255,255,0.08)] scale-105 font-black';
                      }
                      return isLight
                        ? 'text-slate-500 hover:text-slate-800 hover:bg-white/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-white/5';
                    }
                  };

                  return (
                    <div className={`flex items-center justify-around px-2 py-1.5 rounded-full ${containerClass}`}>
                      {/* Chats */}
                      <button
                        type="button"
                        onClick={() => setActiveScreen('chatList')}
                        aria-label="Chats"
                        aria-current={activeScreen === 'chatList' ? 'page' : undefined}
                        className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-full text-[11px] font-extrabold transition-all cursor-pointer select-none ${getButtonClass('chatList')}`}
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span className="text-[10px] mt-0.5">Chats</span>
                      </button>

                      {/* Calls */}
                      <button
                        type="button"
                        onClick={() => setActiveScreen('calls')}
                        aria-label="Calls"
                        aria-current={activeScreen === 'calls' ? 'page' : undefined}
                        className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-full text-[11px] font-extrabold transition-all cursor-pointer select-none ${getButtonClass('calls')}`}
                      >
                        <Phone className="w-4 h-4" />
                        <span className="text-[10px] mt-0.5">Calls</span>
                      </button>

                      {/* People */}
                      <button
                        type="button"
                        onClick={() => setActiveScreen('search')}
                        aria-label="People & Groups"
                        aria-current={activeScreen === 'search' ? 'page' : undefined}
                        className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-full text-[11px] font-extrabold transition-all cursor-pointer select-none ${getButtonClass('search')}`}
                      >
                        <Users className="w-4 h-4" />
                        <span className="text-[10px] mt-0.5">People</span>
                      </button>

                      {/* Settings */}
                      <button
                        type="button"
                        onClick={() => setActiveScreen('settings')}
                        aria-label="Settings"
                        aria-current={activeScreen === 'settings' ? 'page' : undefined}
                        className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-full text-[11px] font-extrabold transition-all cursor-pointer select-none ${getButtonClass('settings')}`}
                      >
                        <Settings className="w-4 h-4" />
                        <span className="text-[10px] mt-0.5">Settings</span>
                      </button>
                    </div>
                  );
                })()}
              </nav>
            )}

            {/* Full-Screen Profile details */}
            {activeProfileView && (
              <LazyBoundary>
              <FullscreenProfile
                type={activeProfileView.type}
                data={activeProfileView.data}
                onClose={() => setActiveProfileView(null)}
                currentUser={currentUser}
                allProfiles={allProfiles}
                messagesList={messagesList}
                groupsList={groups}
                onSendMessage={handleFullscreenProfileSendMessage}
                onSelectChat={(chatId, peer, targetMsgId) => {
                  setSelectedChatId(chatId);
                  if (peer) setSelectedPeerProfile(peer);
                  if (targetMsgId) setSelectedTargetMsgId(targetMsgId);
                  setActiveProfileView(null);
                  setActiveScreen('chat');
                }}
                onStartDM={(peer) => {
                  const sortedIds = [currentUser.id, peer.id].sort();
                  const dmId = `dm:${sortedIds[0]}:${sortedIds[1]}`;
                  setSelectedChatId(dmId);
                  setSelectedPeerProfile(peer);
                  setActiveProfileView(null);
                  setActiveScreen('chat');
                }}
                onCall={(type, peerId) => {
                  const peer = allProfiles.find((p) => p.id === peerId);
                  if (peer) {
                    setSelectedPeerProfile(peer);
                    const sortedIds = [currentUser.id, peer.id].sort();
                    const dmId = `dm:${sortedIds[0]}:${sortedIds[1]}`;
                    setSelectedChatId(dmId);
                    setActiveProfileView(null);
                    handleInitiateCall(type);
                  }
                }}
              />
              </LazyBoundary>
            )}

            {/* Real-Time Signaling Calling Interface Overlay */}
            {activeCall && activeCallPartnerProfile && (
              <LazyBoundary>
              <CallOverlay
                currentCall={activeCall}
                currentUser={currentUser}
                peerProfile={activeCallPartnerProfile}
                sendBroadcastEvent={sendBroadcastEvent}
                allProfiles={allProfiles}
                onUpdateCallStatus={(status) => {
                  setGroupCallStatuses((prev) => ({ ...prev, [activeCall.id]: status }));
                  if (status === 'rejected' || status === 'ended' || status === 'missed') {
                    handleCallEndOrClose(undefined, status);
                  } else {
                    setActiveCall((prev) => prev ? { ...prev, status } : null);
                  }
                }}
                onClose={(statusMessage, finalStatus) => {
                  handleCallEndOrClose(statusMessage, finalStatus || 'ended');
                }}
              />
              </LazyBoundary>
            )}
          </>
        )}
      </div>

      {/* Global Action Toasts */}
      {toastMessage && (
        <div className="toast show fixed bottom-5 left-1/2 -translate-x-1/2 bg-[#161d28]/95 border border-[#20e3a2]/40 text-[#eef1f6] px-3.5 py-1.5 rounded-full text-xs font-bold shadow-2xl backdrop-blur-md z-[9999] whitespace-nowrap animate-fade-in flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#20e3a2]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  </div>
);
}
