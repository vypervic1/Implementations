// Comprehensive and resilient offline-first storage engine (WhatsApp / Telegram architecture)
// Stores messages, profiles, and media blobs in IndexedDB with lightning-fast retrieval.

import { Message, Profile } from '../types';
import { compareMessagesChronologically } from './customNames';

const DB_NAME = 'VyperVicLocalStorageDB';
const DB_VERSION = 4; // Incremented to add outbox store
const STORE_FILES = 'saved_files';
const STORE_MESSAGES = 'cached_messages';
const STORE_PROFILES = 'cached_profiles';
const STORE_OUTBOX = 'offline_outbox';

export interface SavedFile {
  id: string; // message_id or random ID
  fileName: string;
  fileType: string;
  fileData: string; // Base64 data url
  savedAt: string;
  direction?: 'to' | 'from';
  targetName?: string;
}

let databasePromise: Promise<IDBDatabase> | null = null;
let currentDatabase: IDBDatabase | null = null;
function releaseDatabase(db: IDBDatabase) {
  if (currentDatabase === db) { databasePromise = null; currentDatabase = null; }
  db.close();
}
export function openDatabase(): Promise<IDBDatabase> {
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB is not supported in this environment'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_FILES)) {
        db.createObjectStore(STORE_FILES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
        const msgStore = db.createObjectStore(STORE_MESSAGES, { keyPath: 'id' });
        msgStore.createIndex('chat_id', 'chat_id', { unique: false });
        msgStore.createIndex('created_at', 'created_at', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_PROFILES)) {
        db.createObjectStore(STORE_PROFILES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_OUTBOX)) {
        db.createObjectStore(STORE_OUTBOX, { keyPath: 'id' });
      }
      // One-time scrubbing of legacy browser profile verifiers; these are never authentication.
      const cursor = request.transaction!.objectStore(STORE_PROFILES).openCursor();
      cursor.onsuccess = () => {
        const item = cursor.result; if (!item) return;
        const profile = item.value;
        for (const key of Object.keys(profile)) if (/password|credential/i.test(key)) delete profile[key];
        if (typeof profile.about === 'string') profile.about = profile.about.replace(/\[auth:[^\]]*\]/gi, '').trim();
        item.update(profile); item.continue();
      };

    };

    request.onsuccess = () => {
      currentDatabase = request.result;
      request.result.onversionchange = () => releaseDatabase(request.result);
      resolve(request.result);
    };

    request.onerror = (event) => {
      databasePromise = null; reject(request.error);
    };
  });
  return databasePromise;
}

// -------------------------------------------------------------
// 1. MEDIA & FILE CACHING (Base64 / Binary local storage)
// -------------------------------------------------------------

export async function saveFileToLocalStorage(
  fileName: string,
  fileType: string,
  fileData: string,
  id?: string,
  direction?: 'to' | 'from',
  targetName?: string
): Promise<void> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_FILES, 'readwrite');
    const store = transaction.objectStore(STORE_FILES);

    const fileId = id || `file_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const record: SavedFile = {
      id: fileId,
      fileName,
      fileType,
      fileData,
      savedAt: new Date().toISOString(),
      direction,
      targetName
    };

    const committed = transactionFinished(transaction);
    store.put(record); await committed;

  } catch (error) {
    throw error;
  }
}

export async function getSavedFile(id: string): Promise<SavedFile | null> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_FILES, 'readonly');
    const store = transaction.objectStore(STORE_FILES);

    return new Promise((resolve) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => resolve(null);
    });
  } catch (error) {
    return null;
  }
}

export async function getAllSavedFiles(): Promise<SavedFile[]> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_FILES, 'readonly');
    const store = transaction.objectStore(STORE_FILES);

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        resolve(request.result || []);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.warn('Failed to get saved files from IndexedDB:', error);
    return [];
  }
}

export async function deleteSavedFile(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_FILES, 'readwrite');
    const store = transaction.objectStore(STORE_FILES);

    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.warn('Failed to delete saved file from IndexedDB:', error);
  }
}

// -------------------------------------------------------------
// 2. OFFLINE MESSAGE CACHING (Instant load, unlimited persistence)
// -------------------------------------------------------------

export async function cacheMessagesLocally(messages: Message[]): Promise<void> {
  if (!messages?.length) return;
  const db = await openDatabase();
  const tx = db.transaction([STORE_MESSAGES, STORE_FILES], 'readwrite');
  const committed = transactionFinished(tx);
  const store = tx.objectStore(STORE_MESSAGES), files = tx.objectStore(STORE_FILES);
  for (const message of messages) {
    if (!message.id) continue;
    if (message.file_data) files.put({ id: `media_${message.id}`, fileName: message.file_name || 'media', fileType: message.file_type || 'application/octet-stream', fileData: message.file_data, savedAt: new Date().toISOString(), automatic: true });
    store.put({ ...message, file_data: null });
  }
  await committed;
}

export async function getCachedMessagesLocally(): Promise<Message[]> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction([STORE_MESSAGES, STORE_FILES], 'readonly');
    const msgStore = transaction.objectStore(STORE_MESSAGES);
    const filesStore = transaction.objectStore(STORE_FILES);

    return new Promise((resolve) => {
      const msgReq = msgStore.getAll();
      const filesReq = filesStore.getAll();

      let messages: Message[] | null = null;
      let filesLoaded = false;
      const filesMap = new Map<string, string>();

      const checkFinish = () => {
        if (messages !== null && filesLoaded) {
          // Rehydrate file_data from local files store if missing from message payload
          for (const msg of messages) {
            if (!msg.file_data && msg.id) {
              const fileKey = `media_${msg.id}`;
              if (filesMap.has(fileKey)) {
                msg.file_data = filesMap.get(fileKey)!;
              }
            }
          }
          // Sort chronologically ascending with monotonic tie breaking
          messages.sort(compareMessagesChronologically);
          resolve(messages);
        }
      };

      msgReq.onsuccess = () => {
        messages = (msgReq.result || []) as Message[];
        checkFinish();
      };
      msgReq.onerror = () => {
        messages = [];
        checkFinish();
      };

      filesReq.onsuccess = () => {
        filesLoaded = true;
        const fileList = (filesReq.result || []) as SavedFile[];
        for (const f of fileList) {
          if (f.id && f.fileData) {
            filesMap.set(f.id, f.fileData);
          }
        }
        checkFinish();
      };
      filesReq.onerror = () => {
        filesLoaded = true;
        checkFinish();
      };
    });
  } catch (err) {
    console.warn('Failed to read messages from IndexedDB:', err);
    return [];
  }
}

export async function deleteCachedMessageLocally(messageId: string): Promise<void> {
  if (!messageId) return;
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_MESSAGES, 'readwrite');
    const store = transaction.objectStore(STORE_MESSAGES);
    store.delete(messageId);
  } catch (err) {
    console.warn('Failed to delete cached message from IndexedDB:', err);
  }
}

// -------------------------------------------------------------
// 3. OFFLINE PROFILES CACHING
// -------------------------------------------------------------

export async function cacheProfilesLocally(profiles: Profile[], replace = false): Promise<void> {
  if (!profiles || profiles.length === 0 && !replace) return;
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_PROFILES, 'readwrite');
    const store = transaction.objectStore(STORE_PROFILES);
    const committed = transactionFinished(transaction);
    if (replace) store.clear();
    for (const prof of profiles) {
      if (!prof.id) continue;
      store.put(prof);
    }
    await committed;
  } catch (err) {
    console.warn('Failed to cache profiles to IndexedDB:', err);
  }
}

export async function getCachedProfilesLocally(): Promise<Profile[]> {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_PROFILES, 'readonly');
    const store = transaction.objectStore(STORE_PROFILES);

    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => resolve((request.result || []) as Profile[]);
      request.onerror = () => resolve([]);
    });
  } catch (err) {
    console.warn('Failed to read profiles from IndexedDB:', err);
    return [];
  }
}

export async function deleteCachedProfileLocally(profileId: string): Promise<void> {
  if (!profileId) return;
  try {
    const db = await openDatabase();
    const transaction = db.transaction(STORE_PROFILES, 'readwrite');
    const store = transaction.objectStore(STORE_PROFILES);
    store.delete(profileId);
  } catch (err) {
    console.warn('Failed to delete cached profile from IndexedDB:', err);
  }
}

// -------------------------------------------------------------
// 4. STORAGE PURGE & WIPE HELPERS (For full fresh start)
// -------------------------------------------------------------

export async function clearAllCachedDataLocally(): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction([STORE_FILES, STORE_MESSAGES, STORE_PROFILES, STORE_OUTBOX], 'readwrite');
    const committed = transactionFinished(tx);
    for (const store of [STORE_FILES, STORE_MESSAGES, STORE_PROFILES, STORE_OUTBOX]) tx.objectStore(store).clear();
    await committed;
  } finally { releaseDatabase(db); }
}

export async function clearCachedMessagesStore(): Promise<void> {
  try {
    const db = await openDatabase();
    if (db.objectStoreNames.contains(STORE_MESSAGES)) {
      const tx = db.transaction(STORE_MESSAGES, 'readwrite');
      tx.objectStore(STORE_MESSAGES).clear();
    }
  } catch (e) {}
}

export async function clearCachedProfilesStore(): Promise<void> {
  try {
    const db = await openDatabase();
    if (db.objectStoreNames.contains(STORE_PROFILES)) {
      const tx = db.transaction(STORE_PROFILES, 'readwrite');
      tx.objectStore(STORE_PROFILES).clear();
    }
  } catch (e) {}
}

// -------------------------------------------------------------
// 5. OFFLINE OUTBOX QUEUE (No localStorage quota limits)
// -------------------------------------------------------------

function transactionFinished(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error('IndexedDB write failed'));
    transaction.onabort = () => reject(transaction.error || new Error('IndexedDB transaction aborted'));
  });
}
export async function saveOfflineQueueMessageLocally(msg: Message, stillCurrent: () => boolean = () => true): Promise<void> {
  if (!msg?.id) throw new Error('Outbox message requires a stable ID');
  const db = await openDatabase();
  try {
    if (!stillCurrent()) throw new Error('Account changed during outbox write');
    const tx = db.transaction(STORE_OUTBOX, 'readwrite');
    const committed = transactionFinished(tx);
    tx.objectStore(STORE_OUTBOX).put(msg);
    await committed;
  } finally { releaseDatabase(db); }
}
export async function getOfflineQueueMessagesLocally(): Promise<Message[]> {
  const db = await openDatabase();
  try {
    return await new Promise<Message[]>((resolve, reject) => {
      const req = db.transaction(STORE_OUTBOX, 'readonly').objectStore(STORE_OUTBOX).getAll();
      req.onsuccess = () => resolve((req.result as Message[]).sort(compareMessagesChronologically));
      req.onerror = () => reject(req.error);
    });
  } finally { releaseDatabase(db); }
}
export async function removeOfflineQueueMessageLocally(id: string): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_OUTBOX, 'readwrite'); const committed = transactionFinished(tx);
    tx.objectStore(STORE_OUTBOX).delete(id); await committed;
  } finally { releaseDatabase(db); }
}
export async function clearOfflineQueueLocally(): Promise<void> {
  const db = await openDatabase();
  try {
    const tx = db.transaction(STORE_OUTBOX, 'readwrite'); const committed = transactionFinished(tx);
    tx.objectStore(STORE_OUTBOX).clear(); await committed;
  } finally { releaseDatabase(db); }
}

export async function pruneDisposableCache(maxMessages = 3000, maxMediaBytes = 50 * 1024 * 1024): Promise<void> {
  const db = await openDatabase();
  const read = <T>(store: string) => new Promise<T[]>((resolve, reject) => { const request = db.transaction(store).objectStore(store).getAll(); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  const [messages, files, pending] = await Promise.all([read<Message>(STORE_MESSAGES), read<SavedFile & { automatic?: boolean }>(STORE_FILES), read<Message>(STORE_OUTBOX)]);
  const protectedIds = new Set(pending.map(row => row.id));
  const tx = db.transaction([STORE_MESSAGES, STORE_FILES], 'readwrite'), committed = transactionFinished(tx);
  const oldest = messages.filter(row => !protectedIds.has(row.id)).sort(compareMessagesChronologically);
  for (const row of oldest.slice(0, Math.max(0, messages.length - maxMessages))) tx.objectStore(STORE_MESSAGES).delete(row.id);
  const disposable = files.filter(file => file.automatic && !protectedIds.has(file.id.replace(/^media_/, ''))).sort((a,b) => a.savedAt.localeCompare(b.savedAt));
  let bytes = disposable.reduce((sum,file) => sum + file.fileData.length * 2, 0);
  for (const file of disposable) { if (bytes <= maxMediaBytes) break; tx.objectStore(STORE_FILES).delete(file.id); bytes -= file.fileData.length * 2; }
  await committed;
}
