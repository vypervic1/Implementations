# Vyper / Arena ChatApp

React/TypeScript chat client, authenticated Node/Oracle API, Firebase signaling/FCM delivery, and a native Android WebView application loading the VPS HTTPS origin.

**Not production-ready.** A historical Firebase credential still requires provider revocation and repository-wide history cleanup. The Android project, deployed services and physical-device workflows have not been accepted. See [REMEDIATION.md](REMEDIATION.md) for exact evidence and remaining work.

## Local checks

```sh
npm ci
npm run lint
npm run typecheck
npm test
npm run build:ci && npm run check:bundle  # test-only, deliberately not deployable
```

For development, configure an ignored runtime environment file from `.env.example`, then `npm run dev`. Without real backend configuration, authentication/push/storage features report unavailable; there are no fake accounts or push registrations.

- [Android project/build guide](docs/ANDROID.md)
- [VPS deployment, migrations and recovery](deploy/README-AZURE.md)
- [Required staging/device acceptance](docs/STAGING-ACCEPTANCE.md)
- [Credential incident response](docs/SECURITY-INCIDENT.md)

Production uses an explicit canonical Firebase environment, authenticated ORDS, private Redis/TURN, real mail delivery and reviewed migrations/rules. Never put server credentials in browser/APK assets or use the deprecated destructive SQL for setup.
