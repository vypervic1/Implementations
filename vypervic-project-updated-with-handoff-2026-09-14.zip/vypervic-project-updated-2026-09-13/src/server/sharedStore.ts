import { createClient } from 'redis';
import { randomUUID, createHash } from 'node:crypto';
import { isProduction } from './config';

type Redis = ReturnType<typeof createClient>;
let client: Redis | undefined;
let connecting: Promise<Redis> | undefined;
export async function getRedis(): Promise<Redis | null> {
  if (!process.env.REDIS_URL) {
    if (isProduction()) throw new Error('Shared store is required');
    return null;
  }
  if (client?.isReady) return client;
  if (!connecting) {
    const next = createClient({ url: process.env.REDIS_URL, socket: { connectTimeout: 3000, reconnectStrategy: false }, disableOfflineQueue: true });
    next.on('error', () => console.error('[SharedStore] Redis unavailable'));
    connecting = next.connect().then(() => { client = next; return next; }).finally(() => { connecting = undefined; });
  }
  return connecting;
}
export async function closeSharedStore(): Promise<void> {
  if (client?.isOpen) await client.quit();
  client = undefined;
}
export const storeKey = (kind: string, id: string): string => `vyper:${kind}:${createHash('sha256').update(id).digest('hex')}`;
const memoryValues = new Map<string, { value: string; expires: number }>();
export async function sharedGet(key: string): Promise<string | null> {
  const redis = await getRedis();
  if (redis) { const value = await redis.get(key); return value === null ? null : String(value); }
  const entry = memoryValues.get(key);
  if (!entry || entry.expires <= Date.now()) { memoryValues.delete(key); return null; }
  return entry.value;
}
export async function sharedSet(key: string, value: string, ttlMs: number): Promise<void> {
  const redis = await getRedis();
  if (redis) { await redis.set(key, value, { PX: Math.max(1, ttlMs) }); return; }
  memoryValues.set(key, { value, expires: Date.now() + ttlMs });
}

const locks = new Set<string>();
/** Shared lease with owner-checked renewal/release; callers check ownership before each durable step.
 * Idempotent primary keys are still mandatory: leases cannot undo a committed upstream request. */
export async function withLease<T>(resource: string, fn: (assertHeld: () => void) => Promise<T>, ttlMs = 120_000): Promise<T> {
  const redis = await getRedis();
  const key = storeKey('lock', resource);
  const owner = randomUUID();
  if (redis ? !(await redis.set(key, owner, { NX: true, PX: ttlMs })) : locks.has(key)) throw new BusyError();
  if (!redis) locks.add(key);
  let held = true;
  const assertHeld = () => { if (!held) throw new Error('Operation lease lost; retry safely'); };
  const timer = redis ? setInterval(() => {
    void redis.eval("if redis.call('GET',KEYS[1]) == ARGV[1] then return redis.call('PEXPIRE',KEYS[1],ARGV[2]) else return 0 end", {
      keys: [key], arguments: [owner, String(ttlMs)],
    }).then(n => { if (Number(n) !== 1) held = false; }).catch(() => { held = false; });
  }, Math.floor(ttlMs / 3)) : null;
  timer?.unref();
  try { return await fn(assertHeld); }
  finally {
    if (timer) clearInterval(timer);
    if (redis) await redis.eval("if redis.call('GET',KEYS[1]) == ARGV[1] then return redis.call('DEL',KEYS[1]) else return 0 end", {
      keys: [key], arguments: [owner],
    }).catch(() => console.error('[SharedStore] Lease release failed; expiry will recover it'));
    else locks.delete(key);
  }
}
export class BusyError extends Error {
  status = 409;
  constructor() { super('Operation already in progress; retry later'); }
}

/** Serialize revocation behind an already-running mint; retry only lock acquisition, never a
 * callback that has started side effects. A bounded failure remains explicit/retryable. */
export async function withQueuedLease<T>(resource: string, action: (held: () => void) => Promise<T>, waitMs = 15000): Promise<T> {
  const deadline = Date.now() + waitMs;
  for (;;) {
    let entered = false;
    try { return await withLease(resource, held => { entered = true; return action(held); }); }
    catch (error) {
      if (entered || !(error instanceof BusyError) || Date.now() >= deadline) throw error;
      await new Promise(resolve => setTimeout(resolve, 25));
    }
  }
}
