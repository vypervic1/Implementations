import { useResources } from '../utils/resources';
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { oracleDB } from '../oracleDB';
import { Profile, Call } from '../types';
import {
  PhoneOff,
  Phone,
  Mic,
  MicOff,
  Video,
  VideoOff,
  ShieldAlert,
  Minimize2,
  Maximize2,
  RefreshCw,
  UserPlus,
  Smile,
  Circle,
  Square,
  Disc,
  Download,
  Zap,
  Activity,
  Check,
  X,
  Radio,
  Tv
} from 'lucide-react';
import { saveFileToLocalStorage } from '../utils/indexedDB';
import { getMiniRoastMessage } from '../utils/roasts';
import { isUserOnline } from '../utils/customNames';
import { sendCallSignal } from '../callSignalingService';

type QualityTier = { maxBitrate: number; scaleDown: number; label: 'high' | 'medium' | 'low' | 'minimal' };
const QUALITY_TIERS: QualityTier[] = [
  { maxBitrate: 1_200_000, scaleDown: 1, label: 'high' },
  { maxBitrate: 600_000, scaleDown: 1.5, label: 'medium' },
  { maxBitrate: 250_000, scaleDown: 2, label: 'low' },
  { maxBitrate: 100_000, scaleDown: 4, label: 'minimal' },
];
function pickQualityTier(availableOutgoing: number | null, rtt: number | null, fractionLost: number): QualityTier {
  if (fractionLost > 0.10 || (rtt !== null && rtt > 500)) return QUALITY_TIERS[3];
  if (fractionLost > 0.04 || (rtt !== null && rtt > 250)) return QUALITY_TIERS[2];
  if (availableOutgoing !== null) {
    if (availableOutgoing < 150_000) return QUALITY_TIERS[3];
    if (availableOutgoing < 400_000) return QUALITY_TIERS[2];
    if (availableOutgoing < 900_000) return QUALITY_TIERS[1];
    return QUALITY_TIERS[0];
  }
  return QUALITY_TIERS[1];
}

// Advanced SDP Munging for Ultra-Low Latency & 3G Packet Loss Resilience
const optimizeSdpForUltraLowLatency = (sdpStr: string): string => {
  if (!sdpStr) return sdpStr;
  const lines = sdpStr.split('\r\n');
  const modifiedLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];

    // Optimize Opus Audio: Enable In-band Forward Error Correction (FEC), Discontinuous Transmission (DTX),
    // 10ms frame packing (minptime=10 for ultra-low latency), and mono speech bitrate optimization
    if (line.startsWith('a=fmtp:') && line.includes('opus')) {
      if (!line.includes('useinbandfec=')) {
        line += ';useinbandfec=1';
      }
      if (!line.includes('usedtx=')) {
        line += ';usedtx=1';
      }
      if (!line.includes('minptime=')) {
        line += ';minptime=10';
      }
      if (!line.includes('maxaveragebitrate=')) {
        line += ';maxaveragebitrate=64000;cbr=1';
      }
      if (!line.includes('sprop-stereo=')) {
        line += ';stereo=0;sprop-stereo=0';
      }
    }

    modifiedLines.push(line);

    // Inject bandwidth ceiling if audio or video media definition line
    if (line.startsWith('m=audio')) {
      modifiedLines.push('b=AS:64'); // 64kbps crystal clear mono opus
    } else if (line.startsWith('m=video')) {
      modifiedLines.push('b=AS:1200'); // 1.2Mbps max, smoothly degrades on 3G
    }
  }

  return modifiedLines.join('\r\n');
};

interface CallOverlayProps {
  currentCall: Call;
  currentUser: Profile;
  peerProfile: Profile;
  sendBroadcastEvent?: (event: string, payload: any) => void;
  onClose: (statusMessage?: string, finalStatus?: Call['status']) => void;
  onUpdateCallStatus?: (status: Call['status']) => void;
  allProfiles?: Profile[];
}

export default function CallOverlay({
  currentCall,
  currentUser,
  peerProfile,
  sendBroadcastEvent,
  onClose,
  onUpdateCallStatus,
  allProfiles = []
}: CallOverlayProps) {
  const resources = useResources();
  const [callStatus, setCallStatus] = useState<Call['status']>(currentCall.status);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(currentCall.type === 'video');
  const [errorMessage, setErrorMessage] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [currentCameraIndex, setCurrentCameraIndex] = useState(0);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  // Multi-party calling states (Requirement 3 & 4)
  const [participants, setParticipants] = useState<Profile[]>([peerProfile]);
  const [showAddParticipant, setShowAddParticipant] = useState(false);
  const [focusedParticipantId, setFocusedParticipantId] = useState<string | null>(null);

  // Group call dynamic active participants presence
  const [activeGroupParticipants, setActiveGroupParticipants] = useState<Record<string, { id: string, username: string, display_name: string, avatar_url: string | null, lastSeen: number }>>({});

  useEffect(() => {
    if (callStatus !== 'accepted' || currentCall.receiver_id !== 'general') return;

    // 1. Broadcast our presence immediately, and then every 3 seconds
    const sendHeartbeat = () => {
      if (sendBroadcastEvent) {
        sendBroadcastEvent('vyper_group_call_heartbeat', {
          callId: currentCall.id,
          profile: {
            id: currentUser.id,
            username: currentUser.username,
            display_name: currentUser.display_name,
            avatar_url: currentUser.avatar_url,
          }
        });
      }
    };

    sendHeartbeat();
    const broadcastInterval = setInterval(sendHeartbeat, 3000);

    // 2. Setup event listener for incoming heartbeats
    const handleHeartbeat = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.callId === currentCall.id && detail.profile) {
        const p = detail.profile;
        if (p.id === currentUser.id) return; // skip ourselves

        setActiveGroupParticipants((prev) => ({
          ...prev,
          [p.id]: {
            id: p.id,
            username: p.username,
            display_name: p.display_name,
            avatar_url: p.avatar_url,
            lastSeen: Date.now(),
          }
        }));
      }
    };

    // 3. Setup event listener for when a participant explicitly leaves
    const handleLeave = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.callId === currentCall.id && detail.userId) {
        setActiveGroupParticipants((prev) => {
          if (!prev[detail.userId]) return prev;
          const updated = { ...prev };
          delete updated[detail.userId];
          return updated;
        });
      }
    };

    window.addEventListener('vyper_group_call_heartbeat', handleHeartbeat);
    window.addEventListener('vyper_group_call_leave', handleLeave);

    // 4. Periodically prune participants who haven't sent a heartbeat for 8 seconds
    const pruneInterval = setInterval(() => {
      const now = Date.now();
      setActiveGroupParticipants((prev) => {
        let changed = false;
        const updated = { ...prev };
        Object.keys(updated).forEach((id) => {
          if (now - updated[id].lastSeen > 8000) {
            delete updated[id];
            changed = true;
          }
        });
        return changed ? updated : prev;
      });
    }, 2000);

    return () => {
      clearInterval(broadcastInterval);
      clearInterval(pruneInterval);
      window.removeEventListener('vyper_group_call_heartbeat', handleHeartbeat);
      window.removeEventListener('vyper_group_call_leave', handleLeave);
    };
  }, [callStatus, currentCall.id, currentCall.receiver_id, currentUser, sendBroadcastEvent]);

  // Live interactive reactions (Requirement 3.2)
  interface ActiveReaction {
    id: string;
    emoji: string;
    senderName: string;
    senderId: string;
    x: number;
  }
  const [activeReactions, setActiveReactions] = useState<ActiveReaction[]>([]);
  const [showReactions, setShowReactions] = useState(false);
  const [isEditingReactions, setIsEditingReactions] = useState(false);
  const [listedReactions, setListedReactions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('vyper_unified_reaction_emojis_v2');
      return saved ? JSON.parse(saved) : ['❤️', '👍', '🔥', '🎉', '😮', '😂'];
    } catch (e) {
      return ['❤️', '👍', '🔥', '🎉', '😮', '😂'];
    }
  });

  const [showCallEmojiPicker, setShowCallEmojiPicker] = useState(false);
  const [callCustomEmojiInput, setCallCustomEmojiInput] = useState('');

  const CALL_PRESET_EMOJIS = [
    '❤️', '👍', '🔥', '🎉', '😮', '😂', '👏', '🙏', '😢', '💯',
    '💩', '🤡', '🚀', '⚡', '✨', '💡', '💎', '🍕', '🎯', '🥰',
    '😎', '🥳', '🤩', '🤯', '😍', '👀', '🤝', '🙌', '💪', '💖',
    '⭐', '🍀', '🏆', '🎈'
  ];

  useEffect(() => {
    const handleEmojisUpdate = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setListedReactions(e.detail);
      }
    };
    window.addEventListener('vyper_unified_emojis_updated', handleEmojisUpdate);
    return () => window.removeEventListener('vyper_unified_emojis_updated', handleEmojisUpdate);
  }, []);

  const handleAddNewCallReaction = (newEmojiStr: string) => {
    const cleanEmoji = newEmojiStr.trim();
    if (!cleanEmoji) return;

    setListedReactions((prev) => {
      const filtered = prev.filter((e) => e !== cleanEmoji);
      const updated = [...filtered.slice(0, Math.max(0, prev.length - 1)), cleanEmoji];
      try {
        localStorage.setItem('vyper_unified_reaction_emojis_v2', JSON.stringify(updated));
        window.dispatchEvent(new CustomEvent('vyper_unified_emojis_updated', { detail: updated }));
      } catch (e) {}
      return updated;
    });

    triggerReaction(cleanEmoji);
  };

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const localVideoElementsRef = useRef(new Set<HTMLVideoElement>());
  const remoteVideoElementsRef = useRef(new Set<HTMLVideoElement>());
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const registerLocalVideo = (el: HTMLVideoElement | null) => {
    if (localVideoRef.current) localVideoElementsRef.current.delete(localVideoRef.current);
    if (el) { localVideoElementsRef.current.add(el); localVideoRef.current = el; }
    else localVideoRef.current = null;
    if (el && streamRef.current) { el.srcObject = streamRef.current; void el.play().catch(() => {}); }
  };
  const registerRemoteVideo = (el: HTMLVideoElement | null) => {
    if (remoteVideoRef.current) remoteVideoElementsRef.current.delete(remoteVideoRef.current);
    if (el) { remoteVideoElementsRef.current.add(el); remoteVideoRef.current = el; }
    else remoteVideoRef.current = null;
    if (el && remoteStreamRef.current) { el.srcObject = remoteStreamRef.current; void el.play().catch(() => {}); }
  };
  useEffect(() => {
    const local = streamRef.current;
    for (const el of localVideoElementsRef.current) { el.srcObject = local ?? null; if (local) void el.play().catch(() => {}); }
    const remote = remoteStreamRef.current;
    for (const el of remoteVideoElementsRef.current) { el.srcObject = remote ?? null; if (remote) void el.play().catch(() => {}); }
    if (remoteAudioRef.current && remote) { remoteAudioRef.current.srcObject = remote; void remoteAudioRef.current.play().catch(() => {}); }
  }, [callStatus, isVideoOn, focusedParticipantId]);
  const isTerminatedRef = useRef<boolean>(false);
  const isAcceptingRef = useRef<boolean>(false);
  const [isProcessingAction, setIsProcessingAction] = useState<boolean>(false);

  // Call Recording & Quality States
  const [isRecording, setIsRecording] = useState(false);
  const [recordingType, setRecordingType] = useState<'screen' | 'voice' | null>(null);
  const [showRecordOptions, setShowRecordOptions] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [savedRecordingInfo, setSavedRecordingInfo] = useState<{ url: string; fileName: string; type: string } | null>(null);
  const [networkLatency, setNetworkLatency] = useState<number | null>(null);
  const [is3GMode, setIs3GMode] = useState<boolean>(false);
  const sustainedMinimalTierCountRef = useRef(0);
  const recoveredVideoTierCountRef = useRef(0);
  const cleanHighTierCountRef = useRef(0);
  const remoteInboundTotalsRef = useRef({ packetsLost: 0, packetsReceived: 0 });
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const streamToRecordRef = useRef<MediaStream | null>(null);

  // Live recording timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRecording) {
      setRecordingDuration(0);
      interval = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setRecordingDuration(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording]);

  const startRecording = async (type: 'screen' | 'voice') => {
    try {
      setShowRecordOptions(false);
      recordedChunksRef.current = [];
      let recordStream: MediaStream;

      if (type === 'screen') {
        try {
          // Attempt display/screen recording with audio
          recordStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
        } catch (e) {
          console.warn("Screen capture failed/denied, falling back to active call streams:", e);
          // Fallback: combine all tracks from local and remote streams
          const tracks: MediaStreamTrack[] = [];
          if (localVideoRef.current?.srcObject instanceof MediaStream) {
            (localVideoRef.current.srcObject as MediaStream).getTracks().forEach(t => tracks.push(t));
          }
          if (remoteVideoRef.current?.srcObject instanceof MediaStream) {
            (remoteVideoRef.current.srcObject as MediaStream).getTracks().forEach(t => tracks.push(t));
          }
          if (tracks.length === 0 && streamRef.current) {
            streamRef.current.getTracks().forEach(t => tracks.push(t));
          }
          if (tracks.length === 0) {
            // Last resort fallback
            recordStream = await resources.getUserMedia({ video: true, audio: true });
          } else {
            recordStream = new MediaStream(tracks);
          }
        }
      } else {
        // Voice/Audio only recording
        const tracks: MediaStreamTrack[] = [];
        if (localVideoRef.current?.srcObject instanceof MediaStream) {
          (localVideoRef.current.srcObject as MediaStream).getAudioTracks().forEach(t => tracks.push(t));
        }
        if (remoteVideoRef.current?.srcObject instanceof MediaStream) {
          (remoteVideoRef.current.srcObject as MediaStream).getAudioTracks().forEach(t => tracks.push(t));
        }
        if (tracks.length === 0 && streamRef.current) {
          streamRef.current.getAudioTracks().forEach(t => tracks.push(t));
        }
        if (tracks.length === 0) {
          // Last resort fallback
          recordStream = await resources.getUserMedia({ audio: true });
        } else {
          recordStream = new MediaStream(tracks);
        }
      }

      streamToRecordRef.current = recordStream;

      let options = {};
      if (type === 'screen') {
        const mimeTypes = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
        const chosenType = mimeTypes.find(t => MediaRecorder.isTypeSupported(t)) || '';
        if (chosenType) options = { mimeType: chosenType };
      } else {
        const mimeTypes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg', 'audio/mp4'];
        const chosenType = mimeTypes.find(t => MediaRecorder.isTypeSupported(t)) || '';
        if (chosenType) options = { mimeType: chosenType };
      }

      const mediaRecorder = resources.recorder(new MediaRecorder(recordStream, options));
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const blobType = type === 'screen' ? 'video/webm' : 'audio/webm';
        const blob = new Blob(recordedChunksRef.current, { type: blobType });
        const downloadBlobUrl = resources.blob(blob);

        const reader = resources.reader();
        reader.readAsDataURL(blob);
        reader.onloadend = async () => {
          const base64data = reader.result as string;
          const fileName = type === 'voice' ? 'Voicecall record' : 'Videocall record';
          const fileType = type === 'screen' ? 'video/webm' : 'audio/voice-note';
          const targetName = peerProfile?.display_name || peerProfile?.username || 'Operator';
          const msgId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `msg_${Date.now()}`;

          // Set instant download popup for the user
          setSavedRecordingInfo({
            url: downloadBlobUrl,
            fileName: `${fileName}_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.${type === 'screen' ? 'webm' : 'webm'}`,
            type: fileType,
          });

          // Save to IndexedDB local device storage
          await saveFileToLocalStorage(
            fileName,
            fileType,
            base64data,
            msgId,
            'from',
            targetName
          );

          // Dispatch mini roast toast
          const roast = getMiniRoastMessage(type === 'voice' ? 'record_voice' : 'record_video');
          window.dispatchEvent(new CustomEvent('vyper_show_roast_toast', { detail: roast }));

          // Forward to user's private vault chat as backup
          const chatRoomId = `me:${currentUser.id}`;
          const textMessage = `🎥 ${fileName} saved to device local storage.`;

          const dbPayload = {
            id: msgId,
            chat_id: chatRoomId,
            sender_id: currentUser.id,
            text: textMessage,
            file_name: fileName,
            file_type: fileType,
            file_data: base64data,
            is_voice: type === 'voice',
          };

          try {
            const { error } = await oracleDB.from('messages').insert(dbPayload);
            if (error) console.error("Failed to forward call record to private chat:", error);

            // Notify local UI
            window.dispatchEvent(new CustomEvent('vyper_new_local_message', { detail: dbPayload }));
          } catch (err) {
            console.error("Error inserting recording:", err);
          }
        };

        // Stop all track media streams
        if (streamToRecordRef.current) {
          streamToRecordRef.current.getTracks().forEach(track => track.stop());
          streamToRecordRef.current = null;
        }
      };

      mediaRecorder.start(1000);
      setIsRecording(true);
      setRecordingType(type);
    } catch (err) {
      console.warn("Failed to start call recording:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        console.error("Error stopping recorder:", e);
      }
    }
    setIsRecording(false);
    setRecordingType(null);
  };
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const earlySignalingQueueRef = useRef<any[]>([]);
  const pendingCandidatesRef = useRef<any[]>([]);
  const remoteStreamRef = useRef<MediaStream | null>(null);

  const isCaller = currentCall.caller_id === currentUser.id;

  const remotePeerIdRef = useRef<string | null>(
    currentCall.receiver_id === 'general'
      ? (isCaller ? null : currentCall.caller_id)
      : peerProfile.id
  );

  const sendSignal = (type: 'ready' | 'offer' | 'answer' | 'candidate' | 'hangup', extraData: any = {}) => {
    const targetId = remotePeerIdRef.current || (currentCall.receiver_id === 'general' ? 'general' : peerProfile.id);
    const signalPacket = {
      type,
      senderId: currentUser.id,
      receiverId: targetId,
      callId: currentCall.id,
      ...extraData
    };
    void sendCallSignal(signalPacket, oracleDB.getSSEClientId()).catch((error) => console.warn('[WebRTC] Signaling request failed', error));
  };

  // Sync callStatus when currentCall.status changes
  useEffect(() => {
    setCallStatus(currentCall.status);
    if (currentCall.status === 'rejected') {
      onClose('Call was declined', 'rejected');
    } else if (currentCall.status === 'ended') {
      onClose('Call ended', 'ended');
    } else if (currentCall.status === 'missed') {
      onClose('Missed call logged', 'missed');
    }
  }, [currentCall.status, onClose]);

  // Synchronize participants and reactions in real-time (Requirements 3.2 & 3.3)
  useEffect(() => {
    const handleParticipantAdded = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.callId === currentCall.id && detail.profile) {
        setParticipants((prev) => {
          if (prev.some((p) => p.id === detail.profile.id)) return prev;
          return [...prev, detail.profile];
        });
      }
    };

    const handleLiveReaction = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && detail.callId === currentCall.id) {
        const id = `react_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
        const newReact = {
          id,
          emoji: detail.emoji,
          senderName: detail.senderName,
          senderId: detail.senderId,
          x: Math.random() * 80 + 10, // 10% to 90% horizontal range
        };
        setActiveReactions((prev) => [...prev, newReact]);

        // Auto remove reaction after 3 seconds
        resources.timeout(() => {
          setActiveReactions((prev) => prev.filter((r) => r.id !== id));
        }, 3000);
      }
    };

    window.addEventListener('vyper_call_participant_added', handleParticipantAdded);
    window.addEventListener('vyper_call_live_reaction', handleLiveReaction);

    return () => {
      window.removeEventListener('vyper_call_participant_added', handleParticipantAdded);
      window.removeEventListener('vyper_call_live_reaction', handleLiveReaction);
    };
  }, [currentCall.id]);

  // 1. Subscribe to updates on this specific call record for real-time status synchronization
  useEffect(() => {
    const callSub = oracleDB
      .channel(`call_room:${currentCall.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'calls', filter: `id=eq.${currentCall.id}` },
        (payload) => {
          const updated = payload.new as Call;
          if (!updated) return;
          setCallStatus(updated.status);

          if (updated.status === 'rejected') {
            onClose('Call was declined', 'rejected');
          } else if (updated.status === 'ended') {
            onClose('Call ended', 'ended');
          } else if (updated.status === 'missed') {
            onClose('Missed call logged', 'missed');
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'calls', filter: `id=eq.${currentCall.id}` },
        () => {
          onClose('Call terminated');
        }
      )
      .subscribe();

    return () => {
      oracleDB.removeChannel(callSub);
    };
  }, [currentCall.id, onClose]);

  // 2. Local call duration counter when status is accepted
  useEffect(() => {
    if (callStatus === 'accepted') {
      timerRef.current = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callStatus]);

  // Save active duration to localStorage so call logs have live accurate durations
  useEffect(() => {
    if (duration > 0) {
      try {
        const stored = JSON.parse(localStorage.getItem('vyper_call_durations') || '{}');
        stored[currentCall.id] = duration;
        localStorage.setItem('vyper_call_durations', JSON.stringify(stored));
      } catch (e) {
        console.warn('Failed to persist call duration:', e);
      }
    }
  }, [duration, currentCall.id]);

  // Ringing Auto-timeout: Ends the call automatically if not answered
  useEffect(() => {
    if (callStatus !== 'ringing') return;

    const isPeerOffline = !peerProfile || !isUserOnline(peerProfile);
    const timeoutDuration = isPeerOffline ? 18000 : 30000;

    const timeoutId = resources.timeout(() => {
      console.log('WebRTC: Call ringing timed out');
      if (isPeerOffline) {
        setErrorMessage('Recipient is offline. Logged as missed call.');
      } else {
        setErrorMessage('Connection timed out. No response from recipient.');
      }
      resources.timeout(() => {
        handleEndCall();
      }, 1800);
    }, timeoutDuration);

    return () => resources.clearTimeout(timeoutId);
  }, [callStatus, peerProfile]);

  // 3. Ringtone loop: Play standard double-beep ringtones with single reusable AudioContext & node cleanup
  useEffect(() => {
    if (callStatus !== 'ringing') return;

    let audioCtx: AudioContext | null = null;
    let isPlaying = true;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    } catch (e) {}

    const playRingCycle = () => {
      if (!isPlaying || !audioCtx) return;
      try {
        if (audioCtx.state === 'suspended') {
          audioCtx.resume();
        }

        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        osc1.type = 'sine';
        osc1.frequency.value = isCaller ? 400 : 440; // Caller hears ringback, receiver hears ringtone

        osc2.type = 'sine';
        osc2.frequency.value = isCaller ? 450 : 480;

        const now = audioCtx.currentTime;
        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.linearRampToValueAtTime(0.08, now + 0.1);
        gainNode.gain.setValueAtTime(0.08, now + 1.2);
        gainNode.gain.linearRampToValueAtTime(0, now + 1.4);

        osc1.connect(gainNode);
        osc2.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        osc1.start(now);
        osc2.start(now);

        osc1.stop(now + 1.5);
        osc2.stop(now + 1.5);

        osc1.onended = () => {
          try {
            osc1.disconnect();
            osc2.disconnect();
            gainNode.disconnect();
          } catch (e) {}
        };
      } catch (err) {
        console.warn('Ringtone sound error:', err);
      }
    };

    // Loop ringtone every 3 seconds
    const interval = setInterval(playRingCycle, 3000);
    playRingCycle(); // Play instantly first

    return () => {
      isPlaying = false;
      clearInterval(interval);
      if (audioCtx && audioCtx.state !== 'closed') {
        audioCtx.close().catch(() => {});
      }
    };
  }, [callStatus, isCaller]);

  // Switch between available camera devices or toggle facingMode on mobile/tablets safely
  const handleSwitchCamera = async () => {
    if (!streamRef.current || currentCall.type !== 'video' || callStatus !== 'accepted') return;

    try {
      // 1. Refresh available devices dynamically to ensure up-to-date device IDs
      let availableVideoDevices = cameras;
      try {
        const enumerated = await navigator.mediaDevices.enumerateDevices();
        const vDevices = enumerated.filter((d) => d.kind === 'videoinput');
        if (vDevices.length > 0) {
          availableVideoDevices = vDevices;
          setCameras(vDevices);
        }
      } catch (e) {
        console.warn('WebRTC: Device enumeration warning during switch:', e);
      }

      const currentVideoTrack = streamRef.current.getVideoTracks()[0];
      const previousSettings = currentVideoTrack ? currentVideoTrack.getSettings() : null;

      let targetConstraints: MediaTrackConstraints = {};
      let nextIndex = currentCameraIndex;
      let nextFacingMode = facingMode;

      if (availableVideoDevices.length > 1) {
        nextIndex = (currentCameraIndex + 1) % availableVideoDevices.length;
        setCurrentCameraIndex(nextIndex);
        const nextDevice = availableVideoDevices[nextIndex];
        // Use ideal constraint rather than exact to avoid Overconstrained / NotReadable errors
        targetConstraints = nextDevice.deviceId ? { deviceId: { ideal: nextDevice.deviceId } } : {};
        console.log('WebRTC: Switching to camera index:', nextIndex, nextDevice.label || nextDevice.deviceId);
      } else {
        nextFacingMode = facingMode === 'user' ? 'environment' : 'user';
        setFacingMode(nextFacingMode);
        targetConstraints = { facingMode: { ideal: nextFacingMode } };
        console.log('WebRTC: Toggling facingMode to:', nextFacingMode);
      }

      // 2. CRITICAL: Stop previous video track before acquiring new one.
      // Most OS camera drivers (Linux, Windows, Android, macOS) hold an exclusive hardware lock.
      // Attempting to open a second video source simultaneously causes "NotReadableError: Could not start video source".
      if (currentVideoTrack) {
        currentVideoTrack.stop();
        streamRef.current.removeTrack(currentVideoTrack);
      }

      // Small pause to allow OS driver to cleanly release the camera hardware handle
      await new Promise((resolve) => resources.timeout(resolve, 60));

      let newStream: MediaStream | null = null;
      try {
        newStream = await resources.getUserMedia({
          video: {
            ...targetConstraints,
            width: { min: 320, ideal: 1280, max: 1920 },
            height: { min: 240, ideal: 720, max: 1080 },
            frameRate: { min: 20, ideal: 30, max: 60 },
          },
          audio: false,
        });
      } catch (deviceError) {
        console.warn('WebRTC: Specific camera constraint failed, attempting general video fallback:', deviceError);
        // Fallback 1: Try general ideal facing mode or basic video
        try {
          newStream = await resources.getUserMedia({
            video: {
              facingMode: { ideal: nextFacingMode },
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
            audio: false,
          });
        } catch (fallbackError) {
          console.warn('WebRTC: Ideal constraint failed, falling back to any available video source:', fallbackError);
          // Fallback 2: Basic generic video constraint
          newStream = await resources.getUserMedia({
            video: true,
            audio: false,
          });
        }
      }

      if (newStream) {
        const newVideoTrack = newStream.getVideoTracks()[0];
        if (newVideoTrack) {
          newVideoTrack.enabled = isVideoOn;
          newVideoTrack.contentHint = 'motion';
          streamRef.current.addTrack(newVideoTrack);

          // Update WebRTC peer connection sender
          if (peerConnectionRef.current) {
            const senders = peerConnectionRef.current.getSenders();
            const videoSender = senders.find((s) => s.track && s.track.kind === 'video');
            if (videoSender) {
              await videoSender.replaceTrack(newVideoTrack);
              console.log('WebRTC: Video track replaced on peer connection');
            }
          }

          // Update local view
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = streamRef.current;
          }

          // Update self-demo remote view if applicable
          const isSelfDemo = currentCall.caller_id === currentCall.receiver_id;
          if (isSelfDemo && remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = streamRef.current;
          }

          setErrorMessage('');
        }
      }
    } catch (err: any) {
      console.warn('WebRTC: Failed to switch camera device gracefully:', err);
      // Attempt recovery: restore default video capture so video stream is not lost
      try {
        const recoveryStream = await resources.getUserMedia({ video: true, audio: false });
        const recoveryTrack = recoveryStream.getVideoTracks()[0];
        if (recoveryTrack && streamRef.current) {
          recoveryTrack.enabled = isVideoOn;
          streamRef.current.addTrack(recoveryTrack);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = streamRef.current;
          }
          if (peerConnectionRef.current) {
            const videoSender = peerConnectionRef.current.getSenders().find((s) => s.track && s.track.kind === 'video');
            if (videoSender) {
              await videoSender.replaceTrack(recoveryTrack);
            }
          }
        }
      } catch (recoverErr) {
        console.error('WebRTC: Video recovery also failed:', recoverErr);
        setIsVideoOn(false);
      }
      setErrorMessage('Camera switched to available device.');
      resources.timeout(() => setErrorMessage(''), 3000);
    }
  };

  // 3G & Network Quality adaptive monitor
  useEffect(() => {
    if (callStatus !== 'accepted') return;
    const interval = setInterval(async () => {
      const pc = peerConnectionRef.current;
      if (!pc || pc.connectionState !== 'connected') return;

      try {
        const stats = await pc.getStats();
        let currentRtt: number | null = null;
        let availableOutgoing: number | null = null;
        let fractionLost: number | null = null;
        let remoteInboundLost = 0;
        let remoteInboundReceived = 0;

        stats.forEach((report) => {
          if (report.type === 'candidate-pair' && report.state === 'succeeded') {
            if (report.currentRoundTripTime) currentRtt = Math.round(report.currentRoundTripTime * 1000);
            if (typeof report.availableOutgoingBitrate === 'number') availableOutgoing = report.availableOutgoingBitrate;
          }
          if (report.type === 'outbound-rtp' && report.kind === 'video' && typeof report.fractionLost === 'number') {
            fractionLost = report.fractionLost;
          }
          if (report.type === 'remote-inbound-rtp' && report.kind === 'video') {
            remoteInboundLost += report.packetsLost || 0;
            remoteInboundReceived += report.packetsReceived || 0;
          }
        });

        if (fractionLost === null && (remoteInboundLost || remoteInboundReceived)) {
          const previous = remoteInboundTotalsRef.current;
          const lostDelta = Math.max(0, remoteInboundLost - previous.packetsLost);
          const receivedDelta = Math.max(0, remoteInboundReceived - previous.packetsReceived);
          fractionLost = lostDelta / Math.max(1, receivedDelta + lostDelta);
          remoteInboundTotalsRef.current = { packetsLost: remoteInboundLost, packetsReceived: remoteInboundReceived };
        }
        const lossRate = fractionLost ?? 0;
        const candidateTier = pickQualityTier(availableOutgoing, currentRtt, lossRate);
        setNetworkLatency(currentRtt);
        cleanHighTierCountRef.current = candidateTier.label === 'high' && lossRate < 0.01 && (availableOutgoing ?? 0) > 900_000 ? cleanHighTierCountRef.current + 1 : 0;
        const tier = candidateTier.label === 'high' && cleanHighTierCountRef.current < 2 ? QUALITY_TIERS[1] : candidateTier;
        setIs3GMode(tier.label !== 'high');
        sustainedMinimalTierCountRef.current = tier.label === 'minimal' ? sustainedMinimalTierCountRef.current + 1 : 0;
        recoveredVideoTierCountRef.current = tier.label !== 'minimal' ? recoveredVideoTierCountRef.current + 1 : 0;

        const senders = pc.getSenders();
        const videoSender = senders.find((s) => s.track && s.track.kind === 'video');
        if (videoSender) {
          const params = videoSender.getParameters() || {};
          if (params.encodings && params.encodings.length > 0) {
            params.encodings[0].maxBitrate = tier.maxBitrate;
            params.encodings[0].scaleResolutionDownBy = tier.scaleDown;
            await videoSender.setParameters(params);
          }
          const videoTrack = streamRef.current?.getVideoTracks()[0];
          if (videoTrack && sustainedMinimalTierCountRef.current >= 3) {
            videoTrack.enabled = false;
            setIsVideoOn(false);
            setErrorMessage('Video paused to keep the call connected — network too weak for video.');
          } else if (videoTrack && tier.label !== 'minimal' && recoveredVideoTierCountRef.current >= 3 && !videoTrack.enabled) {
            videoTrack.enabled = true;
            setIsVideoOn(true);
            setErrorMessage('');
          }
        }
        const audioSender = senders.find((s) => s.track?.kind === 'audio');
        if (audioSender) {
          const audioParams = audioSender.getParameters() || {};
          if (audioParams.encodings?.length) {
            audioParams.encodings[0].maxBitrate = tier.label === 'minimal' ? 16_000 : tier.label === 'low' ? 24_000 : 64_000;
            await audioSender.setParameters(audioParams);
          }
        }
        const videoReceiver = pc.getReceivers().find((r) => r.track?.kind === 'video');
        if (videoReceiver && 'playoutDelayHint' in videoReceiver) {
          (videoReceiver as any).playoutDelayHint = tier.label === 'high' ? 0 : tier.label === 'medium' ? 0.1 : 0.25;
        }
      } catch (e) {}
    }, 2000);

    return () => clearInterval(interval);
  }, [callStatus]);

  // Perfect Negotiation state flags
  const makingOfferRef = useRef(false);
  const isSettingRemoteAnswerPendingRef = useRef(false);

  // Initialize RTCPeerConnection with high-speed STUN servers and 3G resilience
  const peerCleanupRef = useRef<(() => void) | null>(null);
  const initializePeerConnection = async (localStream: MediaStream, cancelled: () => boolean) => {
    peerCleanupRef.current?.();
    const loadIce = async () => {
      const res = await fetch(`/api/calls/${encodeURIComponent(currentCall.id)}/ice-servers`, { credentials: 'same-origin' });
      const body = await res.json();
      if (!res.ok || !Array.isArray(body.iceServers)) throw new Error(body.error || 'Private relay unavailable');
      return body.iceServers as RTCIceServer[];
    };
    const iceServers = await loadIce();
    if (cancelled()) throw new Error('Call closed');
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
    }

    const pc = new RTCPeerConnection({
      iceServers,
      iceCandidatePoolSize: 10,
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require'
    });

    // Add local tracks with content hints for ultra-low latency & motion priority
    localStream.getTracks().forEach((track) => {
      if (track.kind === 'video') {
        track.contentHint = 'motion';
      } else if (track.kind === 'audio') {
        track.contentHint = 'speech';
      }
      pc.addTrack(track, localStream);
    });

    // Apply sender parameter optimizations (maintain-framerate degradation for 3G, priority high)
    const optimizeTimer = resources.timeout(async () => {
      try {
        if (cancelled() || String(pc.signalingState) === 'closed') return;
        const senders = pc.getSenders();
        for (const sender of senders) {
          if (sender.track) {
            const params: any = sender.getParameters();
            if (!params) continue;
            if (!params.encodings || params.encodings.length === 0) {
              params.encodings = [{}];
            }
            if (sender.track.kind === 'video') {
              params.degradationPreference = 'maintain-framerate';
              if (params.encodings && params.encodings.length > 0) {
                params.encodings[0].maxBitrate = 600000;
                params.encodings[0].scaleResolutionDownBy = 1.5;
                params.encodings[0].networkPriority = 'high';
                params.encodings[0].priority = 'high';
              }
            } else if (sender.track.kind === 'audio') {
              if (params.encodings && params.encodings.length > 0) {
                params.encodings[0].maxBitrate = 64000;
                params.encodings[0].networkPriority = 'high';
                params.encodings[0].priority = 'high';
              }
            }
            await sender.setParameters(params);
          }
        }
      } catch (e) {}
    }, 500);

    // Handle remote media track arrival
    pc.ontrack = (event) => {
      console.log('WebRTC: Received remote media track', event.track.kind);
      if (!remoteStreamRef.current) {
        remoteStreamRef.current = new MediaStream();
      }

      // Safely insert the track into our persistent remote media stream object
      remoteStreamRef.current.addTrack(event.track);
      const remoteStream = remoteStreamRef.current;

      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
        remoteVideoRef.current.play().catch(e => console.warn("Video play error:", e));
      }
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = remoteStream;
        remoteAudioRef.current.play().catch(e => console.warn("Audio play error:", e));
      }
    };

    // Handle ICE Candidate generation and broadcast
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignal('candidate', { candidate: event.candidate });
      }
    };

    let retryTimer: ReturnType<typeof setTimeout> | undefined;
    let restarts = 0;
    const restart = async () => {
      if (cancelled() || String(pc.signalingState) === 'closed' || restarts++ >= 3) return;
      try {
        const servers = await loadIce();
        if (cancelled() || String(pc.signalingState) === 'closed') return;
        pc.setConfiguration({ ...pc.getConfiguration(), iceServers: servers });
        pc.restartIce();
        if (isCaller) {
          const offer = await pc.createOffer({ iceRestart: true });
          await pc.setLocalDescription(offer); sendSignal('offer', { sdp: pc.localDescription });
        } else sendSignal('ready');
      } catch { if (!cancelled()) setErrorMessage('Call relay reconnect failed. Please retry or end the call.'); }
    };
    const onNetworkChange = () => { if (retryTimer) resources.clearTimeout(retryTimer); retryTimer = resources.timeout(() => void restart(), 1000); };
    pc.oniceconnectionstatechange = () => {
      if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') { restarts = 0; setErrorMessage(''); }
      else if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') { setErrorMessage('Connection interrupted. Reconnecting…'); onNetworkChange(); }
    };
    window.addEventListener('online', onNetworkChange);
    const refreshTimer = setInterval(() => {
      void loadIce().then(servers => { if (!cancelled() && pc.signalingState !== 'closed') pc.setConfiguration({ ...pc.getConfiguration(), iceServers: servers }); })
        .catch(() => { if (!cancelled()) setErrorMessage('Call relay renewal failed; reconnect may be unavailable'); });
    }, 5 * 60000);
    const connectTimeout = resources.timeout(() => {
      if (!cancelled() && !['connected', 'completed'].includes(pc.iceConnectionState)) setErrorMessage('Call connection timed out. Check the network and retry.');
    }, 30000);
    peerCleanupRef.current = () => {
      window.removeEventListener('online', onNetworkChange);
      resources.clearTimeout(optimizeTimer); resources.clearTimeout(connectTimeout); clearInterval(refreshTimer); if (retryTimer) resources.clearTimeout(retryTimer);
      pc.onicecandidate = null; pc.oniceconnectionstatechange = null; pc.ontrack = null;
      pc.close();
    };
    peerConnectionRef.current = pc;
    return pc;
  };

  // Handle incoming signaling messages with Perfect Negotiation & SDP Optimization
  const handleSignalingMessage = async (payload: any) => {
    payload = payload?.signalData ? { ...payload.signalData, callId: payload.callId ?? payload.signalData.callId } : payload;
    if (payload.callId !== currentCall.id) return;

    // Fast-path immediate teardown on hangup/cancellation
    if (payload.type === 'hangup' || payload.type === 'ended' || payload.type === 'rejected') {
      console.log('WebRTC: Received hangup/rejection signaling message');
      if (onUpdateCallStatus) {
        onUpdateCallStatus(payload.status === 'rejected' ? 'rejected' : 'ended');
      }
      onClose(payload.status === 'rejected' ? 'Call was declined' : 'Call ended');
      return;
    }

    // Discover peer ID from incoming signals to ensure precise 1-to-1 WebRTC signaling
    if (payload.senderId && payload.senderId !== currentUser.id) {
      remotePeerIdRef.current = payload.senderId;
    }

    const pc = peerConnectionRef.current;

    // Queue signal if connection or stream is not ready
    if (!streamRef.current || !pc) {
      console.log('WebRTC: Connection or stream not ready yet. Queuing signal:', payload.type);
      if (earlySignalingQueueRef.current.length < 100) {
        earlySignalingQueueRef.current.push(payload);
      }
      return;
    }

    if (pc.signalingState === 'closed') {
      console.warn('WebRTC: Signaling message received but RTCPeerConnection is closed.');
      return;
    }

    // Determine politeness deterministically
    const targetPeerId = remotePeerIdRef.current || peerProfile.id;
    const isPolite = currentUser.id < targetPeerId;

    try {
      if (payload.type === 'ready') {
        console.log('WebRTC: Receiver signaled ready, negotiating offer');
        if (isCaller) {
          try {
            makingOfferRef.current = true;
            const offer = await pc.createOffer({ iceRestart: true });
            if (pc.signalingState !== 'stable') return;
            const optimizedSdp = optimizeSdpForUltraLowLatency(offer.sdp || '');
            const modifiedOffer = new RTCSessionDescription({ type: offer.type, sdp: optimizedSdp });
            await pc.setLocalDescription(modifiedOffer);
            sendSignal('offer', { sdp: pc.localDescription || modifiedOffer });
          } catch (e) {
            console.warn('WebRTC: Offer creation failed:', e);
          } finally {
            makingOfferRef.current = false;
          }
        }
      } else if (payload.type === 'offer') {
        const offerCollision = makingOfferRef.current || pc.signalingState !== 'stable';
        if (offerCollision && !isPolite) {
          console.log('WebRTC: Impolite peer ignoring colliding offer');
          return;
        }

        console.log('WebRTC: Processing offer, creating answer');
        await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));

        // Flush any pending ICE candidates
        for (const candidate of pendingCandidatesRef.current) {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(candidate));
          } catch (e) {
            console.warn('WebRTC: Error adding deferred candidate:', e);
          }
        }
        pendingCandidatesRef.current = [];

        const answer = await pc.createAnswer();
        const optimizedSdp = optimizeSdpForUltraLowLatency(answer.sdp || '');
        const modifiedAnswer = new RTCSessionDescription({ type: answer.type, sdp: optimizedSdp });
        await pc.setLocalDescription(modifiedAnswer);
        sendSignal('answer', { sdp: pc.localDescription || modifiedAnswer });
      } else if (payload.type === 'answer') {
        if (pc.signalingState === 'have-local-offer') {
          console.log('WebRTC: Processing answer, setting remote description');
          isSettingRemoteAnswerPendingRef.current = true;
          await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
          isSettingRemoteAnswerPendingRef.current = false;

          // Flush any pending ICE candidates
          for (const candidate of pendingCandidatesRef.current) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(candidate));
            } catch (e) {
              console.warn('WebRTC: Error adding deferred candidate:', e);
            }
          }
          pendingCandidatesRef.current = [];
        } else {
          console.log(`WebRTC: Received answer in unexpected state ${pc.signalingState}, ignoring.`);
        }
      } else if (payload.type === 'candidate') {
        if (payload.candidate) {
          if (pc.remoteDescription && pc.remoteDescription.type) {
            console.log('WebRTC: Adding remote ICE candidate');
            try {
              await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
            } catch (e) {
              console.warn('WebRTC: Error adding candidate:', e);
            }
          } else {
            console.log('WebRTC: Remote description not set yet. Caching candidate.');
            pendingCandidatesRef.current.push(payload.candidate);
          }
        }
      }
    } catch (err) {
      console.error('WebRTC: Signaling handling error:', err);
    }
  };

  // Listen to the authenticated VPS SSE signaling stream
  useEffect(() => {
    const onSignal = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        handleSignalingMessage(detail);
      }
    };
    window.addEventListener('vypervic_webrtc_signal', onSignal);


    return () => {
      window.removeEventListener('vypervic_webrtc_signal', onSignal);
    };
  }, [currentCall.id]);

  // 4. Camera/Mic capture and WebRTC setup activation with 3G optimization
  useEffect(() => {
    if (callStatus === 'ended' || callStatus === 'rejected') {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }
      return;
    }

    // Do NOT request camera/microphone permissions on incoming ringing calls until the user actually accepts!
    if (!isCaller && callStatus === 'ringing') {
      return;
    }

    let cancelled = false;
    const wantVideo = currentCall.type === 'video';

    const grabStream = (withVideo: boolean) => {
      if (streamRef.current) {
        return Promise.resolve(streamRef.current);
      }

      const audioConstraints: MediaTrackConstraints = {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1, // Mono saves bandwidth on 3G while enhancing clarity
        sampleRate: { ideal: 48000 },
      };

      const connectionType = (navigator as any).connection?.effectiveType;
      const startLow = ['slow-2g', '2g', '3g'].includes(connectionType);
      const videoConstraints: MediaTrackConstraints = {
        facingMode: facingMode,
        width: { min: 320, ideal: startLow ? 640 : 1280, max: 1920 },
        height: { min: 240, ideal: startLow ? 480 : 720, max: 1080 },
        frameRate: { min: 15, ideal: startLow ? 20 : 30, max: 60 },
      };

      return resources.getUserMedia({
        video: withVideo ? videoConstraints : false,
        audio: audioConstraints,
      }).catch((err) => {
        if (withVideo) {
          console.warn('WebRTC: Video capture failed, gracefully falling back to audio only:', err);
          setErrorMessage('Camera blocked or busy. Connecting via audio stream.');
          return resources.getUserMedia({ video: false, audio: audioConstraints });
        }
        throw err;
      });
    };

    grabStream(wantVideo)
      .then(async (stream) => {
        if (cancelled) { stream.getTracks().forEach(track => track.stop()); return; }
        streamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Enumerate devices once we have permission (stream loaded) to find all video inputs
        if (wantVideo) {
          navigator.mediaDevices.enumerateDevices()
            .then((devices) => {
              if (cancelled) return;
              const videoDevices = devices.filter((d) => d.kind === 'videoinput');
              setCameras(videoDevices);
              const activeTrack = stream.getVideoTracks()[0];
              if (activeTrack) {
                const settings = activeTrack.getSettings();
                if (settings.deviceId) {
                  const idx = videoDevices.findIndex((d) => d.deviceId === settings.deviceId);
                  if (idx !== -1) {
                    setCurrentCameraIndex(idx);
                  }
                }
              }
            })
            .catch((err) => console.warn('WebRTC: Device enumeration failed:', err));
        }

        // Initialize WebRTC connection only when call has been accepted
        if (callStatus === 'accepted') {
          // If testing in a self-test call (calling oneself), loop back video for instant visual verification
          const isSelfDemo = currentCall.caller_id === currentCall.receiver_id;
          if (isSelfDemo) {
            if (remoteVideoRef.current) {
              remoteVideoRef.current.srcObject = stream;
            }
          }

          // Initialize Connection
          const pc = await initializePeerConnection(stream, () => cancelled);
          if (cancelled) { pc.close(); return; }

          // Process any early queued signaling messages sequentially to bypass async race conditions
          const queue = [...earlySignalingQueueRef.current];
          earlySignalingQueueRef.current = [];
          for (const msg of queue) {
            await handleSignalingMessage(msg);
          }

          // Both peers announce that tracks and the peer connection are ready.
          // The caller creates the offer only after receiving the callee's ready signal.
          sendSignal('ready');
        }
      })
      .catch((err) => {
        if (cancelled) return;
        streamRef.current?.getTracks().forEach(track => track.stop()); streamRef.current = null;
        setErrorMessage(err instanceof Error ? err.message : 'Camera, microphone or call relay unavailable. No call media is connected.');
      });
    return () => {
      cancelled = true;
      peerCleanupRef.current?.(); peerCleanupRef.current = null;
      streamRef.current?.getTracks().forEach(track => track.stop()); streamRef.current = null;
      remoteStreamRef.current?.getTracks().forEach(track => track.stop()); remoteStreamRef.current = null;
      peerConnectionRef.current?.close(); peerConnectionRef.current = null;
    };

  }, [callStatus, currentCall.id, currentCall.type, currentCall.caller_id, currentCall.receiver_id, currentUser.id, isCaller]);

  useEffect(() => {
    const background = () => {
      streamRef.current?.getTracks().forEach(track => track.stop());
      peerCleanupRef.current?.();
      void oracleDB.from('calls').update({ status: 'ended' }).eq('id', currentCall.id);
      onClose('Call ended when the app left the foreground', 'ended');
    };
    window.addEventListener('vyper_native_background', background);
    return () => window.removeEventListener('vyper_native_background', background);
  }, [currentCall.id]);

  // Handle Mute
  useEffect(() => {
    if (streamRef.current) {
      const audioTrack = streamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !isMuted;
      }
    }
  }, [isMuted]);

  // Handle Camera toggles
  useEffect(() => {
    if (streamRef.current) {
      const videoTrack = streamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = isVideoOn;
      }
    }
  }, [isVideoOn]);

  // Handle Caller Cancelling or ending call
  const handleEndCall = async () => {
    if (isTerminatedRef.current) return;
    isTerminatedRef.current = true;
    setIsProcessingAction(true);

    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (peerConnectionRef.current) {
        try {
          peerConnectionRef.current.close();
        } catch {}
      }

      const finalStatus = 'ended' as const; // cancellation is not a missed call before its ringing deadline

      sendSignal('hangup', { status: finalStatus });

      if (sendBroadcastEvent) {
        sendBroadcastEvent('vyper_group_call_leave', {
          callId: currentCall.id,
          userId: currentUser.id,
        });
        sendBroadcastEvent('call_status_update', {
          callId: currentCall.id,
          status: finalStatus,
        });
      }

      if (onUpdateCallStatus) {
        onUpdateCallStatus(finalStatus);
      }
      onClose('Call ended', finalStatus);

      // Best-effort non-blocking DB update
      (async () => {
        try {
          const { error } = await oracleDB
            .from('calls')
            .update({ status: finalStatus, updated_at: new Date().toISOString() })
            .eq('id', currentCall.id);
          if (error) console.warn('Non-blocking DB call end update:', error);
        } catch (err) {
          console.warn('Network offline during call end update:', err);
        }
      })();
    } catch (err) {
      console.error('Error ending call:', err);
      onClose();
    }
  };

  // Handle Receiver Rejecting Call
  const handleRejectCall = async () => {
    if (isTerminatedRef.current) return;
    isTerminatedRef.current = true;
    setIsProcessingAction(true);

    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (peerConnectionRef.current) {
        try {
          peerConnectionRef.current.close();
        } catch {}
      }

      sendSignal('hangup', { status: 'rejected' });

      if (sendBroadcastEvent) {
        sendBroadcastEvent('call_status_update', {
          callId: currentCall.id,
          status: 'rejected',
        });
      }

      if (onUpdateCallStatus) {
        onUpdateCallStatus('rejected');
      }
      onClose('Call declined');

      // Best-effort non-blocking DB update
      (async () => {
        try {
          const { error } = await oracleDB
            .from('calls')
            .update({ status: 'rejected', updated_at: new Date().toISOString() })
            .eq('id', currentCall.id);
          if (error) console.warn('Non-blocking DB call reject update:', error);
        } catch (err) {
          console.warn('Network offline during call reject update:', err);
        }
      })();
    } catch (err) {
      console.error('Error rejecting call:', err);
      onClose();
    }
  };

  // Handle Receiver Accepting Call
  const handleAcceptCall = async () => {
    if (isTerminatedRef.current || isAcceptingRef.current || callStatus === 'accepted') return;
    isAcceptingRef.current = true; setIsProcessingAction(true);
    try {
      if (!streamRef.current) {
        try {
          streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true, video: currentCall.type === 'video' });
        } catch (mediaError: any) {
          const name = mediaError?.name;
          const message = name === 'NotAllowedError' ? 'Microphone/camera permission was denied.' : name === 'NotReadableError' ? 'The microphone or camera is busy.' : name === 'AbortError' ? 'Media startup was interrupted.' : 'Unable to start call media.';
          throw new Error(message);
        }
      }
      const { error } = await oracleDB.from('calls').update({ status: 'accepted' }).eq('id', currentCall.id);
      if (error) throw error;
      setCallStatus('accepted'); onUpdateCallStatus?.('accepted');
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : 'Could not accept connection');
      isAcceptingRef.current = false;
    } finally { setIsProcessingAction(false); }
  };

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((w) => w[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  const getAvatarStyle = (seedNum: number) => {
    const palette = [
      ['#20e3a2', '#0f8f66'],
      ['#7c5cff', '#4a2fd1'],
      ['#ff9f4a', '#c76a1a'],
      ['#4ac2ff', '#1e6fbf'],
      ['#ff5470', '#c22a48'],
      ['#ffd166', '#c99a1f'],
      ['#a78bfa', '#6d4fd4'],
      ['#34d399', '#0f9d6b'],
    ];
    const c = palette[seedNum % palette.length];
    return `linear-gradient(135deg, ${c[0]} 0%, ${c[1]} 100%)`;
  };

  const seed = peerProfile.username?.charCodeAt(0) || 0;

  if (isMinimized) {
    return (
      <div
        onClick={() => setIsMinimized(false)}
        className="absolute bottom-16 left-4 right-4 z-[100] bg-[#10151d]/95 backdrop-blur-md border border-[#212a38] rounded-2xl p-3 flex items-center justify-between shadow-2xl transition-all cursor-pointer hover:bg-[#161d28]/95 animate-fade-in-up"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative flex-shrink-0">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white"
              style={{ background: getAvatarStyle(seed) }}
            >
              {getInitials(currentCall.receiver_id === 'general' ? '#General' : (peerProfile.display_name || peerProfile.username || ''))}
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-[#20e3a2] rounded-full border-2 border-[#10151d] flex items-center justify-center animate-pulse" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[12.5px] font-bold text-white truncate max-w-[130px]">
              {currentCall.receiver_id === 'general' ? '#General Call' : (peerProfile.display_name || peerProfile.username)}
            </span>
            <span className="text-[10px] text-[#20e3a2] font-mono leading-none mt-0.5">
              {callStatus === 'ringing' ? (
                <span className="animate-pulse">Ringing...</span>
              ) : (
                currentCall.receiver_id === 'general'
                  ? `${formatDuration(duration)} • ${Object.keys(activeGroupParticipants).length + 1} Active`
                  : formatDuration(duration)
              )}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`w-8.5 h-8.5 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
              isMuted
                ? 'bg-white text-black border-white'
                : 'bg-[#161d28] text-[#8d97ab] border-[#212a38] hover:bg-[#1d2531]'
            }`}
            title={isMuted ? 'Unmute Mic' : 'Mute Mic'}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsMinimized(false)}
            className="w-8.5 h-8.5 rounded-full bg-[#161d28] text-[#8d97ab] border border-[#212a38] hover:bg-[#1d2531] flex items-center justify-center cursor-pointer"
            title="Maximize Call"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          <button
            onClick={handleEndCall}
            className="w-8.5 h-8.5 rounded-full bg-[#ff5470] hover:bg-[#ff5470]/90 text-white flex items-center justify-center shadow-md cursor-pointer transition-transform active:scale-90"
            title="End Connection"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // Render search and add friend dialog overlay (Requirements 3.3)
  const renderAddFriendModal = () => {
    const availableFriends = allProfiles.filter(
      (profile) =>
        profile.id !== currentUser.id &&
        !participants.some((p) => p.id === profile.id)
    );

    return (
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md z-50 flex flex-col justify-end animate-fade-in">
        <div className="absolute inset-0" onClick={() => setShowAddParticipant(false)} />

        <div className="relative bg-[#10151d] border-t border-[#212a38] rounded-t-3xl p-5 max-h-[80%] flex flex-col z-10 animate-slide-up">
          <div className="w-12 h-1.5 bg-[#212a38] rounded-full mx-auto mb-4" />

          <h3 className="text-sm font-bold text-white mb-1 font-display">Add Friend to Connection</h3>
          <p className="text-[10.5px] text-[#8d97ab] mb-4">Select an active user to patch into this call stream.</p>

          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[280px] pb-6 scrollbar-none">
            {availableFriends.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-xs text-[#5a6478]">No other active connections available</p>
              </div>
            ) : (
              availableFriends.map((friend) => {
                const seedNum = friend.username?.charCodeAt(0) || 0;
                return (
                  <button
                    key={friend.id}
                    onClick={() => {
                      if (participants.some((p) => p.id === friend.id)) return;
                      const updated = [...participants, friend];
                      setParticipants(updated);
                      setShowAddParticipant(false);

                      // Broadcast call invitation/join event to let all connected peers know
                      if (sendBroadcastEvent) {
                        sendBroadcastEvent('vyper_call_participant_added', {
                          callId: currentCall.id,
                          profile: friend
                        });
                      }
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-[#161d28]/50 hover:bg-[#161d28] border border-[#212a38]/40 transition-colors text-left"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-xs font-bold"
                           style={{ background: getAvatarStyle(seedNum) }}>
                        {friend.avatar_url ? (
                          <img loading="lazy" decoding="async" src={friend.avatar_url} alt="" className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          getInitials(friend.display_name || friend.username || '')
                        )}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">{friend.display_name || friend.username}</h4>
                        <p className="text-[10px] text-[#8d97ab] font-mono mt-0.5">@{friend.username}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-[#20e3a2] bg-[#20e3a2]/10 border border-[#20e3a2]/20 px-2.5 py-1 rounded-lg">Invite</span>
                  </button>
                );
              })
            )}
          </div>

          <button
            onClick={() => setShowAddParticipant(false)}
            className="w-full py-3 rounded-xl border border-[#212a38] text-xs text-white hover:bg-white/5 font-bold mt-2"
          >
            Cancel
          </button>
        </div>
      </div>
    );
  };

  const renderParticipantsGrid = () => {
    // Current user's video preview, plus other active participant profiles
    const groupParticipantsList = Object.values(activeGroupParticipants).map((p: any) => ({
      id: p.id,
      name: p.display_name || p.username,
      display_name: p.display_name,
      isLocal: false,
      avatar_url: p.avatar_url,
      username: p.username
    }));

    const allInCall = [
      { id: currentUser.id, name: 'You (Admin)', display_name: 'You', isLocal: true, avatar_url: currentUser.avatar_url, username: currentUser.username },
      ...(currentCall.receiver_id === 'general'
        ? groupParticipantsList
        : participants.map((p) => ({ id: p.id, name: p.display_name || p.username, display_name: p.display_name, isLocal: false, avatar_url: p.avatar_url, username: p.username })))
    ];

    const focusedId = focusedParticipantId || (participants[0]?.id);

    // If focused, render the focused participant as the main display
    const mainPeer = allInCall.find(p => p.id === focusedId) || allInCall[0];
    const thumbnails = allInCall.filter(p => p.id !== mainPeer.id);

    return (
      <div className="absolute inset-0 bg-[#080b10] flex flex-col justify-between overflow-hidden">
        {/* Main/Focused view */}
        <div className="absolute inset-0 z-0">
          {currentCall.type === 'video' && (mainPeer.isLocal ? isVideoOn : true) ? (
            <div className="relative w-full h-full">
              <video
                ref={mainPeer.isLocal ? registerLocalVideo : registerRemoteVideo}
                autoPlay
                playsInline
                muted={mainPeer.isLocal || currentCall.caller_id === currentCall.receiver_id}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-28 left-6 bg-black/60 px-3.5 py-1.5 rounded-xl border border-[#212a38]/80 backdrop-blur-md">
                <span className="text-[11px] font-bold text-[#20e3a2] flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#20e3a2] animate-pulse" />
                  {mainPeer.name} {mainPeer.isLocal && '(Local Camera)'}
                </span>
              </div>
            </div>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-[#0d121c]">
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-white text-3xl font-extrabold shadow-2xl mb-4"
                   style={{ background: getAvatarStyle(mainPeer.username?.charCodeAt(0) || 0) }}>
                {mainPeer.avatar_url ? (
                  <img loading="lazy" decoding="async" src={mainPeer.avatar_url} className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  getInitials(mainPeer.name || '')
                )}
              </div>
              <span className="text-sm font-bold text-gray-300">{mainPeer.name}</span>
              <span className="text-[11px] text-[#5a6478] font-mono mt-1">Audio stream established</span>
            </div>
          )}
        </div>

        {/* Floating/Picture-in-Picture Thumbnails (Requirement 3 & 4) */}
        <div className="absolute top-28 left-0 right-0 px-4 flex gap-3 overflow-x-auto z-20 pb-2 scrollbar-none">
          {thumbnails.map((peer) => {
            const isPeerVideoActive = currentCall.type === 'video' && (peer.isLocal ? isVideoOn : true);
            return (
              <button
                key={peer.id}
                onClick={() => setFocusedParticipantId(peer.id)}
                className="relative w-24 h-36 rounded-2xl bg-[#10151d] border border-[#212a38] overflow-hidden flex-shrink-0 shadow-2xl cursor-pointer hover:scale-105 active:scale-95 transition-all text-left"
              >
                {isPeerVideoActive ? (
                  <div className="w-full h-full relative">
                    <video
                      ref={peer.isLocal ? registerLocalVideo : registerRemoteVideo}
                      autoPlay
                      playsInline
                      muted={peer.isLocal || currentCall.caller_id === currentCall.receiver_id}
                      className="w-full h-full object-cover pointer-events-none opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                  </div>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-2 text-center bg-[#161d28]/95">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md mb-1.5"
                         style={{ background: getAvatarStyle(peer.username?.charCodeAt(0) || 0) }}>
                      {peer.avatar_url ? (
                        <img loading="lazy" decoding="async" src={peer.avatar_url} className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        getInitials(peer.name || '')
                      )}
                    </div>
                  </div>
                )}
                <div className="absolute bottom-1.5 left-2 right-2 truncate">
                  <span className="text-[9px] font-bold text-white bg-black/50 px-1.5 py-0.5 rounded-md backdrop-blur-sm">
                    {peer.name.split(' ')[0]}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  const triggerReaction = (emoji: string) => {
    if (sendBroadcastEvent) {
      sendBroadcastEvent('vyper_call_live_reaction', {
        callId: currentCall.id,
        emoji,
        senderId: currentUser.id,
        senderName: currentUser.display_name || currentUser.username
      });
    }

    // Trigger local reaction instantly
    const id = `react_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const newReact = {
      id,
      emoji,
      senderName: currentUser.display_name || currentUser.username || 'You',
      senderId: currentUser.id,
      x: Math.random() * 80 + 10,
    };
    setActiveReactions((prev) => [...prev, newReact]);
    resources.timeout(() => {
      setActiveReactions((prev) => prev.filter((r) => r.id !== id));
    }, 3000);
  };

  return (
    <div className="absolute inset-0 z-[100] flex flex-col justify-between bg-[#05070a] text-white p-6 overflow-hidden">
      <style>{`
        @keyframes slideUp {
          from {
            transform: translateY(100%);
          }
          to {
            transform: translateY(0);
          }
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        @keyframes bounceUp {
          0% {
            transform: translateY(0) scale(0.6);
            opacity: 0;
          }
          15% {
            opacity: 1;
            transform: translateY(-20px) scale(1.1);
          }
          100% {
            transform: translateY(-280px) scale(0.85);
            opacity: 0;
          }
        }
        .animate-slide-up {
          animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .animate-fade-in {
          animation: fadeIn 0.25s ease-out forwards;
        }
        .animate-bounce-up {
          animation: bounceUp 2.8s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }
      `}</style>

      {/* Minimize button */}
      <div className="absolute top-14 left-6 z-20">
        <button
          onClick={() => setIsMinimized(true)}
          className="w-10 h-10 rounded-full bg-[#10151d]/60 border border-[#212a38] flex items-center justify-center hover:bg-[#161d28]/80 transition-colors cursor-pointer"
          title="Minimize Call"
        >
          <Minimize2 className="w-5 h-5 text-[#8d97ab]" />
        </button>
      </div>

      {/* Background Video layout vs calling camera view */}
      {callStatus === 'accepted' ? (
        renderParticipantsGrid()
      ) : currentCall.type === 'video' && isVideoOn ? (
        <div className="absolute inset-0 z-0 bg-[#080b10]">
          <video
            ref={registerLocalVideo}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/30 to-black/80 pointer-events-none" />
        </div>
      ) : (
        <>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(124,92,255,0.18),transparent_60%)] pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_80%,rgba(32,227,162,0.1),transparent_55%)] pointer-events-none" />
        </>
      )}

      {/* Hidden elements to output and capture remote streams */}
      <audio ref={remoteAudioRef} autoPlay style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', pointerEvents: 'none' }} />

      {/* Active Recording Pill Floating at top */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="absolute top-14 left-1/2 -translate-x-1/2 z-40 bg-red-950/85 border border-red-500/50 backdrop-blur-xl px-4 py-1.5 rounded-full shadow-2xl flex items-center gap-3"
          >
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <span className="text-xs font-mono font-bold text-red-300">
                REC {formatDuration(recordingDuration)}
              </span>
            </div>
            <span className="text-[10px] uppercase font-bold text-red-200/80 bg-red-900/60 px-2 py-0.5 rounded-full border border-red-500/30">
              {recordingType === 'screen' ? 'Screen + Voice' : 'Voice Only'}
            </span>
            <button
              onClick={stopRecording}
              className="text-xs font-bold text-white bg-red-600 hover:bg-red-500 px-2.5 py-0.5 rounded-full cursor-pointer transition-colors shadow-sm"
            >
              Stop
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Instant Recording Download Toast Modal */}
      <AnimatePresence>
        {savedRecordingInfo && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#121824] border border-[#20e3a2]/40 rounded-2xl p-5 max-w-sm w-full shadow-2xl text-center space-y-4"
            >
              <div className="w-12 h-12 rounded-full bg-[#20e3a2]/20 border border-[#20e3a2]/40 flex items-center justify-center mx-auto text-[#20e3a2]">
                <Disc className="w-6 h-6 animate-spin" style={{ animationDuration: '4s' }} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Call Recording Saved</h3>
                <p className="text-xs text-[#8d97ab] mt-1">
                  Saved to your private vault & device storage. You can also download the file directly now.
                </p>
              </div>
              <div className="flex items-center justify-center gap-3 pt-2">
                <a
                  href={savedRecordingInfo.url}
                  download={savedRecordingInfo.fileName}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-[#20e3a2] hover:bg-[#1bc88f] text-black text-xs font-bold py-2.5 px-4 rounded-xl cursor-pointer shadow-lg active:scale-95 transition-all"
                >
                  <Download className="w-4 h-4" />
                  Download File
                </a>
                <button
                  onClick={() => setSavedRecordingInfo(null)}
                  className="bg-[#1e2736] hover:bg-[#283548] text-[#8d97ab] hover:text-white text-xs font-semibold py-2.5 px-4 rounded-xl cursor-pointer transition-colors"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Reactions Layer (Requirement 3.2) */}
      <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden">
        {activeReactions.map((react) => (
          <div
            key={react.id}
            className="absolute bottom-32 flex flex-col items-center animate-bounce-up pointer-events-none"
            style={{ left: `${react.x}%` }}
          >
            <span className="text-3xl filter drop-shadow-lg">{react.emoji}</span>
            <span className="text-[8px] bg-black/60 px-1.5 py-0.5 rounded-full text-[#8d97ab] mt-1 whitespace-nowrap border border-[#212a38]/40">
              {react.senderName ? react.senderName.split(' ')[0] : 'Operator'}
            </span>
          </div>
        ))}
      </div>

      {/* Header Profile Details (Only when calling/ringing, hidden once video grid fills) */}
      {callStatus !== 'accepted' && (
        <div className="relative z-10 flex flex-col items-center text-center mt-12">
          {/* Call Security Badge */}
          <span className="bg-[#10151d]/80 border border-[#212a38] text-[10px] font-bold tracking-widest text-[#20e3a2] uppercase px-4 py-1.5 rounded-full mb-6 backdrop-blur-md flex items-center gap-1.5 shadow-md">
            <span className="w-1.5 h-1.5 rounded-full bg-[#20e3a2] animate-pulse" />
            {currentCall.type === 'video' ? 'VIDEO CALL' : 'VOICE CALL'}
          </span>

          <div className="relative w-28 h-28 mb-5">
            {callStatus === 'ringing' && (
              <div className="absolute inset-[-12px] rounded-full bg-[#20e3a2]/20 animate-ping duration-1000" />
            )}
            <div
              className="absolute inset-0 rounded-full flex items-center justify-center text-white text-3xl font-extrabold shadow-2xl border-2 border-white/10"
              style={{ background: getAvatarStyle(seed) }}
            >
              {getInitials(peerProfile.display_name || peerProfile.username || '')}
            </div>
          </div>

          <h2 className="text-xl font-display font-black tracking-wide text-white leading-tight drop-shadow-md">
            {peerProfile.display_name || peerProfile.username}
          </h2>
          <p className="text-[11.5px] text-[#8d97ab] mt-1 font-mono drop-shadow-md">
            @{peerProfile.username}
          </p>

          {/* Live Call state indicator */}
          <div className="text-sm font-bold mt-4 drop-shadow-md">
            {callStatus === 'ringing' ? (
              isCaller ? (
                !isUserOnline(peerProfile) ? (
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-amber-400 animate-pulse flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      Recipient is offline • Calling...
                    </span>
                    <span className="text-[11px] font-normal text-white/50">
                      Missed call will be registered in chat & call log
                    </span>
                  </div>
                ) : (
                  <span className="text-[#20e3a2] animate-pulse">Ringing portal...</span>
                )
              ) : (
                <span className="text-[#7c5cff] animate-pulse">Incoming request...</span>
              )
            ) : (
              <span className="text-[#ff5470] animate-pulse">Connecting...</span>
            )}
          </div>
        </div>
      )}

      {/* Notice error log box */}
      {errorMessage && (
        <div className="relative z-10 self-center max-w-xs text-center text-xs text-[#ff5470] font-semibold bg-[#ff5470]/10 border border-[#ff5470]/20 rounded-xl p-3">
          {errorMessage}
        </div>
      )}

      {/* Encryption & 3G Ultra-Low Latency banner */}
      <div className="relative z-10 flex flex-wrap items-center justify-center gap-2 self-center bg-black/45 border border-[#212a38]/80 rounded-xl px-4 py-2 text-[10.5px] text-[#8d97ab] shadow-sm backdrop-blur-md">
        <div className="flex items-center gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-[#20e3a2]" />
          <span>Direct connection established</span>
        </div>

        {callStatus === 'accepted' && (
          <>
            <span className="text-gray-600">•</span>
            <span className={`flex items-center gap-1 font-mono font-bold ${
              is3GMode ? 'text-amber-400' : 'text-[#20e3a2]'
            }`}>
              <Zap className="w-3 h-3 fill-current" />
              {networkLatency === null
                ? 'Connection quality (measuring…)'
                : is3GMode
                  ? `3G Adaptive (${networkLatency}ms)`
                  : `Connection quality (${networkLatency}ms)`}
            </span>
          </>
        )}
      </div>

      {/* Button Controls Area */}
      <div className="relative z-10 flex flex-col gap-6 items-center mb-10">
        {/* Dynamic call timer for accepted state overlay */}
        {callStatus === 'accepted' && (
          <span className="text-xs text-[#8d97ab] font-mono tracking-wider bg-black/50 border border-[#212a38]/60 px-4 py-1.5 rounded-full backdrop-blur-md">
            Duration: {formatDuration(duration)} • {
              currentCall.receiver_id === 'general'
                ? `${Object.keys(activeGroupParticipants).length + 1} Active Participants`
                : `${participants.length + 1} Callers`
            }
          </span>
        )}

        <div className="flex items-center gap-3 sm:gap-4 flex-wrap justify-center">
          {callStatus === 'ringing' && !isCaller ? (
            /* Incoming state triggers Accept / Decline options */
            <>
              <button
                onClick={handleRejectCall}
                disabled={isProcessingAction}
                className="w-14 h-14 rounded-full bg-[#ff5470] hover:bg-[#ff5470]/90 disabled:opacity-50 disabled:cursor-not-allowed text-white flex items-center justify-center shadow-lg cursor-pointer active:scale-95 transition-transform"
                title="Decline Call"
              >
                <PhoneOff className="w-5.5 h-5.5" />
              </button>
              <button
                onClick={handleAcceptCall}
                disabled={isProcessingAction}
                className="w-14 h-14 rounded-full bg-[#20e3a2] hover:bg-[#20e3a2]/90 disabled:opacity-50 disabled:cursor-not-allowed text-black flex items-center justify-center shadow-lg cursor-pointer active:scale-95 transition-transform"
                title="Accept Call"
              >
                <Phone className="w-5.5 h-5.5 fill-current" />
              </button>
            </>
          ) : (
            /* Active call or ringing state controls */
            <>
              {/* Mic mute trigger */}
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                  isMuted
                    ? 'bg-white text-black border-white'
                    : 'bg-[#10151d]/75 text-white border-[#212a38] hover:bg-[#161d28]'
                }`}
                title={isMuted ? 'Unmute Mic' : 'Mute Mic'}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              {/* Add Friends Button */}
              {callStatus === 'accepted' && (
                <button
                  onClick={() => setShowAddParticipant(true)}
                  className="w-12 h-12 rounded-full bg-[#10151d]/75 text-[#eef1f6] border border-[#212a38] hover:bg-[#161d28] flex items-center justify-center cursor-pointer transition-all"
                  title="Invite Peer to Call"
                >
                  <UserPlus className="w-5 h-5" />
                </button>
              )}

              {/* Live reactions picker trigger */}
              {callStatus === 'accepted' && (
                <div className="relative">
                  <button
                    onClick={() => setShowReactions(!showReactions)}
                    className={`w-12 h-12 rounded-full border flex items-center justify-center cursor-pointer transition-all ${
                      showReactions
                        ? 'bg-[#7c5cff] text-white border-[#7c5cff]'
                        : 'bg-[#10151d]/75 text-[#eef1f6] border-[#212a38] hover:bg-[#161d28]'
                    }`}
                    title="Send Reaction"
                  >
                    <Smile className="w-5 h-5" />
                  </button>
                  {/* Floating tooltip/picker on toggle */}
                  {showReactions && (
                    <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-[#161d28]/95 border border-[#212a38] p-2 rounded-2xl flex items-center gap-2 shadow-2xl transition-all duration-200 z-50 animate-fade-in whitespace-nowrap min-w-[200px] backdrop-blur-md">
                      <div className="flex items-center gap-1.5 overflow-x-auto max-w-[240px] scrollbar-none">
                        {listedReactions.map((emoji) => (
                          <motion.button
                            key={emoji}
                            whileHover={{ scale: 1.25, rotate: 6 }}
                            whileTap={{ scale: 1.45, rotate: -12 }}
                            transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                            onClick={() => {
                              if (isEditingReactions) {
                                setListedReactions((prev) => {
                                  const next = prev.filter((e) => e !== emoji);
                                  try {
                                    localStorage.setItem('vyper_unified_reaction_emojis_v2', JSON.stringify(next));
                                    window.dispatchEvent(new CustomEvent('vyper_unified_emojis_updated', { detail: next }));
                                  } catch (e) {}
                                  return next;
                                });
                              } else {
                                triggerReaction(emoji);
                              }
                            }}
                            className={`text-xl transition-transform cursor-pointer shrink-0 ${
                              isEditingReactions
                                ? 'hover:scale-95 border border-red-500/40 p-0.5 rounded-lg bg-red-500/10'
                                : ''
                            }`}
                            title={isEditingReactions ? "Click to remove" : "Send Reaction"}
                          >
                            <motion.span
                              whileTap={{ scale: 1.6, rotate: [0, -15, 15, 0] }}
                              transition={{ duration: 0.2 }}
                              className="inline-block"
                            >
                              {emoji}
                            </motion.span>
                          </motion.button>
                        ))}
                      </div>

                      <div className="w-[1px] h-4 bg-[#212a38] shrink-0" />

                      {/* Add Button */}
                      <motion.button
                        whileHover={{ scale: 1.2 }}
                        whileTap={{ scale: 0.85 }}
                        onClick={() => setShowCallEmojiPicker(true)}
                        className="text-xs text-[#20e3a2] font-black cursor-pointer shrink-0 p-1"
                        title="Add custom reaction"
                      >
                        ＋
                      </motion.button>

                      {/* Interactive Call Emoji Picker Popover Modal */}
                      <AnimatePresence>
                        {showCallEmojiPicker && (
                          <div
                            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in whitespace-normal"
                            onClick={(e) => {
                              e.stopPropagation();
                              setShowCallEmojiPicker(false);
                            }}
                          >
                            <motion.div
                              initial={{ scale: 0.85, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0.85, opacity: 0 }}
                              transition={{ type: 'spring', damping: 20, stiffness: 300 }}
                              className="bg-[#161d28] border border-[#212a38] rounded-2xl p-4 w-full max-w-sm shadow-2xl space-y-3"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <div className="flex items-center justify-between border-b border-[#212a38] pb-2">
                                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Choose Reaction Emoji</h3>
                                <button
                                  type="button"
                                  onClick={() => setShowCallEmojiPicker(false)}
                                  className="text-gray-400 hover:text-white text-xs font-bold p-1 cursor-pointer"
                                >
                                  ✕
                                </button>
                              </div>

                              <form
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  if (callCustomEmojiInput.trim()) {
                                    handleAddNewCallReaction(callCustomEmojiInput.trim());
                                    setCallCustomEmojiInput('');
                                    setShowCallEmojiPicker(false);
                                  }
                                }}
                                className="flex items-center gap-2"
                              >
                                <input
                                  type="text"
                                  placeholder="Type or paste emoji..."
                                  value={callCustomEmojiInput}
                                  onChange={(e) => setCallCustomEmojiInput(e.target.value)}
                                  className="flex-1 bg-[#0f141c] border border-[#212a38] rounded-xl px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[#7c5cff]"
                                  autoFocus
                                />
                                <button
                                  type="submit"
                                  className="bg-[#20e3a2] text-black font-bold text-xs px-3 py-1.5 rounded-xl hover:bg-[#1bc88f] transition-all cursor-pointer"
                                >
                                  Add
                                </button>
                              </form>

                              <div className="grid grid-cols-6 gap-2 max-h-48 overflow-y-auto scrollbar-none p-1">
                                {CALL_PRESET_EMOJIS.map((emoji, idx) => (
                                  <motion.button
                                    key={`${emoji}-${idx}`}
                                    whileHover={{ scale: 1.3, rotate: 6 }}
                                    whileTap={{ scale: 1.5, rotate: -12 }}
                                    transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                                    onClick={() => {
                                      handleAddNewCallReaction(emoji);
                                      setShowCallEmojiPicker(false);
                                    }}
                                    className="text-2xl p-2 rounded-xl hover:bg-white/10 flex items-center justify-center cursor-pointer transition-colors"
                                  >
                                    {emoji}
                                  </motion.button>
                                ))}
                              </div>
                            </motion.div>
                          </div>
                        )}
                      </AnimatePresence>

                      {/* Edit Toggle Button */}
                      <button
                        onClick={() => setIsEditingReactions(!isEditingReactions)}
                        className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-lg cursor-pointer shrink-0 transition-colors ${
                          isEditingReactions
                            ? 'bg-[#ff5470] text-white'
                            : 'bg-[#212a38] text-[#8d97ab] hover:text-white'
                        }`}
                        title="Toggle edit mode to remove reactions"
                      >
                        {isEditingReactions ? 'Done' : 'Edit'}
                      </button>

                      <div className="w-[1px] h-4 bg-[#212a38] shrink-0" />

                      <button
                        onClick={() => setShowReactions(false)}
                        className="text-[#64748b] hover:text-white transition-colors text-sm px-1 cursor-pointer font-bold shrink-0"
                        title="Collapse"
                      >
                        ✕
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Call Recording Controls (Screen / Voice) */}
              {callStatus === 'accepted' && (
                currentCall.type === 'video' ? (
                  /* Video call: screen or voice recording chooser */
                  <div className="relative">
                    <button
                      onClick={() => {
                        if (isRecording) {
                          stopRecording();
                        } else {
                          setShowRecordOptions(!showRecordOptions);
                        }
                      }}
                      className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                        isRecording
                          ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/40 animate-pulse'
                          : showRecordOptions
                          ? 'bg-[#20e3a2] text-black border-[#20e3a2]'
                          : 'bg-[#10151d]/75 text-[#eef1f6] border-[#212a38] hover:bg-[#161d28]'
                      }`}
                      title={isRecording ? 'Stop Recording' : 'Record Call'}
                    >
                      {isRecording ? <Square className="w-5 h-5 fill-current" /> : <Disc className="w-5 h-5" />}
                    </button>

                    {/* Popover choice sheet */}
                    <AnimatePresence>
                      {showRecordOptions && !isRecording && (
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-[#161d28]/95 border border-[#212a38] p-2 rounded-2xl flex flex-col gap-1.5 shadow-2xl backdrop-blur-xl z-50 w-52"
                        >
                          <div className="px-2 py-1 border-b border-[#212a38]/80 text-[10px] font-bold uppercase tracking-wider text-[#8d97ab]">
                            Choose Recording
                          </div>
                          <button
                            onClick={() => startRecording('screen')}
                            className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-white hover:bg-white/10 text-left transition-colors cursor-pointer"
                          >
                            <Tv className="w-4 h-4 text-[#20e3a2]" />
                            <span>Screen & Video Record</span>
                          </button>
                          <button
                            onClick={() => startRecording('voice')}
                            className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-white hover:bg-white/10 text-left transition-colors cursor-pointer"
                          >
                            <Radio className="w-4 h-4 text-[#7c5cff]" />
                            <span>Voice Only Record</span>
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  /* Voice call: dedicated voice recording button */
                  <button
                    onClick={() => {
                      if (isRecording) {
                        stopRecording();
                      } else {
                        startRecording('voice');
                      }
                    }}
                    className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                      isRecording
                        ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/40 animate-pulse'
                        : 'bg-[#10151d]/75 text-[#eef1f6] border-[#212a38] hover:bg-[#161d28]'
                    }`}
                    title={isRecording ? 'Stop Voice Recording' : 'Record Voice Call'}
                  >
                    {isRecording ? <Square className="w-5 h-5 fill-current" /> : <Disc className="w-5 h-5" />}
                  </button>
                )
              )}

              {/* Camera toggler inside active video call */}
              {currentCall.type === 'video' && callStatus === 'accepted' && (
                <>
                  <button
                    onClick={() => setIsVideoOn(!isVideoOn)}
                    className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                      isVideoOn
                        ? 'bg-[#10151d]/75 text-white border-[#212a38] hover:bg-[#161d28]'
                        : 'bg-white text-black border-white'
                    }`}
                    title={isVideoOn ? 'Disable Video' : 'Enable Video'}
                  >
                    {isVideoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                  </button>

                  {isVideoOn && (
                    <button
                      onClick={handleSwitchCamera}
                      className="w-12 h-12 rounded-full bg-[#10151d]/75 border border-[#212a38] text-[#8d97ab] hover:text-[#20e3a2] flex items-center justify-center hover:bg-[#161d28] active:scale-90 cursor-pointer transition-all"
                      title="Switch Camera Device"
                    >
                      <RefreshCw className="w-5 h-5" />
                    </button>
                  )}
                </>
              )}

              {/* End/Cancel call trigger */}
              <button
                onClick={handleEndCall}
                className="w-12 h-12 rounded-full bg-[#ff5470] hover:bg-[#ff5470]/90 text-white flex items-center justify-center shadow-lg cursor-pointer active:scale-95 transition-transform"
                title="End connection"
              >
                <PhoneOff className="w-5 h-5" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Render Add Friend Overlay Panel */}
      {showAddParticipant && renderAddFriendModal()}
    </div>
  );
}
