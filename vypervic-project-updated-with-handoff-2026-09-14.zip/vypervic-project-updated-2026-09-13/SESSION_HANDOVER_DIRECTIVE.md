# SESSION HANDOVER DIRECTIVE — VyperVic (Arena ChatApp)

> **Critical directive for the AI agent in this session:**
> 1. **DO NOT BUILD A NEW APP OR GENERATE A NEW USER INTERFACE.**
> 2. Preserve the existing code tree exactly as extracted: keep
>    `ChatScreen.tsx`, `ChatListScreen.tsx`, `CallOverlay.tsx`,
>    `SettingsScreen.tsx`, `AdminDashboard.tsx`, `FullscreenProfile.tsx`,
>    `SearchScreen.tsx`, `CallsScreen.tsx`, the native Kotlin shell in
>    `/android`, and the VPS-authority server architecture.
> 3. Never revert to client-side direct database calls. The client talks to
>    the VPS over HTTPS + HttpOnly cookie (`vyper_session`) only.

## 1. Security architecture (binding)

- The **VPS is the sole policy authority**: HTTPS + HttpOnly `vyper_session`
  cookie, identity derived strictly from verified JWT claims (`req.user.sub`),
  never from client payloads.
- **Oracle ADB `VYPERVIC1`** is the authoritative durable system of record
  (profiles, messages, calls, groups, push registrations, schedules, jobs).
- **Firebase project `vypervic-chatapp`**, database **`(default)`**, is the
  low-latency edge only: presence, WebRTC signaling, FCM push. Admin SDK
  credentials live in `src/server/firebaseAdmin.ts` + VPS env, never in the
  client/APK/bundle.
- Phone numbers are strictly unique (`UQ_PROFILES_PHONE`).
- Admin role is re-checked with a fresh Oracle lookup on privileged routes;
  a role snapshot inside a 30-day JWT is never trusted for authorization.
- `VYPERVIC_MASTER_SPECIFICATION.md` is the full contract; this file is the
  session state + runbook pointer.

## 2. Canonical configuration (names only — values live in the VPS runtime env)

```text
APP_URL                         canonical https origin, no path
JWT_SECRET                      >= 32 chars (openssl rand -hex 48)
ORDS_BASE_URL                   https://<adb-host>/ords/admin
ORDS_OAUTH_CLIENT_ID / _SECRET  from deploy/vypervic_wipe_and_reset.sql PART 6 (exactly one ORDS auth mode)
REDIS_URL                       private authenticated Redis
FIREBASE_PROJECT_ID             vypervic-chatapp
FIREBASE_CLIENT_EMAIL           firebase-adminsdk-fbsvc@vypervic-chatapp.iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY            quoted, \n-escaped, VPS only
FIRESTORE_DATABASE_ID           (default)
VITE_FIREBASE_*                 public web config, same project/database (see docs/VPS-SETUP.md step 7)
TURN_URLS                       udp + tcp + tls endpoints
TURN_SHARED_SECRET              >= 32 chars, VPS only
RESEND_API_KEY / MAIL_FROM      account recovery mail
```

Draft-name translation: `ORACLE_ORDS_BASE_URL`->`ORDS_BASE_URL`,
`ORACLE_CLIENT_*`->`ORDS_OAUTH_*`, `APP_ORIGIN`->`APP_URL`,
`TURN_SERVER_URL`->`TURN_URLS`. `COOKIE_DOMAIN` is unused (host-only cookie);
`VITE_ORACLE_ORDS_URL` is forbidden.

## 3. Verified session state (2026-09-09)

- [x] Existing screens + `/android` shell + server proxy preserved (zero-variance).
- [x] Firebase Admin key for `vypervic-chatapp`: valid RSA, service-account
      email matches the canonical project, fingerprint
      `b6b3ce95…4248b9` is NOT on the compromised-key list. Validated
      ephemerally; the key material was never written to the repo.
- [x] Admin seed verified: `vypervic1@gmail.com` / `VyperVic2008.` (dot
      included). PBKDF2-HMAC-SHA256/100k recomputation matches; seed uses a
      hex salt because the server fails closed on non-hex salts.
- [x] Fresh wipe SQL: `deploy/vypervic_wipe_and_reset.sql` (schema =
      migrations 000+001, ORDS auth ON, OAuth client, admin seed).
- [x] Migration 003 live-DB fix (2026-09-09): `USER_TAB_COLUMNS` has no
      `VIRTUAL_COLUMN` column, so the fence package read `USER_TAB_COLS`
      (+ `hidden_column='NO'`) instead. Recompile snippet was run in the
      worksheet; package VALID, 12/12 triggers ENABLED.
- [x] ORDS OAuth live-DB fix (2026-09-09): `OAUTH.grant_client_role` takes
      ROLE names (`oracle.dbtools.role.autorest.*` from `USER_ORDS_ROLES`),
      not privilege names (ORA-01403). Wipe PART 5 + 003 now grant the 18
      scoped roles (+ `vyper_backend`) loudly; `.any.` roles excluded.
- [x] `npm run typecheck` + `npm run build` + test suite: see §5.

## 4. Seeded admin (for verification only — rotate after first login if exposed)

- Email: `vypervic1@gmail.com`
- Password: `VyperVic2008.` (trailing dot included)
- Login must set an HttpOnly `vyper_session` cookie; the JWT must never
  appear in `localStorage`.

## 5. Compile / verify commands (the `compile_applet` equivalent)

```sh
npm ci
npm run typecheck
npm run build
npm run check:bundle
npm test
DOTENV_CONFIG_PATH=/secure/runtime.env npm run check:config   # on the VPS
```

A clean session ends with all five passing and no new UI generated.
