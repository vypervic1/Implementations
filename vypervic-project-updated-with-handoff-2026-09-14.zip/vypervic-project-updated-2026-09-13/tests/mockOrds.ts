// =========================================================================
// MOCK ORACLE ORDS SERVER (test infrastructure)
// ------------------------------------------------------------------------
// Implements the small AutoREST surface the app uses, in-memory:
//   GET    /<table>/?q=<json>&limit=N     collection query ($eq fields,
//                                         $or / $and nodes supported)
//   GET    /<table>/<id>                  single row (404 when missing)
//   POST   /<table>/                      insert (400 + ORA-00001 text on
//                                         PK/unique conflicts)
//   PUT    /<table>/<id>                  replace (404 when missing)
//   PATCH  /<table>/<id>                  merge (404 when missing)
//   DELETE /<table>/<id>                  delete (404 when missing)
// When an ORDS_API_KEY is configured, requests WITHOUT the matching Bearer
// token are rejected (mirrors the authenticated ORDS deployment, C-02).
// =========================================================================

import http from 'http';
import crypto from 'crypto';

export interface MockRow {
  [key: string]: any;
}

const TABLES = new Set([
  'profiles',
  'messages',
  'calls',
  'groups',
  'vault',
  'audit_logs',
  'user_push_tokens',
  'user_credentials',
  'password_resets',
  'scheduled_messages',
  'deletion_jobs',
  'delivery_outbox',
]);

// Deterministic row-id helpers mirroring the server's implementation.
export function credentialRowId(userId: string): string {
  return `cred_${crypto.createHash('sha256').update(String(userId)).digest('hex').slice(0, 40)}`;
}
export function resetTokenRowId(token: string): string {
  return `pwdres_${crypto.createHash('sha256').update(String(token)).digest('hex').slice(0, 40)}`;
}

const deletionReceipts = new Map<string, {job:string; table:string; affected:number}>();
let gate = { owner: null as string | null, epoch: 0 };
let pageCap = Infinity;
export function setPageCap(limit: number) { pageCap = limit; }
const activeDml = new Set<Promise<void>>();
const pauses = new Map<string, { entered: () => void; resume: Promise<void>; finished: () => void; done: Promise<void> }>();
export function pauseNextDml(table: string) {
  let entered!: () => void, resume!: () => void, finished!: () => void;
  const started = new Promise<void>(resolve => { entered = resolve; });
  const wait = new Promise<void>(resolve => { resume = resolve; });
  const done = new Promise<void>(resolve => { finished = resolve; });
  pauses.set(table, { entered, resume: wait, finished, done });
  return { started, release: resume };
}
const lostDeletionAcks = new Set<string>();
export function loseNextDeletionAck(id: string) { lostDeletionAcks.add(id); }
const data = new Map<string, Map<string, MockRow>>();
for (const t of TABLES) data.set(t, new Map());

export function seedRow(table: string, row: MockRow): void {
  let m = data.get(table);
  if (!m) {
    m = new Map();
    data.set(table, m);
  }
  m.set(String(row.ID ?? row.id), row);
}

export function getRow(table: string, id: string): MockRow | null {
  return data.get(table)?.get(String(id)) || null;
}

export function allRows(table: string): MockRow[] {
  return Array.from(data.get(table)?.values() || []);
}

export function clearTable(table: string): void {
  data.get(table)?.clear();
}

export function resetAllTables(): void {
  for (const m of data.values()) m.clear();
  disableOrdsOAuth();
  lostDeletionAcks.clear(); pauses.clear(); activeDml.clear(); deletionReceipts.clear(); injectedFailures.length = 0; pageCap = Infinity; gate = { owner: null, epoch: 0 };
}

// ---------------------------------------------------------------- q-filter evaluation
function matchesBranch(row: MockRow, branch: any): boolean {
  if (!branch || typeof branch !== 'object') return false;
  for (const [key, value] of Object.entries(branch)) {
    const lower = key.toLowerCase();
    if (lower === '$orderby') continue;
    if (lower === '$or') {
      const branches = value as any[];
      if (!Array.isArray(branches) || !branches.some((b) => matchesBranch(row, b))) return false;
      continue;
    }
    if (lower === '$and') {
      const branches = value as any[];
      if (!Array.isArray(branches) || !branches.every((b) => matchesBranch(row, b))) return false;
      continue;
    }
    const cell = row[lower] ?? row[key] ?? row[key.toUpperCase()];
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      for (const [op, operand] of Object.entries(value)) {
        if (op === '$in' && (!Array.isArray(operand) || !operand.some(v => String(v) === String(cell)))) return false;
        if (op === '$eq' && String(cell) !== String(operand)) return false;
        if (op === '$gt' && !(cell > operand!)) return false;
        if (op === '$gte' && !(cell >= operand!)) return false;
        if (op === '$lt' && !(cell < operand!)) return false;
        if (op === '$lte' && !(cell <= operand!)) return false;
      }
    } else if (value === null ? cell != null : String(cell ?? '') !== String(value)) return false;
  }
  return true;
}

function uniqueConstraintViolation(table: string, row: MockRow): string | null {
  if (table === 'profiles') {
    const existing = allRows('profiles');
    for (const other of existing) {
      if (String(other.ID) === String(row.ID)) continue;
      if (row.EMAIL && String(other.EMAIL).toLowerCase() === String(row.EMAIL).toLowerCase()) {
        return 'ORA-00001: unique constraint (ADMIN.UQ_PROFILES_EMAIL) violated';
      }
      if (row.USERNAME && String(other.USERNAME).toLowerCase() === String(row.USERNAME).toLowerCase()) {
        return 'ORA-00001: unique constraint (ADMIN.UQ_PROFILES_USERNAME) violated';
      }
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Optional OAuth2 client-credentials enforcement (mirrors the deployment
// SQL's ORDS setup: short-lived bearer tokens issued by POST /oauth/token).
// Tests enable it to verify the server's OAuth fetch/refresh/retry flow.
// ---------------------------------------------------------------------------
let oauthCreds: { clientId: string; clientSecret: string } | null = null;
const oauthTokens = new Map<string, number>(); // token -> expiresAtMs
let oauthIssuances = 0;

export function enableOrdsOAuth(clientId: string, clientSecret: string): void {
  oauthCreds = { clientId, clientSecret };
  oauthTokens.clear();
  oauthIssuances = 0;
}
export function disableOrdsOAuth(): void {
  oauthCreds = null;
  oauthTokens.clear();
  oauthIssuances = 0;
}
export function expireAllOrdsOAuthTokens(): void {
  for (const t of oauthTokens.keys()) oauthTokens.set(t, Date.now() - 1);
}
export function oauthIssuanceCount(): number {
  return oauthIssuances;
}

const injectedFailures: Array<{ method: string; path: RegExp; status: number; count: number; skip?: number; body?: unknown }> = [];
export function failRequests(method: string, path: RegExp, count = 1, status = 503, body?: unknown) {
  injectedFailures.push({ method, path, count, status, body });
}
export function failNthRequest(method: string, path: RegExp, nth: number, status = 503) {
  injectedFailures.push({ method, path, count: 1, skip: nth - 1, status });
}
export function startMockOrds(opts: { apiKey?: string } = {}): Promise<string> {
  const server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', async () => {
      const bodyText = Buffer.concat(chunks).toString('utf8');
      let body: any = null;
      try {
        body = bodyText ? JSON.parse(bodyText) : null;
      } catch (e) {
        body = null;
      }

      const url = new URL(req.url || '/', 'http://localhost');
      const json = (status: number, payload: any) => {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(payload));
      };

      const failure = injectedFailures.find(f => f.count > 0 && f.method === req.method && (f.path.test(url.pathname) || f.path.test(url.pathname.replace(/_meta(?=\/)/g, ''))));
      if (failure && !failure.skip) { failure.count--; return json(failure.status, failure.body || { error: 'Simulated upstream failure' }); }
      if (failure?.skip) failure.skip--;

      // OAuth2 token endpoint (client_credentials) — mirrors ORDS behavior,
      // including expires_in being returned as a STRING.
      if (url.pathname.endsWith('/oauth/token')) {
        if (!oauthCreds) return json(404, { code: 'NotFound', message: 'OAuth not enabled on mock' });
        const auth = req.headers.authorization || '';
        const expected = `Basic ${Buffer.from(`${oauthCreds.clientId}:${oauthCreds.clientSecret}`).toString('base64')}`;
        if (auth !== expected) return json(401, { error: 'invalid_client' });
        let grant = '';
        try {
          grant = new URLSearchParams(bodyText).get('grant_type') || '';
        } catch {
          grant = '';
        }
        if (grant !== 'client_credentials') return json(400, { error: 'unsupported_grant_type' });
        const token = `mock-oauth-token-${++oauthIssuances}-${Date.now()}`;
        oauthTokens.set(token, Date.now() + 900_000);
        return json(200, { access_token: token, token_type: 'bearer', expires_in: '900' });
      }

      // C-02 mirror: authenticated ORDS rejects anonymous requests. When the
      // OAuth client is configured on the mock, ONLY freshly issued OAuth
      // bearer tokens are accepted (the static apiKey path is for the
      // non-OAuth suites).
      {
        const auth = req.headers.authorization || '';
        if (oauthCreds) {
          const bearer = auth.startsWith('Bearer ') ? auth.slice('Bearer '.length) : '';
          const expiresAt = oauthTokens.get(bearer);
          if (!bearer || expiresAt === undefined || expiresAt <= Date.now()) {
            return json(401, { code: 'Unauthorized', message: 'ORS authentication required' });
          }
        } else if (opts.apiKey) {
          if (auth !== `Bearer ${opts.apiKey}`) {
            return json(401, { code: 'Unauthorized', message: 'ORS authentication required' });
          }
        }
      }

      let gateway = false;
      if (url.pathname === '/vyper-internal/write') {
        if (body.epoch !== gate.epoch || gate.owner) return json(503,{error:'ORA-20906: stale epoch'});
        gateway = true;
        req.method = body.method;
        url.pathname = `/${body.table_name}/${encodeURIComponent(body.record_id || '')}`;
        body = body.data;
        const failure = injectedFailures.find(f => f.count > 0 && f.method === req.method && f.path.test(url.pathname));
        if (failure && !failure.skip) { failure.count--; return json(failure.status, failure.body || {error:'Gateway write failed'}); }
        if (failure?.skip) failure.skip--;
      }
      if (url.pathname.startsWith('/vyper-internal/')) {
        if (url.pathname === '/vyper-internal/gate/') return json(200, { ...gate, schemaVersion: 3, guardCount: 10, outboxTriggers: 2 });
        if (url.pathname === '/vyper-internal/gate/begin') {
          await Promise.all([...activeDml]);
          if (!getRow('deletion_jobs', body.job_id) || gate.owner && gate.owner !== body.job_id) return json(409, { error: 'Fence unavailable' });
          if (!gate.owner) { gate.owner = body.job_id; gate.epoch++; }
          return json(200, gate);
        }
        if (url.pathname === '/vyper-internal/gate/end') {
          if (gate.owner && gate.owner !== body.job_id) return json(403, {});
          gate.owner = null; return json(200, gate);
        }
        if (url.pathname.startsWith('/vyper-internal/maintenance/counts/')) {
          const id = url.pathname.split('/').at(-1); const counts: Record<string, number> = {};
          for (const r of deletionReceipts.values()) if (r.job===id) counts[r.table]=(counts[r.table] || 0)+r.affected;
          return json(200, counts);
        }
        if (url.pathname === '/vyper-internal/maintenance/dml') {
          if (!gate.owner || gate.owner !== body.job_id) return json(403, {});
          const target = data.get(body.table_name), id = body.record_id;
          if (!target) return json(404, {});
          const failure = injectedFailures.find(f => f.count > 0 && f.method === body.method && f.path.test(`/${body.table_name}/${id}`));
          if (failure && !failure.skip) { failure.count--; return json(failure.status, failure.body || { error: 'Simulated fenced DML failure' }); }
          if (failure?.skip) failure.skip--;
          if (body.method === 'DELETE') { const rid = `${body.job_id}:${body.table_name}:${id}`; const affected = deletionReceipts.get(rid)?.affected ?? Number(target.delete(id)); deletionReceipts.set(rid, {job:body.job_id, table:body.table_name, affected}); if (lostDeletionAcks.delete(id)) return json(503, {error:'Commit succeeded but response was lost'}); return json(200, { affected }); }
          if (body.method === 'PATCH' && body.table_name === 'groups') { target.set(id, { ...target.get(id), ...body.data }); deletionReceipts.set(`${body.job_id}:groups:${id}`, {job:body.job_id, table:'groups', affected:1}); return json(200, { affected: 1 }); }
          return json(405, {});
        }
        if (url.pathname === '/vyper-internal/admin/stats') return json(200, { totalUsers: allRows('profiles').length, onlineUsers: allRows('profiles').filter(r => r.IS_ONLINE === 1).length,
          totalMessages: allRows('messages').length, totalCalls: allRows('calls').length, vaultItemsCount: allRows('vault').length, pendingDeliveries: allRows('delivery_outbox').filter(r => ['queued','sending'].includes(r.STATUS)).length, failedDeliveries: 0 });
        return json(404, {});
      }
      const parts = url.pathname.split('/').filter(Boolean);
      const alias = (parts[0] || '').toLowerCase();
      const metadata = alias.endsWith('_meta');
      const table = metadata ? alias.slice(0, -5) : alias;
      const rowId = parts[1] ? decodeURIComponent(parts[1]) : null;

      if (!TABLES.has(table)) {
        return json(404, { code: 'NotFound' });
      }
      const store = data.get(table)!;
      if (metadata && req.method !== 'GET') return json(405, {});
      if ((!gateway || gate.owner) && !['GET','HEAD'].includes(req.method || '') && !['deletion_jobs','audit_logs'].includes(table)) return json(503, { error: 'ORA-20902: Maintenance in progress' });

      try {
        if (req.method === 'GET' && !rowId) {
          const qRaw = url.searchParams.get('q');
          let qFilter: any = null;
          if (qRaw) qFilter = JSON.parse(qRaw);
          let rows = Array.from(store.values());
          if (qFilter) rows = rows.filter((r) => matchesBranch(r, qFilter));
          let order: Record<string, string> = { ID: 'asc' };
          try { order = JSON.parse(url.searchParams.get('q') || '{}').$orderby || order; } catch { /* invalid handled above */ }
          rows.sort((a, b) => {
            for (const [col, dir] of Object.entries(order)) {
              const av = a[col] ?? a[col.toLowerCase()] ?? '';
              const bv = b[col] ?? b[col.toLowerCase()] ?? '';
              if (av !== bv) return (av < bv ? -1 : 1) * (dir === 'desc' ? -1 : 1);
            }
            return 0;
          });
          const limit = Math.min(pageCap, Number(url.searchParams.get('limit') || 1000));
          const offset = Number(url.searchParams.get('offset') || 0);
          const items = rows.slice(offset, offset + limit).map(row => {
            if (!metadata) return row;
            const r = { ...row };
            for (const [column, flag] of [['FILE_DATA','HAS_MEDIA'],['AVATAR_URL','HAS_AVATAR'],['COVER_URL','HAS_COVER'],['ICON','HAS_ICON']]) { r[flag] = r[column] ? 1 : 0; if (column !== 'ICON' || String(r[column] || '').length > 32) delete r[column]; }
            delete r.SIGNAL_DATA; delete r.PASSWORD_HASH; delete r.PASSWORD_SALT;
            return r;
          });
          return json(200, { items, count: items.length, hasMore: offset + limit < rows.length, limit, offset });
        }

        if (req.method === 'GET' && rowId) {
          const row = store.get(rowId);
          if (!row) return json(404, { code: 'NotFound' });
          return json(200, row);
        }

        if (req.method === 'POST' && !rowId) {
          if (!body || typeof body !== 'object') return json(400, { code: 'BadRequest', message: 'missing body' });
          const id = String(body.ID ?? body.id);
          if (!id) return json(400, { code: 'BadRequest', message: 'missing ID' });
          if (store.has(id)) {
            return json(400, { code: 'BadRequest', message: 'ORA-00001: unique constraint (ADMIN.SYS_C001_PK) violated' });
          }
          const pause = pauses.get(table);
          if (pause) { pauses.delete(table); activeDml.add(pause.done); pause.entered(); await pause.resume; }
          const violation = uniqueConstraintViolation(table, body);
          if (violation) {
            return json(400, { code: 'BadRequest', message: violation });
          }
          if (table === 'messages' || table === 'calls' && body.STATUS === 'ringing') {
            const kind = table === 'messages' ? 'message' : 'call';
            const eid = `${kind === 'message' ? 'msg' : 'call'}_${crypto.createHash('sha256').update(id).digest('hex')}`;
            if (data.get('delivery_outbox')!.has(eid)) return json(400, { error: 'ORA-00001: duplicate delivery intent' });
            const now = new Date().toISOString();
            data.get('delivery_outbox')!.set(eid, { ID: eid, KIND: kind, ENTITY_ID: id, SENDER_ID: body.SENDER_ID || body.CALLER_ID, STATUS: 'queued', ATTEMPTS: 0, RESULTS: '{}', NEXT_ATTEMPT_AT: now, UPDATED_AT: now, CREATED_AT: now });
          }
          store.set(id, body);
          if (pause) { pause.finished(); activeDml.delete(pause.done); }
          return json(201, body);
        }

        if (req.method === 'PUT' && rowId) {
          const existing = store.get(rowId);
          if (!existing) return json(404, { code: 'NotFound' });
          const violation = uniqueConstraintViolation(table, body || {});
          if (violation) {
            return json(400, { code: 'BadRequest', message: violation });
          }
          store.set(rowId, body);
          return json(200, body);
        }

        if (req.method === 'PATCH' && rowId) {
          const existing = store.get(rowId);
          if (!existing) return json(404, { code: 'NotFound' });
          const merged = { ...existing, ...(body || {}) };
          const violation = uniqueConstraintViolation(table, merged);
          if (violation) {
            return json(400, { code: 'BadRequest', message: violation });
          }
          store.set(rowId, merged);
          return json(200, merged);
        }

        if (req.method === 'DELETE' && rowId) {
          if (!store.has(rowId)) return json(404, { code: 'NotFound' });
          store.delete(rowId);
          return json(200, {});
        }

        return json(405, { code: 'MethodNotAllowed' });
      } catch (err: any) {
        return json(500, { code: 'InternalServerError', message: err?.message });
      }
    });
  });

  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const addr = server.address() as { port: number };
      (server as any).closeAllMocks = undefined;
      resolve(`http://127.0.0.1:${addr.port}`);
    });
    // keep a handle so vitest doesn't hang
    (globalThis as any).__mockOrdsServer = server;
  });
}

export function stopMockOrds(): void {
  const server = (globalThis as any).__mockOrdsServer;
  if (server) server.close();
}
