-- Add authoritative uniqueness for bound phone numbers. NULL remains allowed.
-- Run after resolving any existing duplicate non-NULL phone numbers.
DECLARE
  v_constraint_count NUMBER;
  v_duplicate_count NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_duplicate_count
    FROM (SELECT PHONE_NUMBER FROM PROFILES WHERE PHONE_NUMBER IS NOT NULL GROUP BY PHONE_NUMBER HAVING COUNT(*) > 1);
  IF v_duplicate_count > 0 THEN
    RAISE_APPLICATION_ERROR(-20071, 'Duplicate non-NULL PHONE_NUMBER values exist; resolve them before adding UQ_PROFILES_PHONE');
  END IF;
  SELECT COUNT(*) INTO v_constraint_count FROM USER_CONSTRAINTS
    WHERE TABLE_NAME = 'PROFILES' AND CONSTRAINT_NAME = 'UQ_PROFILES_PHONE';
  IF v_constraint_count = 0 THEN
    EXECUTE IMMEDIATE 'ALTER TABLE PROFILES ADD CONSTRAINT UQ_PROFILES_PHONE UNIQUE (PHONE_NUMBER)';
  END IF;
END;
/
