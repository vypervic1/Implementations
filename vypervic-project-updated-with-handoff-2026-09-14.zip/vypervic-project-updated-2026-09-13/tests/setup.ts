// Vitest global setup: start the mock ORDS server BEFORE the app modules
// are imported (they read ORDS_BASE_URL / ORDS_API_KEY at module load).
// This runs at MODULE EVALUATION time (top-level await), because test-file
// modules are evaluated before beforeAll hooks fire.
import { afterAll } from 'vitest';
import { startMockOrds, stopMockOrds } from './mockOrds';

const apiKey = 'test-ords-secret';
const base = await startMockOrds({ apiKey });
process.env.ORDS_BASE_URL = base;
process.env.ORDS_API_KEY = apiKey;
process.env.JWT_SECRET = 'test-jwt-secret-test-jwt-secret-0123456789';
process.env.NODE_ENV = 'test';
process.env.ALLOW_TEST_PUSH_TOKENS = 'true'; // explicit unit-test transport bypass, forbidden in production
process.env.TRUST_PROXY = 'loopback';
process.env.APP_URL = 'https://app.example.com';
(globalThis as any).__MOCK_ORDS_BASE = base;

afterAll(() => {
  stopMockOrds();
});
