import 'dotenv/config';
import { runDeletionJob, jobResponse } from '../src/server/destructiveJobs';
import { collectProductionConfigProblems, formatConfigProblems } from '../src/server/config';
async function main() {
  const id = process.argv[2];
  if (!/^(wipe_[a-f0-9-]{36}|delete_[a-f0-9]{40})$/.test(id || '')) throw new Error('Pass one existing operation ID');
  const problems = collectProductionConfigProblems(); if (problems.length) throw new Error(formatConfigProblems(problems));
  const result = await runDeletionJob(id); console.log(JSON.stringify(jobResponse(result))); process.exit(result.status === 'completed' ? 0 : 1);
}
void main().catch(() => { console.error('Operation recovery failed; inspect service logs and the durable operation'); process.exit(1); });
