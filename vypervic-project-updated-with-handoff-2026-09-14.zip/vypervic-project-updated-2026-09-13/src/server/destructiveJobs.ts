import { assertMutationContext } from './mutationContext';
import { withDataMutation, beginMaintenance, finishMaintenance } from './mutationGate';
import { createHash, randomUUID } from 'node:crypto';
import { fetchRowById, fetchRowsByFilter, fetchAllRows, deleteRowsByFilter, wipeTable, ordsFetch, groupMembers, isUniqueViolation } from './oracleBackend';
import { withLease, BusyError } from './sharedStore';
import { revokeUserSessions, revokeEverySession } from './sessionState';
import { ApiError, OracleError } from './errors';

export type JobStatus = 'queued' | 'running' | 'completed' | 'partial' | 'failed';
interface StepResult { deleted: number; failed: number; verifiedAbsent?: number }
export interface DeletionJob {
  id: string; kind: 'account' | 'wipe' | 'messages' | 'calls'; actor_id: string; target_id: string | null; status: JobStatus;
  steps: Record<string, StepResult>; attempts: number; last_error: string | null; created_at: string; updated_at: string;
}
export const accountJobId = (userId: string) => `delete_${createHash('sha256').update(userId).digest('hex').slice(0, 40)}`;
function decodeJob(row: any): DeletionJob {
  return { ...row, steps: typeof row.steps === 'string' ? JSON.parse(row.steps) : row.steps || {}, attempts: Number(row.attempts || 0) };
}
async function save(job: DeletionJob) {
  job.updated_at = new Date().toISOString();
  const res = await ordsFetch(`/deletion_jobs/${job.id}`, { method: 'PATCH', body: {
    STATUS: job.status, STEPS: JSON.stringify(job.steps), ATTEMPTS: job.attempts, LAST_ERROR: job.last_error, UPDATED_AT: job.updated_at,
  } });
  if (!res.ok) throw new OracleError(res.status);
}
export async function getDeletionJob(id: string): Promise<DeletionJob | null> {
  const row = await fetchRowById('deletion_jobs', id);
  return row ? decodeJob(row) : null;
}
export async function assertAccountsWritable(userIds: string[]): Promise<void> {
  const wipe = await fetchRowsByFilter('deletion_jobs', { KIND: 'wipe', STATUS: { $in: ['queued', 'running', 'partial', 'failed'] } }, 1);
  if (wipe.length) throw new ApiError(503, 'Maintenance workflow is incomplete; writes are disabled');
  for (const userId of userIds) if (await getDeletionJob(accountJobId(userId))) throw new ApiError(409, 'Account deletion is in progress');
}
async function audit(job: DeletionJob, action: 'started' | 'completed') {
  const result = await ordsFetch('/audit_logs/', { method: 'POST', body: {
    ID: `${job.id}_${action}`, ADMIN_ID: job.actor_id, ACTION: `${job.kind}_deletion_${action}`, TARGET_ID: job.target_id,
    DETAILS: JSON.stringify({ operationId: job.id, status: job.status, steps: job.steps }), CREATED_AT: new Date().toISOString(),
  } });
  if (!result.ok && !isUniqueViolation(result)) throw new OracleError(result.status);
}
export async function beginDeletionJob(kind: DeletionJob['kind'], actorId: string, targetId?: string, operationId?: string): Promise<DeletionJob> {
  const id = kind === 'account' ? accountJobId(targetId!) : operationId || `wipe_${randomUUID()}`;
  let existing = await getDeletionJob(id);
  if (existing) {
    if (existing.kind !== kind || existing.actor_id !== actorId && kind === 'wipe' || existing.target_id !== (targetId || null)) throw new ApiError(403, 'Operation is not owned by this request');
    return existing;
  }
  const now = new Date().toISOString();
  const job: DeletionJob = { id, kind, actor_id: actorId, target_id: targetId || null, status: 'queued', steps: {}, attempts: 0, last_error: null, created_at: now, updated_at: now };
  const result = await ordsFetch('/deletion_jobs/', { method: 'POST', body: {
    ID: id, KIND: kind, ACTOR_ID: actorId, TARGET_ID: targetId || null, STATUS: job.status, STEPS: '{}', ATTEMPTS: 0, LAST_ERROR: null, CREATED_AT: now, UPDATED_AT: now,
  } });
  if (isUniqueViolation(result)) { existing = await getDeletionJob(id); if (existing) return existing; }
  if (!result.ok) throw new OracleError(result.status);
  return job;
}
async function cleanEdge(_userId?: string): Promise<StepResult> { return { deleted: 0, failed: 0 }; }

async function removeGroupMembership(userId: string): Promise<StepResult> {
  let deleted = 0;
  for (const group of await fetchAllRows('groups')) {
    const members = groupMembers(group);
    if (!members.includes(userId)) continue;
    const remaining = members.filter(id => id !== userId);
    const result = await ordsFetch(`/groups/${encodeURIComponent(group.id)}`, remaining.length ? {
      method: 'PATCH', body: { MEMBERS: JSON.stringify(remaining), ADMINS: JSON.stringify((Array.isArray(group.admins) ? group.admins : []).filter((id: string) => id !== userId)), CREATOR_ID: group.creator_id === userId ? remaining[0] : group.creator_id },
    } : { method: 'DELETE' });
    if (!result.ok && result.status !== 404) throw new OracleError(result.status);
    deleted++;
  }
  return { deleted, failed: 0 };
}
export async function runDeletionJob(id: string): Promise<DeletionJob> {
  return withDataMutation(() => withLease('destructive-workflows', async assertHeld => {
    const job = await getDeletionJob(id);
    if (!job) throw new ApiError(404, 'Unknown deletion operation');
    if (job.status === 'completed') {
      const gate = await ordsFetch('/vyper-internal/gate/');
      if (gate.json?.owner === job.id) { await beginMaintenance(job.id); await finishMaintenance(job.id); }
      return job;
    }
    await beginMaintenance(job.id);
    job.status = 'running'; job.attempts++; await save(job);
    const target = job.target_id!;
    const steps: Array<[string, () => Promise<StepResult>]> = job.kind === 'wipe' ? [
      ...['delivery_outbox', 'messages', 'calls', 'scheduled_messages', 'groups', 'vault', 'user_push_tokens', 'password_resets'].map(table => [table, () => wipeTable(table)] as [string, () => Promise<StepResult>]),
      ['edge', () => cleanEdge()],
      ['sessions', async () => { await revokeEverySession(); return { deleted: 0, failed: 0 }; }],
      ['credentials', () => wipeTable('user_credentials')], ['profiles', () => wipeTable('profiles')],
    ] : job.kind === 'messages' || job.kind === 'calls' ? [
      [job.kind, () => wipeTable(job.kind)],
      ['delivery_outbox', () => deleteRowsByFilter('delivery_outbox', { KIND: job.kind === 'messages' ? 'message' : 'call' })],
      ['edge', () => cleanEdge()],
    ] : [
      ['delivery_outbox', () => deleteRowsByFilter('delivery_outbox', { SENDER_ID: target })],
      ['scheduled_messages', () => deleteRowsByFilter('scheduled_messages', { USER_ID: target })],
      ['calls', async () => {
        const a = await deleteRowsByFilter('calls', { CALLER_ID: target });
        const b = await deleteRowsByFilter('calls', { RECEIVER_ID: target });
        return { deleted: a.deleted + b.deleted, failed: a.failed + b.failed };
      }],
      ['messages', () => deleteRowsByFilter('messages', { SENDER_ID: target })],
      ['groups', () => removeGroupMembership(target)],
      ...['user_push_tokens', 'password_resets', 'vault'].map(table => [table, () => deleteRowsByFilter(table, { USER_ID: target })] as [string, () => Promise<StepResult>]),
      ['edge', () => cleanEdge(target)],
      ['sessions', async () => { await revokeUserSessions(target); return { deleted: 0, failed: 0 }; }],
      ['credentials', () => deleteRowsByFilter('user_credentials', { USER_ID: target })],
      // Profile LAST: failures in earlier resources leave a recoverable, blocked identity, not a fabricated success.
      ['profile', async () => { const r = await ordsFetch(`/profiles/${encodeURIComponent(target)}`, { method: 'DELETE' }); return { deleted: r.ok ? 1 : 0, failed: r.ok || r.status === 404 ? 0 : 1 }; }],
    ];
    try {
      await audit(job, 'started');
      for (const [name, perform] of steps) {
        assertHeld();
        if (job.steps[name]?.failed === 0) continue;
        const result = await perform();
        job.steps[name] = { ...result, deleted: (job.steps[name]?.deleted || 0) + result.deleted };
        const receipt = await ordsFetch(`/vyper-internal/maintenance/counts/${job.id}`);
        if (!receipt.ok) throw new Error('Deletion receipts unavailable');
        const table = name === 'profile' ? 'profiles' : name === 'credentials' ? 'user_credentials' : name;
        if (Number.isSafeInteger(receipt.json?.[table])) job.steps[name].deleted = receipt.json[table];
        await save(job); // checkpoint after each idempotent step, before reporting anything complete
        if (result.failed) throw new Error(`Step ${name} failed`);
      }
      assertHeld();
      const receipts = await ordsFetch(`/vyper-internal/maintenance/counts/${job.id}`);
      if (!receipts.ok) throw new Error('Deletion receipts unavailable');
      for (const [step, result] of Object.entries(job.steps)) { const table = step === 'profile' ? 'profiles' : step === 'credentials' ? 'user_credentials' : step; if (Number.isSafeInteger(receipts.json?.[table])) result.deleted = receipts.json[table]; }
      await audit(job, 'completed');
      await finishMaintenance(job.id);
      job.status = 'completed'; job.last_error = null; await save(job);
    } catch {
      job.status = Object.values(job.steps).some(step => step.deleted > 0) ? 'partial' : 'failed';
      job.last_error = 'Operation incomplete; retry from durable checkpoints';
      await save(job); // if the checkpoint store is down the endpoint fails; it never fabricates completion
      console.error('[Deletion] Recovery required', { operationId: job.id, status: job.status });
    }
    return job;
  }), id);
}
export function jobResponse(job: DeletionJob) {
  return { operationId: job.id, status: job.status, success: job.status === 'completed', results: job.steps,
    failedCount: Object.values(job.steps).reduce((n, s) => n + s.failed, 0) || (job.status === 'completed' ? 0 : 1) };
}
let recoveryTimer: ReturnType<typeof setInterval> | undefined;
export function startDeletionRecovery(): void {
  if (recoveryTimer) return;
  const pass = async () => {
    try {
      const rows = await fetchRowsByFilter('deletion_jobs', { STATUS: { $in: ['queued', 'running', 'partial', 'failed'] } }, 100);
      const fence = await ordsFetch('/vyper-internal/gate/');
      if (fence.json?.owner && !rows.some(row => row.id === fence.json.owner)) { const owner = await getDeletionJob(fence.json.owner); if (owner) rows.unshift(owner); }
      for (const row of rows) {
        if (Number(row.attempts) >= 5 && row.status !== 'completed') continue;
        try { await runDeletionJob(row.id); } catch (error) { if (!(error instanceof BusyError)) console.error('[Deletion] Recovery worker unavailable'); }
      }
    } catch { console.error('[Deletion] Recovery scan failed'); }
  };
  recoveryTimer = setInterval(() => void pass(), 5000); recoveryTimer.unref();
  void pass();
}

const activeJobs = new Map<string, Promise<DeletionJob>>();
export function kickDeletionJob(id: string): void {
  if (activeJobs.has(id)) return;
  const task = runDeletionJob(id);
  activeJobs.set(id, task);
  void task.catch(() => console.warn('[Deletion] Pending recovery', { operationId: id }))
    .finally(() => activeJobs.delete(id));
}
export async function waitForLocalOperation(id: string): Promise<void> { await activeJobs.get(id)?.catch(() => undefined); }
export function stopDeletionRecovery() { if (recoveryTimer) clearInterval(recoveryTimer); recoveryTimer = undefined; }
