# Firestore retention deployment

The application writes expiry timestamps to ephemeral records and the production project must enable Firestore TTL policies on the canonical `(default)` database.

Configure TTL for these fields using the Firebase/Google Cloud deployment account:

| Collection group | TTL field | Purpose |
|---|---|---|
| `ephemeral_presence` | `expires_at` | Presence and typing expiry |
| `ephemeral_signaling` | `expires_at` | Offer/answer cleanup |
| `ephemeral_calls` | `expires_at` | Expired call lifecycle cleanup |
| `ephemeral_messages` | `expires_at` | Bounded ephemeral message retention |

TTL is a cleanup mechanism, not an authorization control. Firestore rules remain deny-by-default and every client write must go through the authenticated server boundary. After applying policies, run the staging acceptance checks for expiry, authorization, and cross-store cleanup.

This file intentionally contains no project credentials or provider-specific service account material.
