import { useEffect } from 'react';
import type { Message } from '../types';
import { sessionEpoch } from '../sessionEpoch';
import { getSessionStatus } from '../sessionStatus';
import { cacheMessagesLocally } from '../utils/indexedDB';
/** Metadata pages/SSE stay small. Fetch bounded single rows only when an attachment is visible. */
export function MessageMediaLoader({ messages, onLoaded }: { messages: Message[]; onLoaded: (message: Message) => void }) {
  useEffect(() => {
    if (getSessionStatus().status !== 'authenticated') return;
    const version = sessionEpoch.version, controller = new AbortController();
    const queued = new Set<string>(); const pending: string[] = []; let active = 0, disposed = false;
    const next = async () => {
      if (disposed || active >= 2 || !pending.length) return;
      const id = pending.shift()!; active++;
      try {
        const response = await fetch(`/api/messages/${encodeURIComponent(id)}`, { credentials: 'same-origin', signal: controller.signal });
        if (!response.ok) return;
        const row = await response.json();
        if (disposed || version !== sessionEpoch.version || row.id !== id || typeof row.file_data !== 'string' || row.file_data.length > 4000000) return;
        await cacheMessagesLocally([row]); if (!disposed && version === sessionEpoch.version) onLoaded(row);
      } catch { /* display keeps attachment metadata; a later mount/network retry can fetch it */ }
      finally { active--; void next(); }
    };
    const enqueue = (id: string) => { if (queued.has(id)) return; queued.add(id); pending.push(id); void next(); };
    const candidates = messages.filter(row => row.has_media && !row.file_data && !row.is_pending);
    const observer = typeof IntersectionObserver === 'undefined' ? null : new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) { enqueue(entry.target.id.slice(4)); observer?.unobserve(entry.target); }
    }, { rootMargin: '200px' });
    if (observer) for (const row of candidates) { const element = document.getElementById(`msg-${row.id}`); if (element) observer.observe(element); }
    else candidates.slice(-10).forEach(row => enqueue(row.id));
    return () => { disposed = true; controller.abort(); observer?.disconnect(); pending.length = 0; };
  }, [messages, onLoaded]);
  return null;
}
