import { withDataMutation } from './mutationGate';
// =========================================================================
// SERVER-BACKED SCHEDULED MESSAGES (M-06)
// ------------------------------------------------------------------------
// Scheduled messages used to live ONLY in each browser's localStorage: they
// never synced across devices, two tabs could process the same due message
// (double-send), and a crashed browser lost the schedule outright.
//
// They now live in the server-only SCHEDULED_MESSAGES Oracle table and a
// server worker delivers them:
//   * atomic claim: status scheduled -> sending (lease), single delivery
//   * idempotent message id (`schedm_<scheduleId>`): a retried delivery
//     cannot create a duplicate row — the PK rejects it and the schedule is
//     marked sent
//   * retry with attempt cap; failed deliveries are marked, not lost
// Local storage remains only as an offline display cache on the client.
// =========================================================================

import { withLease, BusyError } from './sharedStore';
import { assertAccountsWritable } from './destructiveJobs';
import { persistMessage } from './oracleRoutes';
import { randomUUID } from 'node:crypto';
import { ordsFetch, fetchRowsByFilter, fetchRowById, fetchAllRows } from './oracleBackend';
import { publishScopedEvent } from './realtimeBus';
import { publishAdminEphemeralMessage } from './edgePublish';
import { isChatParticipant } from './authz';

export interface ScheduledMessageRow {
  id: string;
  user_id: string;
  chat_id: string;
  recipient_id: string | null;
  text: string | null;
  file_name: string | null;
  file_type: string | null;
  file_data: string | null;
  is_voice: boolean;
  scheduled_for: string;
  status: 'scheduled' | 'sending' | 'sent' | 'failed' | 'cancelled' | string;
  attempts: number;
  message_id: string | null;
  last_error: string | null;
  created_at: string;
  updated_at: string;
}

const MAX_PENDING_PER_USER = 50;
const MAX_TEXT_LEN = 8000;
const MAX_FILE_DATA_LEN = 4_000_000; // ~8MB base64
const DELIVERY_INTERVAL_MS = 15_000;
const MAX_ATTEMPTS = 5;
const CLAIM_LEASE_MS = 2 * 60_000;

function normalizeRow(row: any): ScheduledMessageRow {
  const out: any = {};
  for (const [k, v] of Object.entries(row || {})) out[k.toLowerCase()] = v;
  return {
    id: String(out.id),
    user_id: String(out.user_id),
    chat_id: String(out.chat_id),
    recipient_id: out.recipient_id ?? null,
    text: out.text ?? null,
    file_name: out.file_name ?? null,
    file_type: out.file_type ?? null,
    file_data: out.file_data ?? null,
    is_voice: out.is_voice === 1 || out.is_voice === true || out.is_voice === '1',
    scheduled_for: String(out.scheduled_for),
    status: String(out.status || 'scheduled'),
    attempts: Number(out.attempts || 0),
    message_id: out.message_id ?? null,
    last_error: out.last_error ?? null,
    created_at: String(out.created_at || ''),
    updated_at: String(out.updated_at || ''),
  };
}

// ---------------------------------------------------------------------------
// Client-facing CRUD (exposed through /api/scheduler/* in server.ts)
// ---------------------------------------------------------------------------

async function createScheduledMessageUnlocked(input: {
  userId: string;
  chatId: string;
  recipientId: string | null;
  text: string | null;
  fileName: string | null;
  fileType: string | null;
  fileData: string | null;
  isVoice: boolean;
  scheduledFor: Date;
}): Promise<{ ok: true; row: ScheduledMessageRow } | { ok: false; error: string; status: number }> {
  const { userId, chatId, scheduledFor } = input;
  await assertAccountsWritable([userId]);
  if (!(await isChatParticipant(chatId, userId))) return { ok: false, status: 403, error: 'Not a chat member' };
  const expectedRecipient = chatId.startsWith('dm:') ? chatId.split(':').slice(1).find(id => id !== userId) || null : null;
  if (input.recipientId && input.recipientId !== expectedRecipient) return { ok: false, status: 400, error: 'Recipient does not match the chat' };
  input.recipientId = expectedRecipient;
  if (expectedRecipient) await assertAccountsWritable([expectedRecipient]);
  if (input.fileData === '[stored_in_indexeddb]') return { ok: false, status: 400, error: 'Attachment bytes are required' };
  if (!input.text && !input.fileData) return { ok: false, status: 400, error: 'Message content required' };

  if (!chatId || typeof chatId !== 'string') return { ok: false, status: 400, error: 'chat_id is required' };
  if (Number.isNaN(scheduledFor.getTime())) return { ok: false, status: 400, error: 'scheduled_for must be a valid ISO date' };
  if (scheduledFor.getTime() < Date.now() + 20_000) {
    return { ok: false, status: 400, error: 'scheduled_for must be at least 20 seconds in the future' };
  }
  if (scheduledFor.getTime() > Date.now() + 365 * 24 * 3600_000) {
    return { ok: false, status: 400, error: 'scheduled_for may not be more than one year ahead' };
  }
  const text = input.text ? String(input.text) : null;
  if (text && text.length > MAX_TEXT_LEN) return { ok: false, status: 400, error: `text too long (max ${MAX_TEXT_LEN})` };
  const fileData = input.fileData ? String(input.fileData) : null;
  if (fileData && fileData.length > MAX_FILE_DATA_LEN) {
    return { ok: false, status: 413, error: 'attachment too large for a scheduled message' };
  }

  // Pending cap (DoS / storage bound)
  const existing = await fetchRowsByFilter('scheduled_messages', { USER_ID: userId, STATUS: 'scheduled' }, MAX_PENDING_PER_USER + 1);
  if (existing.length >= MAX_PENDING_PER_USER) {
    return { ok: false, status: 429, error: `Too many pending scheduled messages (max ${MAX_PENDING_PER_USER}).` };
  }

  const id = `sched_${randomUUID()}`;
  const nowIso = new Date().toISOString();
  const payload = {
    ID: id,
    USER_ID: userId,
    CHAT_ID: chatId,
    RECIPIENT_ID: input.recipientId || null,
    TEXT: text,
    FILE_NAME: input.fileName || null,
    FILE_TYPE: input.fileType || null,
    FILE_DATA: fileData,
    IS_VOICE: input.isVoice ? 1 : 0,
    SCHEDULED_FOR: scheduledFor.toISOString(),
    STATUS: 'scheduled',
    NEXT_ATTEMPT_AT: nowIso,
    ATTEMPTS: 0,
    MESSAGE_ID: `schedm_${id}`,
    LAST_ERROR: null,
    CREATED_AT: nowIso,
    UPDATED_AT: nowIso,
  };

  const res = await ordsFetch(`/scheduled_messages/`, { method: 'POST', body: payload });
  if (!res.ok) {
    return { ok: false, status: 502, error: 'Could not store the scheduled message. Please try again.' };
  }

  return {
    ok: true,
    row: {
      id,
      user_id: userId,
      chat_id: chatId,
      recipient_id: input.recipientId || null,
      text,
      file_name: input.fileName || null,
      file_type: input.fileType || null,
      file_data: fileData,
      is_voice: input.isVoice,
      scheduled_for: scheduledFor.toISOString(),
      status: 'scheduled',
      attempts: 0,
      message_id: payload.MESSAGE_ID,
      last_error: null,
      created_at: nowIso,
      updated_at: nowIso,
    },
  };
}

export function createScheduledMessage(input: Parameters<typeof createScheduledMessageUnlocked>[0]): ReturnType<typeof createScheduledMessageUnlocked> {
  return withLease(`schedule-create:${input.userId}`, () => createScheduledMessageUnlocked(input));
}

export async function listScheduledMessages(userId: string, limit = 200): Promise<ScheduledMessageRow[]> {
  const rows = await fetchAllRows('scheduled_messages', { USER_ID: userId });
  return rows
    .map(normalizeRow)
    .filter((r) => r.id)
    .sort((a, b) => (a.scheduled_for < b.scheduled_for ? 1 : -1));
}

async function cancelScheduledMessageUnlocked(userId: string, id: string): Promise<{ ok: boolean; status: number; error?: string }> {
  const row = await fetchRowById('scheduled_messages', id);
  if (!row) return { ok: false, status: 404, error: 'Scheduled message not found' };
  const normalized = normalizeRow(row);
  if (normalized.user_id !== userId) return { ok: false, status: 403, error: 'Forbidden: not your scheduled message' };
  if (normalized.status !== 'scheduled') return { ok: false, status: 409, error: `Cannot cancel a message that is ${normalized.status}` };
  const res = await ordsFetch(`/scheduled_messages/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    timeoutMs: 8000,
  });
  return res.ok ? { ok: true, status: 200 } : { ok: false, status: 502, error: 'Could not cancel the scheduled message' };
}

export function cancelScheduledMessage(userId: string, id: string) {
  return withLease(`schedule:${id}`, () => cancelScheduledMessageUnlocked(userId, id));
}

/** Deliver a scheduled message immediately on the user's explicit request. */
export async function sendScheduledNow(userId: string, id: string): Promise<{ ok: boolean; status: number; error?: string }> {
  const row = await fetchRowById('scheduled_messages', id);
  if (!row) return { ok: false, status: 404, error: 'Scheduled message not found' };
  const normalized = normalizeRow(row);
  if (normalized.user_id !== userId) return { ok: false, status: 403, error: 'Forbidden: not your scheduled message' };
  if (normalized.status !== 'scheduled') return { ok: false, status: 409, error: `Message is already ${normalized.status}` };
  const delivered = await deliverOne(normalized, true);
  return delivered ? { ok: true, status: 200 } : { ok: false, status: 502, error: 'Delivery failed; it will be retried' };
}

// ---------------------------------------------------------------------------
// Delivery worker
// ---------------------------------------------------------------------------

export const schedulerHealth = { lastPassAt: 0, failures: 0 };
let workerStarted = false;
let delivering = false;

export function startScheduledMessageWorker(): void {
  if (workerStarted) return;
  workerStarted = true;
  const timer = setInterval(() => {
    void deliverDue();
  }, DELIVERY_INTERVAL_MS);
  if (typeof timer.unref === 'function') timer.unref();
  void deliverDue();
  console.log(`[Scheduler] Scheduled-message worker started (every ${DELIVERY_INTERVAL_MS / 1000}s, max ${MAX_ATTEMPTS} attempts)`);
}

/** One scheduler pass — exported for integration tests. */
export function runSchedulerPass(): Promise<void> {
  return deliverDue();
}

async function deliverDue(): Promise<void> {
  if (delivering) return;
  delivering = true;
  try {
    const nowIso = new Date().toISOString();
    // Due = status scheduled, due time elapsed, or stale 'sending' lease.
    const scheduled = await fetchRowsByFilter('scheduled_messages', { STATUS: 'scheduled' }, 50);
    const sending = await fetchRowsByFilter('scheduled_messages', { STATUS: 'sending' }, 50);
    const due = scheduled.filter(row => row.scheduled_for <= nowIso && (!row.next_attempt_at || row.next_attempt_at <= nowIso));
    const stale = sending.filter(row => row.updated_at && Date.now() - Date.parse(row.updated_at) > CLAIM_LEASE_MS);

    const candidates: ScheduledMessageRow[] = [];
    for (const raw of [...due, ...stale]) {
      const row = normalizeRow(raw);
      if (!row.id) continue;
      if (row.status === 'scheduled' && row.scheduled_for <= nowIso) candidates.push(row);
      if (
        row.status === 'sending' &&
        row.updated_at &&
        Date.now() - Date.parse(row.updated_at) > CLAIM_LEASE_MS
      ) {
        candidates.push(row); // reclaim a dead worker's lease
      }
    }

    for (const row of candidates.slice(0, 25)) {
      try {
        await deliverOne(row);
      } catch (err: any) {
        console.warn('[Scheduler] delivery error for', row.id, err?.message);
      }
    }
    schedulerHealth.lastPassAt = Date.now();
  } catch (err: any) {
    schedulerHealth.failures++;
    console.error('[Scheduler] Pass failed:', err?.message || err);
  } finally {
    delivering = false;
  }
}

/**
 * Claim + deliver a single scheduled message. Idempotent via MESSAGE_ID.
 * Returns true when the message is durably delivered.
 */
async function deliverOne(snapshot: ScheduledMessageRow, force = false): Promise<boolean> {
  try { return await withDataMutation(() => deliverOneUnlocked(snapshot, force)); } catch { return false; }
}
async function deliverOneUnlocked(snapshot: ScheduledMessageRow, force = false): Promise<boolean> {
  try {
    return await withLease(`schedule:${snapshot.id}`, async assertHeld => {
      const raw = await fetchRowById('scheduled_messages', snapshot.id);
      if (!raw) return false;
      const row = normalizeRow(raw);
      if (row.status === 'sent') return true;
      if (!['scheduled', 'sending'].includes(row.status) || row.status === 'sending' && Date.now() - Date.parse(row.updated_at) <= CLAIM_LEASE_MS) return false;
      if (!force && row.scheduled_for > new Date().toISOString()) return false;
      if (row.attempts >= MAX_ATTEMPTS) {
        const failed = await ordsFetch(`/scheduled_messages/${row.id}`, { method: 'PATCH', body: { STATUS: 'failed', LAST_ERROR: 'Retry limit reached' } });
        if (!failed.ok) throw new Error('Failed to persist retry limit');
        return false;
      }
      assertHeld();
      const claim = await ordsFetch(`/scheduled_messages/${row.id}`, { method: 'PATCH', body: { STATUS: 'sending', ATTEMPTS: row.attempts + 1, UPDATED_AT: new Date().toISOString() } });
      if (!claim.ok) throw new Error('Failed to persist claim');
      try {
        const messageId = row.message_id || `schedm_${row.id}`;
        // Unique ID + authoritative acknowledgment resolve crashes after commit and before mark-sent.
        await persistMessage({ id: messageId, sender_id: row.user_id, chat_id: row.chat_id, recipient_id: row.recipient_id,
          text: row.text, file_name: row.file_name, file_type: row.file_type, file_data: row.file_data, is_voice: row.is_voice }, row.user_id);
        assertHeld();
        const sent = await ordsFetch(`/scheduled_messages/${row.id}`, { method: 'PATCH', body: { STATUS: 'sent', LAST_ERROR: null, UPDATED_AT: new Date().toISOString() } });
        if (!sent.ok) throw new Error('Failed to persist delivery acknowledgment');
        return true;
      } catch {
        schedulerHealth.failures++;
        assertHeld();
        const result = await ordsFetch(`/scheduled_messages/${row.id}`, { method: 'PATCH', body: {
          STATUS: row.attempts + 1 >= MAX_ATTEMPTS ? 'failed' : 'scheduled', LAST_ERROR: 'Durable delivery or acknowledgment failed',
          NEXT_ATTEMPT_AT: new Date(Date.now() + Math.min(300000, 1000 * 2 ** (row.attempts + 1))).toISOString(), UPDATED_AT: new Date().toISOString(),
        } });
        if (!result.ok) throw new Error('Failed to persist retry; stale-claim recovery required');
        return false;
      }
    });
  } catch (error) {
    if (!(error instanceof BusyError)) console.error('[Scheduler] Delivery failed; recovery required');
    return false;
  }
}
