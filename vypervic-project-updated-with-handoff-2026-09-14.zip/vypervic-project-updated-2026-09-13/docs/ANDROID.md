# Native Android application

This is an Android application project, **not an installed PWA shortcut**. Its WebView loads the configured VPS HTTPS origin; the app uses native Firebase Messaging for notifications. It does not bundle local web assets and does not route browser requests to localhost.

## Build prerequisites

- JDK 17, Android SDK platform/build tools 35, Node 22/npm 10.
- The checked-in Gradle wrapper uses Gradle 8.11.1 with the upstream distribution SHA-256 pinned. AGP/Kotlin/Firebase BOM versions are pinned in the build files.
- Supply **all three** HTTPS origin variables: `DEVELOPMENT_APP_ORIGIN`, `STAGING_APP_ORIGIN`, `PRODUCTION_APP_ORIGIN` (Gradle configures every flavor).
- Put each environment's **public Android Firebase configuration** at `android/app/src/<flavor>/google-services.json`. These files are ignored by Git. Never put an Admin service-account JSON/private key in this directory or APK.
- Set `<FLAVOR>_FIREBASE_PROJECT_ID` to the same canonical project as that environment's web/Admin configuration. Register the correct package in Firebase:

| Flavor | Android package |
|---|---|
| development | `com.vyper.chat.development` |
| staging | `com.vyper.chat.staging` |
| production | `com.vyper.chat` |

```sh
node scripts/validate-android-config.mjs staging
cd android
./gradlew --no-daemon :app:testStagingDebugUnitTest :app:lintStagingDebug :app:assembleStagingDebug
```

Release builds additionally require `ANDROID_KEYSTORE_PATH`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. Set these through protected CI/secret storage, not command-line literals. The manual `android-release.yml` workflow builds a **signed candidate**, not a release accepted for distribution. Configure required reviewers for the GitHub staging/production environments.

CI's development contract configuration is explicitly synthetic, cannot produce a release build, and its APK is not uploaded. It does not prove Firebase connectivity. The local sandbox could not download the Android SDK/Gradle distribution, so **no Android compilation or signed APK is claimed in this remediation pass**.

## Security and transport model

- HTTPS-only approved origin; off-origin HTTPS links open through external intents. Unsafe schemes, mixed content, file/content navigation and universal file access are disabled. TLS errors are never bypassed.
- AndroidX origin-scoped `WebMessageListener`, restricted to the main frame. Protocol v1 only exposes `capabilities`, `getPushToken`, `flushCookies`, and `logout`. No generic native HTTP/file/eval bridge.
- The same HttpOnly cookie authenticates WebView requests and native token refresh. JavaScript never receives the application's session JWT. Cookies are flushed after verified sign-in and lifecycle changes; DOM storage/IndexedDB are enabled; third-party cookies and app backup are disabled.
- Android runtime camera/microphone permissions are checked before granting the corresponding WebChromeClient resources. Notification permission is requested on Android 13+. Denial is reported, not simulated as a successful call/token.
- Native FCM channels are exactly **`vyper_messages`** and **`vyper_calls`**. The notification icon is a monochrome vector. Data-only pushes avoid duplicate automatic/native notification rendering. The service handles process-start delivery; WorkManager retries token refresh with the verified session and bounded backoff.
- Deep links carry only chat/call IDs at the approved origin. The server rechecks access. Existing WebViews receive navigation events rather than reloading and destroying an unrelated active call.
- Web Push/service-worker registration is disabled by native capabilities/UA; legacy Firebase workers are unregistered. Native registration never manufactures a token.

## Deliberate limitations and mandatory device checks

- Minimum Android API 23. Native calling currently requires the app to remain foreground; leaving it stops media and ends the call. There is **no foreground service/Telecom implementation for ongoing background calls**. Do not market it as such.
- General/group calls are disabled. Delegated group administration is now a persisted server-enforced feature. Direct calling requires a verified existing relationship and configured private TURN.
- Android force-stop, OEM battery restrictions, DND, notification-channel user settings and Google Play services availability affect FCM. Process-death delivery is not equivalent to force-stop delivery; there is no promise to bypass OS restrictions.
- App Links need a deployed `/.well-known/assetlinks.json` containing the real signing certificate fingerprint/package. The HTTPS manifest filter alone is not verification.
- Test notification tap/navigation, permission denial/retry, cookies/IndexedDB after swipe-away/process kill/reboot, logout/revocation, portrait/landscape/keyboard insets, camera/audio release, separate networks, private TURN UDP/TCP/TLS, and device storage limits using `STAGING-ACCEPTANCE.md`.

Gradle now checks the per-flavor Firebase JSON/project/package automatically. FCM retries use stable event IDs with a bounded on-device receipt history. These changes still require native compilation and physical-device validation.
